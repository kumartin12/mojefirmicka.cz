"""Export vydaných a přijatých faktur do Money S3 (XML datová komunikace, kořen MoneyData, schéma _Document.xsd
z instalace Money S3: Data/XMLDE/Schemas). V Money S3: Money → Import / Export → XML přenosy (Import z XML).

Money staví doklad ze souhrnu DPH (SouhrnDPH), ne z položek – souhrn proto nese přesně základ a DPH z Firmičky
(stejná rekapitulace jako na faktuře, v ISDOC i v Pohodě). Položky jsou pro přehled a tisk; recyklační poplatek
je samostatná položka ve stejné sazbě. Zálohové faktury (nejsou daňový doklad) se neexportují – do účetnictví
jde daňový doklad k přijaté platbě (Druh D) a konečná faktura s odpočtem zálohy. Dobropis má příznak Dobropis
a záporné částky. Číslo dokladu nad 10 znaků (limit Money) se nepošle – Money ho přidělí z řady a naše číslo
je v EvCisDokl (vydané) / PrijatDokl (přijaté)."""
import time
import xml.etree.ElementTree as ET

from . import __version__
from .regimes import note as regime_note
from .db import qty_text, line_parts, invoice_totals, advance_vat, is_advance

PAYMENTS = {"prevod": "převodem", "hotove": "hotově", "karta": "kartou", "dobirka": "dobírkou"}
DRUH = {"faktura": "N", "dobropis": "N", "ddkpp": "D"}
REDUCED, BASIC = 12, 21


def _e(parent, tag, text=None):
    e = ET.SubElement(parent, tag)
    if text is not None:
        e.text = str(text)
    return e


def _amt(hal):
    return "%.2f" % (hal / 100)


def _unit(amount, q):
    v = "%.4f" % (amount / q / 100)
    return v.rstrip("0").rstrip(".") if "." in v else v


def _address(parent, tag, address):
    lines = [x.strip() for x in (address or "").split("\n") if x.strip()]
    street = lines[0] if lines else ""
    zip_, city = "", ""
    if len(lines) > 1:
        parts = lines[1].split(" ")
        if len(parts) > 1 and parts[0].isdigit() and len(parts[0]) == 3 and parts[1].isdigit():
            zip_, city = parts[0] + " " + parts[1], " ".join(parts[2:])
        elif parts[0].isdigit():
            zip_, city = parts[0], " ".join(parts[1:])
        else:
            city = lines[1]
    a = _e(parent, tag)
    if street:
        _e(a, "Ulice", street[:50])
    if city:
        _e(a, "Misto", city[:40])
    if zip_:
        _e(a, "PSC", zip_[:10])
    country = lines[2] if len(lines) > 2 else ""
    _e(a, "Stat", country[:20] or "Česká republika")
    return a


def _partner(parent, name, address, ico, dic):
    p = _e(parent, "DodOdb")
    _e(p, "ObchNazev", name[:200])
    _address(p, "ObchAdresa", address)
    if ico:
        _e(p, "ICO", ico[:10])
    if dic:
        _e(p, "DIC", dic[:20])
    _e(p, "PlatceDPH", "1" if dic else "0")
    _e(p, "FyzOsoba", "0")


def _summary(parent, lines, vat_payer):
    """SouhrnDPH: 0 % → Zaklad0, snížená 12 % → Zaklad5/DPH5, základní 21 % → Zaklad22/DPH22, jiné sazby
    (doklady se starými sazbami 10 / 15 %) → SeznamDalsiSazby. Neplátce: vše jako Zaklad0."""
    t = invoice_totals(lines, vat_payer)
    s = _e(parent, "SouhrnDPH")
    other = []
    vals = {"Zaklad0": 0, "Zaklad5": 0, "Zaklad22": 0, "DPH5": 0, "DPH22": 0}
    for r in t["recap"]:
        rate = r["rate"] if vat_payer else 0
        if rate == 0:
            vals["Zaklad0"] += r["base"]
        elif rate == REDUCED:
            vals["Zaklad5"] += r["base"]
            vals["DPH5"] += r["vat"]
        elif rate == BASIC:
            vals["Zaklad22"] += r["base"]
            vals["DPH22"] += r["vat"]
        else:
            other.append(r)
    for k, v in vals.items():
        _e(s, k, _amt(v))
    if other:
        lst = _e(s, "SeznamDalsiSazby")
        for r in other:
            d = _e(lst, "DalsiSazba")
            _e(d, "Popis", "%d %%" % r["rate"])
            _e(d, "HladinaDPH", "1" if r["rate"] < BASIC else "2")
            _e(d, "Sazba", str(r["rate"]))
            _e(d, "Zaklad", _amt(r["base"]))
            _e(d, "DPH", _amt(r["vat"]))
    return t


def _items(parent, lines, vat_payer, tax_date):
    lst = _e(parent, "SeznamPolozek")
    t = invoice_totals(lines, vat_payer)
    gross = t["shora"]
    for n, x in enumerate(line_parts(lines, vat_payer), 1):
        ln = x["ln"]
        text = ("recyklační poplatek – " if x["fee"] else "") + (ln["text"] or "Položka")
        p = _e(lst, "Polozka")
        _e(p, "Popis", text[:50])
        if len(text) > 50:
            _e(p, "Poznamka", text)
        q = ln["qty"] or 0
        _e(p, "PocetMJ", qty_text(q, 4))
        _e(p, "SazbaDPH", str(x["rate"]))
        if q:
            _e(p, "Cena", _unit(x["gross"] if gross else x["base"], q))
        else:
            _e(p, "Cena", "0")
        _e(p, "CenaTyp", "1" if gross else "0")
        sd = _e(p, "SouhrnDPH")
        _e(sd, "Zaklad", _amt(x["base"]))
        _e(sd, "DPH", _amt(x["vat"]))
        _e(p, "Poradi", str(n))
        nep = _e(p, "NesklPolozka")
        _e(nep, "MJ", (ln["unit"] or "ks")[:10])
        adv = vat_payer and advance_vat(ln) is not None
        if is_advance(ln):
            _e(nep, "Zaloha", "1")                  # odpočet zálohy
            _e(nep, "ZdanZaloha", "1" if adv else "0")
            if adv and tax_date:
                _e(nep, "PlnenoDPH", tax_date)
        _e(nep, "Protizapis", "0")


def _invoice(parent, tag, number, our_number, evcis, druh, credit, issue, tax, due, vs, payment, text, party, note,
             lines, vat_payer):
    f = _e(parent, tag)
    if len(number) <= 10:
        _e(f, "Doklad", number)
    if evcis:
        _e(f, "EvCisDokl", evcis[:50])
    _e(f, "Popis", text[:50])
    _e(f, "Vystaveno", issue)
    _e(f, "DatUcPr", tax or issue)
    if vat_payer:
        _e(f, "PlnenoDPH", tax)
    _e(f, "Splatno", due)
    digits = "".join(c for c in (vs or "") if c.isdigit())
    if digits:
        _e(f, "VarSymbol", digits[:20])
    if our_number:
        _e(f, "PrijatDokl", our_number[:50])
    _e(f, "Druh", druh)
    _e(f, "Dobropis", "1" if credit else "0")
    _e(f, "Uhrada", PAYMENTS.get(payment, "převodem"))
    _e(f, "ZpVypDPH", "1")
    _e(f, "SazbaDPH1", str(REDUCED))
    _e(f, "SazbaDPH2", str(BASIC))
    t = _summary(f, lines, vat_payer)
    _e(f, "Celkem", _amt(t["total"]))
    if note:
        _e(f, "Poznamka", note)
    _e(f, "Vystavil", ("Firmička %s" % __version__)[:50])
    _partner(f, *party)
    _items(f, lines, vat_payer, tax if vat_payer else "")


def export(s, issued, received):
    """issued = [(invoice_row, lines)], received = [(purchase_row, lines)] → bajty XML (UTF-8) pro Money S3.
    Zálohové faktury se vynechají (viz docstring modulu)."""
    from .invoices import kind_of, doc_name
    root = ET.Element("MoneyData")
    if s["firm_ico"]:
        root.set("ICAgendy", s["firm_ico"])
    root.set("description", "Faktury z Firmičky %s" % __version__)
    root.set("ExpDate", time.strftime("%Y-%m-%d"))
    root.set("ExpTime", time.strftime("%H:%M:%S"))
    vyd = [(inv, lines) for inv, lines in issued if kind_of(inv) != "zaloha"]
    if vyd:
        lst = _e(root, "SeznamFaktVyd")
        for inv, lines in vyd:
            k = kind_of(inv)
            ref = inv["ref_number"] if "ref_number" in inv.keys() else ""
            text = "%s %s" % (doc_name(inv, True), inv["cust_name"])
            note = "\n".join(x for x in (regime_note(inv["regime"] if "regime" in inv.keys() else ""),
                                         ("Opravuje doklad %s" % ref) if ref else "",
                                         ("Důvod: " + inv["reason"]) if k == "dobropis" and inv["reason"] else "",
                                         inv["note"]) if x)
            _invoice(lst, "FaktVyd", inv["number"], "", inv["number"], DRUH[k], k == "dobropis", inv["issue_date"],
                     inv["tax_date"], inv["due_date"], inv["vs"], inv["payment"], text,
                     (inv["cust_name"], inv["cust_address"], inv["cust_ico"], inv["cust_dic"]), note, lines,
                     bool(inv["vat_payer"]))
    if received:
        vp = s["vat_payer"] == "1"
        lst = _e(root, "SeznamFaktPrij")
        for p, lines in received:
            credit = invoice_totals(lines, vp)["total"] < 0
            _invoice(lst, "FaktPrij", p["doc_number"], p["number"] or p["doc_number"], "", "N", credit, p["issue_date"],
                     p["tax_date"], p["due_date"], p["vs"], p["payment"], "Přijatá faktura %s" % p["supp_name"],
                     (p["supp_name"], p["supp_address"], p["supp_ico"], p["supp_dic"]),
                     "\n".join(x for x in ("Doklad %s ve Firmičce" % p["doc_number"], p["note"]) if x), lines, vp)
    return b'<?xml version="1.0" encoding="UTF-8"?>\n' + ET.tostring(root, encoding="utf-8")
