"""Import adresáře a zboží z CSV nebo Excelu (.xlsx) – přechod z jiného programu (Aconto, Money, Pohoda, Excel…).
Dva kroky: nahrát soubor → náhled s rozpoznanými sloupci (jdou změnit) a stavem každého řádku → importovat.
Soubor se mezi kroky nese ve skrytém poli (base64), na disk se nic neukládá. Existující záznamy (IČO / název,
EAN / kód / název) se buď přeskočí, nebo doplní údaji ze souboru – prázdná buňka nikdy nic nesmaže."""
import base64
import csv
import io
import re
import unicodedata
import xml.etree.ElementTree as ET
import zipfile

from .db import today
from .web import h, flash, flash_redirect, HTTPError

MAX_BYTES = 5_000_000
MAX_ROWS = 20_000
PREVIEW = 15

# klíč, popisek, rozpoznávané názvy sloupců (po normalizaci: malá písmena bez diakritiky, jen písmena a číslice)
CONTACT_FIELDS = [
    ("name", "Název / jméno", "nazev nazevfirmy firma jmeno obchodnijmeno nazevsubjektu odberatel dodavatel spolecnost "
                              "nazevodberatele nazevpartnera partner zakaznik subjekt name company jmenonazevfirmy nazevjmeno jmenonazev"),
    ("person", "Kontaktní osoba (když chybí název, použije se jako název)", "kontaktniosoba osoba jmenoosoby contactperson"),
    ("surname", "Příjmení (připojí se ke jménu)", "prijmeni surname lastname"),
    ("ico", "IČO", "ico ic icoodberatele identifikacnicislo companyid regno"),
    ("dic", "DIČ", "dic dicodberatele danoveidentifikacnicislo vat vatid taxid dicicdph icdph dicdph"),
    ("street", "Ulice a č. p.", "ulice ulicecp ulicecislo adresa street address"),
    ("city", "Obec", "obec mesto misto city town"),
    ("zip", "PSČ", "psc zip postcode postalcode"),
    ("country", "Stát", "stat zeme country"),
    ("email", "E-mail", "email mail emailovaadresa"),
    ("phone", "Telefon", "telefon tel mobil telefonnicislo phone mobile"),
    ("note", "Poznámka", "poznamka pozn note notes"),
]
ITEM_FIELDS = [
    ("code", "Kód", "kod kodzbozi katalogovecislo katcislo katc cislozbozi cislo sku plu code zkratka katalog"),
    ("ean", "EAN", "ean carovykod carkod barcode ean13 gtin"),
    ("name", "Název", "nazev nazevzbozi nazevpolozky polozka zbozi popis name"),
    ("unit", "Jednotka", "jednotka mj mernajednotka jedn unit"),
    ("price", "Prodejní cena (bez DPH u plátce)", "prodejnicena cena cenabezdph prodejnicenabezdph cenaj jednotkovacena price"),
    ("price_vat", "Prodejní cena s DPH", "prodejnicenasdph cenasdph cenavcetnedph pricevat"),
    ("vat_rate", "Sazba DPH %", "dph sazbadph dphpct dphprocent sazba vatrate"),
    ("qty", "Počáteční stav (jen nové zboží)", "stav mnozstvi zasoba skladem stavskladu stavzasoby pocet ks qty quantity stock"),
    ("cost", "Nákupní cena (bez DPH u plátce)", "nakupnicena nakup nakupo nakupnicenabezdph porizovacicena cost"),
    ("min_qty", "Minimální stav", "minstav minimalnistav minimum min"),
    ("supplier", "Dodavatel", "dodavatel vyrobce supplier"),
    ("warranty", "Záruka (měsíců)", "zaruka zarukames zarukamesicu warranty"),
    ("kind", "Druh (zboží / služba)", "druh typ kind type"),
    ("active", "Aktivní (ano / ne)", "aktivni active"),
    ("recycling_fee", "Recyklační poplatek", "recpoplatek recyklacnipoplatek poplatek"),
    ("note", "Poznámka", "poznamka pozn note"),
]
KINDS = {"adresar": ("Adresář", "kontakty", CONTACT_FIELDS), "sklad": ("Zboží a služby", "položky", ITEM_FIELDS)}


class RowError(ValueError):
    pass


def norm(s):
    s = unicodedata.normalize("NFKD", str(s or "")).encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]", "", s)


# ---------- čtení souboru ----------

def _xlsx(raw):
    """První list .xlsx → řádky (jen standardní knihovna: sdílené řetězce + čísla; datumy jako čísla neřešíme)."""
    ns = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        names = z.namelist()
        shared = []
        if "xl/sharedStrings.xml" in names:
            for si in ET.fromstring(z.read("xl/sharedStrings.xml")).findall("m:si", ns):
                shared.append("".join(t.text or "" for t in si.iter("{%s}t" % ns["m"])))
        sheets = sorted((n for n in names if re.match(r"xl/worksheets/sheet\d+\.xml$", n)),
                        key=lambda n: int(re.search(r"(\d+)\.xml$", n).group(1)))
        if not sheets:
            raise RowError("V souboru Excel není žádný list")
        best = []
        for name in sheets[:20]:          # list s nejvíc daty (první bývá třeba „Info“ s nadpisem)
            rows = _sheet_rows(ET.fromstring(z.read(name)), shared, ns)
            if len([r for r in rows if sum(1 for c in r if c) >= 2]) > len([r for r in best if sum(1 for c in r if c) >= 2]):
                best = rows
        return best


def _sheet_rows(root, shared, ns):
    rows = []
    for r in root.iter("{%s}row" % ns["m"]):
        row = {}
        for c in r.findall("m:c", ns):
            ref = re.match(r"([A-Z]+)", c.get("r", "A"))
            col = 0
            for ch in ref.group(1) if ref else "A":
                col = col * 26 + ord(ch) - 64
            t = c.get("t", "")
            v = c.find("m:v", ns)
            if t == "s" and v is not None:
                val = shared[int(v.text)] if v.text and v.text.isdigit() and int(v.text) < len(shared) else ""
            elif t == "inlineStr":
                val = "".join(x.text or "" for x in c.iter("{%s}t" % ns["m"]))
            elif v is not None and v.text is not None:
                val = v.text
                if t != "str" and re.match(r"^-?\d+\.0+$", val):
                    val = val.split(".")[0]           # 12.0 → 12 (IČO, PSČ, množství)
                elif t != "str" and re.match(r"^-?\d+\.\d{9,}$", val):
                    val = repr(round(float(val), 6))   # 0.21000000000000002 → 0.21
            else:
                val = ""
            row[col] = val
        if row:
            rows.append([row.get(i, "") for i in range(1, max(row) + 1)])
    return rows


def read_table(raw, fields=None, numbers=False):
    """Bajty CSV / XLSX → (záhlaví, řádky). Kódování UTF-8 (i s BOM) nebo Windows-1250, oddělovač ; , nebo tabulátor.
    Záhlaví = mezi prvními 10 řádky ten s nejvíc rozpoznanými sloupci (nad tabulkou bývá nadpis nebo prázdné řádky)."""
    if raw[:2] == b"PK":
        try:
            rows = _xlsx(raw)
        except (zipfile.BadZipFile, KeyError, ET.ParseError, ValueError, IndexError, EOFError):
            raise RowError("Soubor vypadá jako Excel, ale nejde přečíst. Uložte ho v Excelu jako CSV a nahrajte znovu.")
    else:
        if raw[:3] == b"\xef\xbb\xbf":
            text = raw[3:].decode("utf-8", "replace")
        else:
            try:
                text = raw.decode("utf-8")
            except UnicodeDecodeError:
                text = raw.decode("cp1250", "replace")
        if raw[:4] in (b"\xd0\xcf\x11\xe0",) or "\0" in text[:2000]:
            raise RowError("Starý formát Excelu (.xls) neumím – uložte soubor jako .xlsx nebo CSV.")
        sample = text[:20000]
        try:
            dialect = csv.Sniffer().sniff(sample, delimiters=";,\t")
        except csv.Error:
            class dialect(csv.excel):
                delimiter = ";" if sample.count(";") >= sample.count(",") else ","
        try:
            rows = list(csv.reader(io.StringIO(text, newline=""), dialect))
        except csv.Error:
            raise RowError("Soubor nejde přečíst jako tabulku CSV – zkontrolujte, že je to CSV nebo Excel (.xlsx).")
    rows = [[(c or "").strip() for c in r] for r in rows]
    nums = [i for i, r in enumerate(rows, 1) if any(r)]      # číslo řádku v souboru (prázdné se vynechají)
    rows = [r for r in rows if any(r)]
    if not rows:
        raise RowError("Soubor je prázdný")
    hi = 0
    if fields:
        score = [(sum(1 for k in guess(r, fields) if k), sum(1 for c in r if c)) for r in rows[:10]]
        hi = max(range(len(score)), key=lambda i: (score[i][0], score[i][1] >= 2, -i))
        if score[hi][0] == 0:
            hi = next((i for i, sc in enumerate(score) if sc[1] >= 2), 0)
    head, body = rows[hi], rows[hi + 1:]
    if len(body) > MAX_ROWS:
        raise RowError("Soubor má %d řádků, najednou jde importovat nejvýš %d – rozdělte ho." % (len(body), MAX_ROWS))
    width = max(len(head), max((len(r) for r in body), default=0))
    head = head + [""] * (width - len(head))
    body = [r + [""] * (width - len(r)) for r in body]
    return (head, body, nums[hi + 1:]) if numbers else (head, body)


# druhé kolo pro nerozpoznané sloupce: část názvu (pořadí = priorita; „cena s DPH“ dřív než „cena“)
CONTAINS = [("price_vat", ("sdph", "vcetnedph", "vcdph", "pricevat")), ("dic", ("dic",)), ("email", ("mail",)),
            ("phone", ("telefon", "mobil")), ("zip", ("psc",)), ("city", ("mesto", "obec")), ("street", ("ulice",)),
            ("ean", ("ean", "carov")), ("cost", ("nakup",)), ("price", ("cena", "price")), ("vat_rate", ("dph", "sazba")),
            ("qty", ("stav", "zasob", "mnozstv")), ("code", ("kod", "katalog")), ("name", ("nazev", "firma"))]


def guess(head, fields):
    """Sloupec → klíč pole podle názvu sloupce (každé pole nejvýš jednou): nejdřív přesná shoda se známými
    názvy, pak část názvu (např. „Prodejní cena vč. DPH“, „E-mail fakturační“)."""
    syn = {}
    for key, _, words in fields:
        for w in words.split():
            syn.setdefault(w, key)
    keys = {f[0] for f in fields}
    used, out = set(), []
    for col in head:
        k = syn.get(norm(col), "")
        if k == "name" and k in used and "person" in keys:
            k = "person"                           # Firma + Jméno: jméno je kontaktní osoba
        if k in used:
            k = ""
        used.add(k)
        out.append(k)
    for i, col in enumerate(head):
        if out[i]:
            continue
        n = norm(col)
        for key, parts in CONTAINS:
            if key in keys and key not in used and any(p in n for p in parts):
                out[i] = key
                used.add(key)
                break
    return out


# ---------- převod hodnot ----------

def number(s, what):
    t = (s or "").replace("\xa0", "").replace(" ", "").replace("Kč", "").replace("CZK", "").replace("%", "").strip()
    if not t:
        return None
    if "," in t and "." in t:
        t = t.replace(".", "").replace(",", ".") if t.rfind(",") > t.rfind(".") else t.replace(",", "")
    else:
        t = t.replace(",", ".")
    try:
        v = float(t)
    except ValueError:
        raise RowError("%s „%s“ není číslo" % (what, s[:30]))
    if v != v or abs(v) > 1e9:
        raise RowError("%s „%s“ není rozumné číslo" % (what, s[:30]))
    return v


def money_of(s, what):
    v = number(s, what)
    return None if v is None else int(round(v * 100))


VAT_WORDS = {"zakladni": 21, "zaklad": 21, "snizena": 12, "prvnisnizena": 12, "druhasnizena": 12, "snizena1": 12,
             "snizena2": 12, "nulova": 0, "bezdph": 0, "osvobozeno": 0, "osvobozene": 0, "nedanove": 0, "high": 21,
             "low": 12, "none": 0}


def vat_of(s):
    w = VAT_WORDS.get(norm(s))
    if w is not None:
        return w                                   # Pohoda a jiné programy píšou sazbu slovy
    v = number(s, "Sazba DPH")
    if v is None:
        return None
    if 0 < v < 1:
        v *= 100                                   # 0,21 → 21 %
    if v < 0 or v > 99 or abs(v - round(v)) > 1e-6:
        raise RowError("Sazba DPH „%s“ není platná" % s[:20])
    return int(round(v))


def ico_of(s):
    t = re.sub(r"\s", "", s or "")
    if t.isdigit() and len(t) < 8:
        t = t.zfill(8)                             # Excel umaže úvodní nuly
    return t


def yes(s, default=1):
    n = norm(s)
    if not n:
        return default
    return 0 if n in ("ne", "no", "0", "false", "n", "neaktivni", "vyrazeno", "vyrazena") else 1


# ---------- záznamy ----------

def contact_rec(v):
    join = lambda *xs: " ".join(x for x in xs if x).strip()  # noqa: E731
    name, person, note = v.get("name", ""), v.get("person", ""), v.get("note", "")
    if person:
        person = join(person, v.get("surname", ""))
    else:
        name = join(name, v.get("surname", ""))
    if not name:
        name, person = person, ""
    if person:
        note = join("Kontaktní osoba: " + person + (";" if note else ""), note)
    if not name:
        raise RowError("chybí název / jméno")
    rec = {"name": name[:200], "ico": ico_of(v.get("ico")), "dic": re.sub(r"\s", "", v.get("dic", "")).upper()}
    if rec["ico"] and not rec["ico"].isdigit():
        raise RowError("IČO „%s“ obsahuje jiné znaky než číslice" % rec["ico"][:20])
    for k in ("street", "city", "zip", "country", "email", "phone"):
        rec[k] = v.get(k, "")[:500]
    rec["note"] = note[:500]
    return rec


def item_rec(v, payer):
    from .stock import from_gross
    name = v.get("name", "").strip()
    if not name:
        raise RowError("chybí název")
    ean = re.sub(r"\s", "", v.get("ean", ""))
    if re.match(r"^\d+([.,]\d+)?[eE]\+?\d+$", ean):
        raise RowError("EAN „%s“ je v exponenciálním tvaru – v Excelu nastavte sloupec jako text a uložte znovu" % ean)
    rate = vat_of(v.get("vat_rate", ""))
    svc = norm(v.get("kind", "")) in ("sluzba", "sluzby", "prace", "service")
    price = money_of(v.get("price", ""), "Prodejní cena")
    pvat = money_of(v.get("price_vat", ""), "Cena s DPH")
    rate_eff = 21 if rate is None else rate
    if price is None and pvat is not None:
        price = from_gross(pvat, rate_eff) if payer else pvat
    w = number(v.get("warranty", ""), "Záruka")
    if w is not None and (w < 0 or w > 600):
        raise RowError("Záruka „%s“ není v měsících 0–600" % v["warranty"][:20])
    q = number(v.get("qty", ""), "Stav")
    if q is not None and q < 0:
        raise RowError("Počáteční stav nemůže být záporný (%s)" % v["qty"][:20])
    return {"code": v.get("code", "")[:100], "ean": ean[:50], "name": name[:300],
            "unit": (v.get("unit", "") or ("h" if svc else "ks"))[:20],
            "price": price, "vat_rate": rate, "service": 1 if svc else 0 if v.get("kind") else None,
            "recycling_fee": None if svc else money_of(v.get("recycling_fee", ""), "Recyklační poplatek"),
            "min_qty": None if svc else number(v.get("min_qty", ""), "Minimální stav"),
            "supplier": v.get("supplier", "")[:200], "warranty": None if svc or w is None else int(w),
            "note": v.get("note", "")[:500], "active": yes(v.get("active", "")) if v.get("active") else None,
            "qty": 0 if svc else (q or 0), "cost": money_of(v.get("cost", ""), "Nákupní cena")}


def find_contact(db, rec):
    if rec["ico"]:
        r = db.one("SELECT id FROM contacts WHERE ico = ?", (rec["ico"],))
        if r:
            return r["id"]
        return None
    r = db.one("SELECT id FROM contacts WHERE name = ? COLLATE NOCASE AND ico = ''", (rec["name"],))
    return r["id"] if r else None


def find_item(db, rec):
    for col in ("ean", "code"):
        if rec[col]:
            r = db.one("SELECT id FROM items WHERE %s = ?" % col, (rec[col],))
            if r:
                return r["id"]
    if not rec["ean"] and not rec["code"]:
        r = db.one("SELECT id FROM items WHERE name = ? COLLATE NOCASE", (rec["name"],))
        return r["id"] if r else None
    return None


def analyse(db, kind, head, rows, mapping, payer, numbers=None):
    """Každý řádek → (číslo řádku v souboru, záznam, stav 'novy'|'existuje'|'chyba', id existujícího, text)."""
    out, seen = [], {}
    for n, row in zip(numbers or range(2, len(rows) + 2), rows):
        v = {}
        for col, key in enumerate(mapping):
            if key and col < len(row) and row[col]:
                v[key] = row[col]
        try:
            rec = contact_rec(v) if kind == "adresar" else item_rec(v, payer)
        except RowError as e:
            out.append((n, None, "chyba", None, str(e)))
            continue
        keys = ([("IČO", rec["ico"])] if rec["ico"] else [("název", rec["name"].lower())]) if kind == "adresar" else \
            [(k, rec[c]) for k, c in (("EAN", "ean"), ("kód", "code")) if rec[c]] or [("název", rec["name"].lower())]
        dup = next((seen[k] for k in keys if k in seen), None)
        if dup:
            out.append((n, None, "chyba", None, "stejné %s jako řádek %d" % (dup[1], dup[0])))
            continue
        for k in keys:
            seen[k] = (n, k[0])
        eid = find_contact(db, rec) if kind == "adresar" else find_item(db, rec)
        out.append((n, rec, "existuje" if eid else "novy", eid, ""))
    return out


CONTACT_COLS = ["name", "ico", "dic", "street", "city", "zip", "country", "email", "phone", "note"]
ITEM_DEFAULTS = {"price": 0, "vat_rate": 21, "service": 0, "recycling_fee": 0, "min_qty": 0, "warranty": 0, "active": 1}
ITEM_COLS = ["code", "ean", "name", "unit", "price", "recycling_fee", "vat_rate", "min_qty", "note", "active",
             "service", "supplier", "warranty"]


def apply(db, kind, result, update, wh):
    """Zapíše nové záznamy (a při update doplní existující neprázdnými hodnotami). Vrací (nové, doplněné)."""
    new = upd = 0
    with db.tx():
        for _, rec, st, eid, _ in result:
            if st == "chyba":
                continue
            # znovu až v transakci: jiný uživatel mohl mezitím importovat totéž (jinak duplicity)
            eid = find_contact(db, rec) if kind == "adresar" else find_item(db, rec)
            st = "existuje" if eid else "novy"
            if kind == "adresar":
                if st == "novy":
                    vals = dict(rec, country=rec["country"] or "Česká republika")
                    db.run("INSERT INTO contacts(%s) VALUES(%s)" % (",".join(CONTACT_COLS), ",".join("?" * len(CONTACT_COLS))),
                           [vals[k] for k in CONTACT_COLS])
                    new += 1
                elif update:
                    sets = [(k, rec[k]) for k in CONTACT_COLS if rec[k] and k != "name"]
                    if sets:
                        db.run("UPDATE contacts SET %s WHERE id = ?" % ",".join(k + "=?" for k, _ in sets),
                               [x for _, x in sets] + [eid])
                        upd += 1
                continue
            if st == "novy":
                vals = {k: (ITEM_DEFAULTS.get(k, "") if rec.get(k) is None else rec[k]) for k in ITEM_COLS}
                iid = db.run("INSERT INTO items(%s) VALUES(%s)" % (",".join(ITEM_COLS), ",".join("?" * len(ITEM_COLS))),
                             [vals[k] for k in ITEM_COLS])
                if rec["qty"] and not vals["service"]:
                    db.run("INSERT INTO movements(item_id, date, qty, kind, unit_cost, warehouse_id) VALUES(?,?,?,'pocatek',?,?)",
                           (iid, today(), rec["qty"], rec["cost"] or 0, wh))
                new += 1
            elif update:
                sets = [(k, rec[k]) for k in ITEM_COLS if k != "name" and rec.get(k) not in (None, "")]
                if sets:
                    db.run("UPDATE items SET %s WHERE id = ?" % ",".join(k + "=?" for k, _ in sets), [x for _, x in sets] + [eid])
                    upd += 1
    return new, upd


# ---------- stránky ----------

def register(app):
    db = app.db

    def page(req, kind):
        title, what, fields = KINDS[kind]
        back = "/" + kind
        if req.method == "GET" or not (req.files.get("soubor") or req.f("data")):
            return app.page("Import – " + title, """%s<div class="bar"><h1>Import – %s</h1></div>
<section class="card"><form method="post" enctype="multipart/form-data">%s
<p>Nahrajte tabulku z jiného programu nebo z Excelu: <b>CSV</b> nebo <b>Excel (.xlsx)</b>, první řádek = názvy sloupců.
Sloupce Firmička pozná sama (název, IČO, DIČ, EAN, cena, DPH…) a v dalším kroku je můžete upravit – nic se zatím neuloží.</p>
<p><input type="file" name="soubor" accept=".csv,.txt,.xlsx" required> <button class="btn primary">Načíst náhled</button>
<a class="btn" href="%s">Zpět</a></p>
<p class="hint">Tip: v Acontu, Money, Pohodě i jinde najdete u adresáře a ceníku export do Excelu nebo CSV.
Export CSV z Firmičky má stejné sloupce, takže poslouží i jako vzor.</p></form></section>""" % (
                flash(req), h(title), app.csrf(), back), back)
        payer = req.settings["vat_payer"] == "1"
        if req.files.get("soubor"):
            fname, raw = req.files["soubor"]
        else:
            fname = req.f("filename")
            try:
                raw = base64.b64decode(req.form.get("data", ""), validate=True)
            except ValueError:
                raise HTTPError(400, "Poškozená data importu – nahrajte soubor znovu")
        if len(raw) > MAX_BYTES:
            flash_redirect(back + "/import", "Soubor je větší než 5 MB – rozdělte ho na menší části")
        try:
            head, rows, nums = read_table(raw, fields, numbers=True)
        except RowError as e:
            flash_redirect(back + "/import", str(e))
        keys = [k for k, _, _ in fields]
        if req.files.get("soubor"):
            mapping = guess(head, fields)
        else:
            mapping = [req.f("map_%d" % i) if req.f("map_%d" % i) in keys else "" for i in range(len(head))]
        update = req.f("existujici") == "doplnit"
        result = analyse(db, kind, head, rows, mapping, payer, nums)
        if req.f("akce") == "import":
            if "name" not in mapping:
                flash_redirect(back + "/import", "Chybí sloupec s názvem")
            from .warehouses import read_wh
            new, upd = apply(db, kind, result, update, read_wh(db, req))
            bad = sum(1 for r in result if r[2] == "chyba")
            msg = "Importováno: %d nových%s%s" % (new, ", %d aktualizovaných" % upd if upd else "",
                                                 ", %d řádků s chybou vynecháno" % bad if bad else "")
            flash_redirect(back, msg)
        cnt = {s: sum(1 for r in result if r[2] == s) for s in ("novy", "existuje", "chyba")}
        opts = lambda cur: '<option value="">— nepoužít —</option>' + "".join(  # noqa: E731
            '<option value="%s"%s>%s</option>' % (k, " selected" if k == cur else "", h(lbl)) for k, lbl, _ in fields)
        maprows = "".join("<tr><td><b>%s</b></td><td class=hint>%s</td><td><select name='map_%d'>%s</select></td></tr>" % (
            h(col or "(bez názvu)"), h(", ".join(r[i] for r in rows[:3] if r[i])[:80]), i, opts(mapping[i]))
            for i, col in enumerate(head))
        shown = [k for k in keys if k in mapping]
        labels = dict((k, lbl) for k, lbl, _ in fields)
        state = {"novy": ("zaplacena", "nový"), "existuje": ("vystavena", "existuje – " + ("aktualizuje se" if update else "přeskočí")),
                 "chyba": ("stornovana", "chyba")}

        def cell(rec, k):
            if rec is None:
                return ""
            v = rec.get(k) if kind == "sklad" else rec.get(k, "")
            if kind == "sklad" and k in ("price", "price_vat", "cost", "recycling_fee"):
                v = None if v is None else ("%.2f" % (v / 100)).replace(".", ",")
            if k == "kind":
                v = {1: "služba", 0: "zboží"}.get(rec.get("service"), "")
            elif k == "active":
                v = {1: "ano", 0: "ne"}.get(v, "")
            elif k == "qty" and v is not None:
                v = ("%g" % v).replace(".", ",")
            return h("" if v is None else v)
        cols = [k for k in shown if k not in ("surname", "person", "price_vat")] + (["note"] if "person" in shown and "note" not in shown else [])
        if "price_vat" in shown and "price" not in cols:
            cols.insert(cols.index("vat_rate") if "vat_rate" in cols else len(cols), "price")    # dopočtená cena bez DPH
        if kind == "sklad" and payer:
            labels = dict(labels, price="Prodejní cena bez DPH")
        prev = "".join("<tr><td class=num>%d</td><td><span class='tag %s'>%s</span></td>%s</tr>" % (
            n, state[st][0], state[st][1],
            ("<td colspan=%d class=hint>%s</td>" % (max(len(cols), 1), h(msg))) if msg else
            "".join("<td>%s</td>" % cell(rec, k) for k in cols)) for n, rec, st, eid, msg in result[:PREVIEW])
        errs = [r for r in result if r[2] == "chyba"]
        errlist = ""
        if errs:
            errlist = "<details%s><summary>Řádky s chybou (%d) – při importu se vynechají</summary><ul>%s</ul></details>" % (
                " open" if len(errs) <= 10 else "", len(errs),
                "".join("<li>řádek %d: %s</li>" % (n, h(m)) for n, _, _, _, m in errs[:200]))
        wh = ""
        if kind == "sklad":
            from .warehouses import wh_select, default_wh
            wh = wh_select(db, default_wh(db, req), label="Počáteční stav do skladu")
        missing = "" if "name" in mapping else "<div class='flash error'>Vyberte, který sloupec je <b>název</b>.</div>"
        note = ("<p class=hint>Ceny bez DPH: pokud soubor má jen ceny s DPH, vyberte u nich „Prodejní cena s DPH“ – "
                "základ se dopočítá. Stav skladu se zapíše jen u nových položek jako počáteční stav; "
                "u existujících ho upravte inventurou.</p>") if kind == "sklad" else ""
        return app.page("Import – " + title, """%s<div class="bar"><h1>Import – %s</h1></div>
<form method="post">%s<input type="hidden" name="data" value="%s"><input type="hidden" name="filename" value="%s">
<section class="card"><h2>Soubor %s: %s</h2>
<div class="stats"><div><span>Nové %s</span><b>%d</b></div><div><span>Už existují</span><b>%d</b><small>podle %s</small></div>
<div><span>S chybou</span><b>%d</b><small>vynechají se</small></div></div>%s
<label class="check"><input type="radio" name="existujici" value="preskocit"%s onchange="this.form.akce.value='nahled';this.form.submit()"> Existující přeskočit</label>
<label class="check"><input type="radio" name="existujici" value="doplnit"%s onchange="this.form.akce.value='nahled';this.form.submit()"> Existující aktualizovat údaji ze souboru <span class="hint">(prázdná buňka nic nesmaže, název se nemění)</span></label>
%s%s</section>
<section class="card"><h2>Sloupce</h2><table class="list"><thead><tr><th>Sloupec v souboru</th><th>Ukázka</th><th>Pole ve Firmičce</th></tr></thead>
<tbody>%s</tbody></table><button class="btn" onclick="this.form.akce.value='nahled'">Obnovit náhled</button></section>
<section class="card"><h2>Náhled (prvních %d řádků)</h2><div class="scroll nowrap"><table class="list"><thead><tr><th class=num>Řádek</th><th>Stav</th>%s</tr></thead>
<tbody>%s</tbody></table></div>%s
<div class="actions"><input type="hidden" name="akce" value="nahled"><button class="btn primary" onclick="this.form.akce.value='import'"%s>Importovat %d %s</button>
<a class="btn" href="%s">Zrušit</a></div></section></form>""" % (
            flash(req), h(title), app.csrf(), base64.b64encode(raw).decode(), h(fname), h(fname),
            "%d %s" % (len(rows), "řádek" if len(rows) == 1 else "řádky" if 2 <= len(rows) <= 4 else "řádků"),
            what, cnt["novy"], cnt["existuje"], "IČO, jinak názvu" if kind == "adresar" else "EAN, kódu, jinak názvu",
            cnt["chyba"], missing, "" if update else " checked", " checked" if update else "", wh, note, maprows,
            min(PREVIEW, len(rows)), "".join("<th>%s</th>" % h(labels[k].split(" (")[0]) for k in cols), prev, errlist,
            " disabled" if "name" not in mapping else "", cnt["novy"] + (cnt["existuje"] if update else 0),
            "záznamů", back), back)

    @app.route("/adresar/import", ("GET", "POST"))
    def import_contacts(req):
        return page(req, "adresar")

    @app.route("/sklad/import", ("GET", "POST"))
    def import_items(req):
        return page(req, "sklad")
