"""Evidence majetku: inventární čísla, kde co je a kdo to má, pořízení, záruka, vyřazení
a tisk štítků s QR kódem (archy A4 do běžné tiskárny i tiskárna na štítky). Bez daňových odpisů."""
import sqlite3
import urllib.parse

from . import pdf, qr
from .db import next_invoice_number, line_parts, today, now
from .web import h, money, parse_money, parse_id, cz_date, flash, flash_redirect, allowed, HTTPError, Response, Redirect

MM = 72 / 25.4
CATEGORIES = ["Výpočetní technika", "Telefony a tablety", "Nářadí", "Stroje a zařízení", "Měřicí přístroje",
              "Nábytek", "Dopravní prostředky", "Kancelářská technika", "Ostatní"]
# archy A4: (název, sloupců, řádků, šířka, výška, levý okraj, horní okraj, mezera vodorovně, mezera svisle) v mm
# archy přes celou výšku A4 (HERMA, Avery) mají rozteč 297 / řádků (např. 37,125 mm u „70 × 37“) a žádný okraj;
# 38,1 × 21,2 = Avery L7651 / J8651 (okraje 10,7 a 4,75 mm podle výrobce)
SHEETS = {
    "a4-3x8": ("24 štítků 70 × 37 mm (3 × 8)", 3, 8, 70, 297 / 8, 0, 0, 0, 0),
    "a4-3x7": ("21 štítků 70 × 42,3 mm (3 × 7)", 3, 7, 70, 297 / 7, 0, 0, 0, 0),
    "a4-3x10": ("30 štítků 70 × 29,7 mm (3 × 10)", 3, 10, 70, 29.7, 0, 0, 0, 0),
    "a4-4x10": ("40 štítků 52,5 × 29,7 mm (4 × 10)", 4, 10, 52.5, 29.7, 0, 0, 0, 0),
    "a4-5x13": ("65 štítků 38,1 × 21,2 mm (5 × 13)", 5, 13, 38.1, 21.2, 4.75, 10.7, 2.5, 0),
    "a4-2x7": ("14 štítků 105 × 42,3 mm (2 × 7)", 2, 7, 105, 297 / 7, 0, 0, 0, 0),
    "a4-2x4": ("8 štítků 105 × 74 mm (2 × 4)", 2, 4, 105, 297 / 4, 0, 0, 0, 0),
}
# tiskárny na štítky (role): (název, šířka, výška) v mm; jeden štítek = jedna stránka PDF
ROLLS = {
    "r-62x29": ("62 × 29 mm (Brother DK-11209)", 62, 29),
    "r-90x29": ("90 × 29 mm (Brother DK-11201)", 90, 29),
    "r-54x25": ("54 × 25 mm (Dymo 11352)", 54, 25),
    "r-57x32": ("57 × 32 mm (Dymo 11354)", 57, 32),
    "r-50x25": ("50 × 25 mm (Zebra a jiné termotiskárny)", 50, 25),
    "r-50x30": ("50 × 30 mm (Zebra a jiné termotiskárny)", 50, 30),
    "r-vlastni": ("Vlastní rozměr", 0, 0),
}
SETTINGS = {"asset_format": "MAJ{NNNN}", "asset_label": "a4-3x8", "asset_label_w": "50", "asset_label_h": "30",
            "asset_label_dx": "0", "asset_label_dy": "0", "asset_label_firm": "1", "asset_label_serial": "1"}
FIELDS = ("number", "name", "category", "serial", "acquired", "price", "supplier", "doc", "location", "holder",
          "warranty", "note")


def setting(db, key):
    r = db.one("SELECT value FROM settings WHERE key = ?", (key,))
    return r["value"] if r and r["value"] != "" else SETTINGS[key]


def next_number(db):
    return next_invoice_number(db, today(), setting(db, "asset_format"), "assets")


def _mm(v, default, lo, hi):
    try:
        x = float(str(v).replace(",", ".").strip())
    except ValueError:
        return default
    return min(hi, max(lo, x)) if x == x else default


# ---------- štítky ----------
def _fit(p, text, size, width, f="R", minimum=4.5):
    """Zmenší písmo, aby se text vešel na šířku (nejmenší čitelné písmo)."""
    while size > minimum and p.width(text, size, f) > width:
        size -= 0.25
    return size


def _clip(p, text, size, width, f="R"):
    """Text ořízne s výpustkou, pokud se nevejde ani nejmenším písmem."""
    if p.width(text, size, f) <= width:
        return text
    while text and p.width(text + "…", size, f) > width:
        text = text[:-1]
    return text + "…"


def _chars(p, text, size, width, f="R"):
    """Zalomí text po znacích (dlouhá čísla bez mezer) na co nejméně stejně dlouhých řádků – bez osiřelého znaku."""
    out, line = [], ""
    for ch in text:
        if line and p.width(line + ch, size, f) > width:
            out.append(line)
            line = ""
        line += ch
    out = out + [line] if line else out or [""]
    if len(out) > 1:          # stejný počet řádků, ale rovnoměrně
        k = len(out)
        step = -(-len(text) // k)
        even = [text[i:i + step] for i in range(0, len(text), step)]
        if len(even) == k and all(p.width(x, size, f) <= width for x in even):
            out = even
    return out


def draw_label(p, x, y, w, h, a, firm, serial=True, border=False):
    """Jeden štítek v bodech (x, y = levý horní roh): QR s inventárním číslem vlevo, vpravo firma, číslo, název."""
    if border:
        for x1, y1, x2, y2 in ((x, y, x + w, y), (x, y + h, x + w, y + h), (x, y, x, y + h), (x + w, y, x + w, y + h)):
            p.line(x1, y1, x2, y2, 0.3, 0.6)
    pad = max(1.2 * MM, min(2.5 * MM, h * 0.08))
    side = min(h - 2 * pad, w * 0.42)
    m = qr.matrix(a["number"])
    cell = side / len(m)
    for r, row in enumerate(m):          # vodorovné úseky tmavých modulů jako jeden obdélník (menší a rychlejší PDF)
        c = 0
        while c < len(row):
            if row[c]:
                e = c
                while e + 1 < len(row) and row[e + 1]:
                    e += 1
                p.rect(x + pad + c * cell, y + pad + r * cell, (e - c + 1) * cell + 0.05, cell + 0.05)
                c = e + 1
            else:
                c += 1
    tx = x + pad + side + pad * 0.9
    tw = x + w - pad - tx
    bottom = y + h - pad
    ty = y + pad
    small = max(4.5, min(h * 0.085, 7.5))
    num = _fit(p, a["number"], max(7, min(h * 0.2, 17)), tw, "B", minimum=4.5)
    parts = _chars(p, a["number"], num, tw, "B")
    # inventární číslo musí být vždy celé: když se i zalomené nevejde na výšku, zmenší se a případně odpadne název firmy
    while num > 2.5 and (small * 1.35 if firm else 0) + len(parts) * num > bottom - ty + 0.01:
        if firm and len(parts) * num <= bottom - ty:
            firm = ""
            continue
        num -= 0.25
        parts = _chars(p, a["number"], num, tw, "B")
    if firm:
        ty += small
        p.text(tx, ty, _clip(p, firm, small, tw), small, gray=0.35)
        ty += small * 0.35
    for part in parts:
        ty += num
        p.text(tx, ty, part, num, "B")
    ty += num * 0.3
    sub = ("v. č. " + a["serial"]) if serial and a["serial"] else ""
    reserve = small * 1.2 if sub else 0
    fs = max(5, min(h * 0.12, 9.5))
    lines = p.wrap(a["name"], tw, fs)
    shown = []
    for ln in lines:
        if ty + fs * 1.15 > bottom - reserve + 0.01:
            break
        shown.append(ln)
        ty += fs * 1.15
    if len(shown) < len(lines) and shown:
        shown[-1] = _clip(p, shown[-1] + " " + " ".join(lines[len(shown):]), fs, tw)
    yy = ty - fs * 1.15 * len(shown)
    for ln in shown:
        yy += fs * 1.15
        p.text(tx, yy, _clip(p, ln, fs, tw), fs)
    if sub and bottom - ty >= small * 0.9:
        p.text(tx, bottom - small * 0.15, _clip(p, sub, small, tw), small, gray=0.35)


def labels_pdf(assets, fmt, firm="", serial=True, border=False, start=1, copies=1, size=None, dx=0.0, dy=0.0):
    """PDF se štítky. fmt = klíč ze SHEETS (arch A4) nebo ROLLS (stránka = štítek, size = (šířka, výška) mm u vlastního)."""
    items = [a for a in assets for _ in range(copies)]
    if fmt in SHEETS:
        _, cols, rows, w, hh, left, top, gx, gy = SHEETS[fmt]
        p = pdf.PDF("Štítky majetku", firm, pdf.A4)
        per = cols * rows
        start = min(max(1, start), per)
        for i, a in enumerate(items):
            slot = i + start - 1
            if slot % per == 0 or i == 0:
                p.add_page()
            s = slot % per
            c, r = s % cols, s // cols
            draw_label(p, (left + dx + c * (w + gx)) * MM, (top + dy + r * (hh + gy)) * MM, w * MM, hh * MM, a, firm,
                       serial, border)
        if not items:
            p.add_page()
        return p.output()
    w, hh = size if fmt == "r-vlastni" and size else ROLLS.get(fmt, ROLLS["r-62x29"])[1:]
    p = pdf.PDF("Štítky majetku", firm, (w * MM, hh * MM))
    for a in items:
        p.add_page()
        draw_label(p, dx * MM, dy * MM, w * MM, hh * MM, a, firm, serial, border)
    if not items:
        p.add_page()
    return p.output()


def register(app):
    db = app.db

    def get(aid):
        a = db.one("SELECT * FROM assets WHERE id = ?", (aid,))
        if not a:
            raise HTTPError(404, "Majetek neexistuje")
        return a

    def values(req, current=None):
        """Údaje z formuláře; vrací (dict, chyba)."""
        v = {k: req.f(k)[:2000 if k == "note" else 200] for k in FIELDS}
        v["number"] = v["number"][:40]
        if not v["name"]:
            return v, "Zadejte název"
        # číslo nabídnuté formulářem mezitím mohl dostat jiný majetek (dva lidé naráz) → vezme se další volné
        v["auto"] = current is None and (not v["number"] or v["number"] == req.f("number_auto"))
        if not v["number"]:
            v["number"] = next_number(db)
        try:
            v["price"] = parse_money(v["price"])
        except ValueError:
            return v, "Pořizovací cena není číslo"
        if v["price"] < 0:
            return v, "Pořizovací cena nesmí být záporná"
        for k in ("acquired", "warranty"):
            if v[k] and not (len(v[k]) == 10 and v[k][4] == "-" and v[k][7] == "-" and v[k].replace("-", "").isdigit()):
                return v, "Datum zadejte ve tvaru RRRR-MM-DD"
        dup = db.one("SELECT id FROM assets WHERE number = ? AND id != ?", (v["number"], current or 0))
        if dup and v["auto"]:
            v["number"], dup = next_number(db), None
        if dup:
            return v, "Inventární číslo %s už má jiný majetek" % v["number"]
        return v, ""

    def datalist(col, extra=()):
        vals = list(extra) + [r[0] for r in db.q("SELECT DISTINCT %s FROM assets WHERE %s != '' ORDER BY %s COLLATE NOCASE"
                                                    % (col, col, col))]
        seen = []
        for x in vals:
            if x not in seen:
                seen.append(x)
        return '<datalist id="dl-%s">%s</datalist>' % (col, "".join('<option value="%s">' % h(x) for x in seen))

    def form_fields(a, new=False):
        g = lambda k: h(a.get(k, "") if isinstance(a, dict) else a[k])
        price = a.get("price", "") if isinstance(a, dict) else a["price"]
        price = money(price, False) if isinstance(price, int) and price else (h(price) if isinstance(price, str) else "")
        holders = [r["name"] or r["username"] for r in db.q("SELECT name, username FROM users WHERE active = 1")]
        return """<label>Inventární číslo<input name="number" value="%s" required maxlength="40">%s</label>
<label class="wide">Název<input name="name" value="%s" required maxlength="200" placeholder="např. Notebook Lenovo ThinkPad T14"></label>
<label>Kategorie<input name="category" value="%s" list="dl-category" maxlength="80"></label>
<label>Výrobní číslo<input name="serial" value="%s" maxlength="80"></label>
<label>Datum pořízení<input type="date" name="acquired" value="%s"></label>
<label>Pořizovací cena (Kč)<input name="price" value="%s" inputmode="decimal"><span class="hint">plátce DPH bez DPH, neplátce s DPH</span></label>
<label>Dodavatel<input name="supplier" value="%s" maxlength="200"></label>
<label>Doklad<input name="doc" value="%s" maxlength="80" placeholder="číslo faktury, účtenky"></label>
<label>Umístění<input name="location" value="%s" list="dl-location" maxlength="120" placeholder="kancelář, dílna, auto…"></label>
<label>Kdo ho má<input name="holder" value="%s" list="dl-holder" maxlength="120"></label>
<label>Záruka do<input type="date" name="warranty" value="%s"></label>
%s<label class="wide">Poznámka<textarea name="note" rows="2">%s</textarea></label>%s%s%s""" % (
            g("number"), '<span class="hint">řadu nastavíte dole na stránce Majetek</span>' if new else "",
            g("name"), g("category"), g("serial"), g("acquired"), price, g("supplier"), g("doc"),
            g("location"), g("holder"), g("warranty"),
            '<label>Počet kusů<input name="count" value="%s" inputmode="numeric"><span class="hint">každý kus dostane '
            'vlastní inventární číslo a štítek</span></label>' % h(a.get("count", "1")) if new else "",
            g("note"), datalist("category", CATEGORIES), datalist("location"), datalist("holder", holders))

    # ---------- seznam ----------
    @app.route("/majetek")
    def index(req):
        q = req.args.get("q", "").strip()
        if q:
            hit = db.one("SELECT id FROM assets WHERE number = ? COLLATE NOCASE", (q,))
            if hit:      # pípnutí štítku čtečkou (nebo přesné číslo) → rovnou karta majetku
                raise Redirect("/majetek/%d" % hit["id"])
        stav = req.args.get("stav", "aktivni")
        kat = req.args.get("kat", "")
        where, args = [], []
        if stav == "aktivni":
            where.append("disposed = ''")
        elif stav == "vyrazeny":
            where.append("disposed != ''")
        if kat:
            where.append("category = ?")
            args.append(kat)
        if q:
            where.append("(number LIKE ? OR name LIKE ? OR serial LIKE ? OR location LIKE ? OR holder LIKE ? "
                         "OR supplier LIKE ? OR note LIKE ?)")
            args += ["%" + q + "%"] * 7
        rows = db.q("SELECT * FROM assets%s ORDER BY number COLLATE NOCASE LIMIT 2000" %
                    (" WHERE " + " AND ".join(where) if where else ""), args)
        t = today()
        trs = "".join(
            "<tr%s><td><input type=checkbox name=id value='%d' form=labels aria-label='vybrat'></td>"
            "<td><a href='/majetek/%d'>%s</a></td><td>%s%s</td><td>%s</td><td>%s%s</td><td>%s</td>"
            "<td class=num>%s</td><td>%s</td></tr>" % (
                " class=muted" if a["disposed"] else "", a["id"], a["id"], h(a["number"]), h(a["name"]),
                "<br><small class=hint>v. č. %s</small>" % h(a["serial"]) if a["serial"] else "", h(a["category"]),
                h(a["location"]), "<br><small class=hint>%s</small>" % h(a["holder"]) if a["holder"] else "",
                cz_date(a["acquired"]), money(a["price"]) if a["price"] else "",
                ("<span class=tag>vyřazeno %s</span>" % cz_date(a["disposed"])) if a["disposed"] else
                ("do %s%s" % (cz_date(a["warranty"]), " <span class=tag>po záruce</span>" if a["warranty"] < t else "")
                 if a["warranty"] else ""))
            for a in rows)
        total = sum(a["price"] for a in rows)
        cats = [r[0] for r in db.q("SELECT DISTINCT category FROM assets WHERE category != '' ORDER BY category COLLATE NOCASE")]
        opt = lambda val, cur, lab: '<option value="%s"%s>%s</option>' % (h(val), " selected" if val == cur else "", h(lab))
        any_assets = db.one("SELECT COUNT(*) AS n FROM assets")["n"]
        return app.page("Majetek", """%s<div class="bar"><h1>Evidence majetku</h1>
<a class="btn primary" href="/majetek/novy">+ Nový majetek</a><a class="btn" href="/majetek/export.csv">Export CSV</a></div>
<form class="filters" method="get"><input name="q" value="%s" placeholder="Hledat nebo pípnout štítek…" autofocus>
<select name="stav">%s%s%s</select><select name="kat"><option value="">Všechny kategorie</option>%s</select>
<button class="btn">Filtrovat</button></form>
<form id="labels" method="get" action="/majetek/stitky"></form>
%s
<div class="actions"><label class="check"><input type="checkbox" data-check-all="labels"> vybrat vše</label>
<button class="btn" form="labels">Tisk štítků vybraných</button></div>
%s
<section class="card"><h2>Inventární čísla</h2><form method="post" action="/majetek/nastaveni" class="grid">%s
<label>Číselná řada<input name="asset_format" value="%s"><span class="hint">{YYYY} rok, {NNNN} pořadí · další: <b>%s</b></span></label>
<div class="actions"><button class="btn">Uložit</button></div></form></section>""" % (
            flash(req), h(q),
            opt("aktivni", stav, "V evidenci"), opt("vyrazeny", stav, "Vyřazené"), opt("vse", stav, "Vše"),
            "".join(opt(c, kat, c) for c in cats),
            ("""<table class="list"><thead><tr><th></th><th>Inv. číslo</th><th>Název</th><th>Kategorie</th>
<th>Umístění / kdo</th><th>Pořízeno</th><th class=num>Cena</th><th>Záruka / stav</th></tr></thead><tbody>%s</tbody>
<tfoot><tr><th></th><th colspan=5>Celkem %d ks</th><th class=num>%s</th><th></th></tr></tfoot></table>""" % (
                trs, len(rows), money(total))) if rows else
            "<p class=empty>%s</p>" % ("Nic neodpovídá filtru." if any_assets else
                                       "Zatím žádný majetek. Založte první – nebo ho zařaďte rovnou z přijaté faktury."),
            "", app.csrf(), h(setting(db, "asset_format")), h(next_number(db))), "/majetek")

    @app.route("/majetek/nastaveni", ("POST",))
    def settings(req):
        fmt = req.f("asset_format")[:40] or SETTINGS["asset_format"]
        if not any("{%s}" % ("N" * k) in fmt for k in range(2, 7)):
            fmt += "{NNNN}"
        db.set_settings({"asset_format": fmt})
        flash_redirect("/majetek", "Řada inventárních čísel uložena")

    # ---------- nový ----------
    @app.route("/majetek/novy", ("GET", "POST"))
    def new(req):
        if req.method == "POST":
            v, err = values(req)
            cnt = req.f("count") or "1"
            n = int(cnt) if cnt.isdigit() else 0
            if not err and not 1 <= n <= 200:
                err = "Počet kusů zadejte 1 až 200"
            pid = parse_id(req.f("purchase_id"))
            if pid and not db.one("SELECT id FROM purchases WHERE id = ?", (pid,)):
                pid = None
            if err:
                v["count"] = cnt
                if isinstance(v["price"], int):
                    v["price"] = money(v["price"], False) if v["price"] else ""
                return render_new(req, v, err, pid)
            ids = []
            with db.tx():       # zámek databáze: čísla se přidělují jedno po druhém
                for i in range(n):
                    number = v["number"] if i == 0 else next_number(db)
                    if db.one("SELECT id FROM assets WHERE number = ?", (number,)):
                        if i == 0 and not v["auto"]:
                            break
                        number = next_number(db)
                    if i == 0:
                        v["number"] = number
                    ids.append(db.run(
                        "INSERT INTO assets(number, name, category, serial, acquired, price, supplier, doc, purchase_id, "
                        "location, holder, warranty, note, created) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                        (number, v["name"], v["category"], v["serial"] if i == 0 else "", v["acquired"], v["price"],
                         v["supplier"], v["doc"], pid, v["location"], v["holder"], v["warranty"], v["note"], now())))
            if not ids:
                v["count"], v["price"] = cnt, money(v["price"], False) if v["price"] else ""
                return render_new(req, v, "Inventární číslo %s už má jiný majetek" % v["number"], pid)
            if n == 1:
                flash_redirect("/majetek/%d" % ids[0], "Majetek %s založen" % v["number"])
            flash_redirect("/majetek/stitky?" + urllib.parse.urlencode([("id", i) for i in ids]),
                           "Založeno %d %s – můžete rovnou vytisknout štítky" % (n, "kusy" if n < 5 else "kusů"))
        v = {"number": next_number(db), "acquired": today(), "count": "1"}
        pid = parse_id(req.args.get("prijata"))
        pick = ""
        if pid:
            p = db.one("SELECT * FROM purchases WHERE id = ?", (pid,))
            if not p:
                pid = None
            else:
                lines = db.q("SELECT * FROM purchase_lines WHERE purchase_id = ? ORDER BY pos", (pid,))
                v.update(supplier=p["supp_name"], doc=p["doc_number"], acquired=p["tax_date"] or p["issue_date"])
                lid = parse_id(req.args.get("radek"))
                pos = [x for x in lines if x["qty"] > 0 and x["price"] >= 0]   # dobropis / odpočet zálohy do majetku nepatří
                if len(pos) == 1:
                    lid = pos[0]["id"]
                ln = next((x for x in pos if x["id"] == lid), None)
                if ln:
                    vp = req.settings["vat_payer"] == "1"
                    parts = [x for x in line_parts(lines, True) if x["ln"]["id"] == ln["id"]]
                    amount = sum(x["base"] if vp else x["gross"] for x in parts)
                    q = ln["qty"] if ln["qty"] > 0 else 1
                    whole = q == int(q) and 1 <= q <= 200
                    v.update(name=ln["text"], count=str(int(q)) if whole else "1",
                             price=money(round(amount / q) if whole else amount, False))
                elif pos:
                    pick = ('<section class="card"><h2>Kterou položku z faktury %s zařadit?</h2><ul>%s</ul></section>' % (
                        h(p["doc_number"]), "".join(
                            "<li><a href='/majetek/novy?prijata=%d&radek=%d'>%s</a> <span class=hint>%s ×</span></li>" % (
                                pid, x["id"], h(x["text"]), ("%g" % x["qty"]).replace(".", ",")) for x in pos)))
        return render_new(req, v, "", pid, pick)

    def render_new(req, v, err, pid, pick=""):
        return app.page("Nový majetek", """%s%s<div class="bar"><h1>Nový majetek</h1><a class="btn" href="/majetek">Zpět</a></div>
%s<form method="post" class="grid">%s<input type="hidden" name="purchase_id" value="%s"><input type="hidden" name="number_auto" value="%s">%s
<div class="actions wide"><button class="btn primary">Uložit</button><a class="btn" href="/majetek">Zrušit</a></div></form>""" % (
            flash(req), '<div class="flash error">%s</div>' % h(err) if err else "", pick, app.csrf(), pid or "",
            h(v.get("number_auto") or next_number(db)), form_fields(v, True)), "/majetek")

    # ---------- karta ----------
    @app.route("/majetek/<aid>", ("GET", "POST"))
    def detail(req, aid):
        a = get(aid)
        if req.method == "POST":
            v, err = values(req, a["id"])
            if err:
                flash_redirect("/majetek/%d" % a["id"], err)
            try:
                db.run("UPDATE assets SET number=?, name=?, category=?, serial=?, acquired=?, price=?, supplier=?, doc=?, "
                       "location=?, holder=?, warranty=?, note=? WHERE id = ?",
                       tuple(v[k] for k in FIELDS) + (a["id"],))
            except sqlite3.IntegrityError:      # stejné číslo uložil mezitím někdo jiný
                flash_redirect("/majetek/%d" % a["id"], "Inventární číslo %s už má jiný majetek" % v["number"])
            flash_redirect("/majetek/%d" % a["id"], "Uloženo")
        src = ""
        if a["purchase_id"] and allowed(req.perms, "/prijate"):
            p = db.one("SELECT id, doc_number FROM purchases WHERE id = ?", (a["purchase_id"],))
            if p:
                src = '<a class="btn" href="/prijate/%d">← Přijatá %s</a>' % (p["id"], h(p["doc_number"]))
        if a["disposed"]:
            state = ('<section class="card warn"><h2>Vyřazeno %s</h2><p>%s</p><form method="post" action="/majetek/%d/vratit" '
                     'class="inline">%s<button class="btn">Vrátit do evidence</button></form></section>' % (
                         cz_date(a["disposed"]), h(a["dispose_reason"]) or "Bez udání důvodu.", a["id"], app.csrf()))
        else:
            state = ("""<section class="card"><h2>Vyřazení</h2><form method="post" action="/majetek/%d/vyradit" class="grid">%s
<label>Datum<input type="date" name="date" value="%s" required></label>
<label class="wide">Důvod<input name="reason" placeholder="prodáno, zničeno, ztraceno, darováno…" maxlength="200"></label>
<div class="actions"><button class="btn">Vyřadit z evidence</button></div></form></section>""" % (a["id"], app.csrf(), today()))
        return app.page(a["number"], """%s<div class="bar"><a href="/majetek">← Majetek</a><div class="actions">%s
<a class="btn" href="/majetek/stitky?id=%d">Tisk štítku</a></div></div>
<h1>%s <small>%s</small></h1>
<form method="post" class="grid">%s%s
<div class="actions wide"><button class="btn primary">Uložit</button></div></form>
%s
<form method="post" action="/majetek/%d/smazat" class="inline" onsubmit="return confirm('Smazat majetek z evidence úplně? (Vyřazení zachová historii.)')">%s
<button class="link danger">Smazat (zadáno omylem)</button></form>
<p class="hint">Založeno %s.</p>""" % (
            flash(req), src, a["id"], h(a["number"]), h(a["name"]), app.csrf(), form_fields(a), state, a["id"], app.csrf(),
            _ts(a["created"])), "/majetek")

    def _ts(ts):
        import time
        return time.strftime("%d. %m. %Y", time.localtime(ts)).replace(". 0", ". ").lstrip("0") if ts else "–"

    @app.route("/majetek/<aid>/vyradit", ("POST",))
    def dispose(req, aid):
        a = get(aid)
        d = req.f("date") or today()
        if not (len(d) == 10 and d.replace("-", "").isdigit()):
            flash_redirect("/majetek/%d" % a["id"], "Datum zadejte ve tvaru RRRR-MM-DD")
        db.run("UPDATE assets SET disposed = ?, dispose_reason = ? WHERE id = ?", (d, req.f("reason")[:200], a["id"]))
        flash_redirect("/majetek/%d" % a["id"], "%s vyřazeno z evidence" % a["number"])

    @app.route("/majetek/<aid>/vratit", ("POST",))
    def undispose(req, aid):
        a = get(aid)
        db.run("UPDATE assets SET disposed = '', dispose_reason = '' WHERE id = ?", (a["id"],))
        flash_redirect("/majetek/%d" % a["id"], "%s je zpět v evidenci" % a["number"])

    @app.route("/majetek/<aid>/smazat", ("POST",))
    def delete(req, aid):
        a = get(aid)
        db.run("DELETE FROM assets WHERE id = ?", (a["id"],))
        flash_redirect("/majetek", "Majetek %s smazán" % a["number"])

    # ---------- štítky ----------
    def picked(req):
        raw = urllib.parse.parse_qs(req.env.get("QUERY_STRING", "")).get("id", []) if req.method == "GET" else req.lst("id")
        ids = []
        for x in raw:
            for y in x.split(","):
                i = parse_id(y)
                if i and i not in ids:
                    ids.append(i)
        ids = ids[:2000]
        if not ids:
            return []
        rows = {r["id"]: r for r in db.q("SELECT * FROM assets WHERE id IN (%s)" % ",".join("?" * len(ids)), ids)}
        return [rows[i] for i in ids if i in rows]

    @app.route("/majetek/stitky", ("GET", "POST"))
    def labels(req):
        assets = picked(req)
        if req.method == "POST":
            if not assets:
                flash_redirect("/majetek", "Vyberte majetek, pro který chcete štítky")
            fmt = req.f("format")
            fmt = fmt if fmt in SHEETS or fmt in ROLLS else SETTINGS["asset_label"]
            w = _mm(req.f("w"), 50, 15, 200)
            hh = _mm(req.f("h"), 30, 10, 200)
            dx = _mm(req.f("dx"), 0, -10, 10)
            dy = _mm(req.f("dy"), 0, -10, 10)
            st = req.f("start")
            copies = req.f("copies")
            copies = min(20, max(1, int(copies))) if copies.isdigit() else 1
            firm_on, serial_on = bool(req.f("firm")), bool(req.f("serial"))
            db.set_settings({"asset_label": fmt, "asset_label_w": ("%g" % w), "asset_label_h": ("%g" % hh),
                             "asset_label_dx": "%g" % dx, "asset_label_dy": "%g" % dy,
                             "asset_label_firm": "1" if firm_on else "0", "asset_label_serial": "1" if serial_on else "0"})
            data = labels_pdf(assets, fmt, req.settings["firm_name"] if firm_on else "", serial_on, bool(req.f("border")),
                              int(st) if st.isdigit() else 1, copies, (w, hh), dx, dy)
            return Response(data, ctype="application/pdf",
                            headers=[("Content-Disposition", 'inline; filename="stitky-majetku.pdf"')])
        if not assets:
            flash_redirect("/majetek", "Vyberte majetek, pro který chcete štítky (zaškrtnutím v seznamu)")
        cur = setting(db, "asset_label")
        opt = lambda k, lab: '<option value="%s"%s>%s</option>' % (k, " selected" if k == cur else "", h(lab))
        sheets = "".join(opt(k, "Arch A4 – " + v[0]) for k, v in SHEETS.items())
        rolls = "".join(opt(k, v[0]) for k, v in ROLLS.items())
        chk = lambda key: " checked" if setting(db, key) == "1" else ""
        lis = "".join("<li><b>%s</b> %s</li>" % (h(a["number"]), h(a["name"])) for a in assets[:50])
        more = "<li class=hint>… a dalších %d</li>" % (len(assets) - 50) if len(assets) > 50 else ""
        hidden = "".join('<input type="hidden" name="id" value="%d">' % a["id"] for a in assets)
        return app.page("Štítky majetku", """%s<div class="bar"><h1>Tisk štítků</h1><a class="btn" href="/majetek">Zpět</a></div>
<p>Štítků: <b>%d</b> &nbsp;<span class="hint">QR kód obsahuje inventární číslo – po pípnutí čtečkou do hledání
v Majetku se otevře karta majetku.</span></p><ul class="compact">%s%s</ul>
<form method="post" target="_blank" class="grid" id="label-form">%s%s
<label class="wide">Formát<select name="format" data-label-format><optgroup label="Archy A4 do běžné tiskárny">%s</optgroup>
<optgroup label="Tiskárna na štítky (štítek = stránka)">%s</optgroup></select></label>
<label data-custom>Šířka štítku (mm)<input name="w" value="%s" inputmode="decimal"></label>
<label data-custom>Výška štítku (mm)<input name="h" value="%s" inputmode="decimal"></label>
<label data-sheet>Začít od štítku č.<input name="start" value="1" inputmode="numeric">
<span class="hint">na načatém archu – počítá se po řádcích zleva</span></label>
<label>Kopií každého<input name="copies" value="1" inputmode="numeric"></label>
<label>Posun vodorovně (mm)<input name="dx" value="%s" inputmode="decimal"></label>
<label>Posun svisle (mm)<input name="dy" value="%s" inputmode="decimal"><span class="hint">když tiskárna tiskne mimo štítky</span></label>
<label class="check wide"><input type="checkbox" name="firm" value="1"%s> Název firmy na štítku</label>
<label class="check wide"><input type="checkbox" name="serial" value="1"%s> Výrobní číslo na štítku</label>
<label class="check wide"><input type="checkbox" name="border" value="1"> Orámovat (zkušební tisk na obyčejný papír)</label>
<p class="hint wide">Tiskněte ve <b>skutečné velikosti (100 %%)</b>, ne „Přizpůsobit stránce“. U tiskárny na štítky
zvolte v dialogu tisku formát papíru podle štítku.</p>
<div class="actions wide"><button class="btn primary">Vytvořit PDF se štítky</button></div></form>""" % (
            flash(req), len(assets), lis, more, app.csrf(), hidden, sheets, rolls, h(setting(db, "asset_label_w")),
            h(setting(db, "asset_label_h")), h(setting(db, "asset_label_dx")), h(setting(db, "asset_label_dy")),
            chk("asset_label_firm"), chk("asset_label_serial")), "/majetek")

    # ---------- export ----------
    @app.route("/majetek/export.csv")
    def export(req):
        from .core import csv_response, num
        rows = db.q("SELECT * FROM assets ORDER BY number COLLATE NOCASE")
        return csv_response("majetek.csv", ["Inventární číslo", "Název", "Kategorie", "Výrobní číslo", "Datum pořízení",
                                            "Pořizovací cena", "Dodavatel", "Doklad", "Umístění", "Kdo ho má", "Záruka do",
                                            "Vyřazeno", "Důvod vyřazení", "Poznámka"],
                            [[a["number"], a["name"], a["category"], a["serial"], a["acquired"], num(a["price"]),
                              a["supplier"], a["doc"], a["location"], a["holder"], a["warranty"], a["disposed"],
                              a["dispose_reason"], a["note"]] for a in rows])
