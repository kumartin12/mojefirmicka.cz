"""ISDOC 6.0.2 – český standard elektronické faktury (http://isdoc.cz).
Export vydané faktury (účetní ji načte do svého programu bez přepisování) a import přijaté
faktury od dodavatele (.isdoc nebo zabalené .isdocx). Pořadí prvků podle XSD isdoc-invoice-6.0.2."""
import io
import re
import uuid
import xml.etree.ElementTree as ET
import zipfile

from . import __version__, qr
from .db import qty_text, rnd, invoice_totals, line_fee, line_parts, negate_line

NS = "http://isdoc.cz/namespace/2013"
PAYMENT_CODES = {"prevod": "42", "hotove": "10", "karta": "48", "dobirka": "10"}


def _amt(hal):
    return "%.2f" % (hal / 100)


def _unit(amount, q):
    """Jednotková cena = částka řádku / množství, na 4 desetinná místa (ceny s DPH: částka platí, cena/j. se odvozuje)."""
    v = "%.4f" % (amount / q / 100)
    return v[:-2] + v[-2:].rstrip("0")


def _split_street(street):
    """'Hlavní 12/3' → ('Hlavní', '12/3')."""
    m = re.match(r"^(.*?)[\s,]+(\d[\w/]*)$", (street or "").strip())
    return (m.group(1), m.group(2)) if m else ((street or "").strip(), "")


def _parse_address(text):
    """Víceřádková adresa z faktury → ulice, č. p., obec, PSČ."""
    lines = [x.strip() for x in (text or "").split("\n") if x.strip()]
    street, num = _split_street(lines[0] if lines else "")
    zip_, city = "", ""
    if len(lines) > 1:
        m = re.match(r"^(\d{3}\s?\d{2})\s+(.*)$", lines[1])
        zip_, city = (m.group(1).replace(" ", ""), m.group(2)) if m else ("", lines[1])
    return street, num, city, zip_


def _el(parent, tag, text=None, **attrs):
    e = ET.SubElement(parent, "{%s}%s" % (NS, tag), attrs)
    if text is not None:
        e.text = str(text)
    return e


def _party(parent, tag, name, ico, dic, street, num, city, zip_):
    p = _el(_el(parent, tag), "Party")
    _el(_el(p, "PartyIdentification"), "ID", ico or "")
    _el(_el(p, "PartyName"), "Name", name)
    a = _el(p, "PostalAddress")
    _el(a, "StreetName", street)
    _el(a, "BuildingNumber", num)
    _el(a, "CityName", city)
    _el(a, "PostalZone", zip_)
    c = _el(a, "Country")
    _el(c, "IdentificationCode", "CZ")
    _el(c, "Name", "Česká republika")
    if dic:
        ts = _el(p, "PartyTaxScheme")
        _el(ts, "CompanyID", dic)
        _el(ts, "TaxScheme", "VAT")


DOC_TYPES = {"faktura": "1", "dobropis": "2", "zaloha": "4", "ddkpp": "5"}


def export(inv, lines, s, db=None):
    """Vydaný doklad → bajty XML ISDOC (faktura 1, dobropis 2, zálohová faktura 4, daňový doklad k platbě 5)."""
    from .invoices import kind_of
    k = kind_of(inv)
    ref_no = ref_date = ""
    if k == "dobropis":      # ISDOC 5.2.1+: dobropis je vždy v kladných částkách, odečet plyne z typu dokladu
        lines = [negate_line(ln) for ln in lines]
        keys = inv.keys()
        ref_no = inv["ref_number"] if "ref_number" in keys else ""
        ref_date = inv["ref_issue_date"] if "ref_issue_date" in keys else ""
        if not ref_no and db is not None and inv["ref_id"]:
            r = db.one("SELECT number, issue_date FROM invoices WHERE id = ?", (inv["ref_id"],))
            ref_no, ref_date = (r["number"], r["issue_date"]) if r else ("", "")
    fs, fn = _split_street(s["firm_street"])
    acc = s["bank_account"] if inv["payment"] == "prevod" else ""
    regime = inv["regime"] if "regime" in inv.keys() else ""
    from .regimes import note as regime_note, ISDOC_CODES
    rc = ISDOC_CODES.get(inv["pdp_code"] or "") if regime == "pdp" else None
    return _build(DOC_TYPES[k], inv["number"], "firmicka:%s:%s:%s" % (s["firm_ico"], inv["number"], inv["created"]),
                  inv["issue_date"], inv["tax_date"], bool(inv["vat_payer"]),
                  "\n".join(x for x in (regime_note(regime), inv["note"]) if x),
                  (s["firm_name"], s["firm_ico"], s["firm_dic"], fs, fn, s["firm_city"], s["firm_zip"]),
                  (inv["cust_name"], inv["cust_ico"], inv["cust_dic"]) + _parse_address(inv["cust_address"]),
                  ref_no, ref_date, lines, inv["payment"], inv["due_date"], acc, inv["vs"], rc=rc, rc_flag=regime == "pdp")


def export_received(p, lines, s):
    """Přijatá faktura → ISDOC (dodavatel = Party dodavatele, odběratel = naše firma), aby ji účetní načetla
    do svého programu (Aconto, Money, …). ID = číslo faktury dodavatele, naše číslo dokladu jde do poznámky.
    Přijatý dobropis (záporný součet) jako typ 2 v kladných částkách."""
    vp = s["vat_payer"] == "1" and any(ln["vat_rate"] for ln in lines)
    dtype = "1"
    if invoice_totals(lines, vp)["total"] < 0:
        dtype, lines = "2", [negate_line(ln) for ln in lines]
    fs, fn = _split_street(s["firm_street"])
    note = "\n".join(x for x in ("Přijatá faktura – doklad %s ve Firmičce" % p["doc_number"], p["note"]) if x)
    return _build(dtype, p["number"] or p["doc_number"],
                  "firmicka-prijata:%s:%s:%s" % (s["firm_ico"], p["doc_number"], p["created"]),
                  p["issue_date"], p["tax_date"], vp, note,
                  (p["supp_name"], p["supp_ico"], p["supp_dic"]) + _parse_address(p["supp_address"]),
                  (s["firm_name"], s["firm_ico"], s["firm_dic"], fs, fn, s["firm_city"], s["firm_zip"]),
                  "", "", lines, p["payment"], p["due_date"], p["supp_account"] if p["payment"] == "prevod" else "", p["vs"])


def _build(dtype, number, uuid_seed, issue_date, tax_date, vp, note, supplier, customer, ref_no, ref_date, lines,
           payment, due_date, account, vs, rc=None, rc_flag=False):
    ET.register_namespace("", NS)
    t = invoice_totals(lines, vp)
    root = ET.Element("{%s}Invoice" % NS, version="6.0.2")
    _el(root, "DocumentType", dtype)
    _el(root, "ID", number)
    _el(root, "UUID", str(uuid.uuid5(uuid.NAMESPACE_URL, uuid_seed)).upper())
    _el(root, "IssuingSystem", "Firmička %s" % __version__)
    _el(root, "IssueDate", issue_date)
    if vp:
        _el(root, "TaxPointDate", tax_date)
    _el(root, "VATApplicable", "true" if vp else "false")
    _el(root, "ElectronicPossibilityAgreementReference", "")
    if note:
        _el(root, "Note", note)
    _el(root, "LocalCurrencyCode", "CZK")
    _el(root, "CurrRate", "1")
    _el(root, "RefCurrRate", "1")
    _party(root, "AccountingSupplierParty", *supplier)
    _party(root, "AccountingCustomerParty", *customer)
    if ref_no:
        odr = _el(_el(root, "OriginalDocumentReferences"), "OriginalDocumentReference")
        _el(odr, "ID", ref_no)
        if ref_date:
            _el(odr, "IssueDate", ref_date)

    il = _el(root, "InvoiceLines")
    # části řádků (zboží, recyklační poplatek) se základem a DPH, jejichž součty za sazbu přesně sedí s TaxSubTotal
    # (jinak import v účetním programu hlásí rozdíl); ceny s DPH = výpočet shora (VATCalculationMethod 1)
    method = "1" if t["shora"] else "0"
    for n, x in enumerate(line_parts(lines, vp), 1):
        ln, rate, base, vat, price = x["ln"], x["rate"], x["base"], x["vat"], x["price"]
        text = ("recyklační poplatek – " + ln["text"]) if x["fee"] else ln["text"]
        e = _el(il, "InvoiceLine")
        _el(e, "ID", str(n))
        _el(e, "InvoicedQuantity", qty_text(ln["qty"]), unitCode=ln["unit"] or "ks")
        _el(e, "LineExtensionAmount", _amt(base))
        _el(e, "LineExtensionAmountTaxInclusive", _amt(base + vat))
        _el(e, "LineExtensionTaxAmount", _amt(vat))
        if t["shora"] and ln["qty"]:
            _el(e, "UnitPrice", _unit(base, ln["qty"]))
            _el(e, "UnitPriceTaxInclusive", _unit(base + vat, ln["qty"]))
        else:
            _el(e, "UnitPrice", _amt(price))
            _el(e, "UnitPriceTaxInclusive", _amt(rnd(price * (100 + rate) / 100)))
        ct = _el(e, "ClassifiedTaxCategory")
        _el(ct, "Percent", str(rate))
        _el(ct, "VATCalculationMethod", method)
        if rc:                                    # tuzemská přenesená daňová povinnost – kód předmětu plnění
            _el(_el(ct, "LocalReverseCharge"), "LocalReverseChargeCode", rc)
        _el(_el(e, "Item"), "Description", text)

    tt = _el(root, "TaxTotal")
    for r in t["recap"]:
        st = _el(tt, "TaxSubTotal")
        for k, v in (("TaxableAmount", r["base"]), ("TaxAmount", r["vat"]), ("TaxInclusiveAmount", r["total"]),
                     ("AlreadyClaimedTaxableAmount", 0), ("AlreadyClaimedTaxAmount", 0),
                     ("AlreadyClaimedTaxInclusiveAmount", 0), ("DifferenceTaxableAmount", r["base"]),
                     ("DifferenceTaxAmount", r["vat"]), ("DifferenceTaxInclusiveAmount", r["total"])):
            _el(st, k, _amt(v))
        tc = _el(st, "TaxCategory")
        _el(tc, "Percent", str(r["rate"]))
        if rc_flag:
            _el(tc, "LocalReverseChargeFlag", "true")
    _el(tt, "TaxAmount", _amt(t["vat"]))

    lm = _el(root, "LegalMonetaryTotal")
    for k, v in (("TaxExclusiveAmount", t["base"]), ("TaxInclusiveAmount", t["total"]),
                 ("AlreadyClaimedTaxExclusiveAmount", 0), ("AlreadyClaimedTaxInclusiveAmount", 0),
                 ("DifferenceTaxExclusiveAmount", t["base"]), ("DifferenceTaxInclusiveAmount", t["total"]),
                 ("PaidDepositsAmount", 0), ("PayableAmount", t["total"])):
        _el(lm, k, _amt(v))

    pm = _el(_el(root, "PaymentMeans"), "Payment")
    _el(pm, "PaidAmount", _amt(t["total"]))
    _el(pm, "PaymentMeansCode", PAYMENT_CODES.get(payment, "42"))
    acc = (account or "").replace(" ", "")
    iban = qr.cz_iban(acc) if acc else None
    if payment == "prevod" and iban:
        d = _el(pm, "Details")
        _el(d, "PaymentDueDate", due_date)
        num, _, bank = acc.partition("/") if "/" in acc else (iban[8:].lstrip("0"), "", iban[4:8])
        _el(d, "ID", num)
        _el(d, "BankCode", bank)
        _el(d, "Name", "")
        _el(d, "IBAN", iban)
        _el(d, "BIC", "")
        if vs:
            _el(d, "VariableSymbol", "".join(c for c in vs if c.isdigit())[:10])
    return b'<?xml version="1.0" encoding="UTF-8"?>\n' + ET.tostring(root, encoding="utf-8")


# ---------- import přijaté faktury ----------

def _t(el, path):
    e = el.find(path, {"i": NS}) if el is not None else None
    return (e.text or "").strip() if e is not None and e.text else ""


def _hal(s):
    try:
        return int(rnd(float(s) * 100))
    except (TypeError, ValueError):
        return 0


def parse(raw):
    """Bajty .isdoc / .isdocx → (hlavička pro formulář přijaté faktury, řádky)."""
    if raw[:2] == b"PK":
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            names = [n for n in z.namelist() if n.lower().endswith(".isdoc")]
            if not names:
                raise ValueError("V souboru .isdocx není faktura .isdoc")
            raw = z.read(names[0])
    try:
        root = ET.fromstring(raw)
    except ET.ParseError:
        raise ValueError("Soubor je poškozený nebo to není faktura ISDOC (neplatné XML)")
    if not root.tag.endswith("Invoice") or NS not in root.tag:
        raise ValueError("Soubor není faktura ISDOC")
    sup = root.find("i:AccountingSupplierParty/i:Party", {"i": NS})
    addr = sup.find("i:PostalAddress", {"i": NS}) if sup is not None else None
    street = ("%s %s" % (_t(addr, "i:StreetName"), _t(addr, "i:BuildingNumber"))).strip()
    city = ("%s %s" % (_t(addr, "i:PostalZone"), _t(addr, "i:CityName"))).strip()
    det = root.find("i:PaymentMeans/i:Payment/i:Details", {"i": NS})
    acc = ""
    if det is not None and _t(det, "i:ID"):
        acc = _t(det, "i:ID") + ("/" + _t(det, "i:BankCode") if _t(det, "i:BankCode") else "")
    elif det is not None:
        acc = _t(det, "i:IBAN")
    code = _t(root, "i:PaymentMeans/i:Payment/i:PaymentMeansCode")
    head = {"number": _t(root, "i:ID"), "issue_date": _t(root, "i:IssueDate"),
            "tax_date": _t(root, "i:TaxPointDate") or _t(root, "i:IssueDate"),
            "due_date": _t(det, "i:PaymentDueDate") if det is not None else "",
            "vs": _t(det, "i:VariableSymbol") if det is not None else "",
            "payment": {"10": "hotove", "48": "karta"}.get(code, "prevod"),
            "cust_name": _t(sup, "i:PartyName/i:Name"), "cust_ico": _t(sup, "i:PartyIdentification/i:ID"),
            "cust_dic": _t(sup, "i:PartyTaxScheme/i:CompanyID"), "cust_address": "\n".join(x for x in (street, city) if x),
            "supp_account": acc, "note": _t(root, "i:Note"),
            # Firmička účtuje v Kč; faktura s jinou místní měnou (např. EUR ze Slovenska) se musí přepočítat
            "currency": (_t(root, "i:LocalCurrencyCode") or "CZK").upper()}
    head["due_date"] = head["due_date"] or head["issue_date"]
    vat_applicable = _t(root, "i:VATApplicable") == "true"
    head["doc_type"] = _t(root, "i:DocumentType") or "1"
    lines, supplier_base = [], {}
    for ln in root.findall("i:InvoiceLines/i:InvoiceLine", {"i": NS}):
        q = ln.find("i:InvoicedQuantity", {"i": NS})
        try:
            qty = float(q.text) if q is not None and q.text else 1.0
        except ValueError:
            qty = 1.0
        price = _hal(_t(ln, "i:UnitPrice"))
        ext = _t(ln, "i:LineExtensionAmount")
        if not price and qty and ext:
            price = rnd(_hal(ext) / qty)
        rate = int(float(_t(ln, "i:ClassifiedTaxCategory/i:Percent") or 0)) if vat_applicable else 0
        if ext:
            supplier_base[rate] = supplier_base.get(rate, 0) + _hal(ext)
        else:
            supplier_base[rate] = supplier_base.get(rate, 0) + rnd(qty * price)
        lines.append({"item_id": None, "text": _t(ln, "i:Item/i:Description") or _t(ln, "i:Note") or "Položka",
                      "qty": qty, "unit": (q.get("unitCode") if q is not None else "") or "ks", "price": price,
                      "vat_rate": rate, "recycling_fee": 0})
    # Firmička drží ceny na haléře; jednotková cena dodavatele na víc desetinných míst (0,4567 Kč/ks) by po
    # zaokrouhlení změnila součet faktury → rozdíl dorovnat řádkem v téže sazbě, ať základ i DPH sedí s dokladem
    for rate, sb in sorted(supplier_base.items(), reverse=True):
        diff = sb - sum(rnd(x["qty"] * x["price"]) for x in lines if x["vat_rate"] == rate)
        if diff:
            lines.append({"item_id": None, "text": "Zaokrouhlení cen dodavatele" + (" (%d %%)" % rate if vat_applicable else ""),
                          "qty": 1.0, "unit": "ks", "price": diff, "vat_rate": rate, "recycling_fee": 0})
    head["warnings"] = []
    rc = root.find(".//i:LocalReverseCharge/i:LocalReverseChargeCode", {"i": NS})
    flag = any((e.text or "").strip() == "true" for e in root.iter("{%s}LocalReverseChargeFlag" % NS))
    if rc is not None or flag:                  # tuzemská přenesená daňová povinnost (dodavatel fakturuje bez DPH)
        head["regime"] = "pdp"
        head["pdp_code"] = {"1": "1", "2": "11", "4": "4", "5": "5"}.get((rc.text or "").strip() if rc is not None else "", "")
        head["warnings"].append("Faktura je v režimu přenesené daňové povinnosti – u položek nastavte sazbu DPH, kterou si "
                                "daň sami přiznáte (samovyměření)%s." % ("" if head["pdp_code"] else " a vyberte kód předmětu plnění"))
    if head["doc_type"] == "2":     # dobropis je v ISDOC v kladných částkách – u nás snižuje odpočet → záporně
        lines = [dict(x, qty=-x["qty"]) for x in lines]
        ref = _t(root, "i:OriginalDocumentReferences/i:OriginalDocumentReference/i:ID")
        head["note"] = "\n".join(x for x in ("Opravný daňový doklad (dobropis)" + (" k faktuře %s" % ref if ref else ""),
                                             head["note"]) if x)
    if _hal(_t(root, "i:LegalMonetaryTotal/i:PaidDepositsAmount")) or \
            _hal(_t(root, "i:LegalMonetaryTotal/i:AlreadyClaimedTaxInclusiveAmount")):
        head["warnings"].append("Faktura odečítá zaplacené zálohy – položky jsou v plné výši. Pokud už máte zapsaný "
                                "daňový doklad k záloze, odečtěte zálohu řádkem se zápornou částkou.")
    want = _t(root, "i:LegalMonetaryTotal/i:TaxInclusiveAmount")
    if want and lines:
        from .db import invoice_totals
        got = abs(invoice_totals(lines, vat_applicable)["total"])
        if got != abs(_hal(want)):
            head["warnings"].append("Součet po načtení (%s Kč) nesedí s fakturou dodavatele (%s Kč) – zkontrolujte položky."
                                    % (_kc(got), _kc(abs(_hal(want)))))
    return head, lines


def _kc(hal):
    return ("%.2f" % (hal / 100)).replace(".", ",")
