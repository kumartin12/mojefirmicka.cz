"""Objednávky dodavatelům: z toho, co ve skladu dochází (pod minimem), návrh objednávky po dodavatelích, tisk,
odeslání e-mailem a příjem zboží – buď přijatou fakturou (předvyplní se z objednávky a naskladní), nebo hned
bez faktury (pak se u pozdější přijaté faktury naskladnění nenabízí, aby se zboží nepřičetlo dvakrát).
Dodávka může přijít po částech: order_lines.received = kolik z řádku už přišlo, stav „Částečně dodaná“ zůstává
otevřený, dokud nepřijde zbytek nebo ji někdo neuzavře („zbytek nepřijde“)."""
import math
import time

from .db import item_costs, kit_map, next_invoice_number, stock_levels, today
from .web import (h, cz_date, flash, flash_redirect, HTTPError, BadInput, Response, money, parse_id, parse_money, parse_qty,
                  qty as fmt_qty)

STATUS = {"koncept": "Koncept", "odeslana": "Odeslaná", "castecne": "Částečně dodaná", "dodana": "Dodaná",
          "zrusena": "Zrušená"}
TAG = {"koncept": "", "odeslana": "ceka", "castecne": "ceka", "dodana": "hotovo", "zrusena": "storno"}
OPEN = ("koncept", "odeslana", "castecne")
EPS = 1e-9


def remaining(ln):
    return max(ln["qty"] - (ln["received"] or 0), 0)


def counts(ln, kits):
    """Řádek, na jehož dodání se čeká (zboží ze skladu, ne sada ani volný text)."""
    return bool(ln["item_id"]) and ln["item_id"] not in kits


def olines(db, oid):
    return db.q("SELECT * FROM order_lines WHERE order_id = ? ORDER BY pos", (oid,))


def delivered(db, oid, skip_pid=None):
    """Co k objednávce skutečně přišlo: {item_id: kusy} z přijatých faktur s naskladněním + z příjmů bez faktury.
    Počítá se vždy ze zdrojových dokladů, takže úprava, smazání ani přebytek od dodavatele nemůžou součet rozhodit."""
    out = {}
    for r in db.q("SELECT l.item_id, SUM(l.qty) FROM purchase_lines l JOIN purchases p ON p.id = l.purchase_id "
                  "WHERE p.order_id = ? AND p.stock_in = 1 AND p.id != ? AND l.item_id IS NOT NULL GROUP BY l.item_id",
                  (oid, skip_pid or 0)):
        out[r[0]] = r[1] or 0
    o = db.one("SELECT number FROM orders WHERE id = ?", (oid,))
    if o:
        for r in db.q("SELECT item_id, SUM(qty) FROM movements WHERE doc = ? AND note = ? AND kind = 'prijem' "
                      "AND purchase_id IS NULL GROUP BY item_id", (o["number"], "Objednávka %s" % o["number"])):
            out[r[0]] = out.get(r[0], 0) + (r[1] or 0)
    return out


def ordered(db, oid):
    """Objednané zboží (bez sad a volného textu): {item_id: kusy}."""
    kits, out = kit_map(db), {}
    for ln in olines(db, oid):
        if counts(ln, kits):
            out[ln["item_id"]] = out.get(ln["item_id"], 0) + ln["qty"]
    return out


def closed_short(db, oid):
    """Objednávka ručně uzavřená („zbytek nepřijde“): je Dodaná, ale nepřišlo všechno. Úprava faktury ji nesmí otevřít."""
    o = db.one("SELECT status FROM orders WHERE id = ?", (oid,))
    if not o or o["status"] != "dodana":
        return False
    got = delivered(db, oid)
    return any(q - got.get(i, 0) > EPS for i, q in ordered(db, oid).items())


def sync_received(db, oid, keep_closed=False):
    """Přepočítá dodané kusy po řádcích a stav objednávky ze zdrojových dokladů (volat v transakci).
    Přebytek proti objednanému se zapíše k poslednímu řádku dané položky."""
    got = delivered(db, oid)
    lines = olines(db, oid)
    last = {ln["item_id"]: ln["id"] for ln in lines if ln["item_id"]}
    for ln in lines:
        new = 0
        if ln["item_id"]:
            have = got.get(ln["item_id"], 0)
            new = have if last[ln["item_id"]] == ln["id"] else min(have, ln["qty"])
            got[ln["item_id"]] = have - new
        if abs((ln["received"] or 0) - new) > EPS:
            db.run("UPDATE order_lines SET received = ? WHERE id = ?", (new, ln["id"]))
    o = db.one("SELECT status FROM orders WHERE id = ?", (oid,))
    if not o or o["status"] == "zrusena" or keep_closed:
        return
    kits = kit_map(db)
    lines = olines(db, oid)
    need = [ln for ln in lines if counts(ln, kits)]
    if need:
        done = all(remaining(ln) <= EPS for ln in need)
    else:       # jen volný text / sady: dodáno, jakmile je k objednávce faktura s naskladněním
        done = bool(db.one("SELECT 1 FROM purchases WHERE order_id = ? AND stock_in = 1", (oid,)))
    some = any((ln["received"] or 0) > EPS for ln in lines)
    st = "dodana" if done else "castecne" if some else "odeslana" if o["status"] in ("dodana", "castecne") else o["status"]
    if st != o["status"]:
        db.run("UPDATE orders SET status = ? WHERE id = ?", (st, oid))


def uninvoiced(db, oid):
    """Naskladněné a ještě nevyfakturované řádky objednávky: [(řádek, množství)]."""
    got = delivered(db, oid)
    for r in db.q("SELECT l.item_id, SUM(l.qty) FROM purchase_lines l JOIN purchases p ON p.id = l.purchase_id "
                  "WHERE p.order_id = ? AND l.item_id IS NOT NULL GROUP BY l.item_id", (oid,)):
        if r[0] in got:
            got[r[0]] -= r[1] or 0
    texts = {r[0] for r in db.q("SELECT l.text FROM purchase_lines l JOIN purchases p ON p.id = l.purchase_id "
                                "WHERE p.order_id = ? AND l.item_id IS NULL", (oid,))}
    lines = olines(db, oid)
    last = {ln["item_id"]: ln["id"] for ln in lines if ln["item_id"]}
    out = []
    for ln in lines:
        if not ln["item_id"]:
            if ln["text"] not in texts:
                out.append((ln, ln["qty"]))
            continue
        have = max(got.get(ln["item_id"], 0), 0)
        q = have if last[ln["item_id"]] == ln["id"] else min(have, ln["qty"])
        got[ln["item_id"]] = have - q
        if q > EPS:
            out.append((ln, q))
    return out


def over_message(db, oid, lines, old=None, skip_pid=None):
    """Text upozornění, když faktura naskladní víc, než z objednávky zbývá ('' = v pořádku)."""
    old, want, names = old or {}, {}, {}
    for ln in lines:
        if ln.get("item_id"):
            want[ln["item_id"]] = want.get(ln["item_id"], 0) + (ln["qty"] or 0)
            names[ln["item_id"]] = ln.get("text") or ""
    got, out = delivered(db, oid, skip_pid), []
    for iid, q in ordered(db, oid).items():
        left = max(q - got.get(iid, 0), 0)
        if iid in want and want[iid] > left + EPS and want[iid] > old.get(iid, 0) + EPS:
            out.append("%s: naskladňujete %s, z objednávky zbývá %s" % (names[iid], fmt_qty(want[iid]), fmt_qty(left)))
    return "; ".join(out)


def on_order(db):
    """Objednáno a ještě nedodáno: {item_id: množství}."""
    return {r[0]: r[1] for r in db.q("SELECT l.item_id, SUM(MAX(l.qty - COALESCE(l.received, 0), 0)) FROM order_lines l "
                                     "JOIN orders o ON o.id = l.order_id WHERE o.status IN ('koncept', 'odeslana', 'castecne') "
                                     "AND l.item_id IS NOT NULL GROUP BY l.item_id") if r[1] > EPS}


def buy_price(db, costs, iid):
    """Nákupní cena: průměr ze skladu, jinak z poslední přijaté faktury, jinak 0 (prodejní cena se nepoužije)."""
    p = costs.get(iid, (0, 0))[1]
    if not p:
        r = db.one("SELECT price FROM purchase_lines WHERE item_id = ? ORDER BY id DESC LIMIT 1", (iid,))
        p = r[0] if r else 0
    return p


def suggestions(db):
    """Co dochází (stav ≤ minimum, bez služeb a sad), po dodavatelích; návrh doplní na dvojnásobek minima
    a odečte, co už je objednané."""
    levels, costs, kits, ordered = stock_levels(db), item_costs(db), kit_map(db), on_order(db)
    out = {}
    for it in db.q("SELECT * FROM items WHERE active = 1 AND service = 0 AND min_qty > 0 ORDER BY name COLLATE NOCASE"):
        if it["id"] in kits:
            continue
        st = levels.get(it["id"], 0)
        if st > it["min_qty"]:
            continue
        want = max(it["min_qty"] * 2 - st - ordered.get(it["id"], 0), 0)
        if it["unit"] in ("ks", "bal", "krab", "pár"):
            want = math.ceil(want)
        out.setdefault(it["supplier"] or "", []).append({"item": it, "stock": st, "ordered": ordered.get(it["id"], 0),
                                                         "want": round(want, 3), "price": buy_price(db, costs, it["id"])})
    return out


def supplier_contact(db, name):
    return db.one("SELECT * FROM contacts WHERE name = ? COLLATE NOCASE", (name,)) if name else None


def order_text(s, o, lines):
    rows = "\n".join("- %s%s: %s %s" % (ln["text"], " (kód %s)" % ln["code"] if ln["code"] else "", fmt_qty(ln["qty"]),
                                         ln["unit"]) for ln in lines)
    sign = "\n".join(x for x in (s["firm_name"], s["firm_phone"], s["firm_email"]) if x)
    return ("Objednávka %s – %s" % (o["number"], s["firm_name"]) if s["firm_name"] else "Objednávka %s" % o["number"],
            "Dobrý den,\n\nobjednáváme u vás:\n\n%s\n\n%sProsíme o potvrzení objednávky a termínu dodání.\n\nS pozdravem\n%s" % (
                rows, o["note"] + "\n\n" if o["note"] else "", sign))


def register(app):
    db = app.db

    def get(oid):
        o = db.one("SELECT * FROM orders WHERE id = ?", (oid,))
        if not o:
            raise HTTPError(404, "Objednávka nenalezena")
        return o

    def lines_with_codes(oid):
        return db.q("SELECT l.*, COALESCE(i.code, '') AS code FROM order_lines l LEFT JOIN items i ON i.id = l.item_id "
                    "WHERE l.order_id = ? ORDER BY l.pos", (oid,))

    def total(lines):
        return sum(round(ln["qty"] * ln["price"]) for ln in lines)

    # ---------- přehled + co dochází ----------
    @app.route("/sklad/objednavky")
    def index(req):
        st = req.args.get("stav", "otevrene")
        sql = "SELECT * FROM orders"
        if st == "otevrene":
            sql += " WHERE status IN ('koncept', 'odeslana', 'castecne')"
        elif st in STATUS:
            sql += " WHERE status = '%s'" % st
        rows = db.q(sql + " ORDER BY id DESC LIMIT 500")
        trs = "".join("<tr><td><a href='/sklad/objednavky/%d'>%s</a></td><td>%s</td><td>%s</td><td class=num>%s</td>"
                      "<td><span class='tag %s'>%s</span></td></tr>" % (
                          o["id"], h(o["number"]), h(o["supp_name"]), cz_date(o["order_date"]),
                          money(total(olines(db, o["id"]))), TAG[o["status"]], STATUS[o["status"]]) for o in rows)
        sug = suggestions(db)
        cards = []
        for supp, items in sorted(sug.items(), key=lambda x: (x[0] == "", x[0].lower())):
            trs2 = "".join("""<tr><td>%s</td><td class=num>%s</td><td class=num>%s</td><td class=num>%s</td>
<td><input name="q_%d" value="%s" inputmode="decimal" style="width:6rem"> %s</td></tr>""" % (
                h(x["item"]["name"]), fmt_qty(x["stock"]), fmt_qty(x["item"]["min_qty"]),
                fmt_qty(x["ordered"]) if x["ordered"] else "", x["item"]["id"], fmt_qty(x["want"]) if x["want"] else "",
                h(x["item"]["unit"])) for x in items)
            cards.append("""<form method="post" action="/sklad/objednavky/z-navrhu" class="card">%s
<input type="hidden" name="supplier" value="%s"><h2>%s</h2>
<table class="list"><thead><tr><th>Položka</th><th class=num>Stav</th><th class=num>Minimum</th><th class=num>Objednáno</th>
<th>Objednat</th></tr></thead><tbody>%s</tbody></table><button class="btn primary">Vytvořit objednávku</button></form>""" % (
                app.csrf(), h(supp), h(supp) if supp else "Bez dodavatele <span class=hint>(doplňte ho u položky ve skladu)</span>",
                trs2))
        ssel = "".join('<option value="%s"%s>%s</option>' % (k, " selected" if k == st else "", v) for k, v in
                       [("otevrene", "Otevřené")] + list(STATUS.items()) + [("vse", "Všechny")])
        return app.page("Objednávky", """%s<div class="bar"><a href="/sklad">← Sklad</a><div class="actions">
<a class="btn primary" href="/sklad/objednavky/nova">+ Objednávka</a></div></div>
<h1>Objednávky dodavatelům</h1>
<form class="filters"><select name="stav" onchange="this.form.submit()">%s</select></form>
<table class="list"><thead><tr><th>Číslo</th><th>Dodavatel</th><th>Datum</th><th class=num>Nákupní cena</th><th>Stav</th>
</tr></thead><tbody>%s</tbody></table>
<h2 style="margin-top:2rem">Co dochází</h2><p class="hint">Zboží se stavem na minimu nebo pod ním. Návrh doplní stav na
dvojnásobek minima a odečte, co už je objednané a nedodané.</p>%s""" % (
            flash(req), ssel, trs or "<tr><td colspan=5 class=empty>Žádné objednávky.</td></tr>",
            "".join(cards) or "<p class=empty>Nic nedochází – nebo zboží nemá nastavené minimum.</p>"), "/sklad")

    @app.route("/sklad/objednavky/z-navrhu", ("POST",))
    def from_suggestion(req):
        supp = req.f("supplier")
        sug = {x["item"]["id"]: x for x in suggestions(db).get(supp, [])}
        lines = []
        for iid, x in sug.items():
            q = parse_qty(req.f("q_%d" % iid) or "0")
            if q > 0:
                lines.append({"item_id": iid, "text": x["item"]["name"], "qty": q, "unit": x["item"]["unit"],
                              "price": x["price"], "vat_rate": x["item"]["vat_rate"]})
        if not lines:
            flash_redirect("/sklad/objednavky", "Zadejte, kolik objednat")
        c = supplier_contact(db, supp)
        oid = save({"supp_name": supp or "Dodavatel", "contact_id": c["id"] if c else None,
                    "supp_email": c["email"] if c else "", "supp_ico": c["ico"] if c else "",
                    "supp_address": address(c), "note": "", "order_date": today()}, lines, req)
        flash_redirect("/sklad/objednavky/%d" % oid, "Objednávka připravena – zkontrolujte ji a pošlete")

    def address(c):
        if not c:
            return ""
        return "\n".join(x for x in (c["street"], " ".join(y for y in (c["zip"], c["city"]) if y)) if x)

    def save(o, lines, req, oid=None):
        with db.tx():
            if oid:
                db.run("UPDATE orders SET supp_name = ?, contact_id = ?, supp_email = ?, supp_ico = ?, supp_address = ?, "
                       "note = ?, order_date = ? WHERE id = ?", (o["supp_name"], o["contact_id"], o["supp_email"], o["supp_ico"],
                                                                o["supp_address"], o["note"], o["order_date"], oid))
                db.run("DELETE FROM order_lines WHERE order_id = ?", (oid,))
            else:
                fmt = req.settings.get("order_format") or "OBJ{YYYY}{NNNN}"
                number = next_invoice_number(db, o["order_date"], fmt, "orders", "number")
                oid = db.run("INSERT INTO orders(number, supp_name, contact_id, supp_email, supp_ico, supp_address, note, "
                             "order_date, status, created, created_by) VALUES(?,?,?,?,?,?,?,?, 'koncept', ?, ?)",
                             (number, o["supp_name"], o["contact_id"], o["supp_email"], o["supp_ico"], o["supp_address"],
                              o["note"], o["order_date"], int(time.time()), req.user or ""))
            for pos, ln in enumerate(lines):
                db.run("INSERT INTO order_lines(order_id, pos, item_id, text, qty, unit, price, vat_rate) VALUES(?,?,?,?,?,?,?,?)",
                       (oid, pos, ln["item_id"], ln["text"], ln["qty"], ln["unit"], ln["price"], ln["vat_rate"]))
        return oid

    # ---------- formulář ----------
    def form(req, o, lines, oid=None, err=""):
        items = db.q("SELECT id, name, unit, vat_rate, supplier FROM items WHERE active = 1 AND service = 0 "
                     "ORDER BY name COLLATE NOCASE")
        iopts = '<option value="">— volný text —</option>' + "".join(
            '<option value="%d">%s</option>' % (i["id"], h(i["name"])) for i in items)
        rows = []
        for ln in list(lines) + [{}] * 5:
            sel = iopts.replace('value="%s"' % ln.get("item_id"), 'value="%s" selected' % ln.get("item_id")) if ln.get("item_id") else iopts
            rows.append("""<tr><td><select name="line_item">%s</select></td><td><input name="line_text" value="%s"></td>
<td><input name="line_qty" value="%s" inputmode="decimal" style="width:5rem"></td><td><input name="line_unit" value="%s" style="width:4rem"></td>
<td><input name="line_price" value="%s" inputmode="decimal" style="width:7rem"></td></tr>""" % (
                sel, h(ln.get("text") or ""), fmt_qty(ln["qty"]) if ln.get("qty") else "", h(ln.get("unit") or ""),
                money(ln["price"], False) if ln.get("price") else ""))
        sups = sorted({i["supplier"] for i in items if i["supplier"]} |
                      {c["name"] for c in db.q("SELECT name FROM contacts")}, key=str.lower)
        return app.page("Objednávka", """<div class="bar"><a href="%s">← Zpět</a></div><h1>%s</h1>%s
<form method="post" class="card grid">%s
<label class="wide">Dodavatel<input name="supp_name" value="%s" list="sups" required></label>
<label>E-mail dodavatele<input name="supp_email" type="email" value="%s"></label>
<label>IČO<input name="supp_ico" value="%s"></label>
<label class="wide">Adresa<textarea name="supp_address" rows="2">%s</textarea></label>
<label>Datum<input type="date" name="order_date" value="%s" required></label>
<label class="wide">Poznámka pro dodavatele<input name="note" value="%s" placeholder="např. dodání do pátku, doprava na adresu provozovny"></label>
<div class="wide tablewrap"><table class="list"><thead><tr><th>Položka ze skladu</th><th>Text</th><th>Množství</th><th>Jednotka</th>
<th>Nákupní cena/j. bez DPH</th></tr></thead><tbody>%s</tbody></table>
<p class="hint">Text a jednotka se u položky ze skladu doplní samy. Prázdné řádky se neuloží.</p></div>
<div class="actions wide"><button class="btn primary">Uložit</button></div></form>
<datalist id="sups">%s</datalist>""" % (
            "/sklad/objednavky/%s" % oid if oid else "/sklad/objednavky", "Upravit objednávku" if oid else "Nová objednávka",
            '<div class="flash error">%s</div>' % h(err) if err else "", app.csrf(), h(o.get("supp_name")),
            h(o.get("supp_email")), h(o.get("supp_ico")), h(o.get("supp_address")), h(o.get("order_date") or today()),
            h(o.get("note")), "".join(rows), "".join('<option value="%s">' % h(x) for x in sups)), "/sklad")

    def read(req):
        o = {"supp_name": req.f("supp_name")[:200], "supp_email": req.f("supp_email")[:200], "supp_ico": req.f("supp_ico")[:20],
             "supp_address": req.form.get("supp_address", "").strip()[:400], "note": req.f("note")[:400],
             "order_date": req.f("order_date") or today()}
        c = supplier_contact(db, o["supp_name"])
        o["contact_id"] = c["id"] if c else None
        cols = [req.lst(k) for k in ("line_item", "line_text", "line_qty", "line_unit", "line_price")]
        n = max(len(c_) for c_ in cols)
        cols = [c_ + [""] * (n - len(c_)) for c_ in cols]
        lines = []
        for it, text, q, unit, price in zip(*cols):
            iid = parse_id(it)
            item = db.one("SELECT * FROM items WHERE id = ? AND service = 0", (iid,)) if iid else None
            if not item and not text.strip():
                continue
            qty = parse_qty(q or "0")
            lines.append({"item_id": item["id"] if item else None, "text": text.strip() or item["name"],
                          "qty": qty, "unit": unit.strip() or (item["unit"] if item else "ks"),
                          "price": parse_money(price) if price.strip() else (buy_price(db, item_costs(db), item["id"]) if item else 0),
                          "vat_rate": item["vat_rate"] if item else 21})
        if not o["supp_name"]:
            return o, lines, "Vyplňte dodavatele."
        if not lines:
            return o, lines, "Objednávka musí mít aspoň jednu položku."
        if any(ln["qty"] <= 0 for ln in lines):
            return o, lines, "Množství musí být větší než 0."
        return o, lines, ""

    @app.route("/sklad/objednavky/nova", ("GET", "POST"))
    def new(req):
        if req.method == "POST":
            o, lines, err = read(req)
            if err:
                return form(req, o, lines, err=err)
            oid = save(o, lines, req)
            flash_redirect("/sklad/objednavky/%d" % oid, "Objednávka uložena")
        return form(req, {"order_date": today()}, [])

    @app.route("/sklad/objednavky/<oid>/upravit", ("GET", "POST"))
    def edit(req, oid):
        o = get(oid)
        if o["status"] not in OPEN:
            raise HTTPError(409, "Dodanou nebo zrušenou objednávku už nejde měnit.")
        if db.one("SELECT 1 FROM order_lines WHERE order_id = ? AND received > 0", (o["id"],)):
            raise HTTPError(409, "Část objednávky už je naskladněná – položky už nejde měnit. Zbytek uzavřete a objednejte znovu.")
        if req.method == "POST":
            new_o, lines, err = read(req)
            if err:
                return form(req, new_o, lines, o["id"], err)
            save(new_o, lines, req, o["id"])
            flash_redirect("/sklad/objednavky/%d" % o["id"], "Objednávka uložena")
        return form(req, dict(o), [dict(x) for x in olines(db, o["id"])], o["id"])

    # ---------- detail, tisk, e-mail, příjem ----------
    @app.route("/sklad/objednavky/<oid>")
    def detail(req, oid):
        o = get(oid)
        s = req.settings
        lines = lines_with_codes(o["id"])
        actions = ['<button class="btn" onclick="window.print()">Tisk</button>']
        part = o["status"] == "castecne"
        got = any((ln["received"] or 0) > EPS for ln in lines)
        if o["status"] in OPEN:
            if not got:
                actions.append('<a class="btn" href="/sklad/objednavky/%d/upravit">Upravit</a>' % o["id"])
                actions.append('<a class="btn primary" href="/sklad/objednavky/%d/email">Poslat e-mailem</a>' % o["id"])
            if o["status"] == "koncept":
                actions.append('<form method="post" action="/sklad/objednavky/%d/stav" class="inline">%s<button class="btn" '
                               'name="akce" value="odeslana">Označit jako odeslanou</button></form>' % (o["id"], app.csrf()))
            actions.append('<a class="btn ok" href="/prijate/nova?objednavka=%d">%s s fakturou</a>' % (
                o["id"], "Přijmout zbytek" if part else "Přijmout zboží"))
            actions.append('<a class="btn" href="/sklad/objednavky/%d/naskladnit">%s bez faktury</a>' % (
                o["id"], "Naskladnit zbytek" if part else "Naskladnit"))
        if got and any(ln["item_id"] for ln, _ in uninvoiced(db, o["id"])):
            actions.append('<a class="btn" href="/prijate/nova?objednavka=%d&amp;bez_naskladneni=1">Faktura k naskladněnému '
                           'zboží</a>' % o["id"])
        if part:
            actions.append('<form method="post" action="/sklad/objednavky/%d/stav" class="inline" onsubmit="return confirm('
                           '\'Uzavřít objednávku? Na zbytek se už nebude čekat.\')">%s<button class="btn" name="akce" '
                           'value="dodana">Uzavřít – zbytek nepřijde</button></form>' % (o["id"], app.csrf()))
        elif o["status"] in OPEN:
            actions.append('<form method="post" action="/sklad/objednavky/%d/stav" class="inline" onsubmit="return confirm('
                           '\'Zrušit objednávku?\')">%s<button class="link danger" name="akce" value="zrusena">zrušit</button>'
                           '</form>' % (o["id"], app.csrf()))
        purchases = db.q("SELECT id, doc_number, issue_date FROM purchases WHERE order_id = ? OR id = ? ORDER BY id",
                         (o["id"], o["purchase_id"] or 0))
        for p_ in purchases:
            actions.append('<a class="btn" href="/prijate/%d">→ Faktura %s</a>' % (p_["id"], h(p_["doc_number"])))
        show_got = got or o["status"] in ("castecne", "dodana")
        trs = "".join("<tr><td>%s</td><td>%s</td><td class=num>%s %s</td>%s<td class=num>%s</td><td class=num>%s</td></tr>" % (
            h(ln["code"]), h(ln["text"]), fmt_qty(ln["qty"]), h(ln["unit"]),
            "<td class='num noprint'>%s%s</td>" % (fmt_qty(ln["received"] or 0), " <b class=danger>(chybí %s)</b>" % fmt_qty(
                remaining(ln)) if part and ln["item_id"] and remaining(ln) > EPS else "") if show_got else "",
            money(ln["price"]), money(round(ln["qty"] * ln["price"]))) for ln in lines)
        firm = "<br>".join(h(x) for x in (s["firm_name"], s["firm_street"], " ".join(y for y in (s["firm_zip"], s["firm_city"]) if y),
                                          "IČO: " + s["firm_ico"] if s["firm_ico"] else "", s["firm_email"], s["firm_phone"]) if x)
        supp = "<br>".join(h(x) for x in [o["supp_name"]] + o["supp_address"].split("\n") +
                           ["IČO: " + o["supp_ico"] if o["supp_ico"] else "", o["supp_email"]] if x)
        state = STATUS[o["status"]] + (" · naskladněno bez faktury" if o["received"] else "")
        return app.page("Objednávka " + o["number"], """%s<div class="bar noprint"><a href="/sklad/objednavky">← Objednávky</a>
<div class="actions">%s</div></div>
<div class="invoice"><h1>Objednávka %s</h1><p class="noprint"><span class="tag %s">%s</span></p>
<div class="cols"><div><h3>Odběratel</h3><p>%s</p></div><div><h3>Dodavatel</h3><p>%s</p></div></div>
<p>Datum objednávky: %s</p>
<table class="list"><thead><tr><th>Kód</th><th>Položka</th><th class=num>Množství</th>%s<th class=num>Cena/j. bez DPH</th>
<th class=num>Celkem bez DPH</th></tr></thead><tbody>%s</tbody>
<tfoot><tr><th colspan=%d>Celkem bez DPH (orientačně podle posledních nákupních cen)</th><th class=num>%s</th></tr></tfoot></table>
%s<p>Prosíme o potvrzení objednávky a termínu dodání.</p></div>""" % (
            flash(req), "".join(actions), h(o["number"]), TAG[o["status"]], state, firm, supp, cz_date(o["order_date"]),
            "<th class='num noprint'>Dodáno</th>" if show_got else "", trs, 5 if show_got else 4, money(total(lines)), "<p><b>Poznámka:</b> %s</p>" % h(o["note"]) if o["note"] else ""), "/sklad")

    @app.route("/sklad/objednavky/<oid>/stav", ("POST",))
    def status(req, oid):
        o = get(oid)
        akce = req.f("akce")
        ok = (akce in ("odeslana", "zrusena") and o["status"] in ("koncept", "odeslana")) or \
             (akce == "dodana" and o["status"] == "castecne")
        if not ok:
            raise HTTPError(409, "Stav objednávky nejde změnit.")
        db.run("UPDATE orders SET status = ? WHERE id = ? AND status = ?", (akce, o["id"], o["status"]))
        flash_redirect("/sklad/objednavky/%d" % o["id"], {"zrusena": "Objednávka zrušena", "odeslana": "Označeno jako odeslané",
                                                          "dodana": "Objednávka uzavřena – na zbytek se nečeká"}[akce])

    @app.route("/sklad/objednavky/<oid>/email", ("GET", "POST"))
    def email(req, oid):
        from .mail import eml
        from .reminders import send_mail, smtp_notice
        o = get(oid)
        s = req.settings
        subject, body = order_text(s, o, lines_with_codes(o["id"]))
        if req.method == "POST":
            to, subject, body = req.f("to"), req.f("subject") or subject, req.form.get("body", body)
            if req.f("akce") == "eml":
                return Response(eml(s, to, subject, body, []), ctype="message/rfc822",
                                headers=[("Content-Disposition", 'attachment; filename="objednavka-%s.eml"' % o["id"])])
            if "@" not in to:
                flash_redirect("/sklad/objednavky/%d/email" % o["id"], "Zadejte e-mail dodavatele")
            try:
                send_mail(s, to, subject, body)
            except Exception as e:
                flash_redirect("/sklad/objednavky/%d/email" % o["id"], "Odeslání selhalo: %s" % e)
            with db.tx():
                db.run("UPDATE orders SET status = 'odeslana', supp_email = ? WHERE id = ? AND status = 'koncept'", (to, o["id"]))
                if o["contact_id"]:
                    db.run("UPDATE contacts SET email = ? WHERE id = ? AND email = ''", (to, o["contact_id"]))
            flash_redirect("/sklad/objednavky/%d" % o["id"], "Odesláno na %s" % to)
        smtp = bool(s["smtp_host"])
        return app.page("Poslat objednávku", """%s<div class="bar"><a href="/sklad/objednavky/%d">← Zpět</a></div>
<h1>Poslat objednávku %s</h1>%s<form method="post" class="grid">%s
<label class="wide">Komu<input name="to" type="email" value="%s"></label>
<label class="wide">Předmět<input name="subject" value="%s"></label>
<label class="wide">Text<textarea name="body" rows="14">%s</textarea></label>
<div class="actions wide"><button class="btn primary" name="akce" value="poslat"%s>Odeslat</button>
<button class="btn" name="akce" value="eml" formnovalidate>Otevřít v poštovním programu</button></div></form>""" % (
            flash(req), o["id"], h(o["number"]), smtp_notice(s, eml=True), app.csrf(), h(o["supp_email"]), h(subject), h(body),
            "" if smtp else " disabled title='Nastavte odchozí e-mail v Nastavení'"), "/sklad")

    @app.route("/sklad/objednavky/<oid>/naskladnit", ("GET", "POST"))
    def receive(req, oid):
        from .warehouses import wh_select, default_wh, read_wh
        o = get(oid)
        if o["status"] not in OPEN:
            raise HTTPError(409, "Objednávka už je dodaná nebo zrušená.")
        lines = [ln for ln in olines(db, o["id"]) if ln["item_id"]]
        kits = kit_map(db)
        if req.method == "POST":
            wh = read_wh(db, req)
            n = 0
            with db.tx():
                if db.one("SELECT status FROM orders WHERE id = ?", (o["id"],))["status"] not in OPEN:
                    raise HTTPError(409, "Objednávka už je dodaná nebo zrušená.")
                fresh = {ln["id"]: ln for ln in olines(db, o["id"])}     # stav až v transakci (dvě otevřená okna)
                for ln in lines:
                    q = parse_qty(req.f("q_%d" % ln["id"]) or "0")
                    if q > 1e9:
                        raise BadInput("Množství u %s je nesmyslně velké." % ln["text"])
                    if q > 0 and ln["item_id"] not in kits:
                        left_q = remaining(fresh[ln["id"]]) if ln["id"] in fresh else 0
                        if q > left_q + EPS and not req.f("over_ok"):
                            raise BadInput("%s: zadáno %s, z objednávky zbývá %s. Když dodavatel opravdu poslal víc, zaškrtněte "
                                           "„Přišlo víc, než bylo objednáno“." % (ln["text"], fmt_qty(q), fmt_qty(left_q)))
                        db.run("INSERT INTO movements(item_id, date, qty, kind, unit_cost, doc, warehouse_id, note) "
                               "VALUES(?,?,?,?,?,?,?,?)", (ln["item_id"], req.f("date") or today(), q, "prijem", ln["price"],
                                                           o["number"], wh, "Objednávka %s" % o["number"]))
                        n += 1
                if not n:
                    raise BadInput("Zadejte, kolik zboží přišlo.")
                db.run("UPDATE orders SET received = 1 WHERE id = ?", (o["id"],))
                sync_received(db, o["id"])
                left = db.one("SELECT status FROM orders WHERE id = ?", (o["id"],))["status"] == "castecne"
            word = "položka" if n == 1 else "položky" if 2 <= n <= 4 else "položek"
            flash_redirect("/sklad/objednavky/%d" % o["id"], "Naskladněna %d %s%s. Až přijde faktura, zapište ji tlačítkem "
                           "„Faktura k naskladněnému zboží“." % (n, word, " – zbytek objednávky se čeká" if left else "")
                           if n == 1 else "Naskladněno %d %s%s. Až přijde faktura, zapište ji tlačítkem „Faktura k naskladněnému "
                           "zboží“." % (n, word, " – zbytek objednávky se čeká" if left else ""))
        trs = "".join("<tr><td>%s</td><td class=num>%s %s</td><td class=num>%s</td><td><input name='q_%d' value='%s' "
                      "inputmode='decimal' style='width:6rem'></td></tr>" % (
                          h(ln["text"]), fmt_qty(ln["qty"]), h(ln["unit"]), fmt_qty(ln["received"] or 0) if ln["received"] else "",
                          ln["id"], fmt_qty(remaining(ln)) if remaining(ln) > EPS else "") for ln in lines)
        return app.page("Naskladnit", """<div class="bar"><a href="/sklad/objednavky/%d">← Zpět</a></div>
<h1>Naskladnit objednávku %s bez faktury</h1><p class="hint">Použijte, když zboží přišlo s dodacím listem a faktura dorazí
později. Když nepřišlo všechno, zadejte jen to, co přišlo – objednávka zůstane „částečně dodaná“ a na zbytek se bude čekat.
Fakturu pak zapište z objednávky tlačítkem „Faktura k naskladněnému zboží“ – naskladnění bude vypnuté, aby se zboží
nepřičetlo dvakrát.</p>
<form method="post" class="card grid">%s<label>Datum příjmu<input type="date" name="date" value="%s"></label>%s
<div class="wide"><table class="list"><thead><tr><th>Položka</th><th class=num>Objednáno</th><th class=num>Už dodáno</th><th>Přišlo teď</th></tr></thead>
<tbody>%s</tbody></table></div><label class="check wide"><input type="checkbox" name="over_ok" value="1"> Přišlo víc, než bylo
objednáno</label><div class="actions wide"><button class="btn primary">Naskladnit</button></div></form>""" % (
            o["id"], h(o["number"]), app.csrf(), today(), wh_select(db, default_wh(db, req), label="Do skladu"),
            trs or "<tr><td colspan=4 class=empty>Objednávka nemá položky ze skladu.</td></tr>"), "/sklad")

    app.order_for_purchase = lambda oid: (get(oid), [dict(x) for x in olines(db, oid)])
    app.order_sync = lambda oid, keep_closed=False: sync_received(db, oid, keep_closed)
    app.order_closed_short = lambda oid: closed_short(db, oid)
    app.order_over = lambda oid, lines, old=None, skip_pid=None: over_message(db, oid, lines, old, skip_pid)
    app.order_uninvoiced = lambda oid: uninvoiced(db, oid)
