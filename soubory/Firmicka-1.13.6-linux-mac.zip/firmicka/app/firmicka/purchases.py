"""Přijaté faktury (od dodavatelů): kniha přijatých faktur, naskladnění s nákupní cenou,
úhrada do peněžního deníku, podklady k DPH (výstup z vydaných, odpočet z přijatých).
Formulář sdílí skript s vydanou fakturou (pole cust_* = dodavatel)."""
import json
from datetime import date, timedelta

from .contacts import address as contact_address
from .db import rnd, invoice_totals, next_invoice_number, line_fee, line_gross, gross_mode, today, now, VAT_RATES
from .invoices import PAYMENTS, lines_of
from . import docs
from .docs import auto_number, auto_number_input, doc_rev, rev_conflict, rev_input, REV_MSG
from .stock import items_json, item_options
from .warehouses import wh_select, read_wh, default_wh
from .web import h, money, qty, parse_money, parse_qty, parse_vat, parse_id, cz_date, flash, flash_redirect, allowed, HTTPError, Response

STATUS = {"neuhrazena": "Neuhrazená", "uhrazena": "Uhrazená"}


def plines(db, pid):
    return db.q("SELECT * FROM purchase_lines WHERE purchase_id = ? ORDER BY pos", (pid,))


def ptotals(p, lines):
    """Součty přijaté faktury. V režimu (přenesená daňová povinnost, EU, mimo EU) je doklad od dodavatele bez DPH:
    platí se jen základ (total = base, vat = 0); daň, kterou si odběratel sám přizná a odečte, je v „self“
    (rekapitulace podle sazeb řádků)."""
    t = invoice_totals(lines, True)
    if "regime" in p.keys() and p["regime"]:
        t = dict(t, total=t["base"], vat=0, self_recap=t["recap"], self_vat=t["vat"])
    return t


def unit_cost(ln, vat_payer):
    """Skladová cena za jednotku: plátce bez DPH (odpočte si ji), neplátce včetně DPH."""
    c = ln["price"] + line_fee(ln)
    return c if vat_payer else rnd(c * (100 + ln["vat_rate"]) / 100)


def sync_purchase(db, pid, vat_payer):
    """Naskladnění a zápis úhrady podle aktuálního stavu (volat v transakci)."""
    p = db.one("SELECT * FROM purchases WHERE id = ?", (pid,))
    db.run("DELETE FROM movements WHERE purchase_id = ?", (pid,))
    db.run("DELETE FROM cashbook WHERE purchase_id = ?", (pid,))
    lines = plines(db, pid)
    if p["stock_in"]:
        from .db import service_ids, kit_map
        svc = service_ids(db) | set(kit_map(db))      # služby a sady se nenaskladňují (sada = součásti)
        for ln in lines:
            if ln["item_id"] and ln["item_id"] not in svc:
                db.run("INSERT INTO movements(item_id, date, qty, kind, unit_cost, doc, purchase_id, warehouse_id) "
                       "VALUES(?,?,?,'nakup',?,?,?,?)", (ln["item_id"], p["tax_date"], ln["qty"],
                                                          unit_cost(ln, vat_payer), p["number"], pid, p["warehouse_id"]))
    if p["status"] == "uhrazena":
        total = ptotals(p, lines)["total"]
        db.run("INSERT INTO cashbook(date, doc, text, direction, account, amount, taxable, category, purchase_id) "
               "VALUES(?,?,?,'vydaj',?,?,1,'Materiál a zboží',?)",
               (p["paid_date"] or today(), p["doc_number"], "Úhrada faktury %s – %s" % (p["number"], p["supp_name"]),
                "pokladna" if p["payment"] == "hotove" else "banka", total, pid))


def register(app):
    db = app.db

    @app.route("/prijate")
    def index(req):
        year = req.args.get("rok", "")
        year = year if year.isdigit() and len(year) == 4 else today()[:4]
        st = req.args.get("stav", "")
        sql, args = "SELECT * FROM purchases WHERE substr(tax_date, 1, 4) = ?", [year]
        if st in STATUS:
            sql += " AND status = ?"
            args.append(st)
        rows = db.q(sql + " ORDER BY tax_date DESC, id DESC", args)
        trs, unpaid = [], 0
        for r in rows:
            t = ptotals(r, plines(db, r["id"]))["total"]
            if r["status"] == "neuhrazena":
                unpaid += t
            overdue = r["status"] == "neuhrazena" and r["due_date"] < today()
            trs.append("<tr%s><td><a href='/prijate/%d'>%s</a></td><td>%s</td><td>%s</td><td>%s</td><td>%s</td>"
                       "<td class=num>%s</td><td><span class='tag %s'>%s</span></td></tr>" % (
                           " class=warn" if overdue else "", r["id"], h(r["doc_number"]), h(r["number"]), h(r["supp_name"]),
                           cz_date(r["tax_date"]), cz_date(r["due_date"]), money(t),
                           "vystavena" if r["status"] == "neuhrazena" else "zaplacena",
                           "Po splatnosti" if overdue else STATUS[r["status"]]))
        ssel = "".join('<option value="%s"%s>%s</option>' % (k, " selected" if k == st else "", v)
                       for k, v in [("", "Všechny")] + list(STATUS.items()))
        return app.page("Přijaté faktury", """%s<div class="bar"><h1>Přijaté faktury</h1>
<a class="btn" href="/export">Export pro účetní</a><a class="btn" href="/dph">Podklady k DPH</a><a class="btn" href="/prijate/isdoc-hromadne">Import ISDOC hromadně</a><a class="btn primary" href="/prijate/nova">+ Přijatá faktura</a></div>
<form class="filters"><input name="rok" value="%s" size="4" inputmode="numeric">
<select name="stav" onchange="this.form.submit()">%s</select><button class="btn">Zobrazit</button>
<a class="btn" href="/export/prijate.csv?rok=%s">Export CSV</a></form>
<div class="stats"><div><span>Neuhrazeno dodavatelům</span><b class=out>%s</b></div></div>
<table class="list"><thead><tr><th>Evid. č.</th><th>Číslo dodavatele</th><th>Dodavatel</th><th>DUZP</th><th>Splatnost</th>
<th class=num>Celkem</th><th>Stav</th></tr></thead><tbody>%s</tbody></table>%s""" % (
            flash(req), h(year), ssel, h(year), money(unpaid), "".join(trs),
            "" if rows else "<p class=empty>V tomto roce žádné přijaté faktury.</p>"), "/prijate")

    def form(req, p, lines, pid=None, err=""):
        contacts = db.q("SELECT * FROM contacts ORDER BY name COLLATE NOCASE")
        contacts_js = json.dumps({str(c["id"]): {"name": c["name"], "ico": c["ico"], "dic": c["dic"],
                                                 "address": contact_address(c)} for c in contacts}, ensure_ascii=False)
        copts = '<option value="">— vybrat z adresáře —</option>' + "".join(
            '<option value="%d"%s>%s</option>' % (c["id"], " selected" if str(c["id"]) == str(p.get("contact_id") or "") else "",
                                                  h(c["name"])) for c in contacts)
        items = db.q("SELECT * FROM items WHERE active = 1 ORDER BY name COLLATE NOCASE")
        iopts = item_options(items, "volný text")
        pay = "".join('<option value="%s"%s>%s</option>' % (k, " selected" if k == p.get("payment", "prevod") else "", v)
                      for k, v in PAYMENTS.items())
        vat_opts = "".join('<option value="%d">%d %%</option>' % (v, v) for v in VAT_RATES)
        rows = docs.editor_rows(lines)
        vp = req.settings["vat_payer"] == "1"
        isdoc_form = "" if pid else """<form method="post" action="/prijate/isdoc" enctype="multipart/form-data" class="filters card">
%s<b>Máte fakturu v ISDOC?</b><input type="file" name="isdoc" accept=".isdoc,.isdocx,.xml" required>
<button class="btn">Načíst a předvyplnit</button><a class="btn" href="/prijate/isdoc-hromadne">Víc faktur najednou</a></form>""" % app.csrf()
        action = "/prijate/%s/upravit" % pid if pid else "/prijate/nova"
        return app.page("Přijatá faktura", ("""<h1>%s</h1>%s""" + isdoc_form + """
<form method="post" action=\"""" + action + """\" id="invoice" data-vat="1" data-purchase="1">%s
<div class="grid">
<section class="card wide"><h2>Dodavatel</h2><div class="grid">
<label class="wide">Z adresáře<select name="contact_id" data-contacts='%s'>%s</select></label>
<label class="wide">Název<input name="cust_name" value="%s" required></label>
<label>IČO<span class="row"><input name="cust_ico" value="%s"><button type="button" class="btn" data-ares-inv>ARES</button></span></label>
<label>DIČ<input name="cust_dic" value="%s"></label>
<label class="wide">Adresa<textarea name="cust_address" rows="2">%s</textarea></label>
<label>Účet dodavatele<input name="supp_account" value="%s"></label>
<label class="check"><input type="checkbox" name="save_contact" value="1"> Uložit do adresáře</label>
</div></section>
<label>Evidenční číslo<input name="doc_number" value="%s" required>%s</label>
<label>Číslo faktury dodavatele<input name="number" value="%s" required></label>
<label>Variabilní symbol<input name="vs" value="%s"></label>
<label>Datum vystavení<input type="date" name="issue_date" value="%s" required></label>
<label>DUZP<input type="date" name="tax_date" value="%s"></label>
<label>Splatnost<input type="date" name="due_date" value="%s" required></label>
<label>Způsob platby<select name="payment">%s</select></label>
<label class="check"><input type="checkbox" name="stock_in" value="1"%s> Naskladnit položky ze skladu</label>
%s
</div>
<h2>Položky</h2><p class="hint">Ceny a sazba podle faktury dodavatele (neplátce DPH: sazba 0 %%). Má-li dodavatel na faktuře ceny s DPH (DPH vypočtené shora), zaškrtněte „Ceny s DPH“ a opište částky s DPH.%s</p>%s
<div class="filters"><input id="scan" placeholder="Pípněte EAN – přidá položku" data-scan inputmode="numeric">
<span class="hint" id="scan-msg"></span></div>
<table class="lines"><thead><tr><th>Do skladu</th><th>Popis</th><th class=num>Množství</th><th>Jedn.</th>
<th class=num>Cena/j. bez DPH</th><th class=num>Cena/j. s DPH</th><th class=num>Rec. popl./j.</th><th>DPH</th><th class="num sum-head">Celkem</th><th></th></tr></thead>
<tbody id="lines" data-items='%s' data-rows='%s'></tbody></table>
<template id="line-tpl"><tr>
<td><select name="line_item">%s</select></td><td><input name="line_text"></td>
<td><input name="line_qty" class=num inputmode="decimal" value="1"></td><td><input name="line_unit" value="ks" size="4"></td>
<td><input name="line_price" class=num inputmode="decimal"></td><td><input class="num line-gross" inputmode="decimal" aria-label="Cena za jednotku s DPH"><small class="hint gross-hint" hidden></small></td>
<td><input name="line_fee" class=num inputmode="decimal" placeholder="0"></td><td><select name="line_vat">%s</select></td>
<td class="num line-total"><input name="line_total" class="num line-sum" inputmode="decimal" aria-label="Celkem za řádek"><small class="hint sum-hint" hidden></small></td><td><button type="button" class="link danger" data-del>✕</button></td></tr></template>
<p><button type="button" class="btn" id="add-line">+ Přidat řádek</button> <span class="hint" id="stock-warn"></span></p>
<div class="totals" id="totals"></div>
<label class="wide">Poznámka<textarea name="note" rows="2">%s</textarea></label>
<div class="actions"><button class="btn primary">Uložit</button><a class="btn" href="%s">Zrušit</a></div>
</form>""") % (
            "Upravit přijatou fakturu %s" % h(p["doc_number"]) if pid else "Nová přijatá faktura",
            ('<div class="flash error">%s</div>' % h(err) if err else "") + (p.get("notice") or ""),
            app.csrf() + ('<input type="hidden" name="src_order" value="%s">' % h(p["src_order"]) if p.get("src_order") else "") +
            "".join('<input type="hidden" name="%s" value="1">' % k for k in ("over_ok", "dup_ok") if p.get(k)),
            h(contacts_js), copts,
            h(p.get("cust_name")), h(p.get("cust_ico")), h(p.get("cust_dic")), h(p.get("cust_address")),
            h(p.get("supp_account")), h(p["doc_number"]),
            rev_input(p) if pid else auto_number_input(p, field="doc_number", date_field=""), h(p.get("number")), h(p.get("vs")), h(p["issue_date"]),
            h(p["tax_date"]), h(p["due_date"]), pay, " checked" if p.get("stock_in", 1) else "",
            wh_select(db, p.get("warehouse_id") or default_wh(db, req), label="Naskladnit do skladu") + (
                """<section class="card wide"><h2>Režim DPH</h2><div class="grid"><label class="wide">Režim%s</label>
<label class="wide">Kód předmětu plnění <span class="hint">(jen přenesená daňová povinnost)</span>%s</label>
<p class="hint wide">Faktura od dodavatele je <b>bez DPH</b> – u položek nechte sazbu, kterou si DPH sami přiznáte a zároveň
odečtete (samovyměření; do přiznání i kontrolního hlášení se zapíše samo). Dodavateli zaplatíte jen základ.</p></div></section>""" % (
                    __import__("firmicka.regimes", fromlist=["x"]).regime_select(
                        "regime", __import__("firmicka.regimes", fromlist=["x"]).RECEIVED, p.get("regime") or ""),
                    __import__("firmicka.regimes", fromlist=["x"]).code_select("pdp_code", p.get("pdp_code") or ""))
                if vp else ""),
            "" if vp else " Nejste plátce DPH – do skladu se zboží zapíše za cenu včetně DPH.",
            docs.gross_toggle(p["prices_gross"] if "prices_gross" in p else gross_mode(lines), True),
            h(json.dumps(items_json(db), ensure_ascii=False)), h(rows), iopts, vat_opts, h(p.get("note")),
            "/prijate/%s" % pid if pid else "/prijate"), "/prijate")

    def read_form(req, fallback=None):
        p = {k: req.f(k) for k in ("doc_number", "number", "vs", "issue_date", "tax_date", "due_date", "payment",
                                   "cust_name", "cust_ico", "cust_dic", "supp_account", "contact_id")}
        p["cust_address"] = req.form.get("cust_address", "").strip()
        p["note"] = req.form.get("note", "").strip()
        p["stock_in"] = 1 if req.f("stock_in") else 0
        p["warehouse_id"] = read_wh(db, req, fallback)
        p["save_contact"] = req.f("save_contact")
        from . import regimes
        p["regime"] = req.f("regime") if req.settings["vat_payer"] == "1" and req.f("regime") in regimes.RECEIVED else ""
        p["pdp_code"] = req.f("pdp_code")[:3] if p["regime"] == "pdp" else ""
        p["tax_date"] = p["tax_date"] or p["issue_date"]
        if p["payment"] not in PAYMENTS:
            p["payment"] = "prevod"
        cols = [req.lst(k) for k in ("line_item", "line_text", "line_qty", "line_unit", "line_price", "line_vat", "line_fee",
                                     "line_total")]
        n = len(cols[0])
        cols = [c + [""] * (n - len(c)) for c in cols]
        p["prices_gross"] = docs.gross_flag(req, True)
        lines = []
        for it, text, q, unit, price, vat, fee, total in zip(*cols):
            if not text.strip() and not it:
                continue
            lines.append(docs.apply_gross({"item_id": parse_id(it), "text": text.strip(), "qty": parse_qty(q),
                                           "unit": unit.strip() or "ks", "price": parse_money(price), "vat_rate": parse_vat(vat),
                                           "recycling_fee": parse_money(fee)}, total, p["prices_gross"]))
        from .docs import check_items
        check_items(db, lines)
        return p, lines

    def validate(p, lines, pid=None):
        if not p["cust_name"]:
            return "Vyplňte dodavatele"
        if not p["number"] or not p["doc_number"]:
            return "Vyplňte číslo faktury dodavatele i evidenční číslo"
        if not lines:
            return "Faktura musí mít aspoň jednu položku"
        if db.one("SELECT id FROM purchases WHERE doc_number = ? AND id != ?", (p["doc_number"], pid or 0)):
            return "Evidenční číslo %s už existuje" % p["doc_number"]
        from . import regimes
        err = regimes.check_received(p.get("regime", ""), p.get("pdp_code", ""), p["cust_dic"])
        if err:
            return err
        if p.get("regime") and not any(ln["vat_rate"] for ln in lines):
            return "U faktury v režimu %s nastavte u položek sazbu DPH, kterou si daň přiznáte" % regimes.RECEIVED[p["regime"]].lower()
        for k in ("issue_date", "tax_date", "due_date"):
            try:
                date.fromisoformat(p[k])
            except ValueError:
                return "Neplatné datum"
        return ""

    def save(req, p, lines, pid=None):
        vp = req.settings["vat_payer"] == "1"
        with db.tx():
            cid = p["contact_id"] if p["contact_id"].isdigit() else None
            if p["save_contact"] and not cid:
                from .docs import find_by_ico
                cid = find_by_ico(db, p["cust_ico"])
            if p["save_contact"] and not cid:
                street, _, rest = p["cust_address"].partition("\n")
                zip_, _, city = rest.split("\n")[0].strip().partition(" ")
                cid = db.run("INSERT INTO contacts(name, ico, dic, street, city, zip) VALUES(?,?,?,?,?,?)",
                             (p["cust_name"], p["cust_ico"], p["cust_dic"], street.strip(), city.strip(), zip_))
            vals = (p["number"], p["doc_number"], cid, p["cust_name"], p["cust_address"], p["cust_ico"], p["cust_dic"],
                    p["supp_account"], p["issue_date"], p["tax_date"], p["due_date"], p["payment"], p["vs"], p["note"],
                    p["stock_in"], p["warehouse_id"], p.get("regime", ""), p.get("pdp_code", ""))
            cols = ("number, doc_number, contact_id, supp_name, supp_address, supp_ico, supp_dic, supp_account, "
                    "issue_date, tax_date, due_date, payment, vs, note, stock_in, warehouse_id, regime, pdp_code")
            if pid:
                db.run("UPDATE purchases SET %s WHERE id = ?" % ", ".join(c.strip() + "=?" for c in cols.split(",")),
                       vals + (pid,))
                db.run("DELETE FROM purchase_lines WHERE purchase_id = ?", (pid,))
            else:
                pid = db.run("INSERT INTO purchases(%s, created) VALUES(%s)" % (cols, ",".join("?" * (len(vals) + 1))),
                             vals + (now(),))
            for pos, ln in enumerate(lines):
                db.run("INSERT INTO purchase_lines(purchase_id, pos, item_id, text, qty, unit, price, vat_rate, recycling_fee, gross) "
                       "VALUES(?,?,?,?,?,?,?,?,?,?)", (pid, pos, ln["item_id"], ln["text"], ln["qty"], ln["unit"],
                                                       ln["price"], ln["vat_rate"], ln["recycling_fee"], line_gross(ln)))
            sync_purchase(db, pid, vp)
        return pid

    def get(pid):
        p = db.one("SELECT * FROM purchases WHERE id = ?", (pid,))
        if not p:
            raise HTTPError(404, "Přijatá faktura neexistuje")
        return p

    def as_form(p):
        d = dict(p)
        d.update(cust_name=p["supp_name"], cust_ico=p["supp_ico"], cust_dic=p["supp_dic"], cust_address=p["supp_address"])
        return d

    @app.route("/prijate/nova", ("GET", "POST"))
    def new(req):
        if req.method == "POST":
            p, lines = read_form(req)
            p["src_order"] = str(parse_id(req.f("src_order")) or "")
            with db.lock:   # kontrola čísla/zálohy a zápis naráz (souběh více uživatelů)
                p["doc_number"], num_msg = auto_number(db, req, p["doc_number"], today(), req.settings["purchase_format"],
                                                       "purchases", "doc_number")
                p["number_auto"] = p["doc_number"] if num_msg else req.f("number_auto")
                err = validate(p, lines)
                if err:
                    return form(req, p, lines, err=err)
                p["over_ok"], p["dup_ok"] = req.f("over_ok"), req.f("dup_ok")
                dup = db.one("SELECT doc_number FROM purchases WHERE number = ? AND (supp_ico = ? AND supp_ico != '' OR "
                             "supp_ico = '' AND ? = '' AND supp_name = ? COLLATE NOCASE)",
                             (p["number"], p["cust_ico"], p["cust_ico"], p["cust_name"]))
                if dup and not p["dup_ok"]:
                    p["dup_ok"] = "1"
                    return form(req, p, lines, err="Faktura %s od tohoto dodavatele už je zapsaná jako %s. Jde-li o jiný doklad se "
                                                   "stejným číslem, uložte znovu." % (p["number"], dup["doc_number"]))
                order = db.one("SELECT * FROM orders WHERE id = ?", (int(p["src_order"]),)) if p["src_order"] else None
                if order:
                    if order["status"] == "zrusena" or (p["stock_in"] and order["status"] == "dodana"):
                        p["src_order"] = ""
                        return form(req, p, lines, err="Objednávka %s je mezitím %s. Pokud jde o tutéž dodávku, fakturu neukládejte. "
                                    "Dalším uložením se zapíše jako samostatná faktura bez vazby na objednávku." % (
                                        order["number"], "zrušená" if order["status"] == "zrusena" else "dodaná nebo uzavřená"))
                    if p["stock_in"]:
                        over = app.order_over(order["id"], lines)
                    else:
                        left = {}
                        for ln, q in app.order_uninvoiced(order["id"]):
                            if ln["item_id"]:
                                left[ln["item_id"]] = left.get(ln["item_id"], 0) + q
                        want = {}
                        for ln in lines:
                            if ln.get("item_id"):
                                want[ln["item_id"]] = want.get(ln["item_id"], 0) + (ln["qty"] or 0)
                        ordered_ids = {ln["item_id"] for ln in app.order_for_purchase(order["id"])[1] if ln["item_id"]}
                        over = "; ".join("%s: fakturujete %s, nevyfakturováno zbývá %s" % (
                            next(ln["text"] for ln in lines if ln.get("item_id") == i), qty(q), qty(left.get(i, 0)))
                            for i, q in want.items() if i in ordered_ids and q > left.get(i, 0) + 1e-9)
                    if over and not p["over_ok"]:
                        p["over_ok"] = "1"
                        return form(req, p, lines, err="Množství nesedí s objednávkou %s – %s. Pokud je to správně, uložte "
                                                       "znovu." % (order["number"], over))
                pid = save(req, p, lines)
                if order:
                    with db.tx():     # faktura k objednávce: propojit a dodané kusy přepočítat z dokladů
                        db.run("UPDATE purchases SET order_id = ? WHERE id = ?", (order["id"], pid))
                        db.run("UPDATE orders SET purchase_id = ? WHERE id = ? AND purchase_id IS NULL", (pid, order["id"]))
                        app.order_sync(order["id"])
            flash_redirect("/prijate/%d" % pid, "Přijatá faktura zapsána" + (" a zboží naskladněno" if p["stock_in"] else "") +
                           (" · " + num_msg if num_msg else ""))
        oid = parse_id(req.args.get("objednavka"))
        o = db.one("SELECT * FROM orders WHERE id = ?", (oid,)) if oid else None
        if o:
            only_invoice = req.args.get("bez_naskladneni") == "1"     # zboží už přišlo bez faktury, teď jen faktura
            if not only_invoice and o["status"] not in ("koncept", "odeslana", "castecne"):
                flash_redirect("/sklad/objednavky/%d" % o["id"], "Objednávka je uzavřená – zboží už nejde přijmout")
            p = new_defaults(req)
            p.update({"cust_name": o["supp_name"], "cust_ico": o["supp_ico"], "cust_address": o["supp_address"],
                      "contact_id": str(o["contact_id"] or ""), "note": "Podle objednávky %s" % o["number"],
                      "src_order": str(o["id"]), "stock_in": 0 if only_invoice else 1})
            rows = db.q("SELECT * FROM order_lines WHERE order_id = ? ORDER BY pos", (o["id"],))
            billed = {r[0] for r in db.q("SELECT l.text FROM purchase_lines l JOIN purchases x ON x.id = l.purchase_id "
                                         "WHERE x.order_id = ? AND l.item_id IS NULL", (o["id"],))}
            if only_invoice:
                pairs = app.order_uninvoiced(o["id"])
                if not any(ln["item_id"] for ln, _ in pairs):
                    flash_redirect("/sklad/objednavky/%d" % o["id"], "Všechno naskladněné zboží z objednávky už je vyfakturované")
                p["notice"] = ("<div class='flash'>Zboží z objednávky %s už je naskladněné – naskladnění je proto vypnuté, "
                               "aby se nepřičetlo dvakrát. Předvyplněné je jen to, co ještě není vyfakturované.</div>" % h(o["number"]))
            else:
                pairs = [(ln, max(ln["qty"] - (ln["received"] or 0), 0) if ln["item_id"] else ln["qty"])
                         for ln in rows if ln["item_id"] or ln["text"] not in billed]
                if any((ln["received"] or 0) > 0 for ln in rows):
                    p["notice"] = ("<div class='flash'>Část objednávky %s už přišla – předvyplněné je jen to, co zbývá. Když "
                                   "nepřišlo všechno, upravte množství; na zbytek se bude dál čekat.</div>" % h(o["number"]))
            lines = [{"item_id": ln["item_id"], "text": ln["text"], "qty": q, "unit": ln["unit"], "price": ln["price"],
                      "vat_rate": ln["vat_rate"] if req.settings["vat_payer"] == "1" else 0, "recycling_fee": 0}
                     for ln, q in pairs if q > 1e-9]
            return form(req, p, lines)
        return form(req, new_defaults(req), [])

    def new_defaults(req):
        d = today()
        return {"doc_number": next_invoice_number(db, d, req.settings["purchase_format"], "purchases", "doc_number"),
                "issue_date": d, "tax_date": d, "due_date": (date.today() + timedelta(days=14)).isoformat(), "stock_in": 1}

    @app.route("/prijate/isdoc", ("POST",))
    def from_isdoc(req):
        from . import isdoc
        f = req.files.get("isdoc")
        if not f:
            flash_redirect("/prijate/nova", "Vyberte soubor ISDOC")
        try:
            head, lines = isdoc.parse(f[1])
        except Exception as e:
            return form(req, new_defaults(req), [], err="ISDOC se nepodařilo načíst: %s" % e)
        p = new_defaults(req)
        cur = head.pop("currency", "CZK")
        doc_type, warnings = head.pop("doc_type", "1"), head.pop("warnings", [])
        if doc_type == "4":
            return form(req, new_defaults(req), [], err="Tohle je zálohová faktura – není to daňový doklad a DPH z ní "
                        "odečíst nejde. Zapište ji až jako daňový doklad k přijaté platbě nebo konečnou fakturu.")
        p.update({k: v for k, v in head.items() if v})
        if cur != "CZK":
            p["note"] = "\n".join(x for x in ("Faktura vystavena v měně %s – částky přepočteny na Kč." % cur, p.get("note")) if x)
        known = db.one("SELECT id FROM contacts WHERE ico = ? AND ico != ''", (head["cust_ico"],))
        if known:
            p["contact_id"] = known["id"]
        # řádky se jménem shodným se skladovou položkou rovnou napojit na sklad
        for ln in lines:
            it = db.one("SELECT id FROM items WHERE name = ? COLLATE NOCASE AND active = 1", (ln["text"],))
            if it:
                ln["item_id"] = it["id"]
        if cur != "CZK":
            return form(req, p, lines, err="POZOR: faktura je v měně %s – ceny položek níže jsou v %s, ne v Kč. Přepočtěte je "
                                           "na Kč kurzem ČNB ke dni zdanitelného plnění a teprve pak uložte." % (cur, cur))
        msg = "Načteno z ISDOC – zkontrolujte a uložte" if lines else "V ISDOC nejsou položky"
        if doc_type == "2":
            msg = "Načten DOBROPIS od dodavatele – položky jsou záporné (snižují odpočet DPH). Zkontrolujte a uložte"
        return form(req, p, lines, err=" · ".join([msg] + warnings))

    # ---------- hromadný import ISDOC ----------
    BULK_MAX = 300

    def bulk_docs(files):
        """Nahrané soubory (.isdoc, .isdocx, ZIP s fakturami – i ve složkách) → [(název, bajty jedné faktury)]."""
        import io
        import zipfile
        out = []
        for name, raw in files:
            if raw[:2] == b"PK":
                try:
                    z = zipfile.ZipFile(io.BytesIO(raw))
                    inner = [n for n in z.namelist() if n.lower().endswith((".isdoc", ".isdocx")) and not n.endswith("/")]
                except zipfile.BadZipFile:
                    out.append((name, raw))
                    continue
                isdocs = [n for n in inner if n.lower().endswith(".isdoc")]
                if name.lower().endswith(".isdocx") or (len(isdocs) == 1 and len(inner) == 1 and
                                                        not any("/" in n for n in inner) and not name.lower().endswith(".zip")):
                    out.append((name, raw))                 # .isdocx = jedna faktura (+ přílohy)
                else:
                    total = 0
                    for n in sorted(inner)[:BULK_MAX + 1]:     # víc než limit se stejně odmítne – nerozbalovat
                        size = z.getinfo(n).file_size
                        total += size
                        if size > 5_000_000 or total > 60_000_000:   # ochrana proti „ZIP bombě“
                            out.append((n.rsplit("/", 1)[-1], b""))
                        else:
                            out.append((n.rsplit("/", 1)[-1], z.read(n)))
            else:
                out.append((name, raw))
        return out

    def bulk_analyse(docs_):
        """Každá faktura → dict: name, raw, head, lines, status ok|varovani|chyba|duplicita, msg."""
        from . import isdoc
        res, seen = [], {}
        for name, raw in docs_:
            r = {"name": name, "raw": raw, "head": None, "lines": [], "status": "ok", "msg": ""}
            res.append(r)
            if not raw:
                r.update(status="chyba", msg="soubor je příliš velký")
                continue
            try:
                head, lines = isdoc.parse(raw)
            except Exception as e:
                r.update(status="chyba", msg="nejde načíst: %s" % e)
                continue
            r["head"], r["lines"] = head, lines
            if head.get("doc_type") == "4":
                r.update(status="chyba", msg="zálohová faktura – není daňový doklad, zapište až daňový doklad k platbě")
            elif head.get("currency", "CZK") != "CZK":
                r.update(status="chyba", msg="faktura v měně %s – načtěte ji jednotlivě a přepočtěte na Kč" % head["currency"])
            elif not head["number"]:
                r.update(status="chyba", msg="chybí číslo faktury")
            elif not head["cust_name"]:
                r.update(status="chyba", msg="chybí dodavatel")
            elif not lines:
                r.update(status="chyba", msg="faktura nemá položky")
            elif head.get("regime"):
                r.update(status="chyba", msg="přenesená daňová povinnost – načtěte ji jednotlivě (doplňte sazbu DPH k samovyměření)")
            else:
                key = (head["cust_ico"] or head["cust_name"].lower(), head["number"])
                dup = db.one("SELECT doc_number FROM purchases WHERE number = ? AND (supp_ico = ? AND supp_ico != '' OR "
                             "supp_ico = '' AND supp_name = ? COLLATE NOCASE)", (head["number"], head["cust_ico"], head["cust_name"]))
                if dup:
                    r.update(status="duplicita", msg="už je zapsaná jako %s" % dup["doc_number"])
                elif key in seen:
                    r.update(status="duplicita", msg="stejná faktura jako %s" % seen[key])
                else:
                    seen[key] = name
                    for k in ("issue_date", "tax_date", "due_date"):
                        try:
                            date.fromisoformat(head[k])
                        except ValueError:
                            r.update(status="chyba", msg="neplatné datum %s" % (head[k] or "(prázdné)"))
                            break
                    else:
                        if head.get("warnings"):
                            r.update(status="varovani", msg=" ".join(head["warnings"]))
        return res

    @app.route("/prijate/isdoc-hromadne", ("GET", "POST"))
    def bulk_isdoc(req):
        import base64
        vp = req.settings["vat_payer"] == "1"
        files = req.file_lists.get("soubory", [])
        if req.method == "GET" or not (files or req.lst("doc_data")):
            return app.page("Hromadný import ISDOC", """%s<div class="bar"><h1>Přijaté faktury z ISDOC – hromadně</h1></div>
<section class="card"><form method="post" enctype="multipart/form-data">%s
<p>Vyberte víc souborů najednou (<b>.isdoc</b>, <b>.isdocx</b>) nebo <b>ZIP</b> s fakturami – třeba export z jiného programu
nebo faktury stažené z e-mailu. V dalším kroku uvidíte přehled; zatím se nic neuloží.</p>
<p><input type="file" name="soubory" accept=".isdoc,.isdocx,.xml,.zip" multiple required>
<button class="btn primary">Načíst přehled</button> <a class="btn" href="/prijate">Zpět</a></p>
<p class="hint">Faktury, které už máte zapsané (stejný dodavatel a číslo), se poznají a přeskočí. Zálohové faktury a faktury
v cizí měně se hromadně nenačítají.</p></form></section>""" % (flash(req), app.csrf()), "/prijate")
        if files:
            docs_ = bulk_docs(files)
        else:
            docs_ = []
            for nm, data in zip(req.lst("doc_name"), req.lst("doc_data")):
                try:
                    docs_.append((nm, base64.b64decode(data, validate=True)))
                except ValueError:
                    raise HTTPError(400, "Poškozená data importu – nahrajte soubory znovu")
        if len(docs_) > BULK_MAX:
            flash_redirect("/prijate/isdoc-hromadne", "Najednou jde načíst nejvýš %d faktur (vybráno %d)" % (BULK_MAX, len(docs_)))
        if not docs_:
            flash_redirect("/prijate/isdoc-hromadne", "V nahraných souborech není žádná faktura ISDOC")
        res = bulk_analyse(docs_)
        stock_in = 1 if (req.f("stock_in") if not files else "1") else 0
        save_contacts = 1 if (req.f("save_contact") if not files else "1") else 0
        if req.f("akce") == "import":
            chosen = set(req.lst("vybrat"))
            wh = read_wh(db, req)
            done, errs = [], []
            for i, r in enumerate(res):
                if str(i) not in chosen or r["status"] not in ("ok", "varovani"):
                    continue
                head, lines = dict(r["head"]), [dict(ln) for ln in r["lines"]]
                warnings = head.pop("warnings", [])
                doc_type = head.pop("doc_type", "1")
                head.pop("currency", None)
                for ln in lines:
                    it = db.one("SELECT id FROM items WHERE name = ? COLLATE NOCASE AND active = 1", (ln["text"],))
                    ln["item_id"] = it["id"] if it else None
                note = "\n".join(x for x in ["Načteno z ISDOC (%s)" % r["name"]] +
                                 (["Dobropis od dodavatele"] if doc_type == "2" else []) + warnings + [head.get("note", "")] if x)
                known = db.one("SELECT id FROM contacts WHERE ico = ? AND ico != ''", (head["cust_ico"],))
                p = dict(head, note=note, contact_id=str(known["id"]) if known else "", stock_in=stock_in, warehouse_id=wh,
                         save_contact="1" if save_contacts else "")
                with db.lock:
                    dup = db.one("SELECT doc_number FROM purchases WHERE number = ? AND (supp_ico = ? AND supp_ico != '' OR "
                                 "supp_ico = '' AND supp_name = ? COLLATE NOCASE)", (p["number"], p["cust_ico"], p["cust_name"]))
                    if dup:            # mezitím ji zapsal někdo jiný (souběh)
                        errs.append("%s: už je zapsaná jako %s" % (r["name"], dup["doc_number"]))
                        continue
                    p["doc_number"] = next_invoice_number(db, today(), req.settings["purchase_format"], "purchases", "doc_number")
                    err = validate(p, lines)
                    if err:
                        errs.append("%s: %s" % (r["name"], err))
                        continue
                    save(req, p, lines)
                done.append(p["doc_number"])
            n = len(done)
            msg = "Zapsáno %d %s%s" % (n, "přijatá faktura" if n == 1 else "přijaté faktury" if 2 <= n <= 4 else "přijatých faktur",
                                       (" (%s – %s)" % (done[0], done[-1])) if done else "")
            if errs:
                msg += " · nezapsáno: " + "; ".join(errs[:5])
            flash_redirect("/prijate", msg)
        state = {"ok": ("zaplacena", "v pořádku"), "varovani": ("vystavena", "zkontrolovat"),
                 "chyba": ("stornovana", "chyba"), "duplicita": ("", "přeskočí se")}
        trs = []
        for i, r in enumerate(res):
            hd = r["head"] or {}
            total = ""
            if r["lines"]:
                total = money(invoice_totals(r["lines"], True)["total"])
            can = r["status"] in ("ok", "varovani")
            trs.append("<tr><td><input type=checkbox name=vybrat value=%d%s%s></td><td><span class='tag %s'>%s</span>%s"
                       "<div class=hint>%s</div></td><td>%s<div class=hint>%s</div></td><td>%s</td><td>%s</td><td class=num>%s</td></tr>" % (
                           i, " checked" if r["status"] == "ok" else "", "" if can else " disabled", state[r["status"]][0],
                           state[r["status"]][1], " <span class=hint>%s</span>" % h(r["msg"]) if r["msg"] else "", h(r["name"]),
                           h(hd.get("cust_name", "")), h(hd.get("cust_ico", "")), h(hd.get("number", "")),
                           cz_date(hd["tax_date"]) if hd.get("tax_date") else "", total))
        hidden = "".join('<input type="hidden" name="doc_name" value="%s"><input type="hidden" name="doc_data" value="%s">' % (
            h(r["name"]), base64.b64encode(r["raw"]).decode()) for r in res)
        cnt = {k: sum(1 for r in res if r["status"] == k) for k in state}
        return app.page("Hromadný import ISDOC", """%s<div class="bar"><h1>Přijaté faktury z ISDOC – přehled</h1></div>
<form method="post">%s%s<input type="hidden" name="akce" value="import">
<div class="stats"><div><span>V pořádku</span><b>%d</b></div><div><span>Zkontrolovat</span><b>%d</b><small>nejsou předvybrané</small></div>
<div><span>Už zapsané</span><b>%d</b></div><div><span>Nejde načíst</span><b>%d</b></div></div>
<section class="card"><div class="scroll"><table class="list"><thead><tr><th></th><th>Stav / soubor</th><th>Dodavatel</th><th>Číslo</th>
<th>DUZP</th><th class=num>Celkem</th></tr></thead><tbody>%s</tbody></table></div>
<label class="check"><input type="checkbox" name="stock_in" value="1"%s> Naskladnit zboží <span class="hint">(řádky,
jejichž název se shoduje se skladovou položkou)</span></label>%s
<label class="check"><input type="checkbox" name="save_contact" value="1"%s> Nové dodavatele uložit do adresáře</label>
<p class="hint">Evidenční čísla se přidělí podle řady přijatých faktur. Faktury se zapíšou jako neuhrazené%s.</p>
<div class="actions"><button class="btn primary">Zapsat vybrané faktury</button><a class="btn" href="/prijate">Zrušit</a></div>
</section></form>""" % (flash(req), app.csrf(), hidden, cnt["ok"], cnt["varovani"], cnt["duplicita"], cnt["chyba"], "".join(trs),
                         " checked" if stock_in else "", wh_select(db, default_wh(db, req), label="Naskladnit do skladu"),
                         " checked" if save_contacts else "", "" if vp else "; jako neplátce DPH zapíšete zboží za cenu s DPH"),
            "/prijate")

    def stocked_items(pid):
        """Kolik kusů zboží přijatá faktura naskladnila (pro přepočet dodané objednávky)."""
        p = db.one("SELECT stock_in, order_id FROM purchases WHERE id = ?", (pid,))
        if not p or not p["order_id"] or not p["stock_in"]:
            return None, {}
        got = {}
        for ln in db.q("SELECT item_id, qty FROM purchase_lines WHERE purchase_id = ? AND item_id IS NOT NULL", (pid,)):
            got[ln["item_id"]] = got.get(ln["item_id"], 0) + (ln["qty"] or 0)
        return p["order_id"], got

    @app.route("/prijate/<pid>/upravit", ("GET", "POST"))
    def edit(req, pid):
        p = get(pid)
        if p["status"] == "uhrazena":
            flash_redirect("/prijate/%d" % p["id"], "Uhrazenou fakturu nejdřív vraťte na neuhrazenou")
        if req.method == "POST":
            np, lines = read_form(req, p["warehouse_id"])
            with db.lock:   # kontrola čísla/zálohy a zápis naráz (souběh více uživatelů)
                err = REV_MSG if rev_conflict(db, req, "purchases", p["id"], np) else validate(np, lines, p["id"])
                if err:
                    return form(req, np, lines, p["id"], err)
                oid = p["order_id"]
                if oid and np["stock_in"] and not req.f("over_ok"):
                    over = app.order_over(oid, lines, stocked_items(p["id"])[1], p["id"])
                    if over:          # např. zapnuté naskladnění u faktury k už naskladněnému zboží
                        np["over_ok"] = "1"
                        return form(req, np, lines, p["id"], "Množství nesedí s objednávkou – %s. Zboží by se mohlo "
                                    "naskladnit dvakrát. Pokud je to správně, uložte znovu." % over)
                keep = app.order_closed_short(oid) if oid else False
                save(req, np, lines, p["id"])
                if oid:
                    with db.tx():     # dodané kusy objednávky přepočítat z dokladů, ručně uzavřenou neotevírat
                        app.order_sync(oid, keep)
            flash_redirect("/prijate/%d" % p["id"], "Uloženo")
        return form(req, dict(as_form(p), rev=doc_rev(db, "purchases", p["id"])), [dict(ln) for ln in plines(db, p["id"])],
                    p["id"])

    @app.route("/prijate/<pid>/stav", ("POST",))
    def set_status(req, pid):
        p = get(pid)
        a = req.f("akce")
        with db.tx():
            if a == "zaplaceno" and p["status"] == "neuhrazena":
                db.run("UPDATE purchases SET status='uhrazena', paid_date=? WHERE id=?", (req.f("paid_date") or today(), p["id"]))
                msg = "Uhrazeno – výdaj zapsán do peněžního deníku"
            elif a == "nezaplaceno" and p["status"] == "uhrazena":
                db.run("UPDATE purchases SET status='neuhrazena', paid_date='' WHERE id=?", (p["id"],))
                msg = "Úhrada zrušena"
            else:
                raise HTTPError(400, "Tuto akci nejde provést")
            sync_purchase(db, p["id"], req.settings["vat_payer"] == "1")
        flash_redirect("/prijate/%d" % p["id"], msg)

    @app.route("/prijate/<pid>/smazat", ("POST",))
    def delete(req, pid):
        p = get(pid)
        with db.tx():
            row = db.one("SELECT order_id FROM purchases WHERE id = ?", (p["id"],))     # znovu až v transakci (souběh)
            if not row:
                raise HTTPError(404, "Přijatá faktura už je smazaná")
            oid = row["order_id"]
            keep = app.order_closed_short(oid) if oid else False
            db.run("DELETE FROM movements WHERE purchase_id = ?", (p["id"],))
            db.run("DELETE FROM cashbook WHERE purchase_id = ?", (p["id"],))
            db.run("DELETE FROM purchases WHERE id = ?", (p["id"],))
            if oid:
                app.order_sync(oid, keep)                   # zboží se odepíše → objednávka se zase čeká
        flash_redirect("/prijate", "Přijatá faktura %s smazána (i naskladnění a úhrada)" % p["doc_number"])

    @app.route("/prijate/<pid>")
    def detail(req, pid):
        p = get(pid)
        lines = plines(db, p["id"])
        t = ptotals(p, lines)
        trs = "".join("<tr><td>%s%s</td><td class=num>%s %s</td><td class=num>%s</td><td class=num>%s</td>"
                      "<td class=num>%d %%</td><td class=num>%s</td></tr>" % (
                          h(ln["text"]), " <span class=tag>sklad</span>" if ln["item_id"] and p["stock_in"] else "",
                          qty(ln["qty"]), h(ln["unit"]), money(ln["price"]),
                          money(line_fee(ln)) if line_fee(ln) else "", ln["vat_rate"],
                          money(line_gross(ln) if t["shora"] else rnd(ln["qty"] * (ln["price"] + line_fee(ln))))) for ln in lines)
        recap = "".join("<tr><td>%d %%</td><td class=num>%s</td><td class=num>%s</td><td class=num>%s</td></tr>" % (
            r["rate"], money(r["base"]), money(r["vat"]), money(r["total"])) for r in t["recap"])
        if p["status"] == "neuhrazena":
            act = ('<a class="btn" href="/prijate/%d/upravit">Upravit</a><form method="post" action="/prijate/%d/stav" '
                   'class="inline">%s<input type="hidden" name="akce" value="zaplaceno"><input type="date" name="paid_date" '
                   'value="%s"><button class="btn ok">Uhrazeno</button></form>' % (p["id"], p["id"], app.csrf(), today()))
        else:
            act = ('<form method="post" action="/prijate/%d/stav" class="inline">%s<input type="hidden" name="akce" '
                   'value="nezaplaceno"><button class="btn">Zrušit úhradu</button></form>' % (p["id"], app.csrf()))
        if allowed(req.perms, "/majetek") and any(ln["qty"] > 0 and ln["price"] >= 0 for ln in lines):   # ne u dobropisu
            act += '<a class="btn" href="/majetek/novy?prijata=%d">Zařadit do majetku</a>' % p["id"]
        act += ('<form method="post" action="/prijate/%d/smazat" class="inline" onsubmit="return confirm(\'Smazat přijatou '
                'fakturu včetně naskladnění?\')">%s<button class="link danger">smazat</button></form>' % (p["id"], app.csrf()))
        info = [(k, v) for k, v in [
            ("Číslo dodavatele", h(p["number"])), ("VS", h(p["vs"])), ("Vystaveno", cz_date(p["issue_date"])),
            ("DUZP", cz_date(p["tax_date"])), ("Splatnost", cz_date(p["due_date"])),
            ("Platba", PAYMENTS.get(p["payment"], "")), ("Účet dodavatele", h(p["supp_account"])),
            ("Stav", STATUS[p["status"]] + (" " + cz_date(p["paid_date"]) if p["paid_date"] else ""))] if v]
        return app.page("Přijatá " + p["doc_number"], """%s<div class="bar"><a href="/prijate">← Přijaté faktury</a>
<div class="actions">%s</div></div>
<section class="card"><h1>Přijatá faktura %s</h1><b>%s</b><div>%s</div><div class="hint">%s</div></section>
<div class="stats">%s</div>
<table class="list"><thead><tr><th>Popis</th><th class=num>Množství</th><th class=num>Cena/j.</th><th class=num>Rec./j.</th>
<th class=num>DPH</th><th class=num>%s</th></tr></thead><tbody>%s</tbody></table>
%s<h2>Rekapitulace%s</h2><table class="list"><thead><tr><th>Sazba</th><th class=num>Základ</th><th class=num>DPH</th>
<th class=num>Celkem</th></tr></thead><tbody>%s</tbody>
<tfoot><tr><th>Celkem k úhradě</th><th></th><th></th><th class=num>%s</th></tr></tfoot></table>%s""" % (
            flash(req), act, h(p["doc_number"]), h(p["supp_name"]), h(p["supp_address"]).replace("\n", ", "),
            " · ".join(x for x in ("IČO " + h(p["supp_ico"]) if p["supp_ico"] else "",
                                    "DIČ " + h(p["supp_dic"]) if p["supp_dic"] else "") if x),
            "".join("<div><span>%s</span><b class=small>%s</b></div>" % kv for kv in info),
            "Celkem s DPH" if t["shora"] else "Základ", trs,
            ("<div class='flash'>%s – faktura od dodavatele je bez DPH. Dodavateli se platí <b>%s</b>; DPH %s si přiznáváte "
             "a zároveň odečítáte (samovyměření), v přiznání a kontrolním hlášení se objeví samo.%s</div>" % (
                 h(__import__("firmicka.regimes", fromlist=["x"]).RECEIVED.get(p["regime"], p["regime"])), money(t["total"]),
                 money(t["self_vat"]), (" Kód předmětu plnění %s." % h(p["pdp_code"])) if p["pdp_code"] else "")
             if p["regime"] else ""), " (samovyměření DPH)" if p["regime"] else "", recap, money(t["total"]),
            "<p class=note>%s</p>" % h(p["note"]) if p["note"] else ""), "/prijate")

    # ---------- podklady k DPH ----------
    @app.route("/dph")
    def vat(req):
        year = req.args.get("rok", "")
        year = year if year.isdigit() and len(year) == 4 else today()[:4]
        per = req.args.get("obdobi", "mesic")
        periods = ([("%02d" % m, "%d. měsíc" % m) for m in range(1, 13)] if per == "mesic"
                   else [("Q%d" % q, "%d. čtvrtletí" % q) for q in range(1, 5)])

        def key(d):
            m = int(d[5:7])
            return "%02d" % m if per == "mesic" else "Q%d" % ((m - 1) // 3 + 1)
        out, inp = {}, {}

        def add(target, docs_sql, lines_table, fk, date_col):
            """Řádky všech dokladů roku jedním dotazem (dřív dotaz na každou účtenku → 1 s při 30 000 účtenkách)."""
            docs = db.q(docs_sql, (year,))
            lines = {}
            for ln in db.q("SELECT l.* FROM %s l JOIN (%s) d ON d.id = l.%s ORDER BY l.%s, l.pos" % (
                    lines_table, docs_sql, fk, fk), (year,)):
                lines.setdefault(ln[fk], []).append(ln)
            for d in docs:
                for r in invoice_totals(lines.get(d["id"], []), True)["recap"]:
                    b = target.setdefault(key(d[date_col]), {}).setdefault(r["rate"], [0, 0])
                    b[0] += r["base"]
                    b[1] += r["vat"]
        add(out, "SELECT id, tax_date FROM invoices WHERE status != 'stornovana' AND vat_payer = 1 AND kind != 'zaloha' "
                 "AND substr(tax_date,1,4) = ?", "invoice_lines", "invoice_id", "tax_date")
        add(out, "SELECT id, date FROM receipts WHERE status = 'ok' AND vat_payer = 1 AND substr(date,1,4) = ?",
            "receipt_lines", "receipt_id", "date")
        add(inp, "SELECT id, tax_date FROM purchases WHERE substr(tax_date,1,4) = ?", "purchase_lines", "purchase_id", "tax_date")
        # přijaté v režimu (přenesená daňová povinnost, EU, mimo EU): daň si plátce sám přizná (výstup) i odečte (vstup)
        add(out, "SELECT id, tax_date FROM purchases WHERE regime != '' AND substr(tax_date,1,4) = ?", "purchase_lines",
            "purchase_id", "tax_date")
        trs = []
        for k, name in periods:
            o, i = out.get(k, {}), inp.get(k, {})
            vo = sum(v[1] for v in o.values())
            vi = sum(v[1] for r, v in i.items() if r)
            if not o and not i:
                continue
            cells = []
            for rate in (21, 12):
                cells += [money(o.get(rate, [0, 0])[0]), money(o.get(rate, [0, 0])[1]),
                          money(i.get(rate, [0, 0])[0]), money(i.get(rate, [0, 0])[1])]
            trs.append("<tr><td class=nowrap>%s</td>%s<td class=num><b>%s</b></td></tr>" % (
                name, "".join("<td class=num>%s</td>" % c for c in cells), money(vo - vi)))
        sel = "".join('<option value="%s"%s>%s</option>' % (v, " selected" if v == per else "", t)
                      for v, t in (("mesic", "Měsíčně"), ("ctvrtleti", "Čtvrtletně")))
        warn = "" if req.settings["vat_payer"] == "1" else '<div class="flash">V nastavení nejste plátce DPH.</div>'
        return app.page("Podklady k DPH", """%s<div class="bar"><h1>Podklady k DPH %s</h1>
<button class="btn" onclick="window.print()">Tisk</button></div>
<form class="filters"><input name="rok" value="%s" size="4"><select name="obdobi" onchange="this.form.submit()">%s</select>
<button class="btn">Zobrazit</button></form>
<table class="list dense"><thead><tr><th rowspan=2>Období</th><th colspan=4>Sazba 21 %%</th><th colspan=4>Sazba 12 %%</th>
<th rowspan=2 class=num>Daň k úhradě<br>(− nadměrný odpočet)</th></tr>
<tr><th class=num>Výstup základ</th><th class=num>Výstup daň</th><th class=num>Vstup základ</th><th class=num>Odpočet</th>
<th class=num>Výstup základ</th><th class=num>Výstup daň</th><th class=num>Vstup základ</th><th class=num>Odpočet</th></tr></thead>
<tbody>%s</tbody></table>
%s
<p class="hint">Výstup = vydané faktury, dobropisy, daňové doklady k přijatým zálohám a účtenky z pokladny podle DUZP
(bez stornovaných a bez zálohových faktur), vstup = přijaté faktury podle DUZP. U přijatých faktur v režimu přenesené
daňové povinnosti a z EU je daň na výstupu i na vstupu (samovyměření). Plnění bez daně (přenesená daňová povinnost
u dodavatele, do EU, vývoz) tabulka nezobrazuje – jsou v přiznání v ř. 20–26. Podklad pro přiznání
k DPH a kontrolní hlášení – nárok na odpočet a zařazení do řádků přiznání ověřte s účetní.</p>""" % (
            warn, h(year), h(year), sel, "".join(trs) or "<tr><td colspan=10 class=empty>Žádné doklady.</td></tr>",
            epo_card(req, year, per)), "/dph")

    def epo_card(req, year, per):
        from . import epo
        s = req.settings
        miss = epo.check_settings(s)
        cur = date.today()
        if per == "mesic":
            opts = [("m%d" % m, "%d. měsíc" % m) for m in range(1, 13)]
            default = "m%d" % (cur.month - 1 or 12)
        else:
            opts = [("q%d" % q, "%d. čtvrtletí" % q) for q in range(1, 5)]
            default = "q%d" % ((cur.month - 1) // 3 or 4)
        psel = "".join('<option value="%s"%s>%s</option>' % (v, " selected" if v == default else "", t) for v, t in opts)
        bad = epo.bad_dics(db, "%s-01-01" % year, "%s-12-31" % year) if str(year).isdigit() else []
        badw = ""
        if bad:
            badw = ('<p class="flash error">EPO odmítne kontrolní hlášení s chybným DIČ (kontrolní součet). Zkontrolujte DIČ '
                    'u dokladů: %s%s.</p>' % (h(", ".join("%s %s (%s)" % b for b in bad[:10])),
                                              " a dalších %d" % (len(bad) - 10) if len(bad) > 10 else ""))
        if miss:
            body = '<p class="flash error">Pro export doplňte v <a href="/nastaveni#epo">Nastavení → Finanční úřad</a>: %s.</p>' % \
                   h(", ".join(miss))
        else:
            body = """<form class="filters" action="/dph/epo"><input name="rok" value="%s" size="4">
<select name="obdobi">%s</select>
<select name="forma"><option value="B">řádné</option><option value="O">řádné-opravné</option></select>
<button class="btn primary" name="co" value="dp3">Přiznání k DPH (XML)</button>
<button class="btn primary" name="co" value="kh1">Kontrolní hlášení (XML)</button>
<button class="btn" name="co" value="shv">Souhrnné hlášení – EU (XML)</button></form>""" % (h(year), psel)
            from .web import allowed
            if allowed(req.perms, "/datovka"):
                body += '<p><a class="btn" href="/datovka">Odeslat datovou schránkou…</a></p>'
        return """<section class="card"><h2>Podání přes EPO</h2>%s%s
<p class="hint">Soubor nahrajete na <b>adisspr.mfcr.cz → EPO → Elektronická podání pro finanční správu → Načíst ze souboru</b>,
kde ho EPO zkontroluje a odešlete (datovou schránkou nebo s ověřením). Pokrývá tuzemské plnění v sazbách 21 a 12 %%,
přenesenou daňovou povinnost, dodání zboží a služeb do EU (k tomu souhrnné hlášení), vývoz, pořízení z EU a odpočet
v plné výši. Dovoz zboží, krácený odpočet a třístranný obchod doplňte v EPO ručně. Před odesláním si údaje projděte;
za správnost podání odpovídáte vy.</p></section>""" % (badw, body)

    @app.route("/dph/epo")
    def epo_xml(req):
        from . import epo
        s = req.settings
        if epo.check_settings(s):
            flash_redirect("/dph", "Doplňte údaje pro finanční úřad v Nastavení")
        try:
            xml, name, _ = epo.build(db, s, req.args.get("co", ""), req.args.get("rok", ""), req.args.get("obdobi", ""),
                                     req.args.get("forma", ""))
        except epo.Empty as e:
            flash_redirect("/dph?rok=%s" % h(req.args.get("rok", "")), str(e))
        except ValueError as e:
            raise HTTPError(400, str(e))
        return Response(xml, ctype="application/xml", headers=[("Content-Disposition", 'attachment; filename="%s"' % name)])

    @app.route("/nastaveni/epo", ("POST",))
    def epo_settings(req):
        from .epo_codes import UFO, PRACUFO
        vals = {"epo_ufo": req.f("epo_ufo") if req.f("epo_ufo") in UFO else "",
                "epo_pracufo": req.f("epo_pracufo") if req.f("epo_pracufo") in PRACUFO else "",
                "epo_typ_ds": "F" if req.f("epo_typ_ds") == "F" else "P",
                "epo_jmeno": req.f("epo_jmeno"), "epo_prijmeni": req.f("epo_prijmeni"),
                "epo_opr_jmeno": req.f("epo_opr_jmeno")[:20], "epo_opr_prijmeni": req.f("epo_opr_prijmeni")[:36],
                "epo_opr_postaveni": req.f("epo_opr_postaveni")[:40],
                "epo_okec": "".join(c for c in req.f("epo_okec") if c.isdigit())[:6]}
        if vals["epo_pracufo"] and PRACUFO[vals["epo_pracufo"]][1] != vals["epo_ufo"]:
            flash_redirect("/nastaveni#epo", "Územní pracoviště nepatří k vybranému finančnímu úřadu")
        db.set_settings(vals)
        flash_redirect("/nastaveni#epo", "Údaje pro finanční úřad uloženy")


def epo_settings_form(app, s):
    from .epo_codes import UFO, PRACUFO
    ufo = '<option value="">— vyberte —</option>' + "".join(
        '<option value="%s"%s>%s</option>' % (k, " selected" if k == s["epo_ufo"] else "", h(v))
        for k, v in sorted(UFO.items(), key=lambda kv: kv[1]))
    prac = '<option value="">— vyberte —</option>' + "".join(
        '<option value="%s" data-ufo="%s"%s>%s</option>' % (k, u, " selected" if k == s["epo_pracufo"] else "", h(n))
        for k, (n, u) in sorted(PRACUFO.items(), key=lambda kv: kv[1][0]))
    return """<section class="card" id="epo"><h2>Finanční úřad (přiznání k DPH a kontrolní hlášení)</h2>
<form method="post" action="/nastaveni/epo" class="grid">%s
<label>Finanční úřad<select name="epo_ufo" id="epo_ufo">%s</select></label>
<label>Územní pracoviště<select name="epo_pracufo" id="epo_pracufo">%s</select></label>
<label>Daňový subjekt<select name="epo_typ_ds"><option value="P"%s>právnická osoba (s.r.o., a.s.…)</option>
<option value="F"%s>fyzická osoba (OSVČ)</option></select></label>
<label>CZ-NACE hlavní činnosti<input name="epo_okec" value="%s" inputmode="numeric" placeholder="např. 952100"></label>
<label>Jméno (OSVČ)<input name="epo_jmeno" value="%s"></label><label>Příjmení (OSVČ)<input name="epo_prijmeni" value="%s"></label>
<p class="wide hint">Za právnickou osobu podepisuje oprávněná osoba (jednatel, člen představenstva…):</p>
<label>Jméno oprávněné osoby<input name="epo_opr_jmeno" value="%s" maxlength="20"></label>
<label>Příjmení oprávněné osoby<input name="epo_opr_prijmeni" value="%s" maxlength="36"></label>
<label>Vztah k firmě<input name="epo_opr_postaveni" value="%s" maxlength="40" placeholder="jednatel"></label>
<p class="wide hint">DIČ, adresa, e-mail a telefon se berou z údajů firmy výše.</p>
<div class="actions wide"><button class="btn">Uložit</button></div></form>
<script>(function () { var u = document.getElementById("epo_ufo"), p = document.getElementById("epo_pracufo");
function f() { for (var o of p.options) { o.hidden = o.value && o.dataset.ufo !== u.value; }
  if (p.selectedOptions[0] && p.selectedOptions[0].hidden) p.value = ""; }
u.addEventListener("change", f); f(); })();</script></section>""" % (
        app.csrf(), ufo, prac, " selected" if s["epo_typ_ds"] != "F" else "", " selected" if s["epo_typ_ds"] == "F" else "",
        h(s["epo_okec"]), h(s["epo_jmeno"]), h(s["epo_prijmeni"]), h(s["epo_opr_jmeno"]), h(s["epo_opr_prijmeni"]),
        h(s["epo_opr_postaveni"]))
