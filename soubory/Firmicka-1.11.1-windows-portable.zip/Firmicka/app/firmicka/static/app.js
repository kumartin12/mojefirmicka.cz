// Firmička – formuláře: řádky faktury (ceny, DPH, součty), výběr z adresáře a skladu, ARES.
(function () {
  "use strict";
  var $ = function (s, el) { return (el || document).querySelector(s); };
  var $$ = function (s, el) { return Array.prototype.slice.call((el || document).querySelectorAll(s)); };

  function num(v) { v = String(v || "").replace(/\s| /g, "").replace(",", "."); var n = parseFloat(v); return isNaN(n) ? 0 : n; }
  function money(hal) {
    var neg = hal < 0; hal = Math.abs(Math.round(hal));
    var kc = Math.floor(hal / 100), h = hal % 100;
    return (neg ? "-" : "") + String(kc).replace(/\B(?=(\d{3})+(?!\d))/g, " ") + "," + (h < 10 ? "0" : "") + h + " Kč";
  }
  function fmtPrice(hal) { return (hal / 100).toFixed(2).replace(".", ","); }

  // ---------- kontrola čísel už v prohlížeči ----------
  // Stejná pravidla jako web._num. Formulář s překlepem se vůbec neodešle – řádky přidané skriptem
  // by se po „Zpět“ ze stránky s chybou ztratily (prohlížeč obnoví jen pole, která na stránce byla od začátku).
  var NUM_OK = /^[+-]?(\d+([.,]\d*)?|[.,]\d+)$/;
  function checkNum(el) {
    var t = String(el.value || "").replace(/[\s  ]/g, "").replace(/Kč/g, "");
    var bad = t !== "" && (!NUM_OK.test(t) || Math.abs(parseFloat(t.replace(",", "."))) > 1e9);
    el.setCustomValidity(bad ? "Zadejte číslo, např. 1 234,50" : "");
    return !bad;
  }
  var NUM_SEL = "input[inputmode=decimal]";
  document.addEventListener("input", function (e) {
    if (e.target.matches && e.target.matches(NUM_SEL)) checkNum(e.target);
  }, true);
  document.addEventListener("submit", function (e) {
    var bad = $$(NUM_SEL, e.target).filter(function (el) { return !checkNum(el); });
    if (bad.length) { e.preventDefault(); e.stopImmediatePropagation(); bad[0].reportValidity(); }
  }, true);
  document.addEventListener("click", function (e) {      // před odesláním: nativní bublina u pole s chybou
    var b = e.target.closest && e.target.closest("button, input[type=submit]");
    if (!(b && b.form && b.type === "submit" && !b.formNoValidate)) return;
    var bad = $$(NUM_SEL, b.form).filter(function (el) { return !checkNum(el); });
    if (bad.length) {               // pole ve sbaleném oddílu by prohlížeč neukázal a odeslání tiše zastavil
      for (var d = bad[0].closest("details"); d; d = d.parentElement && d.parentElement.closest("details")) d.open = true;
    }
  }, true);

  // ---------- ARES ----------
  function ares(ico, done) {
    var msg = $("#ares-msg");
    if (msg) msg.textContent = "Hledám…";
    fetch("/api/ares/" + encodeURIComponent(ico.replace(/\D/g, "")))
      .then(function (r) { return r.json(); })
      .then(function (j) {
        if (msg) msg.textContent = j.ok ? "Načteno z ARES" : j.error;
        if (j.ok) done(j.data); else if (!msg) alert(j.error);
      })
      .catch(function () { if (msg) msg.textContent = "ARES nedostupný"; });
  }
  $$("[data-ares]").forEach(function (b) {
    b.addEventListener("click", function () {
      var f = b.form;
      ares(f.ico.value, function (d) { Object.keys(d).forEach(function (k) { if (f[k] && d[k]) f[k].value = d[k]; }); });
    });
  });
  $$("[data-ares-firm]").forEach(function (b) {
    b.addEventListener("click", function () {
      var f = b.form;
      ares(f.firm_ico.value, function (d) {
        var map = { name: "firm_name", dic: "firm_dic", street: "firm_street", city: "firm_city", zip: "firm_zip" };
        Object.keys(map).forEach(function (k) { if (d[k]) f[map[k]].value = d[k]; });
      });
    });
  });

  // ---------- čtečka čárových kódů ----------
  // čtečka = rychlé psaní + Enter; Enter v poli čtečky nikdy neodešle formulář
  function onScan(input, handler) {
    input.addEventListener("keydown", function (e) {
      if (e.key !== "Enter") return;
      e.preventDefault();
      var code = input.value.trim();
      input.value = "";
      if (code) handler(code);
    });
  }
  function findItem(items, code) {
    var ids = Object.keys(items);
    for (var i = 0; i < ids.length; i++) if (items[ids[i]].ean === code) return ids[i];
    for (i = 0; i < ids.length; i++) if (items[ids[i]].code === code) return ids[i];
    return null;
  }
  function beep(ok) {
    try {
      var c = new (window.AudioContext || window.webkitAudioContext)(), o = c.createOscillator();
      o.frequency.value = ok ? 1200 : 300; o.connect(c.destination); o.start(); o.stop(c.currentTime + (ok ? 0.06 : 0.25));
    } catch (e) { /* bez zvuku */ }
  }

  var take = $("#stocktake");
  if (take) {
    onScan($("#scan"), function (code) {
      var tr = $("tr[data-ean='" + CSS.escape(code) + "']", take) || $("tr[data-code='" + CSS.escape(code) + "']", take);
      var msg = $("#scan-msg");
      if (!tr) { msg.textContent = "Neznámý kód " + code; beep(false); return; }
      var inp = tr.querySelector(".count");
      inp.value = String(num(inp.value) + 1).replace(".", ",");
      $$("tr.hit", take).forEach(function (r) { r.classList.remove("hit"); });
      tr.classList.add("hit"); tr.scrollIntoView({ block: "center" });
      msg.textContent = tr.children[1].textContent + ": " + inp.value; beep(true);
    });
  }

  // převodka: stav ve zdrojovém a cílovém skladu podle výběru
  if (take && take.dataset.stocks) {
    var stocks = JSON.parse(take.dataset.stocks), fromW = $("#from_wh"), toW = $("#to_wh"), only = $("#only-src");
    var fmtQ = function (v) { return v ? String(Math.round(v * 1000) / 1000).replace(".", ",") : ""; };
    var showStocks = function () {
      $$("tr[data-id]", take).forEach(function (tr) {
        var st = stocks[tr.dataset.id] || {}, src = st[fromW.value] || 0;
        tr.querySelector(".src-q").textContent = fmtQ(src);
        tr.querySelector(".dst-q").textContent = fmtQ(st[toW.value] || 0);
        tr.hidden = only.checked && src <= 0 && !tr.querySelector(".count").value;
      });
    };
    fromW.addEventListener("change", showStocks); toW.addEventListener("change", showStocks);
    only.addEventListener("change", showStocks);
    only.checked = true; showStocks();
  }

  // ---------- odhlášení po nečinnosti ----------
  // Server ruší relaci po N minutách bez požadavku. Když uživatel jen píše (dlouhá faktura), prohlížeč relaci
  // prodlužuje (/keepalive nejvýš jednou za minutu); po N minutách bez myši a klávesnice se odhlásí sám.
  var idle = parseInt(document.body.dataset.idle || "0", 10) * 1000;
  if (idle) {
    var lastAct = Date.now(), lastPing = Date.now(), every = Math.min(60000, idle / 3);   // prodloužit dřív, než relace vyprší
    var activity = function () {
      lastAct = Date.now();
      if (lastAct - lastPing > every) { lastPing = lastAct; fetch("/keepalive", { credentials: "same-origin" }); }
    };
    ["keydown", "mousedown", "input", "touchstart", "wheel"].forEach(function (ev) {
      document.addEventListener(ev, activity, { passive: true, capture: true });
    });
    setInterval(function () {
      if (Date.now() - lastAct < idle) return;
      var tok = $("input[name=_csrf]"), body = new FormData();
      if (tok) body.append("_csrf", tok.value);
      var go = function () { location.href = "/login?vyprselo=1&next=" + encodeURIComponent(location.pathname + location.search); };
      fetch("/logout", { method: "POST", body: body, credentials: "same-origin" }).then(go, go);
    }, 15000);
  }

  // ---------- karta položky: cena bez / s DPH, zboží / služba ----------
  // Stejný výpočet jako rekapitulace dokladu: s DPH = základ + DPH zaokrouhlená na haléře.
  function grossOf(net, r) { return net + Math.round(net * r / 100); }
  function netOf(gross, r) {
    var b = Math.round(gross * 100 / (100 + r));
    for (var i = 0, c = [b, b - 1, b + 1]; i < 3; i++) if (grossOf(c[i], r) === gross) return c[i];
    return b;
  }
  $$("[data-gross]").forEach(function (g) {
    var f = g.form, name = g.dataset.gross;
    var n = f.querySelector("[data-net='" + name + "']"), src = f.querySelector("[name='" + name + "_src']");
    var rateEl = f.querySelector("[name=vat_rate]");
    function rate() { return rateEl ? parseInt(rateEl.value, 10) || 0 : parseInt(f.dataset.rate || "0", 10); }
    function fromNet() { g.value = n.value.trim() ? fmtPrice(grossOf(Math.round(num(n.value) * 100), rate())) : ""; }
    // některé ceny s DPH z haléřového základu přesně složit nejdou (např. 999,50 při 21 %) – říct, kolik vyjde
    var hint = document.createElement("span");
    hint.className = "hint"; hint.hidden = true;
    g.closest("label").appendChild(hint);
    function fromGross() {
      hint.hidden = true;
      if (!g.value.trim()) { n.value = ""; return; }
      var want = Math.round(num(g.value) * 100), net = netOf(want, rate()), got = grossOf(net, rate());
      n.value = fmtPrice(net);
      if (got !== want) {
        hint.textContent = "na dokladu vyjde " + money(got) + " (přesně " + fmtPrice(want) + " při " + rate() + " % nejde)";
        hint.hidden = false;
      }
    }
    n.addEventListener("input", function () { src.value = "net"; hint.hidden = true; fromNet(); });
    g.addEventListener("input", function () { src.value = "vat"; fromGross(); });
    if (rateEl) rateEl.addEventListener("change", function () { if (src.value === "vat") fromGross(); else fromNet(); });
    fromNet();
  });
  var itemForm = $("[data-item-form]");
  if (itemForm) {
    var kinds = $$("[name=service]", itemForm);
    var syncKind = function () {
      var svc = kinds.some(function (k) { return k.checked && k.value === "1"; });
      $$("[data-goods]", itemForm).forEach(function (el) {
        var box = el.tagName === "INPUT" ? el.closest("label") : el;
        box.hidden = svc;
      });
    };
    kinds.forEach(function (k) {
      k.addEventListener("change", function () {
        var unit = itemForm.querySelector("[name=unit]");      // výchozí jednotka podle druhu
        if (k.value === "1" && unit.value === "ks") unit.value = "h";
        else if (k.value === "0" && unit.value === "h") unit.value = "ks";
        syncKind();
      });
    });
    syncKind();
  }

  // ---------- faktura ----------
  var form = $("#invoice");
  if (!form) return;
  var vatPayer = form.dataset.vat === "1";
  var purchase = form.dataset.purchase === "1";   // přijatá faktura: nákupní cena, bez kontroly zásoby
  var shortage = [];                               // prodej do mínusu → při uložení potvrdit
  var kindEl = form.querySelector("[name=kind]");
  var noStock = !!(kindEl && (kindEl.value === "zaloha" || kindEl.value === "dobropis"));   // sklad nemění / vrací
  if (form.dataset.sale === "1") {
    form.addEventListener("submit", function (e) {
      recalc();
      if (shortage.length && !confirm("Na skladě není dost zboží:\n\n" + shortage.join("\n") +
          "\n\nProdat přesto? Stav skladu půjde do mínusu – dorovnejte ho pak příjemkou nebo inventurou.")) {
        e.preventDefault();
      }
    });
  }
  function priceOf(it) { return purchase ? (it.cost || 0) : it.price; }
  var tbody = $("#lines");
  var items = JSON.parse(tbody.dataset.items || "{}");
  var tpl = $("#line-tpl");

  // popisky sloupců u každého pole (na telefonu je hlavička tabulky skrytá a pole jsou pod sebou)
  var heads = $$("thead th", tbody.closest("table")).map(function (th) { return th.textContent.trim(); });
  function warrantyText(m) {
    m = parseInt(m || 0, 10);
    return m ? "záruka " + m + " " + (m === 1 ? "měsíc" : m <= 4 ? "měsíce" : "měsíců") : "";
  }
  function setWarranty(tr, m) {
    var w = tr.querySelector("[name=line_warranty]");
    if (!w) return;
    w.value = m ? String(m) : "";
    tr.querySelector("small.warranty").textContent = warrantyText(m);
  }
  function addLine(d) {
    var tr = tpl.content.firstElementChild.cloneNode(true);
    $$("td", tr).forEach(function (td, i) { if (heads[i]) td.setAttribute("data-label", heads[i]); });
    tbody.appendChild(tr);
    if (d) {
      tr.querySelector("[name=line_item]").value = d.item || "";
      tr.querySelector("[name=line_text]").value = d.text || "";
      tr.querySelector("[name=line_qty]").value = String(d.qty).replace(".", ",");
      tr.querySelector("[name=line_unit]").value = d.unit || "ks";
      tr.querySelector("[name=line_price]").value = fmtPrice(d.price || 0);
      tr.querySelector("[name=line_vat]").value = String(d.vat || 0);
      tr.querySelector("[name=line_fee]").value = d.fee ? fmtPrice(d.fee) : "";
      setWarranty(tr, d.warranty);
    } else {
      tr.querySelector("[name=line_vat]").value = "21";
    }
    return tr;
  }

  function recalc() {
    var byRate = {}, warn = [], need = {};
    shortage = [];
    $$("tr", tbody).forEach(function (tr) {
      var q = num(tr.querySelector("[name=line_qty]").value);
      var p = Math.round(num(tr.querySelector("[name=line_price]").value) * 100);
      var rate = vatPayer ? parseInt(tr.querySelector("[name=line_vat]").value, 10) : 0;
      var fee = Math.round(num(tr.querySelector("[name=line_fee]").value) * 100);
      var base = Math.round(q * p) + Math.round(q * fee);
      tr.querySelector(".line-total").textContent = money(base);
      byRate[rate] = (byRate[rate] || 0) + base;
      var it = tr.querySelector("[name=line_item]").value;
      if (it) need[it] = (need[it] || 0) + q;
    });
    Object.keys(need).forEach(function (id) {
      var it = items[id];
      var whEl = form.querySelector("[name=warehouse_id]");
      var have = it ? (whEl && it.stocks ? (it.stocks[whEl.value] || 0) : it.stock) : 0;
      if (it && !it.service && !purchase && !noStock && need[id] > have) {
        warn.push(it.name + " (skladem " + String(have).replace(".", ",") + " " + it.unit + ")");
        shortage.push("• " + it.name + ": prodáváte " + String(need[id]).replace(".", ",") + ", skladem " +
                      String(have).replace(".", ",") + " " + it.unit);
      }
    });
    $("#stock-warn").textContent = warn.length ? "⚠ Nedostatek na skladě: " + warn.join(", ") : "";
    var html = "", total = 0;
    Object.keys(byRate).sort(function (a, b) { return b - a; }).forEach(function (r) {
      var base = byRate[r], vat = vatPayer ? Math.round(base * r / 100) : 0;
      total += base + vat;
      if (vatPayer) html += "<div>Základ " + r + " %: " + money(base) + " · DPH " + money(vat) + "</div>";
    });
    html += "<div class='grand'>Celkem k úhradě: " + money(total) + "</div>";
    $("#totals").innerHTML = html;
    lastTotal = total;
    change();
  }

  // pokladna: kolik vrátit
  var lastTotal = 0;
  function change() {
    var rec = $("#received"), out = $("#change"), pay = $("#payment");
    if (!rec || !out) return;
    $("#received-l").hidden = pay.value !== "hotove";
    var r = Math.round(num(rec.value) * 100);
    out.textContent = r ? (r >= lastTotal ? money(r - lastTotal) : "chybí " + money(lastTotal - r)) : "—";
  }
  if ($("#received")) { $("#received").addEventListener("input", change); $("#payment").addEventListener("change", change); }

  tbody.addEventListener("input", recalc);
  if (form.querySelector("select[data-warehouse]")) form.querySelector("select[data-warehouse]").addEventListener("change", recalc);
  tbody.addEventListener("change", function (e) {
    if (e.target.name === "line_item") {
      var it = items[e.target.value], tr = e.target.closest("tr");
      if (it) {
        tr.querySelector("[name=line_text]").value = it.name;
        tr.querySelector("[name=line_unit]").value = it.unit;
        tr.querySelector("[name=line_price]").value = fmtPrice(priceOf(it));
        tr.querySelector("[name=line_vat]").value = String(it.vat);
        tr.querySelector("[name=line_fee]").value = it.fee ? fmtPrice(it.fee) : "";
        setWarranty(tr, it.warranty);
      } else if (!e.target.value) {
        setWarranty(tr, 0);
      }
    }
    recalc();
  });
  tbody.addEventListener("click", function (e) {
    if (e.target.hasAttribute("data-del")) {
      e.target.closest("tr").remove();
      if (!tbody.children.length) addLine();
      recalc();
    }
  });
  $("#add-line").addEventListener("click", function () { addLine().querySelector("[name=line_item]").focus(); recalc(); });

  // pípnutí: stejná položka už na faktuře → +1 ks, jinak nový řádek
  onScan($("#scan"), function (code) {
    var id = findItem(items, code), msg = $("#scan-msg");
    if (!id) {
      // kód ze čtečky může obsahovat cokoli (i „<“) – jen jako text, nikdy jako HTML
      var a = document.createElement("a");
      a.href = "/sklad/nova?ean=" + encodeURIComponent(code); a.target = "_blank"; a.textContent = "založit";
      msg.textContent = "Kód " + code + " není ve skladu – "; msg.appendChild(a);
      beep(false); return;
    }
    var hit = $$("tr", tbody).filter(function (tr) { return tr.querySelector("[name=line_item]").value === id; })[0];
    if (hit) {
      var q = hit.querySelector("[name=line_qty]");
      q.value = String(num(q.value) + 1).replace(".", ",");
    } else {
      var empty = $$("tr", tbody).filter(function (tr) { return !tr.querySelector("[name=line_text]").value; })[0];
      if (empty) empty.remove();
      var it = items[id];
      addLine({ item: id, text: it.name, qty: 1, unit: it.unit, price: priceOf(it), vat: it.vat, fee: it.fee, warranty: it.warranty });
    }
    msg.textContent = items[id].name + " ✓"; beep(true);
    recalc();
  });

  var rows = JSON.parse(tbody.dataset.rows || "[]");
  if (rows.length) rows.forEach(addLine); else addLine();
  recalc();

  // odběratel z adresáře (formuláře bez odběratele – pokladna – tuhle část přeskočí)
  var csel = form.contact_id;
  if (!csel) return;
  var contacts = JSON.parse(csel.dataset.contacts || "{}");
  csel.addEventListener("change", function () {
    var c = contacts[csel.value];
    if (!c) return;
    form.cust_name.value = c.name; form.cust_ico.value = c.ico; form.cust_dic.value = c.dic; form.cust_address.value = c.address;
  });
  var aresBtn = $("[data-ares-inv]");
  if (aresBtn) aresBtn.addEventListener("click", function () {
    ares(form.cust_ico.value, function (d) {
      form.cust_name.value = d.name; form.cust_dic.value = d.dic;
      form.cust_address.value = [d.street, (d.zip + " " + d.city).trim()].concat(d.country && d.country !== "Česká republika" ? [d.country] : []).join("\n");
      csel.value = "";
      if (form.save_contact) form.save_contact.checked = true;
    });
  });
  // splatnost se posune s datem vystavení
  if (!form.issue_date || !form.due_date) return;
  var due0 = form.due_date.value, iss0 = form.issue_date.value;
  form.issue_date.addEventListener("change", function () {
    var d = (new Date(due0) - new Date(iss0)) / 864e5;
    if (!isNaN(d) && form.issue_date.value) {
      var n = new Date(form.issue_date.value); n.setDate(n.getDate() + d);
      form.due_date.value = n.toISOString().slice(0, 10);
      if (form.tax_date && form.tax_date.value === iss0) form.tax_date.value = form.issue_date.value;
      due0 = form.due_date.value; iss0 = form.issue_date.value;
    }
  });
})();

// navržené číslo dokladu: při změně roku v datu vystavení nabídne číslo z řady toho roku
// (jen když uživatel číslo nepřepsal; server to při uložení stejně ohlídá i při souběhu)
(function () {
  var auto = document.querySelector("input[name=number_auto]");
  if (!auto || !auto.dataset.date || !auto.dataset.series) return;
  var form = auto.form, num = form.elements[auto.dataset.field], dt = form.elements[auto.dataset.date];
  if (!num || !dt) return;
  var url = auto.dataset.series === "nabidka" ? "/nabidky/cislo?datum=" : "/faktury/cislo?druh=" + auto.dataset.series + "&datum=";
  var year = (dt.value || "").slice(0, 4);
  dt.addEventListener("change", function () {
    var y = (dt.value || "").slice(0, 4);
    if (y.length !== 4 || y === year || num.value !== auto.value) return;
    year = y;
    fetch(url + encodeURIComponent(dt.value)).then(function (r) { return r.ok ? r.text() : ""; }).then(function (t) {
      if (t && num.value === auto.value) {
        num.value = auto.value = t;
        num.classList.add("changed"); setTimeout(function () { num.classList.remove("changed"); }, 1500);
      }
    });
  });
})();
