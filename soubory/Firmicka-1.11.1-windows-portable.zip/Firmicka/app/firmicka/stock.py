"""Sklad: karty položek (EAN, nákupní průměr, recyklační poplatek), příjem / výdej / inventura,
historie pohybů, inventura čtečkou. Stav = součet pohybů; faktury vydané i přijaté zapisují samy."""
import json

from .db import item_costs, warehouse_levels, today, VAT_RATES, with_vat, rnd
from .warehouses import warehouses, wh_names, wh_select, read_wh, default_wh, multi
from .web import h, money, qty, parse_money, parse_qty, parse_vat, cz_date, flash, flash_redirect, json_response, HTTPError

KINDS = {"prijem": "Příjem", "vydej": "Výdej", "inventura": "Inventura", "faktura": "Faktura", "dobropis": "Dobropis",
         "pocatek": "Počáteční stav", "nakup": "Přijatá faktura", "prodej": "Účtenka", "prevod": "Převodka"}


def find_by_code(db, code):
    """EAN nebo interní kód (čtečka posílá jen číslice + Enter)."""
    code = code.strip()
    if not code:
        return None
    return (db.one("SELECT * FROM items WHERE ean = ? AND active = 1", (code,)) or
            db.one("SELECT * FROM items WHERE code = ? AND active = 1", (code,)) or
            db.one("SELECT * FROM items WHERE ean = ? OR code = ?", (code, code)))


def items_json(db, active_only=True, with_cost=True):
    """Položky pro formuláře (výběr, čtečka) – {id: {...}}; nákupní cena jen pro sklad a přijaté faktury."""
    costs = item_costs(db)
    lv = warehouse_levels(db)
    rows = db.q("SELECT * FROM items%s ORDER BY name COLLATE NOCASE" % (" WHERE active = 1" if active_only else ""))
    return {str(i["id"]): {"name": i["name"], "unit": i["unit"], "price": i["price"], "vat": i["vat_rate"],
                           "fee": i["recycling_fee"], "ean": i["ean"], "code": i["code"],
                           "stock": costs.get(i["id"], (0, 0))[0], "service": i["service"], "warranty": i["warranty"], "cost": costs.get(i["id"], (0, 0))[1] if with_cost else None,
                           "stocks": {str(w): q for w, q in lv.get(i["id"], {}).items()}}
            for i in rows}


def from_gross(gross, rate):
    """Základ z ceny s DPH – pokud jde, takový, aby rekapitulace dokladu dala přesně zadanou cenu s DPH."""
    base = rnd(gross * 100 / (100 + rate))
    for b in (base, base - 1, base + 1):
        if with_vat(b, rate) == gross:
            return b
    return base


def item_options(items, first="volný text"):
    """<option> pro výběr položky na dokladu – zboží a služby (ceník práce) zvlášť."""
    def opt(i):
        return '<option value="%d">%s%s</option>' % (i["id"], h(i["name"]), " (%s)" % h(i["code"]) if i["code"] else "")
    goods = [i for i in items if not i["service"]]
    svc = [i for i in items if i["service"]]
    out = '<option value="">%s</option>' % h(first)
    if not svc:
        return out + "".join(opt(i) for i in goods)
    return out + '<optgroup label="Zboží">%s</optgroup><optgroup label="Služby a práce">%s</optgroup>' % (
        "".join(opt(i) for i in goods), "".join(opt(i) for i in svc))


def register(app):
    db = app.db

    def payer(req):
        return req.settings["vat_payer"] == "1"

    @app.route("/sklad")
    def index(req):
        qs = req.args.get("q", "").strip()
        show = req.args.get("zobrazit", "")
        svc_tab = req.args.get("druh") == "sluzby"
        supp = req.args.get("dodavatel", "")
        if qs and req.args.get("scan"):
            it = find_by_code(db, qs)        # pípnutí čtečkou → rovnou karta položky
            if it:
                flash_redirect("/sklad/%d" % it["id"], "Nalezeno podle kódu %s" % qs)
        vp = payer(req)
        costs = item_costs(db)
        lv = warehouse_levels(db)
        ws = warehouses(db)
        wsel = req.args.get("sklad", "")
        wid = int(wsel) if wsel.isdigit() and int(wsel) in wh_names(db) else None
        many = len(ws) > 1
        cols = ws if many and not wid and not svc_tab else []     # všechny sklady → sloupec pro každý

        def stock_of(iid):
            return lv.get(iid, {}).get(wid, 0) if wid else costs.get(iid, (0, 0))[0]
        sql, args = "SELECT * FROM items WHERE service = ?", [1 if svc_tab else 0]
        if show != "vse":
            sql += " AND active = 1"
        if qs:
            sql += " AND (name LIKE ? OR code LIKE ? OR ean = ? OR supplier LIKE ?)"
            args += ["%" + qs + "%"] * 2 + [qs, "%" + qs + "%"]
        if supp:
            sql += " AND supplier = ?"
            args.append(supp)
        rows = db.q(sql + " ORDER BY name COLLATE NOCASE", args)

        def negative(iid):     # záporný stav celkem nebo v kterémkoli skladu (u vybraného skladu jen v něm)
            if wid:
                return stock_of(iid) < -1e-9
            return any(q < -1e-9 for q in lv.get(iid, {}).values()) or costs.get(iid, (0, 0))[0] < -1e-9
        n_neg = sum(1 for r in db.q("SELECT id FROM items WHERE active = 1 AND service = 0") if negative(r["id"]))
        n_svc = db.one("SELECT COUNT(*) FROM items WHERE service = 1 AND active = 1")[0]
        n_goods = db.one("SELECT COUNT(*) FROM items WHERE service = 0 AND active = 1")[0]
        if not svc_tab:
            if show == "nizke":
                rows = [r for r in rows if stock_of(r["id"]) <= r["min_qty"]]
            elif show == "zaporne":
                rows = [r for r in rows if negative(r["id"])]
            elif wid and show != "vse":
                rows = [r for r in rows if abs(stock_of(r["id"])) > 1e-9]   # sklad: jen co na něm je

        def sub(r):            # dodavatel a záruka pod názvem
            bits = []
            if r["supplier"]:
                bits.append("dodavatel " + h(r["supplier"]))
            if r["warranty"]:
                bits.append("záruka %d měs." % r["warranty"])
            return "<br><small class=hint>%s</small>" % " · ".join(bits) if bits else ""

        def pair(v, rate):     # cena bez DPH | s DPH (plátce), jinak jen jedna
            if not vp:
                return "<td class=num>%s</td>" % (money(v) if v else "")
            return "<td class=num>%s</td><td class=num>%s</td>" % ((money(v), money(with_vat(v, rate))) if v else ("", ""))
        trs, value = [], 0
        for r in rows:
            name = "<a href='/sklad/%d'>%s</a>%s%s" % (r["id"], h(r["name"]),
                                                     "" if r["active"] else " <span class=tag>vyřazeno</span>", sub(r))
            if svc_tab:
                trs.append("<tr><td>%s</td><td>%s</td><td>%s</td>%s%s</tr>" % (
                    h(r["code"] or r["ean"]), name, h(r["unit"]), pair(r["price"], r["vat_rate"]),
                    "<td class=num>%d %%</td>" % r["vat_rate"] if vp else ""))
                continue
            avg = costs.get(r["id"], (0, 0))[1]
            st = stock_of(r["id"])
            if st > 0:
                value += round(st * avg)
            low = r["min_qty"] > 0 and st <= r["min_qty"] or st < 0
            per = "".join("<td class=num>%s</td>" % (qty(lv.get(r["id"], {}).get(w["id"], 0))
                                                      if lv.get(r["id"], {}).get(w["id"]) else "") for w in cols)
            trs.append("<tr%s><td>%s</td><td>%s</td>%s<td class=num><b>%s</b> %s</td><td class=num>%s</td>%s%s"
                       "<td class=num>%s</td></tr>" % (
                           " class=warn" if low else "", h(r["code"] or r["ean"]), name, per,
                           qty(st), h(r["unit"]), qty(r["min_qty"]) if r["min_qty"] else "",
                           pair(avg, r["vat_rate"]), pair(r["price"], r["vat_rate"]),
                           money(round(max(st, 0) * avg)) if avg else ""))
        opts = "".join('<option value="%s"%s>%s</option>' % (v, " selected" if v == show else "", t)
                       for v, t in ((("", "Aktivní"), ("vse", "Vše včetně vyřazených")) if svc_tab else
                                    (("", "Aktivní"), ("nizke", "Nízký stav"), ("zaporne", "Záporný stav"),
                                     ("vse", "Vše včetně vyřazených"))))
        neg_note = ""
        if n_neg and show != "zaporne" and not svc_tab:
            neg_note = ('<div class="flash error">%d %s se záporným stavem – prodalo se víc, než bylo naskladněno. '
                        '<a class="btn" href="/sklad?zobrazit=zaporne%s">Zobrazit</a> Dorovnejte příjemkou (přijatá faktura '
                        'nebo příjem na kartě položky) nebo inventurou.</div>') % (
                n_neg, "položka" if n_neg == 1 else "položky" if n_neg < 5 else "položek",
                "&sklad=%d" % wid if wid else "")
        wopts = ""
        if many and not svc_tab:
            wopts = '<select name="sklad" onchange="this.form.submit()"><option value="">Všechny sklady</option>%s</select>' % "".join(
                '<option value="%d"%s>%s</option>' % (w["id"], " selected" if w["id"] == wid else "", h(w["name"])) for w in ws)
        suppliers = [r[0] for r in db.q("SELECT DISTINCT supplier FROM items WHERE supplier != '' AND service = ? "
                                        "ORDER BY supplier COLLATE NOCASE", (1 if svc_tab else 0,))]
        sopts = ""
        if suppliers:
            sopts = '<select name="dodavatel" onchange="this.form.submit()"><option value="">Všichni dodavatelé</option>%s</select>' % "".join(
                '<option%s>%s</option>' % (" selected" if s == supp else "", h(s)) for s in suppliers)
        wname = wh_names(db).get(wid, "") if wid else ""
        tabs = '<div class="bar tabs"><a class="btn%s" href="/sklad">Zboží <small>%d</small></a>' \
               '<a class="btn%s" href="/sklad?druh=sluzby">Služby a práce <small>%d</small></a></div>' % (
                   "" if svc_tab else " primary", n_goods, " primary" if svc_tab else "", n_svc)
        ph = lambda t: "<th class=num>%s</th>" % t
        if svc_tab:
            head = "<th>Kód</th><th>Název</th><th>Jedn.</th>%s%s" % (
                ph("Cena bez DPH") + ph("s DPH") if vp else ph("Cena"), ph("DPH") if vp else "")
            stats = ('<p class="hint">Ceník práce a služeb: hodinová sazba, doprava, diagnostika… Na fakturách, '
                     'v pokladně a na zakázkách se vybírají stejně jako zboží, ale nehýbou skladem.</p>')
            new_btn = '<a class="btn primary" href="/sklad/nova?druh=sluzba">+ Nová služba</a>'
            empty = "<p class=empty>Zatím žádné služby. Založte třeba „Práce technika“ s hodinovou sazbou.</p>"
        else:
            head = "<th>Kód</th><th>Název</th>%s<th class=num>%s</th><th class=num>Min.</th>%s%s<th class=num>Hodnota</th>" % (
                "".join("<th class=num>%s</th>" % h(w["name"]) for w in cols), "Celkem" if cols else "Skladem",
                ph("Nákup ø bez DPH") + ph("s DPH") if vp else ph("Nákup ø"),
                ph("Prodej bez DPH") + ph("s DPH") if vp else ph("Prodej"))
            stats = '<div class="stats"><div><span>Hodnota zásob (nákup%s)%s</span><b>%s</b><small>%d položek</small></div></div>' % (
                " bez DPH" if vp else "", " – " + h(wname) if wname else "", money(value), len(rows))
            new_btn = '<a class="btn primary" href="/sklad/nova">+ Nová položka</a>'
            empty = "<p class=empty>Žádné položky.</p>"
        return app.page("Sklad", """%s<div class="bar"><h1>Sklad%s</h1>
<a class="btn" href="/sklad/sklady">Sklady</a>%s<a class="btn" href="/sklad/inventura%s">Inventura čtečkou</a>
<a class="btn" href="/sklad/pohyby%s">Pohyby</a>%s</div>%s
%s
<form class="filters"><input type="hidden" name="scan" value="1">%s
<input name="q" value="%s" placeholder="Hledat název, kód, dodavatele – nebo pípnout EAN" autofocus>
%s%s<select name="zobrazit" onchange="this.form.submit()">%s</select><button>Hledat</button>
<a class="btn" href="/export/sklad.csv">Export CSV</a></form>
<table class="list wide"><thead><tr>%s</tr></thead><tbody>%s</tbody></table>%s""" % (
            flash(req) + neg_note, " – " + h(wname) if wname else "",
            '<a class="btn" href="/sklad/prevodky">Převodky</a>' if many else "",
            "?sklad=%d" % wid if wid else "", "?sklad=%d" % wid if wid else "", new_btn, tabs, stats,
            '<input type="hidden" name="druh" value="sluzby">' if svc_tab else "",
            h(qs), wopts, sopts, opts, head, "".join(trs), "" if rows else empty), "/sklad")

    def price_inputs(label, name, val, vp, hint="", placeholder="", attrs=""):
        """Cena bez DPH + s DPH (plátce; pole se dopočítávají v app.js podle sazby), neplátce jedno pole."""
        dec = lambda v: money(v, False).replace("\u00a0", "") if v else ""
        if not vp:
            return '<label>%s<input name="%s" value="%s" inputmode="decimal" placeholder="%s"%s>%s</label>' % (
                label, name, dec(val), placeholder, attrs, hint)
        return ('<label>%s bez DPH<input name="%s" value="%s" inputmode="decimal" placeholder="%s" data-net="%s"%s>%s</label>'
                '<label>%s s DPH<input name="%s_vat" value="" inputmode="decimal" placeholder="%s" data-gross="%s"%s></label>'
                '<input type="hidden" name="%s_src" value="net">') % (
            label, name, dec(val), placeholder, name, attrs, hint, label, name, placeholder, name, attrs, name)

    def item_form(req, it, iid=None, costs=None):
        vp = payer(req)
        rate = it.get("vat_rate", 21)
        vat = "".join('<option value="%d"%s>%d %%</option>' % (v, " selected" if v == rate else "", v)
                      for v in VAT_RATES)
        svc = bool(it.get("service"))
        avg_info = ""
        if iid and costs and not svc:
            st, avg = costs.get(iid, (0, 0))
            avg_info = '<div class="wide hint">Průměrná nákupní cena: <b>%s</b>%s</div>' % (
                (money(avg) + (" bez DPH · %s s DPH" % money(with_vat(avg, rate)) if vp else "")) if avg else
                "zatím neznámá (zadávejte nákupní cenu u příjmu)",
                " · marže při prodejní ceně %s" % ("%.0f %%" % ((it["price"] - avg) * 100 / it["price"]))
                if avg and it.get("price") else "")
        dec = lambda v: money(v or 0, False).replace("\u00a0", "")
        supp = sorted(set([r[0] for r in db.q("SELECT name FROM contacts")] +
                          [r[0] for r in db.q("SELECT DISTINCT supplier FROM items WHERE supplier != ''")]), key=str.lower)
        kind = ('<fieldset class="wide kind"><legend>Druh</legend>'
                '<label class="check"><input type="radio" name="service" value="0"%s> Zboží <span class="hint">(skladem, počítá se stav)</span></label>'
                '<label class="check"><input type="radio" name="service" value="1"%s> Služba / práce <span class="hint">'
                '(ceník – hodinová sazba, doprava…, bez skladu)</span></label></fieldset>') % (
            "" if svc else " checked", " checked" if svc else "")
        initial = ""
        if not iid:
            initial = ('<label data-goods>Počáteční stav<input name="initial" inputmode="decimal" placeholder="0"></label>' +
                       price_inputs("Nákupní cena / j.", "initial_cost", 0, vp, placeholder="nepovinné", attrs=" data-goods") +
                       '<div data-goods>%s</div>' % wh_select(db, default_wh(db, req), label="Počáteční stav do skladu"))
        body = """<h1>%s</h1><form method="post" class="grid item-form" data-item-form>%s%s
<label>Kód<input name="code" value="%s"></label>
<label>EAN (čárový kód)<input name="ean" value="%s" inputmode="numeric" placeholder="pípněte čtečkou" data-scan-field></label>
<label class="wide">Název<input name="name" value="%s" required></label>
<label>Jednotka<input name="unit" value="%s" list="units"></label>
<label%s>Sazba DPH<select name="vat_rate">%s</select></label>
%s
<label data-goods>Recyklační poplatek / j.<input name="recycling_fee" value="%s" inputmode="decimal" placeholder="0">
<span class="hint">účtuje se navíc k ceně</span></label>
<label data-goods>Minimální stav<input name="min_qty" value="%s" inputmode="decimal"></label>
<label>Dodavatel<input name="supplier" value="%s" list="suppliers" placeholder="nepovinné"></label>
<label data-goods>Záruka (měsíců)<input name="warranty" value="%s" inputmode="numeric" placeholder="např. 24">
<span class="hint">0 nebo prázdné = neuvádět</span></label>
%s
<label class="wide">Poznámka<input name="note" value="%s"></label>
<label class="check wide"><input type="checkbox" name="active" value="1"%s> Aktivní (nabízet na dokladech)</label>
%s
<div class="actions wide"><button class="btn primary">Uložit</button><a class="btn" href="/sklad%s">Zpět</a></div>
</form><datalist id="units"><option>ks<option>kg<option>g<option>l<option>m<option>m²<option>bal<option>h<option>km</datalist>
<datalist id="suppliers">%s</datalist>""" % (
            ("Upravit službu" if svc else "Upravit položku") if iid else ("Nová služba" if svc else "Nová položka"),
            app.csrf(), kind, h(it.get("code")), h(it.get("ean")), h(it.get("name")), h(it.get("unit", "h" if svc else "ks")),
            "" if vp else " hidden", vat,
            price_inputs("Prodejní cena", "price", it.get("price"), vp),
            dec(it.get("recycling_fee")) if it.get("recycling_fee") else "", qty(it.get("min_qty", 0)),
            h(it.get("supplier")), it.get("warranty") or "", initial,
            h(it.get("note")), " checked" if it.get("active", 1) else "", avg_info, "?druh=sluzby" if svc else "",
            "".join("<option>%s</option>" % h(s) for s in supp))
        return body

    ITEM_COLS = ["code", "ean", "name", "unit", "price", "recycling_fee", "vat_rate", "min_qty", "note", "active",
                 "service", "supplier", "warranty"]

    def read_price(req, name, rate):
        """Cena bez DPH; plátce mohl naposledy psát do pole s DPH → základ dopočítat tak, aby s DPH vyšlo přesně."""
        if payer(req) and req.f(name + "_src") == "vat" and req.f(name + "_vat"):
            return from_gross(parse_money(req.f(name + "_vat")), rate)
        return parse_money(req.f(name))

    def read_item(req, iid=None):
        name = req.f("name")
        if not name:
            raise HTTPError(400, "Název je povinný")
        ean = req.f("ean")
        if ean and db.one("SELECT id FROM items WHERE ean = ? AND id != ?", (ean, iid or 0)):
            raise HTTPError(400, "EAN %s už má jiná položka" % ean)
        rate = parse_vat(req.f("vat_rate") or "21")
        svc = 1 if req.f("service") == "1" else 0
        w = req.f("warranty")
        if w and not (w.isdigit() and int(w) <= 600):
            raise HTTPError(400, "Záruku zadejte v celých měsících (např. 24)")
        return [req.f("code"), ean, name, req.f("unit") or ("h" if svc else "ks"), read_price(req, "price", rate),
                0 if svc else parse_money(req.f("recycling_fee")), rate, 0 if svc else parse_qty(req.f("min_qty")),
                req.f("note"), 1 if req.f("active") else 0, svc, req.f("supplier")[:200], 0 if svc else int(w or 0)]

    @app.route("/sklad/nova", ("GET", "POST"))
    def new(req):
        if req.method == "POST":
            vals = read_item(req)
            with db.tx():
                iid = db.run("INSERT INTO items(%s) VALUES(%s)" % (", ".join(ITEM_COLS), ",".join("?" * len(ITEM_COLS))), vals)
                init = 0 if vals[10] else parse_qty(req.f("initial"))
                if init:
                    db.run("INSERT INTO movements(item_id, date, qty, kind, unit_cost, warehouse_id) VALUES(?,?,?,'pocatek',?,?)",
                           (iid, today(), init, read_price(req, "initial_cost", vals[6]), read_wh(db, req)))
            flash_redirect("/sklad/%d" % iid, "Služba uložena" if vals[10] else "Položka uložena")
        it = {"active": 1, "ean": req.args.get("ean", ""), "service": 1 if req.args.get("druh") == "sluzba" else 0}
        return app.page("Nová položka", item_form(req, it), "/sklad")

    def used_in(iid):
        """Doklady, na kterých položka je (pak ji nejde smazat, jen vyřadit)."""
        out = []
        for table, label in (("invoice_lines", "faktury"), ("purchase_lines", "přijaté faktury"), ("receipt_lines", "účtenky"),
                             ("quote_lines", "nabídky"), ("job_lines", "zakázky")):
            n = db.one("SELECT COUNT(*) FROM %s WHERE item_id = ?" % table, (iid,))[0]
            if n:
                out.append("%s (%d)" % (label, n))
        n = db.one("SELECT COUNT(*) FROM movements WHERE item_id = ? AND transfer_id IS NOT NULL", (iid,))[0]
        if n:
            out.append("převodky")
        return out

    @app.route("/sklad/<iid>", ("GET", "POST"))
    def item(req, iid):
        it = db.one("SELECT * FROM items WHERE id = ?", (iid,))
        if not it:
            raise HTTPError(404, "Položka neexistuje")
        if req.method == "POST":
            vals = read_item(req, it["id"])
            if vals[10] and not it["service"]:
                st = item_costs(db).get(it["id"], (0, 0))[0]
                if abs(st) > 1e-9:
                    flash_redirect("/sklad/%d" % it["id"], "Na službu jde změnit jen položka s nulovým stavem – nejdřív "
                                   "vyskladněte %s %s (výdej nebo inventura)" % (qty(st), it["unit"]))
            db.run("UPDATE items SET %s WHERE id = ?" % ", ".join(c + "=?" for c in ITEM_COLS), vals + [it["id"]])
            flash_redirect("/sklad/%d" % it["id"], "Uloženo")
        costs = item_costs(db)
        st = costs.get(it["id"], (0, 0))[0]
        names = wh_names(db)
        many = multi(db)
        per = warehouse_levels(db).get(it["id"], {})
        movs = db.q("SELECT m.*, i.number, p.doc_number FROM movements m LEFT JOIN invoices i ON i.id = m.invoice_id "
                    "LEFT JOIN purchases p ON p.id = m.purchase_id "
                    "WHERE m.item_id = ? ORDER BY m.date DESC, m.id DESC LIMIT 300", (it["id"],))

        def doc(m):
            if m["invoice_id"]:
                return "<a href='/faktury/%d'>%s</a>" % (m["invoice_id"], h(m["number"]))
            if m["purchase_id"]:
                return "<a href='/prijate/%d'>%s</a>" % (m["purchase_id"], h(m["doc_number"]))
            if m["receipt_id"]:
                return "<a href='/pokladna/%d'>%s</a>" % (m["receipt_id"], h(m["doc"]))
            if m["transfer_id"]:
                return "<a href='/sklad/prevodky/%d'>%s</a>" % (m["transfer_id"], h(m["doc"]))
            return h(m["doc"])
        trs = "".join(
            "<tr><td>%s</td><td>%s</td>%s<td class=num>%s</td><td class=num>%s</td><td>%s</td><td>%s</td></tr>" % (
                cz_date(m["date"]), KINDS.get(m["kind"], m["kind"]),
                "<td>%s</td>" % h(names.get(m["warehouse_id"], "?")) if many else "",
                ("+" if m["qty"] > 0 else "") + qty(m["qty"]), money(m["unit_cost"]) if m["unit_cost"] else "", doc(m),
                "" if m["invoice_id"] or m["purchase_id"] or m["receipt_id"] or m["transfer_id"] else
                "<form method=post action='/sklad/pohyb/%d/smazat' onsubmit=\"return confirm('Smazat pohyb?')\">%s"
                "<button class='link danger'>smazat</button></form>" % (m["id"], app.csrf()))
            for m in movs)
        per_tbl = ""
        if many or len(per) > 1:
            per_tbl = "<table class=list><thead><tr><th>Sklad</th><th class=num>Stav</th></tr></thead><tbody>%s</tbody></table>%s" % (
                "".join("<tr><td>%s</td><td class=num>%s %s</td></tr>" % (h(names.get(w, "?")), qty(q), h(it["unit"]))
                        for w, q in sorted(per.items()) if abs(q) > 1e-9) or "<tr><td colspan=2>nikde</td></tr>",
                '<p><a class="btn" href="/sklad/prevodky/nova">Převést mezi sklady</a></p>' if many else "")
        move = """<section class="card"><h2>Skladem: %s %s</h2>%s
<form method="post" action="/sklad/%d/pohyb" class="grid move" data-rate="%d">%s%s
<label>Druh<select name="kind"><option value="prijem">Příjem (+)</option><option value="vydej">Výdej (−)</option>
<option value="inventura">Inventura (skutečný stav)</option></select></label>
<label>Množství<input name="qty" inputmode="decimal" required></label>
%s
<label>Datum<input type="date" name="date" value="%s"></label>
<label>Doklad<input name="doc" placeholder="č. dodacího listu…"></label>
<div class="actions"><button class="btn primary">Zapsat</button></div></form></section>""" % (
            qty(st), h(it["unit"]), per_tbl, it["id"], it["vat_rate"], app.csrf(), wh_select(db, default_wh(db, req)),
            price_inputs("Nákupní cena / j.", "unit_cost", 0, payer(req), placeholder="u příjmu"), today())
        history = ("<h2>Historie pohybů</h2><table class=list><thead><tr><th>Datum</th><th>Druh</th>" +
                   ("<th>Sklad</th>" if many else "") + "<th class=num>Množství</th><th class=num>Cena/j.</th><th>Doklad</th>"
                   "<th></th></tr></thead><tbody>%s</tbody></table>" % trs)
        if it["service"]:
            move, history = "", (history if movs else "")
        delete = ""
        if "uzivatele" in req.perms:
            used = used_in(it["id"])
            if used:
                delete = ('<section class="card danger-zone"><h2>Smazat</h2><p class="hint">Nejde smazat – je na dokladech: %s. '
                          'Místo smazání zrušte zaškrtnutí „Aktivní“, položka se pak přestane nabízet.</p></section>') % h(", ".join(used))
            else:
                delete = ('<section class="card danger-zone"><h2>Smazat</h2><form method="post" action="/sklad/%d/smazat" '
                          'onsubmit="return confirm(\'Opravdu smazat „%s“ i s historií pohybů? Nejde vrátit.\')">%s'
                          '<p class="hint">Položka není na žádném dokladu. Smaže se i její historie ručních pohybů.</p>'
                          '<button class="btn danger">Smazat položku</button></form></section>') % (
                    it["id"], h(it["name"]).replace("'", "&#39;"), app.csrf())
        return app.page(it["name"], flash(req) + item_form(req, dict(it), it["id"], costs) + move + history + delete, "/sklad")

    @app.route("/sklad/<iid>/smazat", ("POST",))
    def item_delete(req, iid):
        if "uzivatele" not in req.perms:
            raise HTTPError(403, "Mazat položky smí jen správce")
        it = db.one("SELECT * FROM items WHERE id = ?", (iid,))
        if not it:
            raise HTTPError(404, "Položka neexistuje")
        with db.tx():            # kontrola i smazání pod zámkem – mezitím ji nikdo nedá na doklad
            used = used_in(it["id"])
            if not used:
                db.run("DELETE FROM movements WHERE item_id = ?", (it["id"],))
                db.run("DELETE FROM items WHERE id = ?", (it["id"],))
        if used:
            flash_redirect("/sklad/%d" % it["id"], "Nejde smazat – položka je na dokladech: %s" % ", ".join(used))
        flash_redirect("/sklad%s" % ("?druh=sluzby" if it["service"] else ""), "Smazáno: %s" % it["name"])

    @app.route("/sklad/<iid>/pohyb", ("POST",))
    def move(req, iid):
        it = db.one("SELECT * FROM items WHERE id = ?", (iid,))
        if not it:
            raise HTTPError(404)
        if it["service"]:
            raise HTTPError(400, "Služba nemá skladový stav")
        kind, q = req.f("kind"), parse_qty(req.f("qty"))
        wh = read_wh(db, req)
        if kind == "vydej":
            q = -abs(q)
        elif kind == "inventura":
            q = q - warehouse_levels(db).get(it["id"], {}).get(wh, 0)   # zapíše se rozdíl proti evidenci skladu
        elif kind == "prijem":
            q = abs(q)
        else:
            raise HTTPError(400, "Neznámý druh pohybu")
        if q == 0 and kind != "inventura":
            flash_redirect("/sklad/%d" % it["id"], "Zadejte množství")
        if q != 0:
            db.run("INSERT INTO movements(item_id, date, qty, kind, unit_cost, doc, warehouse_id) VALUES(?,?,?,?,?,?,?)",
                   (it["id"], req.f("date") or today(), q, kind,
                    read_price(req, "unit_cost", it["vat_rate"]) if kind == "prijem" else 0, req.f("doc"), wh))
        flash_redirect("/sklad/%d" % it["id"], "Inventura souhlasí" if q == 0 else "Pohyb zapsán")

    @app.route("/sklad/pohyb/<mid>/smazat", ("POST",))
    def move_delete(req, mid):
        m = db.one("SELECT * FROM movements WHERE id = ?", (mid,))
        if not m or m["invoice_id"] or m["purchase_id"] or m["receipt_id"] or m["transfer_id"]:
            raise HTTPError(400, "Pohyb z faktury se mění jen úpravou faktury")
        db.run("DELETE FROM movements WHERE id = ?", (mid,))
        flash_redirect("/sklad/%d" % m["item_id"], "Pohyb smazán")

    @app.route("/sklad/pohyby")
    def movements(req):
        od, do = req.args.get("od", today()[:8] + "01"), req.args.get("do", today())
        names = wh_names(db)
        many = multi(db)
        wsel = req.args.get("sklad", "")
        wid = int(wsel) if wsel.isdigit() and int(wsel) in names else None
        rows = db.q("SELECT m.*, it.name, it.unit, i.number, p.doc_number FROM movements m JOIN items it ON it.id = m.item_id "
                    "LEFT JOIN invoices i ON i.id = m.invoice_id LEFT JOIN purchases p ON p.id = m.purchase_id "
                    "WHERE m.date BETWEEN ? AND ?%s ORDER BY m.date DESC, m.id DESC" % (" AND m.warehouse_id = ?" if wid else ""),
                    (od, do) + ((wid,) if wid else ()))
        trs = "".join("<tr><td>%s</td>%s<td><a href='/sklad/%d'>%s</a></td><td>%s</td><td class=num>%s %s</td><td>%s</td></tr>" % (
            cz_date(m["date"]), "<td>%s</td>" % h(names.get(m["warehouse_id"], "?")) if many else "",
            m["item_id"], h(m["name"]), KINDS.get(m["kind"], m["kind"]),
            ("+" if m["qty"] > 0 else "") + qty(m["qty"]), h(m["unit"]),
            "<a href='/faktury/%d'>%s</a>" % (m["invoice_id"], h(m["number"])) if m["invoice_id"] else
            "<a href='/prijate/%d'>%s</a>" % (m["purchase_id"], h(m["doc_number"])) if m["purchase_id"] else
            "<a href='/sklad/prevodky/%d'>%s</a>" % (m["transfer_id"], h(m["doc"])) if m["transfer_id"] else h(m["doc"]))
            for m in rows)
        wf = ""
        if many:
            wf = '<select name="sklad"><option value="">Všechny sklady</option>%s</select>' % "".join(
                '<option value="%d"%s>%s</option>' % (k, " selected" if k == wid else "", h(v)) for k, v in names.items())
        return app.page("Pohyby skladu", """<div class="bar"><h1>Pohyby skladu</h1></div>
<form class="filters">od <input type="date" name="od" value="%s"> do <input type="date" name="do" value="%s">
%s<button>Zobrazit</button></form><table class=list><thead><tr><th>Datum</th>%s<th>Položka</th><th>Druh</th>
<th class=num>Množství</th><th>Doklad</th></tr></thead><tbody>%s</tbody></table>%s""" % (
            h(od), h(do), wf, "<th>Sklad</th>" if many else "", trs,
            "" if rows else "<p class=empty>V tomto období žádné pohyby.</p>"), "/sklad")

    # ---------- inventura čtečkou ----------
    @app.route("/sklad/inventura", ("GET", "POST"))
    def stocktake(req):
        if req.method == "POST":
            wh = read_wh(db, req)
            lv = warehouse_levels(db)
            n, d = 0, req.f("date") or today()
            with db.tx():
                for key, val in req.form.items():
                    if not key.startswith("count_") or not val.strip():
                        continue
                    iid = int(key[6:])
                    diff = parse_qty(val) - lv.get(iid, {}).get(wh, 0)
                    if diff:
                        db.run("INSERT INTO movements(item_id, date, qty, kind, doc, warehouse_id) VALUES(?,?,?,'inventura',?,?)",
                               (iid, d, diff, "Inventura %s" % d, wh))
                        n += 1
            flash_redirect("/sklad" + ("?sklad=%d" % wh if multi(db) else ""), "Inventura zapsána – opraveno %d položek" % n)
        items = items_json(db)
        a = req.args.get("sklad", "")
        wh = int(a) if a.isdigit() and int(a) in [w["id"] for w in warehouses(db)] else default_wh(db, req)
        wsel = ""
        if multi(db):
            wsel = '<label>Sklad <select name="warehouse_id" onchange="location=\'/sklad/inventura?sklad=\'+this.value">%s</select></label>' % "".join(
                '<option value="%d"%s>%s</option>' % (w["id"], " selected" if w["id"] == wh else "", h(w["name"])) for w in warehouses(db))
        else:
            wsel = '<input type="hidden" name="warehouse_id" value="%d">' % wh
        trs = "".join("<tr data-id='%s' data-ean='%s' data-code='%s'><td>%s</td><td>%s</td><td class=num>%s %s</td>"
                      "<td><input name='count_%s' class='num count' inputmode='decimal' placeholder='nepočítáno'></td></tr>" % (
                          k, h(v["ean"]), h(v["code"]), h(v["code"] or v["ean"]), h(v["name"]), qty(v["stocks"].get(str(wh), 0)),
                          h(v["unit"]), k)
                      for k, v in items.items() if not v["service"])
        return app.page("Inventura", """<div class="bar"><h1>Inventura čtečkou</h1></div>
<p class="hint">Pípejte zboží čtečkou – každé pípnutí přičte 1 ks. Počet jde i přepsat ručně. Položky, které
nespočítáte (prázdné), zůstanou beze změny. Rozdíly se zapíší jako inventurní pohyby.</p>
<form method="post" id="stocktake">%s
<div class="filters"><input id="scan" placeholder="Pípněte EAN…" data-scan autofocus> <span id="scan-msg" class="hint"></span>
%s <label>Datum <input type="date" name="date" value="%s"></label></div>
<table class="list"><thead><tr><th>Kód</th><th>Položka</th><th class=num>V evidenci</th><th>Spočítáno</th></tr></thead>
<tbody>%s</tbody></table>
<div class="actions"><button class="btn primary" onclick="return confirm('Zapsat inventuru?')">Zapsat inventuru</button>
<a class="btn" href="/sklad">Zrušit</a></div></form>""" % (app.csrf(), wsel, today(), trs), "/sklad")

    @app.route("/api/ean/<code>")
    def api_ean(req, code):
        it = find_by_code(db, code)
        if not it:
            return json_response({"ok": False})
        st, avg = item_costs(db).get(it["id"], (0, 0))
        if not req.perms & {"sklad", "prijate"}:
            avg = None                      # nákupní cenu vidí jen sklad a přijaté faktury
        return json_response({"ok": True, "id": it["id"], "name": it["name"], "unit": it["unit"], "price": it["price"],
                              "vat": it["vat_rate"], "fee": it["recycling_fee"], "stock": st, "cost": avg})

    @app.route("/api/polozky")
    def api_items(req):
        return json_response(items_json(db, with_cost=bool(req.perms & {"sklad", "prijate"})))
