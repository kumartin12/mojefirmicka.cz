"""Šifrovaná záloha na USB disk / flashku a obnova z ní.
Soubor .firmicka = hlavička + sůl + nonce + AES-256-GCM(databáze); klíč z hesla přes scrypt.
Heslo je uložené v nastavení (aby zálohovat šlo jedním klikem) – šifrování chrání ztracenou
flashku, ne tento počítač. Pro obnovu na jiném počítači je heslo potřeba znát."""
import hashlib
import os
import secrets
import sqlite3
import string
import sys
import tempfile
import time

MAGIC = b"FIRMICKA-ENC1\n"
FOLDER = "Firmicka-zalohy"
KEEP = 12


class CryptoMissing(RuntimeError):
    pass


def _aesgcm(key):
    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    except ImportError:
        raise CryptoMissing("Chybí knihovna cryptography (v instalačce pro Windows je přibalená).")
    return AESGCM(key)


def _key(password, salt):
    return hashlib.scrypt(password.encode("utf-8"), salt=salt, n=2 ** 15, r=8, p=1, maxmem=2 ** 26, dklen=32)


def encrypt(data, password):
    salt, nonce = secrets.token_bytes(16), secrets.token_bytes(12)
    return MAGIC + salt + nonce + _aesgcm(_key(password, salt)).encrypt(nonce, data, MAGIC)


def decrypt(blob, password):
    if not blob.startswith(MAGIC):
        raise ValueError("Soubor není záloha Firmičky")
    salt, nonce, ct = blob[len(MAGIC):len(MAGIC) + 16], blob[len(MAGIC) + 16:len(MAGIC) + 28], blob[len(MAGIC) + 28:]
    try:
        return _aesgcm(_key(password, salt)).decrypt(nonce, ct, MAGIC)
    except CryptoMissing:
        raise
    except Exception:
        raise ValueError("Špatné heslo nebo poškozený soubor")


# ---------- disky ----------

def drives():
    """Připojené výměnné / externí disky: [{path, label, free, removable}] (bez systémového disku)."""
    out = []
    if os.name == "nt":
        import ctypes
        k = ctypes.windll.kernel32
        system = (os.environ.get("SystemDrive") or "C:").upper()
        mask = k.GetLogicalDrives()
        for i, letter in enumerate(string.ascii_uppercase):
            if not mask & (1 << i):
                continue
            root = letter + ":\\"
            kind = k.GetDriveTypeW(root)
            if kind not in (2, 3) or root[:2] == system:     # 2 = výměnný, 3 = pevný (USB disky se hlásí jako pevné)
                continue
            label = ctypes.create_unicode_buffer(261)
            if not k.GetVolumeInformationW(root, label, 261, None, None, None, None, 0):
                continue                                     # prázdná čtečka karet apod.
            free = ctypes.c_ulonglong(0)
            k.GetDiskFreeSpaceExW(root, None, None, ctypes.byref(free))
            out.append({"path": root, "label": label.value or "", "free": free.value, "removable": kind == 2})
        return out
    user = os.environ.get("USER", "")
    bases = ["/Volumes"] if sys.platform == "darwin" else ["/media/" + user, "/run/media/" + user, "/media", "/mnt"]
    seen = set()
    for base in bases:
        if not os.path.isdir(base):
            continue
        for name in sorted(os.listdir(base)):
            p = os.path.join(base, name)
            if p in seen or not os.path.ismount(p) or name == "Macintosh HD":
                continue
            seen.add(p)
            try:
                st = os.statvfs(p)
                out.append({"path": p, "label": name, "free": st.f_bavail * st.f_frsize, "removable": True})
            except OSError:
                pass
    return out


def backups_on(path):
    d = os.path.join(path, FOLDER)
    if not os.path.isdir(d):
        return []
    return sorted((f for f in os.listdir(d) if f.endswith(".firmicka")), reverse=True)


# ---------- záloha / obnova ----------

def backup_to(db, path, password, firm=""):
    """Zazálohuje databázi na disk `path`, ověří čitelnost a smaže staré (drží KEEP). Vrací cestu souboru."""
    if not password:
        raise ValueError("Nejdřív nastavte heslo zálohy")
    folder = os.path.join(path, FOLDER)
    os.makedirs(folder, exist_ok=True)
    fd, tmpdb = tempfile.mkstemp(suffix=".sqlite")
    os.close(fd)
    try:
        db.backup(tmpdb)
        with open(tmpdb, "rb") as f:
            data = f.read()
    finally:
        os.remove(tmpdb)
    slug = "".join(c for c in firm if c.isalnum())[:20]
    name = "firmicka-%s%s.firmicka" % (time.strftime("%Y%m%d-%H%M%S"), ("-" + slug) if slug else "")
    target = os.path.join(folder, name)
    blob = encrypt(data, password)
    with open(target + ".tmp", "wb") as f:
        f.write(blob)
        f.flush()
        os.fsync(f.fileno())
    os.replace(target + ".tmp", target)
    # ověření: přečíst z disku, dešifrovat, porovnat
    with open(target, "rb") as f:
        if decrypt(f.read(), password) != data:
            raise IOError("Ověření zálohy selhalo – disk může být vadný")
    for old in backups_on(path)[KEEP:]:
        os.remove(os.path.join(folder, old))
    return target


def read_backup(file_path, password):
    """Dešifruje zálohu do dočasného souboru SQLite a ověří ho. Vrací cestu (volající ji smaže)."""
    with open(file_path, "rb") as f:
        data = decrypt(f.read(), password)
    if not data.startswith(b"SQLite format 3\x00"):
        raise ValueError("Obsah zálohy není databáze")
    fd, tmp = tempfile.mkstemp(suffix=".sqlite")
    with os.fdopen(fd, "wb") as f:
        f.write(data)
    c = sqlite3.connect(tmp)
    try:
        if c.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
            raise ValueError("Záloha je poškozená")
        c.execute("SELECT COUNT(*) FROM invoices").fetchone()
    finally:
        c.close()
    return tmp
