"""Adresář odběratelů a dodavatelů + načtení firmy z ARES podle IČO."""
import json
import urllib.request

from .web import h, money, cz_date, flash, flash_redirect, json_response, HTTPError, allowed, ALL_PERMS

FIELDS = ["name", "ico", "dic", "street", "city", "zip", "country", "email", "phone", "note"]
LABELS = {"name": "Název / jméno", "ico": "IČO", "dic": "DIČ", "street": "Ulice a č. p.", "city": "Obec",
          "zip": "PSČ", "country": "Stát", "email": "E-mail", "phone": "Telefon", "note": "Poznámka"}


def address(c):
    """Víceřádková adresa pro fakturu."""
    lines = [c["street"], ("%s %s" % (c["zip"], c["city"])).strip()]
    if c["country"] and c["country"] != "Česká republika":
        lines.append(c["country"])
    return "\n".join(x for x in lines if x)


def prefill(db, req):
    """Odběratel nového dokladu z adresáře (?kontakt=ID – tlačítka v detailu kontaktu)."""
    cid = req.args.get("kontakt", "")
    c = db.one("SELECT * FROM contacts WHERE id = ?", (cid,)) if cid.isdigit() else None
    if not c:
        return {}
    return {"contact_id": c["id"], "cust_name": c["name"], "cust_address": address(c), "cust_ico": c["ico"],
            "cust_dic": c["dic"], "phone": c["phone"], "email": c["email"]}


def ares(ico):
    ico = "".join(ch for ch in ico if ch.isdigit())
    if not 6 <= len(ico) <= 8:
        raise ValueError("IČO má 8 číslic")
    ico = ico.zfill(8)
    url = "https://ares.gov.cz/ekonomicke-subjekty-v-be/rest/ekonomicke-subjekty/" + ico
    req = urllib.request.Request(url, headers={"Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=10) as r:
        d = json.load(r)
    s = d.get("sidlo") or {}
    street = s.get("nazevUlice") or s.get("nazevCastiObce") or ""
    num = str(s.get("cisloDomovni") or "")
    if s.get("cisloOrientacni"):
        num += "/%s%s" % (s["cisloOrientacni"], s.get("cisloOrientacniPismeno") or "")
    return {"name": d.get("obchodniJmeno", ""), "ico": ico, "dic": d.get("dic", "") or "",
            "street": ("%s %s" % (street, num)).strip(), "city": s.get("nazevObce", ""),
            "zip": str(s.get("psc") or ""), "country": s.get("nazevStatu") or "Česká republika"}


def register(app):
    db = app.db

    @app.route("/adresar")
    def index(req):
        qs = req.args.get("q", "").strip()
        sql = "SELECT c.*, (SELECT COUNT(*) FROM invoices i WHERE i.contact_id = c.id) AS n FROM contacts c"
        args = ()
        if qs:
            sql += " WHERE c.name LIKE ? OR c.ico LIKE ? OR c.city LIKE ?"
            args = ("%" + qs + "%",) * 3
        rows = db.q(sql + " ORDER BY c.name COLLATE NOCASE", args)
        trs = "".join(
            "<tr><td><a href='/adresar/%d'>%s</a></td><td>%s</td><td>%s</td><td>%s</td><td class=num>%d</td></tr>"
            % (r["id"], h(r["name"]), h(r["ico"]), h(r["city"]), h(r["email"]), r["n"]) for r in rows)
        return app.page("Adresář", """%s<div class="bar"><h1>Adresář</h1>
<a class="btn primary" href="/adresar/novy">+ Nový kontakt</a></div>
<form class="filters"><input name="q" value="%s" placeholder="Hledat název, IČO, obec"><button>Hledat</button>
<a class="btn" href="/export/adresar.csv">Export CSV</a></form>
<table class="list"><thead><tr><th>Název</th><th>IČO</th><th>Obec</th><th>E-mail</th><th class=num>Faktur</th></tr></thead>
<tbody>%s</tbody></table>%s""" % (flash(req), h(qs), trs,
                                  "" if rows else "<p class=empty>Zatím žádné kontakty.</p>"), "/adresar")

    def documents(c):
        """Doklady zákazníka v detailu kontaktu (jen části programu, kam má uživatel přístup)."""
        from .db import invoice_totals
        perms = getattr(app.local, "perms", None)
        perms = set(ALL_PERMS) if perms is None else perms
        cid = c["id"]
        btns, parts = [], []
        for path, label in (("/faktury/nova", "Nová faktura"), ("/nabidky/nova", "Nová nabídka"), ("/zakazky/nova", "Nová zakázka")):
            if allowed(perms, path):
                btns.append('<a class="btn" href="%s?kontakt=%d">+ %s</a>' % (path, cid, label))

        def table(title, head, rows, empty):
            body = "".join("<tr>%s</tr>" % "".join("<td%s>%s</td>" % (" class=num" if i == len(r) - 2 else "", x)
                                                  for i, x in enumerate(r)) for r in rows)
            parts.append("<h2>%s</h2>" % title + ("<table class=list><thead><tr>%s</tr></thead><tbody>%s</tbody></table>" % (
                "".join("<th%s>%s</th>" % (" class=num" if i == len(head) - 2 else "", x) for i, x in enumerate(head)), body)
                if rows else "<p class=empty>%s</p>" % empty))
        if allowed(perms, "/faktury"):
            from .invoices import STATUS, KINDS, kind_of, lines_of
            rows = []
            for r in db.q("SELECT * FROM invoices WHERE contact_id = ? ORDER BY issue_date DESC, id DESC LIMIT 30", (cid,)):
                k = kind_of(r)
                rows.append(("<a href='/faktury/%d'>%s</a>%s" % (r["id"], h(r["number"]), "" if k == "faktura" else
                                                               " <span class='tag kind'>%s</span>" % KINDS[k]),
                             cz_date(r["issue_date"]), money(invoice_totals(lines_of(db, r["id"]), r["vat_payer"])["total"]),
                             "<span class='tag %s'>%s</span>" % (r["status"], STATUS.get(r["status"], r["status"]))))
            table("Faktury", ["Číslo", "Vystaveno", "Částka", "Stav"], rows, "Žádné faktury.")
        if allowed(perms, "/nabidky"):
            from .quotes import STATUS as QS, TAG as QT
            rows = [("<a href='/nabidky/%d'>%s</a> %s" % (r["id"], h(r["number"]), h(r["title"])), cz_date(r["issue_date"]),
                     "", "<span class='tag %s'>%s</span>" % (QT.get(r["status"], ""), QS.get(r["status"], r["status"])))
                    for r in db.q("SELECT * FROM quotes WHERE contact_id = ? ORDER BY issue_date DESC, id DESC LIMIT 30", (cid,))]
            if rows:
                table("Nabídky", ["Číslo", "Datum", "", "Stav"], rows, "")
        if allowed(perms, "/zakazky"):
            from .jobs import STATUS as JS, TAG as JT
            rows = [("<a href='/zakazky/%d'>%s</a> %s" % (r["id"], h(r["number"]), h(r["title"])), cz_date(r["start_date"]),
                     "", "<span class='tag %s'>%s</span>" % (JT.get(r["status"], ""), JS.get(r["status"], r["status"])))
                    for r in db.q("SELECT * FROM jobs WHERE contact_id = ? ORDER BY start_date DESC, id DESC LIMIT 30", (cid,))]
            if rows:
                table("Zakázky", ["Číslo", "Přijato", "", "Stav"], rows, "")
        if allowed(perms, "/prijate"):
            from .purchases import STATUS as PS
            rows = [("<a href='/prijate/%d'>%s</a> %s" % (r["id"], h(r["doc_number"]), h(r["number"])), cz_date(r["issue_date"]),
                     "", "<span class='tag %s'>%s</span>" % ("zaplacena" if r["status"] == "uhrazena" else "vystavena",
                                                             PS.get(r["status"], r["status"])))
                    for r in db.q("SELECT * FROM purchases WHERE contact_id = ? ORDER BY issue_date DESC, id DESC LIMIT 30", (cid,))]
            if rows:
                table("Přijaté faktury (dodavatel)", ["Evidenční číslo", "Vystaveno", "", "Stav"], rows, "")
        return '<section class="card" id="doklady"><div class="bar"><h2>Doklady</h2><div class="actions">%s</div></div>%s</section>' % (
            " ".join(btns), "".join(parts))

    def form(req, c, cid=None):
        inputs = "".join(
            '<label class="%s">%s<input name="%s" value="%s"%s></label>' % (
                "wide" if k in ("name", "note") else "", LABELS[k], k, h(c.get(k, "")),
                " required" if k == "name" else "") for k in FIELDS)
        delete = ""
        if cid:
            delete = ('<form method="post" action="/adresar/%d/smazat" onsubmit="return confirm(\'Smazat kontakt?\')">'
                      '%s<button class="btn danger">Smazat</button></form>' % (cid, app.csrf()))
        return app.page("Kontakt", """%s<h1>%s</h1>%s
<form method="post" class="grid" id="contact">%s
<div class="wide ares"><button type="button" class="btn" data-ares>Načíst z ARES podle IČO</button>
<span class="hint" id="ares-msg"></span></div>%s
<div class="actions wide"><button class="btn primary">Uložit</button><a class="btn" href="/adresar">Zpět</a></div></form>
%s""" % (flash(req), h(c.get("name")) if cid else "Nový kontakt", documents(c) if cid else "", app.csrf(), inputs,
          delete), "/adresar")

    @app.route("/adresar/novy", ("GET", "POST"))
    def new(req):
        if req.method == "POST":
            vals = [req.f(k) for k in FIELDS]
            if not vals[0]:
                raise HTTPError(400, "Název je povinný")
            cid = db.run("INSERT INTO contacts(%s) VALUES(%s)" % (",".join(FIELDS), ",".join("?" * len(FIELDS))), vals)
            flash_redirect("/adresar/%d" % cid, "Kontakt uložen")
        return form(req, {"country": "Česká republika"})

    @app.route("/adresar/<cid>", ("GET", "POST"))
    def edit(req, cid):
        c = db.one("SELECT * FROM contacts WHERE id = ?", (cid,))
        if not c:
            raise HTTPError(404, "Kontakt neexistuje")
        if req.method == "POST":
            vals = [req.f(k) for k in FIELDS]
            if not vals[0]:
                raise HTTPError(400, "Název je povinný")
            db.run("UPDATE contacts SET %s WHERE id = ?" % ",".join(k + "=?" for k in FIELDS), vals + [c["id"]])
            flash_redirect("/adresar/%d" % c["id"], "Uloženo (vystavené faktury se nemění)")
        return form(req, dict(c), c["id"])

    @app.route("/adresar/<cid>/smazat", ("POST",))
    def delete(req, cid):
        if db.one("SELECT 1 FROM invoices WHERE contact_id = ?", (cid,)):
            flash_redirect("/adresar/%s" % cid, "Kontakt má faktury – nejde smazat")
        db.run("DELETE FROM contacts WHERE id = ?", (cid,))
        flash_redirect("/adresar", "Kontakt smazán")

    @app.route("/api/ares/<ico>")
    def api_ares(req, ico):
        try:
            return json_response({"ok": True, "data": ares(ico)})
        except Exception as e:  # síť, neexistující IČO…
            msg = "Firma nenalezena" if "404" in str(e) else "ARES nedostupný: %s" % e
            return json_response({"ok": False, "error": msg})

    @app.route("/api/kontakty")
    def api_contacts(req):
        return json_response([dict(r, address=address(r)) for r in
                              db.q("SELECT * FROM contacts ORDER BY name COLLATE NOCASE")])
