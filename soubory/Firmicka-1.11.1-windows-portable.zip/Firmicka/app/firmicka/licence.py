"""Licence: klíč podepsaný autorem (Ed25519), vázaný na IČO firmy z nastavení.

Bez licence běží TRIAL_DAYS dní naplno, potom (a po vypršení předplatného nebo při jiném IČO)
jen pro čtení – data jde dál prohlížet, tisknout, exportovat a zálohovat, nové doklady ne.
"""
import base64
import datetime
import json
import os
import struct

from . import ed25519
from .web import Response, flash, flash_redirect, h

PUBLIC_KEY = "7bd3f359488125766f65aa582f23602921889fc042489f85ec7ff60e87d8f120"
PREFIX = "FIRMICKA-"
TRIAL_DAYS = 30
# co jde i bez licence: přihlášení, nastavení (IČO, zálohy, obnova, uživatelé, licence)
FREE = ("/login", "/logout", "/quit", "/nastaveni", "/obrazek")
_B64 = set("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_")
_cache = {}
# zrušené licence (čísla po řádcích) – zapisuje je správce licencí, platí od verze, která je obsahuje
REVOKED_FILE = os.path.join(os.path.dirname(__file__), "zrusene.txt")


def revoked():
    try:
        with open(REVOKED_FILE, encoding="utf-8") as f:
            return {ln.split("#")[0].strip() for ln in f} - {""}
    except OSError:
        return set()


def norm_ico(s):
    d = "".join(ch for ch in (s or "") if ch.isdigit())
    return d.zfill(8) if d else ""


def cz(iso):
    y, m, d = iso.split("-")
    return "%d. %d. %s" % (int(d), int(m), y)


def encode(lic, signer):
    payload = json.dumps(lic, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
    blob = struct.pack(">BH", 1, len(payload)) + payload + signer(payload)
    return PREFIX + base64.urlsafe_b64encode(blob).decode().rstrip("=")


def clean(text):
    """Jen samotný klíč z vloženého textu (bez mezer, zalomení a textu kolem), nebo ""."""
    s = "".join((text or "").split())
    i = s.find(PREFIX)
    if i < 0:
        return ""
    run = ""
    for ch in s[i + len(PREFIX):]:
        if ch not in _B64:
            break
        run += ch
    try:
        b = run[:8] + "=" * (-len(run[:8]) % 4)
        n = struct.unpack(">BH", base64.urlsafe_b64decode(b)[:3])[1]
    except Exception:
        return ""
    need = -(-(3 + n + 64) * 4 // 3)            # znaků base64 bez '='
    return PREFIX + run[:need] if len(run) >= need else ""


def decode(text):
    """Licence z klíče (dict), nebo None. Snese mezery/zalomení a text kolem klíče."""
    key = clean(text)
    if not key:
        return None
    run = key[len(PREFIX):]
    if run in _cache:
        return _cache[run]
    lic = None
    try:
        blob = base64.urlsafe_b64decode(run + "=" * (-len(run) % 4))
        ver, n = struct.unpack(">BH", blob[:3])
        payload, sig = blob[3:3 + n], blob[3 + n:3 + n + 64]
        if ver == 1 and ed25519.verify(bytes.fromhex(PUBLIC_KEY), payload, sig):
            lic = json.loads(payload.decode())
    except Exception:
        lic = None
    _cache[run] = lic
    return lic


def state(db, today=None):
    """{"mode": full|trial|readonly, "msg": text pro lištu, "lic": licence|None, "days": zbývá dní|None}"""
    s = db.settings()
    t = today or datetime.date.today().isoformat()
    # vrácení hodin zpět nepomůže: počítá se od nejpozdějšího dne, kdy program běžel
    if s["lic_seen"] > t:
        t = s["lic_seen"]
    elif s["lic_seen"] != t and today is None:
        db.set_settings({"lic_seen": t})
    tday = datetime.date.fromisoformat(t)
    lic = decode(s["license_key"]) if s["license_key"] else None
    if lic and lic["id"] in revoked():
        return {"mode": "readonly", "lic": lic, "days": None,
                "msg": "Licence %s byla zrušena. Data můžete prohlížet a exportovat; pro vystavování dokladů "
                       "se obraťte na dodavatele programu." % lic["id"]}
    if lic:
        ico = norm_ico(s["firm_ico"])
        if lic["ic"] != ico:
            return {"mode": "readonly", "lic": lic, "days": None,
                    "msg": "Licence je vystavena na IČO %s (%s), v nastavení firmy je ale %s. Vystavování dokladů "
                           "je zablokované – opravte IČO v Nastavení." % (lic["ic"], lic["n"], ico or "prázdné IČO")}
        if lic["do"]:
            days = (datetime.date.fromisoformat(lic["do"]) - tday).days
            if days < 0:
                return {"mode": "readonly", "lic": lic, "days": days,
                        "msg": "Licence vypršela %s. Data můžete prohlížet a exportovat, nové doklady jdou "
                               "vystavit po prodloužení licence." % cz(lic["do"])}
            return {"mode": "full", "lic": lic, "days": days,
                    "msg": "Licence vyprší %s (za %d dní) – domluvte si prodloužení." % (cz(lic["do"]), days)
                    if days <= 30 else ""}
        return {"mode": "full", "lic": lic, "days": None, "msg": ""}
    start = datetime.date.fromisoformat(s["trial_start"] or t)
    days = TRIAL_DAYS - (tday - start).days
    if days < 0:
        return {"mode": "readonly", "lic": None, "days": days,
                "msg": "Zkušební doba skončila. Data můžete dál prohlížet, tisknout a exportovat; "
                       "pro vystavování nových dokladů vložte licenci."}
    return {"mode": "trial", "lic": None, "days": days,
            "msg": "Zkušební verze – zbývá %d %s." % (days, "den" if days == 1 else "dny" if 2 <= days <= 4 else "dní")}


def max_users(db):
    st = state(db)
    return st["lic"]["u"] if st["mode"] == "full" and st["lic"] else 0


def register(app):
    db = app.db
    if not db.settings()["trial_start"]:
        db.set_settings({"trial_start": datetime.date.today().isoformat()})

    def banner():
        st = state(db)
        if not st["msg"]:
            return ""
        link = (' <a class="btn" href="/nastaveni/licence">Vložit licenci</a>'
                if "uzivatele" in (getattr(app.local, "perms", None) or set()) else "")
        return "<div class='flash%s'>🔑 %s%s</div>" % (" error" if st["mode"] == "readonly" else "", h(st["msg"]), link)
    app.banners.insert(0, banner)

    def gate(req):
        if req.method != "POST" or req.path.startswith(FREE):
            return None
        st = state(db)
        if st["mode"] != "readonly":
            return None
        return Response(app.page("Licence", "<div class='card'><h1>Jen pro čtení</h1><p>%s</p>"
                                 "<p>Vložit licenci může správce v <a href='/nastaveni/licence'>Nastavení → Licence</a>."
                                 "</p></div>" % h(st["msg"])), 403)
    app.gate = gate

    @app.route("/nastaveni/licence", ("GET", "POST"))
    def page(req):
        s = req.settings
        if req.method == "POST":
            key = req.form.get("license_key", "")
            lic = decode(key)
            if not lic:
                flash_redirect("/nastaveni/licence", "Klíč není platný – zkopírujte celý řádek začínající FIRMICKA-")
            if lic["id"] in revoked():
                flash_redirect("/nastaveni/licence", "Licence %s byla zrušena" % lic["id"])
            ico = norm_ico(s["firm_ico"])
            vals = {"license_key": clean(key)}
            if not ico:
                vals["firm_ico"] = lic["ic"]
                if not s["firm_name"]:
                    vals["firm_name"] = lic["n"]
            elif ico != lic["ic"]:
                flash_redirect("/nastaveni/licence", "Licence je na IČO %s (%s), ve Firmičce máte IČO %s – "
                                                     "licence patří jiné firmě" % (lic["ic"], lic["n"], ico))
            db.set_settings(vals)
            flash_redirect("/nastaveni/licence", "Licence %s uložena – děkujeme!" % lic["id"])
        st = state(db)
        lic = st["lic"]
        if lic:
            info = """<table class="kv"><tr><th>Licence</th><td>%s</td></tr><tr><th>Firma</th><td>%s</td></tr>
<tr><th>IČO</th><td>%s</td></tr><tr><th>Uživatelů</th><td>%s</td></tr><tr><th>Platí</th><td>%s</td></tr></table>""" % (
                h(lic["id"]), h(lic["n"]), h(lic["ic"]), lic["u"] or "neomezeně",
                ("do " + cz(lic["do"])) if lic["do"] else "bez omezení")
        else:
            info = "<p>Licence zatím není vložená.</p>"
        status = {"full": "✅ Platná licence", "trial": "🕑 Zkušební verze", "readonly": "⛔ Jen pro čtení"}[st["mode"]]
        return app.page("Licence", """%s<h1>Licence</h1><section class="card"><h2>%s</h2>%s%s</section>
<section class="card"><h2>%s</h2><form method="post" class="grid">%s
<label class="wide">Licenční klíč<textarea name="license_key" rows="4" required placeholder="FIRMICKA-…"></textarea>
<span class="hint">Klíč jste dostali e-mailem. Platí pro firmu s IČO uvedeným v licenci.</span></label>
<div class="actions wide"><button class="btn primary">Uložit licenci</button></div></form></section>""" % (
            flash(req), status, info, ("<p class='hint'>%s</p>" % h(st["msg"])) if st["msg"] else "",
            "Vyměnit licenci" if lic else "Vložit licenci", app.csrf()), "/nastaveni")


def summary(db):
    """Krátký řádek do Nastavení."""
    st = state(db)
    if st["mode"] == "full":
        lic = st["lic"]
        return "Licence %s pro %s%s" % (h(lic["id"]), h(lic["n"]), (", platí do " + cz(lic["do"])) if lic["do"] else "")
    return h(st["msg"])
