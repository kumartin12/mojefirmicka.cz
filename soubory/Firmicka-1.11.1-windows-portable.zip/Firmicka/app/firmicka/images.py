"""Logo, podpis a razítko firmy: nahrání v Nastavení (PNG/JPG), uložené v databázi (tabulka images – proto
jsou v každé záloze) a kopie ve složce dat (obrazky/) pro PDF; zobrazení na fakturách, nabídkách a zakázkových listech (obrazovka i PDF)."""
import base64
import os
import time

from .web import h, flash_redirect, HTTPError, Response

KINDS = {"logo": "Logo", "podpis": "Podpis", "razitko": "Razítko"}
MIME = {"png": "image/png", "jpg": "image/jpeg"}


def folder(data_dir):
    return os.path.join(data_dir, "obrazky")


def path(data_dir, kind):
    """Cesta k obrázku daného druhu, nebo None."""
    for ext in MIME:
        p = os.path.join(folder(data_dir), "%s.%s" % (kind, ext))
        if os.path.isfile(p):
            return p
    return None


def _write(data_dir, kind, ext, data):
    os.makedirs(folder(data_dir), exist_ok=True)
    dest = os.path.join(folder(data_dir), "%s.%s" % (kind, ext))
    for e in MIME:
        other = os.path.join(folder(data_dir), "%s.%s" % (kind, e))
        if e != ext and os.path.isfile(other):
            os.remove(other)
    if os.path.isfile(dest):
        with open(dest, "rb") as f:
            if f.read() == data:
                return
    tmp = dest + ".tmp"
    with open(tmp, "wb") as f:
        f.write(data)
    os.replace(tmp, dest)


def sync(db, data_dir):
    """Srovná složku obrazky/ s databází (při startu a po obnově ze zálohy).
    Data ze starší verze (obrázky jen jako soubory) se nejdřív do databáze převezmou."""
    if db.settings().get("images_db") != "1":
        with db.tx():
            for kind in KINDS:
                p = path(data_dir, kind)
                if p and not db.one("SELECT 1 FROM images WHERE kind = ?", (kind,)):
                    with open(p, "rb") as f:
                        db.run("INSERT INTO images(kind, ext, data, updated) VALUES(?, ?, ?, ?)",
                               (kind, p.rsplit(".", 1)[1], f.read(), int(time.time())))
            db.run("INSERT INTO settings(key, value) VALUES('images_db', '1') "
                   "ON CONFLICT(key) DO UPDATE SET value = '1'")
    rows = {r["kind"]: r for r in db.q("SELECT kind, ext, data FROM images")}
    for kind in KINDS:
        if kind in rows:
            _write(data_dir, kind, rows[kind]["ext"], bytes(rows[kind]["data"]))
        else:
            p = path(data_dir, kind)
            if p:
                os.remove(p)


def inline(data_dir, kind, css=""):
    """<img> s obrázkem přímo v HTML (funguje i při tisku a bez přihlášení k /obrazek)."""
    p = path(data_dir, kind)
    if not p:
        return ""
    with open(p, "rb") as f:
        b64 = base64.b64encode(f.read()).decode()
    return '<img class="%s" src="data:%s;base64,%s" alt="%s">' % (kind, MIME[p.rsplit(".", 1)[1]], b64, KINDS[kind])


def signature_block(data_dir, s):
    """Vystavil + podpis a razítko pod dokladem (HTML)."""
    sig, stamp = inline(data_dir, "podpis"), inline(data_dir, "razitko")
    if not (sig or stamp or s["invoice_issuer"]):
        return ""
    return ('<div class="signoff"><div></div><div class="sigbox"><div class="marks">%s%s</div>'
            '<div class="sigline">Vystavil%s</div></div></div>' % (
                stamp, sig, ": <b>%s</b>" % h(s["invoice_issuer"]) if s["invoice_issuer"] else " (razítko a podpis)"))


def register(app):
    db = app.db
    sync(db, app.data_dir)

    @app.route("/nastaveni/obrazek", ("POST",))
    def upload(req):
        from .pdf import load_image
        kind = req.f("kind")
        if kind not in KINDS:
            raise HTTPError(400)
        if req.f("smazat"):
            db.run("DELETE FROM images WHERE kind = ?", (kind,))
            sync(db, app.data_dir)
            flash_redirect("/nastaveni#obrazky", "%s odstraněno" % KINDS[kind])
        f = req.files.get("soubor")
        if not f:
            flash_redirect("/nastaveni#obrazky", "Vyberte obrázek")
        name, data = f
        ext = "png" if data[:8] == b"\x89PNG\r\n\x1a\n" else "jpg" if data[:2] == b"\xff\xd8" else None
        if not ext:
            flash_redirect("/nastaveni#obrazky", "Obrázek musí být PNG nebo JPG")
        if len(data) > 3_000_000:
            flash_redirect("/nastaveni#obrazky", "Obrázek je větší než 3 MB – zmenšete ho")
        os.makedirs(folder(app.data_dir), exist_ok=True)
        tmp = os.path.join(folder(app.data_dir), "%s.tmp" % kind)
        with open(tmp, "wb") as fh:
            fh.write(data)
        try:
            load_image(tmp)          # ověřit, že ho zvládne i PDF
        except Exception as e:
            os.remove(tmp)
            flash_redirect("/nastaveni#obrazky", "Obrázek nejde použít: %s" % e)
        os.remove(tmp)
        db.run("INSERT INTO images(kind, ext, data, updated) VALUES(?, ?, ?, ?) ON CONFLICT(kind) DO UPDATE SET "
               "ext = excluded.ext, data = excluded.data, updated = excluded.updated", (kind, ext, data, int(time.time())))
        sync(db, app.data_dir)
        flash_redirect("/nastaveni#obrazky", "%s nahráno" % KINDS[kind])

    @app.route("/obrazek/<kind>")
    def serve(req, kind):
        p = path(app.data_dir, kind) if kind in KINDS else None
        if not p:
            raise HTTPError(404)
        with open(p, "rb") as f:
            return Response(f.read(), ctype=MIME[p.rsplit(".", 1)[1]])


def settings_form(app, s):
    cards = []
    for kind, label in KINDS.items():
        has = path(app.data_dir, kind)
        hint = {"logo": "na faktuře vlevo nahoře", "podpis": "nejlépe PNG s průhledným pozadím",
                "razitko": "nejlépe PNG s průhledným pozadím"}[kind]
        cards.append("""<div class="imgcard"><b>%s</b><div class="preview">%s</div>
<form method="post" action="/nastaveni/obrazek" enctype="multipart/form-data">%s<input type="hidden" name="kind" value="%s">
<input type="file" name="soubor" accept=".png,.jpg,.jpeg"><button class="btn">Nahrát</button>%s</form><span class="hint">%s</span></div>""" % (
            label, '<img src="/obrazek/%s?%d" alt="">' % (kind, os.path.getmtime(has)) if has else "<span class=hint>není</span>",
            app.csrf(), kind, ' <button class="link danger" name="smazat" value="1">odstranit</button>' if has else "", hint))
    return """<section class="card" id="obrazky"><h2>Logo, podpis a razítko</h2>
<div class="imgs">%s</div>
<p class="hint">Jméno „Vystavil“ pod podpisem nastavíte nahoře v údajích firmy.</p></section>""" % "".join(cards)
