"""Uživatelé a oprávnění: každý uživatel má zaškrtnuté části programu, ke kterým smí (role majitel,
účetní, skladník, prodavač jsou jen předvolby). Záznam změn (audit).
Dokud žádný uživatel neexistuje, program běží v režimu jednoho uživatele (případně s jedním heslem).
Prvním uživatelem je správce se vším – od té chvíle se každý přihlašuje jménem a heslem."""
import urllib.parse
import json
import secrets
import time

from .db import now
from .web import (h, flash, flash_redirect, hash_password, user_perms, HTTPError, Response, ROLES, MODULES,
                  ALL_PERMS)


def perms_from_form(req):
    return [k for k in ALL_PERMS if req.f("perm_" + k)]


def perm_boxes(selected):
    return '<div class="perms wide">%s</div>' % "".join(
        '<label class="check"><input type="checkbox" name="perm_%s" value="1"%s> %s</label>' % (
            k, " checked" if k in selected else "", h(label)) for k, label, _ in MODULES)


def role_select(current):
    presets = json.dumps({k: v["perms"] for k, v in ROLES.items()})
    return ('<label>Role (předvolba práv)<select name="role" data-presets=\'%s\' onchange="var p=JSON.parse(this.dataset.presets)'
            '[this.value];this.form.querySelectorAll(\'[name^=perm_]\').forEach(function(c){c.checked=p.indexOf(c.name.slice(5))>=0})">'
            '%s</select></label>' % (h(presets), "".join('<option value="%s"%s>%s</option>' % (
                k, " selected" if k == current else "", v["name"]) for k, v in ROLES.items())))


def register(app):
    db = app.db

    def admins(exclude=None):
        """Počet aktivních uživatelů se správou uživatelů (kromě exclude)."""
        return sum(1 for u in db.q("SELECT * FROM users WHERE active = 1 AND id != ?", (exclude or 0,))
                   if "uzivatele" in user_perms(u))

    def max_users_n():
        from .licence import max_users
        return max_users(db)

    def over_limit(exclude=None):
        """Licence na N uživatelů: další aktivní už nejde (0 = neomezeně)."""
        lim = max_users_n()
        return lim and db.one("SELECT COUNT(*) FROM users WHERE active = 1 AND id != ?", (exclude or 0,))[0] >= lim

    def drop_sessions(username, keep=None):
        for tok, sess in list(app.sessions.items()):
            if sess["user"].lower() == username.lower() and tok != keep:
                del app.sessions[tok]

    @app.route("/nastaveni/uzivatele", ("GET", "POST"))
    def index(req):
        first = db.one("SELECT COUNT(*) FROM users WHERE active = 1")[0] == 0
        if req.method == "POST":
            username, pw = req.f("username"), req.form.get("password", "")
            role = "majitel" if first else req.f("role")
            perms = ALL_PERMS if first else perms_from_form(req)
            if not username or role not in ROLES:
                flash_redirect("/nastaveni/uzivatele", "Vyplňte jméno a roli")
            if not perms:
                flash_redirect("/nastaveni/uzivatele", "Zaškrtněte aspoň jednu část programu")
            if len(pw) < 6:
                flash_redirect("/nastaveni/uzivatele", "Heslo musí mít aspoň 6 znaků")
            if over_limit():
                flash_redirect("/nastaveni/uzivatele", "Licence je na %d uživatel%s – nejdřív jiného vypněte, nebo si "
                                                       "rozšiřte licenci" % (max_users_n(), "e" if max_users_n() == 1 else "ů"))
            if db.one("SELECT id FROM users WHERE username = ?", (username,)):
                flash_redirect("/nastaveni/uzivatele", "Uživatel %s už existuje" % username)
            db.run("INSERT INTO users(username, name, role, perms, password_hash, created) VALUES(?,?,?,?,?,?)",
                   (username, req.f("name"), role, ",".join(perms), hash_password(pw), now()))
            if first:
                # zapnulo se přihlašování – tohoto správce rovnou přihlásit, ať se nezamkne
                tok = secrets.token_hex(24)
                app.sessions[tok] = {"user": username, "role": "majitel", "perms": set(ALL_PERMS)}
                return Response("", 302, headers=[("Location", "/nastaveni/uzivatele?msg=" + urllib.parse.quote(
                    "Správce založen – od teď se přihlašuje jménem a heslem")),
                                                  ("Set-Cookie", "firmicka_session=%s; Path=/; HttpOnly; SameSite=Strict" % tok)])
            flash_redirect("/nastaveni/uzivatele", "Uživatel %s založen" % username)
        rows = db.q("SELECT * FROM users ORDER BY active DESC, role, username")
        labels = {k: lab.split(" (")[0].split(",")[0] for k, lab, _ in MODULES}
        trs = "".join("<tr%s><td><a href='/nastaveni/uzivatele/%d'>%s</a></td><td>%s</td><td>%s</td><td class=hint>%s</td><td>%s</td></tr>" % (
            "" if u["active"] else " class=warn", u["id"], h(u["username"]), h(u["name"]), ROLES[u["role"]]["name"],
            "vše" if user_perms(u) == set(ALL_PERMS) else ", ".join(labels[k] for k in ALL_PERMS if k in user_perms(u)),
            "aktivní" if u["active"] else "vypnutý") for u in rows)
        return app.page("Uživatelé", """%s<div class="bar"><h1>Uživatelé a oprávnění</h1>
<a class="btn" href="/nastaveni/audit">Záznam změn</a></div>%s
<table class="list"><thead><tr><th>Přihlašovací jméno</th><th>Jméno</th><th>Role</th><th>Smí do</th><th>Stav</th></tr></thead>
<tbody>%s</tbody></table>
<section class="card"><h2>%s</h2><form method="post" class="grid">%s
<label>Přihlašovací jméno<input name="username" required autocomplete="off"></label>
<label>Celé jméno<input name="name"></label>
<label>Heslo<input type="password" name="password" required minlength="6" autocomplete="new-password"></label>
%s
<div class="actions wide"><button class="btn primary">Založit</button></div></form></section>""" % (
            flash(req),
            '<div class="flash">Zatím nikdo – program je otevřený bez přihlášení. První založený uživatel bude '
            '<b>správce se všemi právy</b> a od té chvíle se každý přihlašuje jménem a heslem.</div>' if first else "",
            trs, "Založit správce" if first else "Nový uživatel", app.csrf(),
            "" if first else role_select("prodavac") + '<p class="wide hint">Smí do (role jen předvyplní, '
                                                       'zaškrtnutí jde libovolně upravit):</p>' + perm_boxes(ROLES["prodavac"]["perms"])),
            "/nastaveni")

    def wh_default(u):
        """Výchozí sklad (pokladna, nové doklady) – jen když je skladů víc."""
        ws = db.q("SELECT * FROM warehouses WHERE active = 1 ORDER BY id")
        if len(ws) < 2:
            return '<input type="hidden" name="warehouse_id" value="%s">' % (u["warehouse_id"] or "")
        return '<label>Výchozí sklad<select name="warehouse_id"><option value="">— první sklad —</option>%s</select></label>' % "".join(
            '<option value="%d"%s>%s</option>' % (w["id"], " selected" if w["id"] == u["warehouse_id"] else "", h(w["name"])) for w in ws)

    @app.route("/nastaveni/uzivatele/<uid>", ("GET", "POST"))
    def edit(req, uid):
        u = db.one("SELECT * FROM users WHERE id = ?", (uid,))
        if not u:
            raise HTTPError(404)
        if req.method == "POST":
            role, active, perms = req.f("role"), 1 if req.f("active") else 0, perms_from_form(req)
            if role not in ROLES:
                raise HTTPError(400)
            if not perms:
                flash_redirect("/nastaveni/uzivatele/%d" % u["id"], "Zaškrtněte aspoň jednu část programu")
            if active and not u["active"] and over_limit(u["id"]):
                flash_redirect("/nastaveni/uzivatele/%d" % u["id"], "Licence je na %d uživatel%s – nejdřív jiného vypněte"
                               % (max_users_n(), "e" if max_users_n() == 1 else "ů"))
            if (not active or "uzivatele" not in perms) and not admins(u["id"]):
                flash_redirect("/nastaveni/uzivatele/%d" % u["id"], "Musí zůstat aspoň jeden aktivní správce uživatelů")
            whv = req.f("warehouse_id")
            wh = int(whv) if whv.isdigit() and db.one("SELECT id FROM warehouses WHERE id = ?", (int(whv),)) else None
            db.run("UPDATE users SET name = ?, role = ?, perms = ?, active = ?, warehouse_id = ? WHERE id = ?",
                   (req.f("name"), role, ",".join(perms), active, wh, u["id"]))
            pw = req.form.get("password", "")
            if pw:
                if len(pw) < 6:
                    flash_redirect("/nastaveni/uzivatele/%d" % u["id"], "Heslo musí mít aspoň 6 znaků")
                db.run("UPDATE users SET password_hash = ? WHERE id = ?", (hash_password(pw), u["id"]))
            # změna práv / vypnutí platí hned – jeho otevřené relace odhlásit (kromě té, ze které se upravuje)
            drop_sessions(u["username"], keep=req.cookies.get("firmicka_session"))
            mine = app.sessions.get(req.cookies.get("firmicka_session", ""))
            if mine and mine["user"].lower() == u["username"].lower():
                mine.update(role=role, perms=set(perms))
            flash_redirect("/nastaveni/uzivatele", "Uloženo")
        return app.page("Uživatel", """%s<h1>Uživatel %s</h1><form method="post" class="grid">%s
<label>Celé jméno<input name="name" value="%s"></label>%s
<label>Nové heslo<input type="password" name="password" placeholder="ponechat" autocomplete="new-password"></label>
<label class="check"><input type="checkbox" name="active" value="1"%s> Aktivní (může se přihlásit)</label>%s
<p class="wide hint">Smí do:</p>%s
<div class="actions wide"><button class="btn primary">Uložit</button><a class="btn" href="/nastaveni/uzivatele">Zpět</a></div>
</form>""" % (flash(req), h(u["username"]), app.csrf(), h(u["name"]), role_select(u["role"]),
              " checked" if u["active"] else "", wh_default(u), perm_boxes(user_perms(u))), "/nastaveni")

    @app.route("/nastaveni/audit")
    def audit(req):
        qs = req.args.get("q", "").strip()
        sql, args = "SELECT * FROM audit", ()
        if qs:
            sql, args = sql + " WHERE username LIKE ? OR action LIKE ? OR detail LIKE ?", ("%" + qs + "%",) * 3
        rows = db.q(sql + " ORDER BY id DESC LIMIT 500", args)
        trs = "".join("<tr><td>%s</td><td>%s</td><td>%s</td><td class=hint>%s</td></tr>" % (
            time.strftime("%d.%m.%Y %H:%M", time.localtime(r["ts"])), h(r["username"] or "—"), h(r["action"]), h(r["detail"]))
            for r in rows)
        return app.page("Záznam změn", """<div class="bar"><h1>Záznam změn</h1></div>
<form class="filters"><input name="q" value="%s" placeholder="Hledat uživatele, akci, číslo dokladu"><button>Hledat</button></form>
<table class="list"><thead><tr><th>Kdy</th><th>Kdo</th><th>Akce</th><th>Podrobnosti</th></tr></thead><tbody>%s</tbody></table>""" % (
            h(qs), trs), "/nastaveni")
