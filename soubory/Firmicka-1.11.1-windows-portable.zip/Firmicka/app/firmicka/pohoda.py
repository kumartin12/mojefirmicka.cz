"""Export vydaných a přijatých faktur do účetnictví POHODA (XML import, schéma Stormware version_2).
V Pohodě: Soubor → Datová komunikace → XML import. Recyklační poplatek jde jako samostatná položka
(stejná sazba DPH), stav úhrady se nepřenáší – úhrady si Pohoda páruje z banky sama."""
import xml.etree.ElementTree as ET

from . import __version__
from .db import line_fee

NS = {"dat": "http://www.stormware.cz/schema/version_2/data.xsd",
      "inv": "http://www.stormware.cz/schema/version_2/invoice.xsd",
      "typ": "http://www.stormware.cz/schema/version_2/type.xsd"}
RATES = {21: "high", 12: "low", 0: "none"}
PAYMENTS = {"prevod": "draft", "hotove": "cash", "karta": "creditcard", "dobirka": "delivery"}
POHODA_TYPES = {"faktura": "issuedInvoice", "dobropis": "issuedCreditNotice", "zaloha": "issuedAdvanceInvoice",
                "ddkpp": "issuedInvoice"}


def _e(parent, tag, text=None):
    pre, name = tag.split(":")
    e = ET.SubElement(parent, "{%s}%s" % (NS[pre], name))
    if text is not None:
        e.text = str(text)
    return e


def _address(parent, name, address, ico, dic):
    lines = [x.strip() for x in (address or "").split("\n") if x.strip()]
    street = lines[0] if lines else ""
    zip_, city = "", ""
    if len(lines) > 1:
        parts = lines[1].split(" ")
        if len(parts) > 1 and parts[0].isdigit() and len(parts[0]) == 3 and parts[1].isdigit():
            zip_, city = parts[0] + parts[1], " ".join(parts[2:])      # „301 00 Plzeň“
        elif parts[0].isdigit():
            zip_, city = parts[0], " ".join(parts[1:])
        else:
            city = lines[1]
    a = _e(_e(parent, "inv:partnerIdentity"), "typ:address")
    _e(a, "typ:company", name[:255])
    if city:
        _e(a, "typ:city", city[:45])
    if street:
        _e(a, "typ:street", street[:64])
    if zip_:
        _e(a, "typ:zip", zip_[:15])
    if ico:
        _e(a, "typ:ico", ico[:15])
    if dic:
        _e(a, "typ:dic", dic[:18])


def _items(parent, lines, vat_payer):
    det = _e(parent, "inv:invoiceDetail")
    for ln in lines:
        parts = [(ln["text"], ln["price"])]
        if line_fee(ln):
            parts.append(("recyklační poplatek – " + ln["text"], line_fee(ln)))
        for text, price in parts:
            it = _e(det, "inv:invoiceItem")
            _e(it, "inv:text", text[:90])
            _e(it, "inv:quantity", "%g" % ln["qty"])
            _e(it, "inv:unit", (ln["unit"] or "ks")[:10])
            _e(it, "inv:payVAT", "false")                       # cena za jednotku je bez DPH
            _e(it, "inv:rateVAT", RATES.get(ln["vat_rate"] if vat_payer else 0, "none"))
            _e(_e(it, "inv:homeCurrency"), "typ:unitPrice", "%.2f" % (price / 100))


def _invoice(pack, n, kind, number, vs, original, issue, tax, due, text, party, payment, account, note, lines, vat_payer):
    item = _e(pack, "dat:dataPackItem")
    item.set("version", "2.0")
    item.set("id", "%s%04d" % ("FP" if kind.startswith("received") else "FV", n))
    inv = _e(item, "inv:invoice")
    inv.set("version", "2.0")
    h = _e(inv, "inv:invoiceHeader")
    _e(h, "inv:invoiceType", kind)
    _e(_e(h, "inv:number"), "typ:numberRequested", number[:32])
    if vs:
        _e(h, "inv:symVar", "".join(c for c in vs if c.isdigit())[:20])
    if original:
        _e(h, "inv:originalDocument", original[:32])
    _e(h, "inv:date", issue)
    if vat_payer:
        _e(h, "inv:dateTax", tax)
    _e(h, "inv:dateAccounting", tax or issue)
    _e(h, "inv:dateDue", due)
    _e(h, "inv:text", text[:240])
    _address(h, *party)
    _e(_e(h, "inv:paymentType"), "typ:paymentType", PAYMENTS.get(payment, "draft"))
    if account and "/" in account:
        num, bank = account.replace(" ", "").split("/", 1)
        acc = _e(h, "inv:account")
        _e(acc, "typ:accountNo", num[:34])
        _e(acc, "typ:bankCode", bank[:9])
    if note:
        _e(h, "inv:note", note)
    _items(inv, lines, vat_payer)
    _e(_e(inv, "inv:invoiceSummary"), "inv:roundingDocument", "none")


def export(s, issued, received):
    """issued = [(invoice_row, lines)], received = [(purchase_row, lines)] → bajty XML (windows-1250)."""
    for k, v in NS.items():
        ET.register_namespace(k, v)
    pack = ET.Element("{%s}dataPack" % NS["dat"])
    pack.set("version", "2.0")
    pack.set("id", "Firmicka")
    if s["firm_ico"]:
        pack.set("ico", s["firm_ico"])
    pack.set("application", "Firmička %s" % __version__)
    pack.set("note", "Faktury z Firmičky")
    vp = s["vat_payer"] == "1"
    n = 0
    from .invoices import kind_of, doc_name
    for inv, lines in issued:
        n += 1
        k = kind_of(inv)
        ref = inv["ref_number"] if "ref_number" in inv.keys() else ""
        text = "%s %s" % (doc_name(inv, True), inv["number"]) + (" k dokladu %s" % ref if ref else "")
        if k == "dobropis" and inv["reason"]:
            text += " – " + inv["reason"]
        # ddkpp jako vydaná faktura (nese DPH ze zálohy); konečná faktura má záporné řádky „odpočet zálohy“
        _invoice(pack, n, POHODA_TYPES[k], inv["number"], inv["vs"], "", inv["issue_date"], inv["tax_date"],
                 inv["due_date"], text, (inv["cust_name"], inv["cust_address"], inv["cust_ico"], inv["cust_dic"]),
                 inv["payment"], "", inv["note"], lines, bool(inv["vat_payer"]))
    for p, lines in received:
        n += 1
        _invoice(pack, n, "receivedInvoice", p["doc_number"], p["vs"], p["number"], p["issue_date"], p["tax_date"],
                 p["due_date"], "Přijatá faktura %s – %s" % (p["number"], p["supp_name"]),
                 (p["supp_name"], p["supp_address"], p["supp_ico"], p["supp_dic"]),
                 p["payment"], p["supp_account"], p["note"], lines, vp)
    body = ET.tostring(pack, encoding="unicode")
    return ('<?xml version="1.0" encoding="Windows-1250"?>\n' + body).encode("cp1250", "xmlcharrefreplace")
