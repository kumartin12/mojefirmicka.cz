"""Firmička – sklad, faktury a peněžní deník pro malé firmy a živnostníky."""
__version__ = "1.11.1"
