"""Kalendář (dovolená, nemoc, schůzky, termíny, zavřeno) a interní poznámky firmy.
Kalendář: měsíční mřížka (na mobilu seznam), státní svátky ČR, přehled dovolených po lidech.
Poznámky: sdílené nebo soukromé (vidí jen autor), připnuté nahoře, hledání."""
import calendar as _cal
import datetime
import time
import urllib.parse

from .db import today
from .web import h, cz_date, flash, flash_redirect, HTTPError

KINDS = [("dovolena", "Dovolená"), ("nemoc", "Nemoc / lékař"), ("schuzka", "Schůzka"), ("termin", "Termín / úkol"),
         ("zavreno", "Zavřeno"), ("jine", "Jiné")]
KIND = dict(KINDS)
ABSENCE = ("dovolena", "nemoc")          # počítá se do přehledu nepřítomnosti
MONTHS = ["leden", "únor", "březen", "duben", "květen", "červen", "červenec", "srpen", "září", "říjen",
          "listopad", "prosinec"]
DAYS = ["Po", "Út", "St", "Čt", "Pá", "So", "Ne"]
FIXED = {(1, 1): "Nový rok, Den obnovy samostatného českého státu", (5, 1): "Svátek práce", (5, 8): "Den vítězství",
         (7, 5): "Den slovanských věrozvěstů Cyrila a Metoděje", (7, 6): "Den upálení mistra Jana Husa",
         (9, 28): "Den české státnosti", (10, 28): "Den vzniku samostatného československého státu",
         (11, 17): "Den boje za svobodu a demokracii", (12, 24): "Štědrý den", (12, 25): "1. svátek vánoční",
         (12, 26): "2. svátek vánoční"}


def easter(y):
    """Velikonoční neděle (gregoriánský kalendář, anonymní algoritmus)."""
    a, b, c = y % 19, y // 100, y % 100
    d, e = b // 4, b % 4
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    hh = (19 * a + b - d - g + 15) % 30
    i, k = c // 4, c % 4
    l_ = (32 + 2 * e + 2 * i - hh - k) % 7
    m = (a + 11 * hh + 22 * l_) // 451
    month = (hh + l_ - 7 * m + 114) // 31
    day = (hh + l_ - 7 * m + 114) % 31 + 1
    return datetime.date(y, month, day)


def holidays(y):
    out = {datetime.date(y, m, d): n for (m, d), n in FIXED.items()}
    e = easter(y)
    out[e - datetime.timedelta(days=2)] = "Velký pátek"
    out[e + datetime.timedelta(days=1)] = "Velikonoční pondělí"
    return out


def workdays(d1, d2):
    """Pracovní dny v rozsahu včetně (bez víkendů a státních svátků)."""
    n, d, hol = 0, d1, {}
    while d <= d2:
        if d.year not in hol:
            hol[d.year] = holidays(d.year)
        if d.weekday() < 5 and d not in hol[d.year]:
            n += 1
        d += datetime.timedelta(days=1)
    return n


def iso(s):
    try:
        return datetime.date.fromisoformat(s)
    except (TypeError, ValueError):
        return None


def span(e):
    """Text termínu: „3. 11. 2026“, „3.–7. 11. 2026“, s časem."""
    a, b = e["date_from"], e["date_to"]
    t = (" " + e["time_from"] if e["time_from"] else "") + ("–" + e["time_to"] if e["time_to"] else "")
    if a == b:
        return cz_date(a) + t
    if a[:7] == b[:7]:
        return "%d.–%s%s" % (int(a[8:10]), cz_date(b), t)
    return "%s – %s%s" % (cz_date(a), cz_date(b), t)


def people(db):
    names = [r[0] for r in db.q("SELECT COALESCE(NULLIF(name, ''), username) FROM users WHERE active = 1")]
    names += [r[0] for r in db.q("SELECT DISTINCT person FROM events WHERE person != ''")]
    return sorted(set(n for n in names if n), key=str.lower)


def upcoming_card(db):
    """Karta na Přehled: dnes a příštích 7 dní."""
    t = datetime.date.today()
    end = (t + datetime.timedelta(days=7)).isoformat()
    rows = db.q("SELECT * FROM events WHERE date_from <= ? AND date_to >= ? ORDER BY date_from, time_from, id",
                (end, t.isoformat()))
    hol = [(d, n) for d, n in sorted(holidays(t.year).items()) + sorted(holidays(t.year + 1).items())
           if t <= d <= t + datetime.timedelta(days=7)]
    items = [(e["date_from"], e["time_from"], "<li><span class=hint>%s</span> <span class='tag ev-%s'>%s</span><br>"
              "<a href='/kalendar/%d'>%s</a>%s</li>" % (span(e), e["kind"], KIND.get(e["kind"], ""), e["id"], h(e["title"]),
                                                       " · " + h(e["person"]) if e["person"] else "")) for e in rows]
    items += [(d.isoformat(), "", "<li><span class=hint>%s</span> <span class='tag ev-svatek'>Svátek</span><br>%s</li>" % (
        cz_date(d.isoformat()), h(n))) for d, n in hol]
    body = "<ul>%s</ul>" % "".join(x[2] for x in sorted(items)) if items else "<p class=empty>Nic naplánováno.</p>"
    return ('<section class="card agenda"><h2>Kalendář – 7 dní <a class="hint" href="/kalendar">celý kalendář →</a></h2>'
            '%s</section>' % body)


def register(app):
    db = app.db

    def tabs(on):
        return '<div class="bar">%s</div>' % "".join(
            '<a class="btn%s" href="%s">%s</a>' % (" primary" if u == on else "", u, t)
            for u, t in (("/kalendar", "Kalendář"), ("/kalendar/poznamky", "Poznámky"), ("/kalendar/prehled", "Dovolené")))

    # ---------- kalendář ----------
    def view_switch(week, month_url, week_url):
        return '<div class="seg"><a class="btn%s" href="%s">Měsíc</a><a class="btn%s" href="%s">Týden</a></div>' % (
            "" if week else " primary", month_url, " primary" if week else "", week_url)

    def week(req):
        t = datetime.date.today()
        d0 = iso(req.args.get("tyden", "")) or t
        if not 1900 <= d0.year <= 2200:
            d0 = t
        mon = d0 - datetime.timedelta(days=d0.weekday())
        sun = mon + datetime.timedelta(days=6)
        who = req.args.get("kdo", "")
        sql, args = "SELECT * FROM events WHERE date_from <= ? AND date_to >= ?", [sun.isoformat(), mon.isoformat()]
        if who:
            sql += " AND person = ?"
            args.append(who)
        evs = db.q(sql + " ORDER BY date_from, time_from, id", args)
        hol = {**holidays(mon.year), **holidays(sun.year)}
        q = "&kdo=" + h(urllib.parse.quote(who)) if who else ""
        cols = []
        for i in range(7):
            d = mon + datetime.timedelta(days=i)
            ds = d.isoformat()
            day_evs = [e for e in evs if e["date_from"] <= ds <= e["date_to"]]
            allday = [e for e in day_evs if not e["time_from"] or e["date_from"] != e["date_to"]]
            timed = sorted([e for e in day_evs if e not in allday], key=lambda e: e["time_from"])

            def card(e, timed_ev):
                when = ""
                if timed_ev:
                    when = "<b class='t'>%s%s</b>" % (h(e["time_from"]), "–" + h(e["time_to"]) if e["time_to"] else "")
                elif e["date_from"] != e["date_to"]:
                    when = "<span class='t'>%s</span>" % h(span(e))
                return ("<a class='wev ev-%s' href='/kalendar/%d'>%s<span class='tt'>%s</span>%s%s</a>" % (
                    e["kind"], e["id"], when, h(e["title"]),
                    "<span class='who'>%s</span>" % h(e["person"]) if e["person"] else "",
                    "<span class='nt'>%s</span>" % h(e["note"]) if e["note"] else ""))
            cls = ["wday"] + (["weekend"] if d.weekday() >= 5 else []) + (["holiday"] if d in hol else []) +                 (["today"] if d == t else [])
            body = "".join(card(e, False) for e in allday) + "".join(card(e, True) for e in timed)
            cols.append("<div class='%s'><div class='wh'><a href='/kalendar/novy?datum=%s' title='Přidat událost'>"
                        "<span>%s</span> <b>%d. %d.</b></a>%s</div><div class='wb'>%s</div></div>" % (
                            " ".join(cls), ds, DAYS[i], d.day, d.month,
                            "<span class='hol'>%s</span>" % h(hol[d]) if d in hol else "",
                            body or "<a class='wadd' href='/kalendar/novy?datum=%s'>+</a>" % ds))
        if mon.month == sun.month:
            title = "%d.–%d. %d. %d" % (mon.day, sun.day, sun.month, sun.year)
        elif mon.year == sun.year:
            title = "%d. %d. – %d. %d. %d" % (mon.day, mon.month, sun.day, sun.month, sun.year)
        else:
            title = "%d. %d. %d – %d. %d. %d" % (mon.day, mon.month, mon.year, sun.day, sun.month, sun.year)
        psel = '<option value="">všichni</option>' + "".join(
            '<option%s>%s</option>' % (" selected" if p == who else "", h(p)) for p in people(db))
        legend = " ".join("<span class='tag ev-%s'>%s</span>" % (k, v) for k, v in KINDS)
        return app.page("Kalendář", """%s%s<div class="bar"><h1>Týden %d <small class="hint">%s</small></h1><div class="actions">%s
<a class="btn" href="/kalendar?tyden=%s%s" title="Předchozí týden">←</a><a class="btn" href="/kalendar?tyden=%s%s">Dnes</a>
<a class="btn" href="/kalendar?tyden=%s%s" title="Další týden">→</a>
<a class="btn primary" href="/kalendar/novy">+ Událost</a></div></div>
<form class="filters">Kdo <select name="kdo" onchange="this.form.submit()">%s</select>
<input type="hidden" name="tyden" value="%s"> <span class="legend">%s</span></form>
<div class="week">%s</div>""" % (
            flash(req), tabs("/kalendar"), mon.isocalendar()[1], title,
            view_switch(True, "/kalendar?mesic=%s%s" % (mon.strftime("%Y-%m"), q), "#"),
            (mon - datetime.timedelta(days=7)).isoformat(), q, t.isoformat(), q,
            (mon + datetime.timedelta(days=7)).isoformat(), q, psel, mon.isoformat(), legend, "".join(cols)), "/kalendar")

    @app.route("/kalendar")
    def month(req):
        if "tyden" in req.args:
            return week(req)
        t = datetime.date.today()
        m = req.args.get("mesic", "")
        try:
            first = datetime.date(int(m[:4]), int(m[5:7]), 1) if len(m) == 7 else t.replace(day=1)
        except ValueError:
            first = t.replace(day=1)
        if not 1900 <= first.year <= 2200:         # svátky sousedních roků, rozumný rozsah
            first = t.replace(day=1)
        last = first.replace(day=_cal.monthrange(first.year, first.month)[1])
        who = req.args.get("kdo", "")
        sql, args = "SELECT * FROM events WHERE date_from <= ? AND date_to >= ?", [last.isoformat(), first.isoformat()]
        if who:
            sql += " AND person = ?"
            args.append(who)
        evs = db.q(sql + " ORDER BY date_from, time_from, id", args)
        hol = {**holidays(first.year - 1), **holidays(first.year), **holidays(first.year + 1)}   # přesah mřížky přes rok
        prev = (first - datetime.timedelta(days=1)).strftime("%Y-%m")
        nxt = (last + datetime.timedelta(days=1)).strftime("%Y-%m")
        q = "&kdo=" + h(urllib.parse.quote(who)) if who else ""

        def chip(e):
            label = (e["time_from"] + " " if e["time_from"] and e["date_from"] == e["date_to"] else "") + e["title"]
            if e["person"] and e["person"] not in e["title"]:
                label += " · " + e["person"]
            return "<a class='ev ev-%s' href='/kalendar/%d' title='%s'>%s</a>" % (
                e["kind"], e["id"], h(KIND.get(e["kind"], "") + ": " + span(e)), h(label))

        cells = []
        start = first - datetime.timedelta(days=first.weekday())
        d = start
        while d <= last or d.weekday() != 0:
            ds = d.isoformat()
            cls = ["day"]
            if d.month != first.month:
                cls.append("other")
            if d.weekday() >= 5:
                cls.append("weekend")
            if d in hol:
                cls.append("holiday")
            if d == t:
                cls.append("today")
            day_evs = [e for e in evs if e["date_from"] <= ds <= e["date_to"]]
            cells.append("<div class='%s'><a class='num' href='/kalendar/novy?datum=%s' title='Přidat událost'>%d</a>%s%s</div>" % (
                " ".join(cls), ds, d.day, "<span class='hol'>%s</span>" % h(hol[d]) if d in hol else "",
                "".join(chip(e) for e in day_evs)))
            d += datetime.timedelta(days=1)
        # seznam (na mobilu místo mřížky, na počítači pod ní jako souhrn)
        items = []
        for d0, n in sorted(hol.items()):
            if first <= d0 <= last:
                items.append((d0.isoformat(), "", "<li><b>%s</b> <span class='tag ev-svatek'>Svátek</span> %s</li>" % (
                    cz_date(d0.isoformat()), h(n))))
        for e in evs:
            items.append((max(e["date_from"], first.isoformat()), e["time_from"], "<li><b>%s</b> <span class='tag ev-%s'>%s</span> "
                          "<a href='/kalendar/%d'>%s</a>%s%s</li>" % (
                              span(e), e["kind"], KIND.get(e["kind"], ""), e["id"], h(e["title"]),
                              " · " + h(e["person"]) if e["person"] else "",
                              "<br><span class=hint>%s</span>" % h(e["note"]) if e["note"] else "")))
        agenda = "".join(x[2] for x in sorted(items)) or "<li class=empty>Tento měsíc nic.</li>"
        psel = '<option value="">všichni</option>' + "".join(
            '<option%s>%s</option>' % (" selected" if p == who else "", h(p)) for p in people(db))
        legend = " ".join("<span class='tag ev-%s'>%s</span>" % (k, v) for k, v in KINDS)
        wk = t if first.year == t.year and first.month == t.month else first
        return app.page("Kalendář", """%s%s<div class="bar"><h1>%s %d</h1><div class="actions">%s
<a class="btn" href="/kalendar?mesic=%s%s" title="Předchozí měsíc">←</a><a class="btn" href="/kalendar%s">Dnes</a>
<a class="btn" href="/kalendar?mesic=%s%s" title="Další měsíc">→</a>
<a class="btn primary" href="/kalendar/novy">+ Událost</a></div></div>
<form class="filters">Kdo <select name="kdo" onchange="this.form.submit()">%s</select>
<input type="hidden" name="mesic" value="%s"> <span class="legend">%s</span></form>
<div class="cal"><div class="dow">%s</div><div class="days">%s</div></div>
<section class="card agenda"><h2>Tento měsíc</h2><ul>%s</ul></section>""" % (
            flash(req), tabs("/kalendar"), MONTHS[first.month - 1].capitalize(), first.year,
            view_switch(False, "#", "/kalendar?tyden=%s%s" % (wk.isoformat(), q)),
            prev, q, "?kdo=" + h(urllib.parse.quote(who)) if who else "", nxt, q,
            psel, first.strftime("%Y-%m"), legend,
            "".join("<div>%s</div>" % x for x in DAYS), "".join(cells), agenda), "/kalendar")

    def event_form(req, e, eid=None, err=""):
        ksel = "".join('<option value="%s"%s>%s</option>' % (k, " selected" if k == e.get("kind") else "", v) for k, v in KINDS)
        plist = "".join("<option value='%s'>" % h(p) for p in people(db))
        delete = ('<form method="post" action="/kalendar/%s/smazat" onsubmit="return confirm(\'Smazat událost?\')">%s'
                  '<button class="link danger">smazat událost</button></form>' % (eid, app.csrf())) if eid else ""
        made = ('<p class="hint">Zapsal%s %s</p>' % ("(a)", h(e["username"]) + ", " + time.strftime("%d. %m. %Y %H:%M", time.localtime(e["created"])))
                if eid and e.get("username") else "")
        return app.page("Událost", """<h1>%s</h1>%s
<form method="post" class="card grid">%s
<label class="wide">Co<input name="title" value="%s" required autofocus placeholder="např. Dovolená, Schůzka s dodavatelem"></label>
<label>Druh<select name="kind">%s</select></label>
<label>Kdo<input name="person" value="%s" list="people" placeholder="jméno (nepovinné)"><datalist id="people">%s</datalist></label>
<label>Od<input type="date" name="date_from" value="%s" required></label>
<label>Do<input type="date" name="date_to" value="%s"><span class="hint">prázdné = jen jeden den</span></label>
<label>Čas od<input type="time" name="time_from" value="%s"></label>
<label>Čas do<input type="time" name="time_to" value="%s"></label>
<label class="wide">Poznámka<textarea name="note" rows="3">%s</textarea></label>
<div class="actions wide"><button class="btn primary">Uložit</button><a class="btn" href="/kalendar?mesic=%s">Zpět</a></div>
</form>%s%s""" % (
            "Upravit událost" if eid else "Nová událost", '<div class="flash error">%s</div>' % h(err) if err else "",
            app.csrf(), h(e.get("title")), ksel, h(e.get("person")), plist, h(e.get("date_from")),
            h(e.get("date_to") if e.get("date_to") != e.get("date_from") else ""), h(e.get("time_from")), h(e.get("time_to")),
            h(e.get("note")), (e.get("date_from") or today())[:7], made, delete), "/kalendar")

    def event_from_form(req):
        e = {k: req.f(k) for k in ("title", "kind", "person", "date_from", "date_to", "time_from", "time_to", "note")}
        e["date_to"] = e["date_to"] or e["date_from"]
        if e["kind"] not in KIND:
            e["kind"] = "jine"
        a, b = iso(e["date_from"]), iso(e["date_to"])
        if not e["title"]:
            return e, "Vyplňte, o co jde"
        if not a or not b:
            return e, "Zadejte datum"
        if b < a:
            return e, "Datum „do“ je před datem „od“"
        if (b - a).days > 366:
            return e, "Událost může trvat nejvýš rok"
        for k in ("time_from", "time_to"):
            t = e[k]
            if len(t) == 4 and t[1] == ":":
                t = e[k] = "0" + t                     # 8:00 → 08:00
            if t and not (len(t) == 5 and t[2] == ":" and t.replace(":", "").isdigit()
                          and int(t[:2]) < 24 and int(t[3:]) < 60):
                return e, "Neplatný čas „%s“ (např. 08:30)" % t[:10]
        if e["time_from"] and e["time_to"] and a == b and e["time_to"] < e["time_from"]:
            return e, "Čas „do“ je před časem „od“"
        return e, ""

    @app.route("/kalendar/novy", ("GET", "POST"))
    def new_event(req):
        if req.method == "POST":
            e, err = event_from_form(req)
            if err:
                return event_form(req, e, err=err)
            db.run("INSERT INTO events(title, kind, person, date_from, date_to, time_from, time_to, note, username, created) "
                   "VALUES(?,?,?,?,?,?,?,?,?,?)", (e["title"], e["kind"], e["person"], e["date_from"], e["date_to"],
                                                   e["time_from"], e["time_to"], e["note"], req.user, int(time.time())))
            flash_redirect("/kalendar?mesic=%s" % e["date_from"][:7], "Událost uložena")
        d = req.args.get("datum", "")
        d = d if iso(d) else today()
        return event_form(req, {"kind": req.args.get("druh", "dovolena"), "date_from": d, "date_to": d,
                                "person": req.args.get("kdo", "")})

    @app.route("/kalendar/<eid>", ("GET", "POST"))
    def edit_event(req, eid):
        old = db.one("SELECT * FROM events WHERE id = ?", (eid,))
        if not old:
            raise HTTPError(404, "Událost neexistuje")
        if req.method == "POST":
            e, err = event_from_form(req)
            if err:
                return event_form(req, dict(old, **e), eid, err)
            db.run("UPDATE events SET title = ?, kind = ?, person = ?, date_from = ?, date_to = ?, time_from = ?, time_to = ?, "
                   "note = ? WHERE id = ?", (e["title"], e["kind"], e["person"], e["date_from"], e["date_to"],
                                              e["time_from"], e["time_to"], e["note"], eid))
            flash_redirect("/kalendar?mesic=%s" % e["date_from"][:7], "Událost uložena")
        return event_form(req, dict(old), eid)

    @app.route("/kalendar/<eid>/smazat", ("POST",))
    def delete_event(req, eid):
        e = db.one("SELECT * FROM events WHERE id = ?", (eid,))
        if not e:
            raise HTTPError(404)
        db.run("DELETE FROM events WHERE id = ?", (eid,))
        flash_redirect("/kalendar?mesic=%s" % e["date_from"][:7], "Událost smazána")

    @app.route("/kalendar/prehled")
    def absences(req):
        y = req.args.get("rok", "")
        y = int(y) if y.isdigit() and len(y) == 4 and 1900 <= int(y) <= 2200 else datetime.date.today().year
        y0, y1 = datetime.date(y, 1, 1), datetime.date(y, 12, 31)
        sums, lists = {}, {}
        for e in db.q("SELECT * FROM events WHERE kind IN ('dovolena', 'nemoc') AND date_from <= ? AND date_to >= ? "
                      "ORDER BY date_from", (y1.isoformat(), y0.isoformat())):
            a, b = max(iso(e["date_from"]), y0), min(iso(e["date_to"]), y1)
            who = e["person"] or "(bez jména)"
            s = sums.setdefault(who, {"dovolena": 0, "nemoc": 0})
            s[e["kind"]] += workdays(a, b)
            lists.setdefault(who, []).append("<a href='/kalendar/%d'>%s</a>%s" % (
                e["id"], span(e), "" if e["kind"] == "dovolena" else " (nemoc)"))
        trs = "".join("<tr><td><a href='/kalendar?kdo=%s'>%s</a></td><td class=num>%d</td><td class=num>%d</td><td>%s</td></tr>" % (
            h(urllib.parse.quote(p)), h(p), s["dovolena"], s["nemoc"], ", ".join(lists[p]))
            for p, s in sorted(sums.items(), key=lambda x: x[0].lower()))
        ysel = "".join('<option%s>%d</option>' % (" selected" if x == y else "", x)
                       for x in range(datetime.date.today().year + 1, datetime.date.today().year - 6, -1))
        return app.page("Dovolené", """%s<div class="bar"><h1>Dovolené a nemoc %d</h1><div class="actions">
<a class="btn primary" href="/kalendar/novy?druh=dovolena">+ Dovolená</a></div></div>
<form class="filters">Rok <select name="rok" onchange="this.form.submit()">%s</select>
<span class="hint">Počítají se pracovní dny (bez víkendů a státních svátků).</span></form>
%s""" % (tabs("/kalendar/prehled"), y, ysel,
            "<table class=list><thead><tr><th>Kdo</th><th class=num>Dovolená (dní)</th><th class=num>Nemoc (dní)</th>"
            "<th>Termíny</th></tr></thead><tbody>%s</tbody></table>" % trs if trs else
            "<p class=empty>V roce %d zatím nikdo dovolenou ani nemoc nezapsal.</p>" % y), "/kalendar")

    # ---------- poznámky ----------
    def visible(n, req):
        return not n["private"] or n["username"] == req.user

    @app.route("/kalendar/poznamky")
    def notes(req):
        qs = req.args.get("q", "").strip()
        sql, args = "SELECT * FROM notes WHERE (private = 0 OR username = ?)", [req.user]
        if qs:
            sql += " AND (title LIKE ? OR body LIKE ?)"
            args += ["%" + qs + "%"] * 2
        rows = db.q(sql + " ORDER BY pinned DESC, updated DESC", args)
        multi = bool(db.one("SELECT COUNT(*) FROM users WHERE active = 1")[0])
        cards = "".join("""<article class="note%s"><div class="note-head"><a href="/kalendar/poznamky/%d"><b>%s</b></a>%s%s</div>
<div class="note-body">%s</div><div class="hint">%s%s</div></article>""" % (
            " pinned" if n["pinned"] else "", n["id"], h(n["title"] or "(bez názvu)"),
            " <span class=tag>📌 připnuto</span>" if n["pinned"] else "",
            " <span class=tag>🔒 jen pro mě</span>" if n["private"] else "",
            h(n["body"]), h(n["username"]) + " · " if n["username"] and multi else "",
            time.strftime("%d. %m. %Y %H:%M", time.localtime(n["updated"]))) for n in rows)
        return app.page("Poznámky", """%s%s<div class="bar"><h1>Poznámky</h1><div class="actions">
<a class="btn primary" href="/kalendar/poznamky/nova">+ Poznámka</a></div></div>
<form class="filters"><input name="q" value="%s" placeholder="Hledat v poznámkách…"><button class="btn">Hledat</button></form>
<div class="notes">%s</div>""" % (flash(req), tabs("/kalendar/poznamky"), h(qs),
                                     cards or "<p class=empty>%s</p>" % ("Nic nenalezeno." if qs else
                                                                         "Zatím žádné poznámky. Sem si můžete psát interní "
                                                                         "věci – postupy, hesla k Wi-Fi pro zákazníky, co objednat…")),
                        "/kalendar")

    def note_form(req, n, nid=None, err=""):
        multi = bool(db.one("SELECT COUNT(*) FROM users WHERE active = 1")[0])
        private = ('<label class="check"><input type="checkbox" name="private" value="1"%s> Jen pro mě '
                   '<span class="hint">(ostatní uživatelé ji neuvidí)</span></label>' % (" checked" if n.get("private") else "")
                   ) if multi and req.user else ""
        delete = ('<form method="post" action="/kalendar/poznamky/%s/smazat" onsubmit="return confirm(\'Smazat poznámku?\')">%s'
                  '<button class="link danger">smazat poznámku</button></form>' % (nid, app.csrf())) if nid else ""
        return app.page("Poznámka", """<h1>%s</h1>%s
<form method="post" class="card grid">%s
<label class="wide">Nadpis<input name="title" value="%s" autofocus></label>
<label class="wide">Text<textarea name="body" rows="12">%s</textarea></label>
<div class="wide"><label class="check"><input type="checkbox" name="pinned" value="1"%s> Připnout nahoru</label> %s</div>
<div class="actions wide"><button class="btn primary">Uložit</button><a class="btn" href="/kalendar/poznamky">Zpět</a></div>
</form>%s""" % ("Upravit poznámku" if nid else "Nová poznámka", '<div class="flash error">%s</div>' % h(err) if err else "",
                app.csrf(), h(n.get("title")), h(n.get("body")), " checked" if n.get("pinned") else "", private, delete),
            "/kalendar")

    def note_from_form(req):
        return {"title": req.f("title"), "body": req.form.get("body", "").strip(), "pinned": 1 if req.f("pinned") else 0,
                "private": 1 if req.f("private") and req.user else 0}

    @app.route("/kalendar/poznamky/nova", ("GET", "POST"))
    def new_note(req):
        if req.method == "POST":
            n = note_from_form(req)
            if not n["title"] and not n["body"]:
                return note_form(req, n, err="Poznámka je prázdná")
            now = int(time.time())
            db.run("INSERT INTO notes(title, body, pinned, private, username, created, updated) VALUES(?,?,?,?,?,?,?)",
                   (n["title"], n["body"], n["pinned"], n["private"], req.user, now, now))
            flash_redirect("/kalendar/poznamky", "Poznámka uložena")
        return note_form(req, {})

    def own_note(req, nid):
        n = db.one("SELECT * FROM notes WHERE id = ?", (nid,))
        if not n or not visible(n, req):
            raise HTTPError(404, "Poznámka neexistuje")
        return n

    @app.route("/kalendar/poznamky/<nid>", ("GET", "POST"))
    def edit_note(req, nid):
        old = own_note(req, nid)
        if req.method == "POST":
            n = note_from_form(req)
            if old["private"] and old["username"] != req.user:
                raise HTTPError(403)
            if not n["title"] and not n["body"]:
                return note_form(req, dict(old, **n), nid, "Poznámka je prázdná – chcete-li ji odstranit, použijte „smazat“")
            if old["username"] != req.user:
                n["private"] = old["private"]      # cizí poznámku nejde udělat soukromou (zmizela by autorovi)
            db.run("UPDATE notes SET title = ?, body = ?, pinned = ?, private = ?, updated = ? WHERE id = ?",
                   (n["title"], n["body"], n["pinned"], n["private"], int(time.time()), nid))
            flash_redirect("/kalendar/poznamky", "Poznámka uložena")
        return note_form(req, dict(old), nid)

    @app.route("/kalendar/poznamky/<nid>/smazat", ("POST",))
    def delete_note(req, nid):
        own_note(req, nid)
        db.run("DELETE FROM notes WHERE id = ?", (nid,))
        flash_redirect("/kalendar/poznamky", "Poznámka smazána")
