"""Export pro účetní za období: POHODA XML (vydané + přijaté), balík ISDOC (ZIP) a tabulky CSV."""
import io
import zipfile
from datetime import date

from . import isdoc, pohoda
from .db import today
from .invoices import lines_of
from .purchases import plines
from .web import h, flash, flash_redirect, Response

MONTHS = ["leden", "únor", "březen", "duben", "květen", "červen", "červenec", "srpen", "září", "říjen", "listopad", "prosinec"]


def period(args):
    """?rok=2026&obdobi=10 | Q4 | rok → (od, do, popis)."""
    y = args.get("rok", "")
    y = int(y) if y.isdigit() and len(y) == 4 else date.today().year
    p = args.get("obdobi", "%02d" % date.today().month)
    if p.startswith("Q") and p[1:] in ("1", "2", "3", "4"):
        q = int(p[1])
        return "%d-%02d-01" % (y, 3 * q - 2), "%d-%02d-31" % (y, 3 * q), "%d. čtvrtletí %d" % (q, y), p
    if p.isdigit() and 1 <= int(p) <= 12:
        return "%d-%s-01" % (y, p.zfill(2)), "%d-%s-31" % (y, p.zfill(2)), "%s %d" % (MONTHS[int(p) - 1], y), p.zfill(2)
    return "%d-01-01" % y, "%d-12-31" % y, "rok %d" % y, "rok"


def register(app):
    db = app.db

    def docs_in(od, do):
        issued = [(i, lines_of(db, i["id"])) for i in db.q(
            "SELECT i.*, r.number AS ref_number, r.issue_date AS ref_issue_date FROM invoices i "
            "LEFT JOIN invoices r ON r.id = i.ref_id WHERE i.status != 'stornovana' AND i.tax_date BETWEEN ? AND ? "
            "ORDER BY i.tax_date, i.number", (od, do))]
        received = [(p, plines(db, p["id"])) for p in db.q(
            "SELECT * FROM purchases WHERE tax_date BETWEEN ? AND ? ORDER BY tax_date, id", (od, do))]
        return issued, received

    @app.route("/export")
    def index(req):
        od, do, label, p = period(req.args)
        y = od[:4]
        issued, received = docs_in(od, do)
        psel = "".join('<option value="%s"%s>%s</option>' % (v, " selected" if v == p else "", t) for v, t in
                       [("%02d" % (i + 1), m) for i, m in enumerate(MONTHS)] +
                       [("Q%d" % q, "%d. čtvrtletí" % q) for q in range(1, 5)] + [("rok", "celý rok")])
        qs = "rok=%s&obdobi=%s" % (y, p)
        return app.page("Export pro účetní", """%s<div class="bar"><h1>Export pro účetní – %s</h1></div>
<form class="filters"><input name="rok" value="%s" size="4" inputmode="numeric">
<select name="obdobi" onchange="this.form.submit()">%s</select><button>Zobrazit</button></form>
<div class="stats"><div><span>Vydané doklady</span><b>%d</b><small>faktury, dobropisy, zálohy – bez stornovaných, podle DUZP</small></div>
<div><span>Přijaté faktury</span><b>%d</b><small>podle DUZP</small></div></div>
<div class="cols">
<section class="card"><h2>POHODA</h2><p>Vydané i přijaté faktury v jednom souboru XML.<br>
V Pohodě: <i>Soubor → Datová komunikace → XML import</i>.</p>
<p><a class="btn primary" href="/ucetni/pohoda.xml?%s">Stáhnout pro Pohodu</a>
<a class="btn" href="/ucetni/pohoda.xml?%s&co=vydane">jen vydané</a> <a class="btn" href="/ucetni/pohoda.xml?%s&co=prijate">jen přijaté</a></p></section>
<section class="card"><h2>ISDOC</h2><p>Každá vydaná faktura jako elektronická faktura ISDOC (umí ji načíst většina
účetních programů), zabalené v ZIP.</p><p><a class="btn" href="/ucetni/isdoc.zip?%s">Stáhnout ISDOC (ZIP)</a></p></section>
<section class="card"><h2>Tabulky (Excel)</h2><p>
<a class="btn" href="/export/faktury.csv?rok=%s">Vydané faktury</a>
<a class="btn" href="/export/prijate.csv?rok=%s">Přijaté faktury</a>
<a class="btn" href="/export/denik.csv?rok=%s">Peněžní deník</a></p><p class="hint">Tabulky jsou za celý rok %s.</p></section>
<section class="card"><h2>Money S3</h2><p class="hint">Připravujeme – zatím použijte ISDOC.</p></section></div>""" % (
            flash(req), h(label), h(y), psel, len(issued), len(received), qs, qs, qs, qs, h(y), h(y), h(y), h(y)), "/faktury")

    @app.route("/ucetni/pohoda.xml")
    def pohoda_xml(req):
        od, do, label, p = period(req.args)
        issued, received = docs_in(od, do)
        co = req.args.get("co", "")
        if co == "vydane":
            received = []
        elif co == "prijate":
            issued = []
        if not issued and not received:
            flash_redirect("/export?rok=%s&obdobi=%s" % (od[:4], p), "V období %s nejsou žádné faktury" % label)
        return Response(pohoda.export(req.settings, issued, received), ctype="application/xml; charset=windows-1250",
                        headers=[("Content-Disposition", 'attachment; filename="pohoda-%s-%s%s.xml"' % (
                            od[:4], p, "-" + co if co else ""))])

    @app.route("/ucetni/isdoc.zip")
    def isdoc_zip(req):
        od, do, label, p = period(req.args)
        issued, _ = docs_in(od, do)
        if not issued:
            flash_redirect("/export?rok=%s&obdobi=%s" % (od[:4], p), "V období %s nejsou vydané faktury" % label)
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
            for inv, lines in issued:
                name = "".join(c for c in inv["number"] if c.isalnum() or c in "-_")
                z.writestr("%s-%s.isdoc" % (inv["kind"], name), isdoc.export(inv, lines, req.settings, db))
        return Response(buf.getvalue(), ctype="application/zip",
                        headers=[("Content-Disposition", 'attachment; filename="isdoc-%s-%s.zip"' % (od[:4], p))])
