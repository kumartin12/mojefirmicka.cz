"""Více skladů (Hlavní sklad, Sklad 2…) a převodky mezi nimi.
Každý pohyb patří do jednoho skladu; doklady (faktura, přijatá faktura, účtenka) mají svůj sklad.
Nákupní průměr je společný pro položku napříč sklady – převodka hodnotu zásob nemění."""
import json

from .db import warehouse_levels, next_invoice_number, today, now
from .web import h, qty, parse_qty, parse_id, cz_date, flash, flash_redirect, HTTPError


def warehouses(db, active_only=True):
    return db.q("SELECT * FROM warehouses%s ORDER BY id" % (" WHERE active = 1" if active_only else ""))


def wh_names(db):
    return {w["id"]: w["name"] for w in warehouses(db, False)}


def multi(db):
    """Víc aktivních skladů → ve formulářích se ukazuje výběr skladu."""
    return db.one("SELECT COUNT(*) AS n FROM warehouses WHERE active = 1")["n"] > 1


def default_wh(db, req=None):
    """Výchozí sklad přihlášeného uživatele, jinak první aktivní."""
    user = getattr(req, "user", "") if req is not None else ""
    if user:
        u = db.one("SELECT w.id FROM users u JOIN warehouses w ON w.id = u.warehouse_id "
                   "WHERE u.username = ? AND w.active = 1", (user,))
        if u:
            return u["id"]
    w = db.one("SELECT id FROM warehouses WHERE active = 1 ORDER BY id LIMIT 1")
    return w["id"] if w else 1


def read_wh(db, req, fallback=None, name="warehouse_id"):
    """Sklad z formuláře (musí existovat a být aktivní, nebo to být původní sklad dokladu)."""
    v = req.f(name)
    if v.isdigit():
        w = db.one("SELECT id, active FROM warehouses WHERE id = ?", (int(v),))
        if w and (w["active"] or w["id"] == fallback):
            return w["id"]
    return fallback or default_wh(db, req)


def wh_select(db, current, name="warehouse_id", label="Sklad", cls=""):
    """<label> s výběrem skladu; při jediném skladu jen skryté pole (formulář se nemění)."""
    current = int(current or 1)
    ws = warehouses(db)
    if len(ws) <= 1:
        return '<input type="hidden" name="%s" value="%d">' % (name, current if not ws or current == ws[0]["id"] else ws[0]["id"])
    opts = "".join('<option value="%d"%s>%s</option>' % (w["id"], " selected" if w["id"] == current else "", h(w["name"]))
                   for w in ws)
    if current not in [w["id"] for w in ws]:     # doklad ze skladu, který je mezitím vyřazený
        old = db.one("SELECT name FROM warehouses WHERE id = ?", (current,))
        opts = '<option value="%d" selected>%s (vyřazený)</option>' % (current, h(old["name"] if old else "?")) + opts
    return '<label%s>%s<select name="%s" data-warehouse>%s</select></label>' % (
        ' class="%s"' % cls if cls else "", label, name, opts)


def register(app):
    db = app.db

    # ---------- správa skladů ----------
    @app.route("/sklad/sklady", ("GET", "POST"))
    def index(req):
        if req.method == "POST":
            name = req.f("name")
            if not name:
                flash_redirect("/sklad/sklady", "Zadejte název skladu")
            if db.one("SELECT id FROM warehouses WHERE name = ? COLLATE NOCASE", (name,)):
                flash_redirect("/sklad/sklady", "Sklad %s už existuje" % name)
            db.run("INSERT INTO warehouses(name, note) VALUES(?, ?)", (name, req.f("note")))
            flash_redirect("/sklad/sklady", "Sklad %s založen" % name)
        lv = warehouse_levels(db)
        totals = {}
        for per in lv.values():
            for w, q in per.items():
                if q:
                    totals[w] = totals.get(w, 0) + 1
        trs = "".join(
            "<tr%s><td>%d</td><td><a href='/sklad?sklad=%d'>%s</a>%s</td><td>%s</td><td class=num>%d</td><td>"
            "<a class='btn' href='/sklad/sklady/%d'>Upravit</a></td></tr>" % (
                "" if w["active"] else " class=warn", w["id"], w["id"], h(w["name"]),
                "" if w["active"] else " <span class=tag>vyřazený</span>", h(w["note"]), totals.get(w["id"], 0), w["id"])
            for w in warehouses(db, False))
        return app.page("Sklady", """%s<div class="bar"><h1>Sklady</h1><a class="btn" href="/sklad">← Sklad</a>
<a class="btn" href="/sklad/prevodky">Převodky</a></div>
<p class="hint">Každý sklad má vlastní stav zásob. Na fakturách, přijatých fakturách a v pokladně se vybírá, ze kterého
skladu se zboží odepíše nebo kam se naskladní. Mezi sklady se zboží přesouvá převodkou. Nákupní průměrná cena je pro
položku společná.</p>
<table class="list"><thead><tr><th>#</th><th>Název</th><th>Poznámka</th><th class=num>Položek se stavem</th><th></th></tr></thead>
<tbody>%s</tbody></table>
<section class="card"><h2>Nový sklad</h2><form method="post" class="grid">%s
<label>Název<input name="name" required placeholder="např. Sklad 2, Prodejna, Auto technika"></label>
<label>Poznámka<input name="note" placeholder="adresa, kdo má na starosti…"></label>
<div class="actions wide"><button class="btn primary">Založit sklad</button></div></form></section>""" % (
            flash(req), trs, app.csrf()), "/sklad")

    @app.route("/sklad/sklady/<wid>", ("GET", "POST"))
    def edit(req, wid):
        w = db.one("SELECT * FROM warehouses WHERE id = ?", (wid,))
        if not w:
            raise HTTPError(404, "Sklad neexistuje")
        stocked = [r for r in db.q("SELECT it.name, it.unit, SUM(m.qty) AS q FROM movements m JOIN items it ON it.id = m.item_id "
                                   "WHERE m.warehouse_id = ? GROUP BY m.item_id HAVING ABS(SUM(m.qty)) > 1e-9 "
                                   "ORDER BY it.name", (w["id"],))]
        if req.method == "POST":
            action = req.f("akce")
            if action == "smazat":
                used = db.one("SELECT 1 FROM movements WHERE warehouse_id = ? UNION SELECT 1 FROM invoices WHERE warehouse_id = ? "
                              "UNION SELECT 1 FROM purchases WHERE warehouse_id = ? UNION SELECT 1 FROM receipts WHERE warehouse_id = ? "
                              "UNION SELECT 1 FROM transfers WHERE from_wh = ? OR to_wh = ?", (w["id"],) * 6)
                if used:
                    flash_redirect("/sklad/sklady/%d" % w["id"], "Sklad už má pohyby nebo doklady – smazat nejde, jen vyřadit")
                if db.one("SELECT COUNT(*) AS n FROM warehouses WHERE active = 1 AND id != ?", (w["id"],))["n"] == 0:
                    flash_redirect("/sklad/sklady/%d" % w["id"], "Musí zůstat aspoň jeden aktivní sklad")
                with db.tx():
                    db.run("UPDATE users SET warehouse_id = NULL WHERE warehouse_id = ?", (w["id"],))
                    db.run("DELETE FROM warehouses WHERE id = ?", (w["id"],))
                flash_redirect("/sklad/sklady", "Sklad %s smazán" % w["name"])
            name = req.f("name")
            if not name:
                flash_redirect("/sklad/sklady/%d" % w["id"], "Zadejte název skladu")
            if db.one("SELECT id FROM warehouses WHERE name = ? COLLATE NOCASE AND id != ?", (name, w["id"])):
                flash_redirect("/sklad/sklady/%d" % w["id"], "Sklad %s už existuje" % name)
            active = 1 if req.f("active") else 0
            if not active and w["active"]:
                if stocked:
                    flash_redirect("/sklad/sklady/%d" % w["id"], "Na skladě ještě je zboží – nejdřív ho převeďte převodkou "
                                                                 "do jiného skladu (nebo vydejte)")
                if db.one("SELECT COUNT(*) AS n FROM warehouses WHERE active = 1 AND id != ?", (w["id"],))["n"] == 0:
                    flash_redirect("/sklad/sklady/%d" % w["id"], "Musí zůstat aspoň jeden aktivní sklad")
            db.run("UPDATE warehouses SET name = ?, note = ?, active = ? WHERE id = ?", (name, req.f("note"), active, w["id"]))
            flash_redirect("/sklad/sklady", "Sklad uložen")
        st = "".join("<tr><td>%s</td><td class=num>%s %s</td></tr>" % (h(r["name"]), qty(r["q"]), h(r["unit"])) for r in stocked)
        return app.page(w["name"], """%s<h1>Sklad %s</h1><form method="post" class="grid">%s
<label>Název<input name="name" value="%s" required></label>
<label>Poznámka<input name="note" value="%s"></label>
<label class="check wide"><input type="checkbox" name="active" value="1"%s> Aktivní (nabízet na dokladech)</label>
<div class="actions wide"><button class="btn primary">Uložit</button><a class="btn" href="/sklad/sklady">Zpět</a></div></form>
<form method="post" class="inline" onsubmit="return confirm('Smazat sklad?')">%s<input type="hidden" name="akce" value="smazat">
<button class="link danger">Smazat sklad (jen nepoužitý)</button></form>
<h2>Zboží na tomto skladě</h2>%s""" % (
            flash(req), h(w["name"]), app.csrf(), h(w["name"]), h(w["note"]), " checked" if w["active"] else "", app.csrf(),
            "<table class=list><tbody>%s</tbody></table>" % st if st else "<p class=empty>Prázdný.</p>"), "/sklad")

    # ---------- převodky ----------
    @app.route("/sklad/prevodky")
    def transfers(req):
        names = wh_names(db)
        rows = db.q("SELECT t.*, (SELECT COUNT(*) FROM movements m WHERE m.transfer_id = t.id AND m.qty > 0) AS n "
                    "FROM transfers t ORDER BY t.date DESC, t.id DESC LIMIT 500")
        trs = "".join("<tr><td><a href='/sklad/prevodky/%d'>%s</a></td><td>%s</td><td>%s → %s</td><td class=num>%d</td><td>%s</td></tr>" % (
            t["id"], h(t["number"]), cz_date(t["date"]), h(names.get(t["from_wh"], "?")), h(names.get(t["to_wh"], "?")),
            t["n"], h(t["note"])) for t in rows)
        new = ('<a class="btn primary" href="/sklad/prevodky/nova">+ Nová převodka</a>' if multi(db) else
               '<a class="btn primary" href="/sklad/sklady">Založit další sklad</a>')
        return app.page("Převodky", """%s<div class="bar"><h1>Převodky mezi sklady</h1><a class="btn" href="/sklad/sklady">Sklady</a>%s</div>
<table class="list"><thead><tr><th>Číslo</th><th>Datum</th><th>Ze skladu → do skladu</th><th class=num>Položek</th><th>Poznámka</th></tr></thead>
<tbody>%s</tbody></table>%s""" % (flash(req), new, trs, "" if rows else "<p class=empty>Zatím žádné převodky.</p>"), "/sklad")

    @app.route("/sklad/prevodky/nova", ("GET", "POST"))
    def transfer_new(req):
        ws = warehouses(db)
        if len(ws) < 2:
            flash_redirect("/sklad/sklady", "Pro převodku potřebujete aspoň dva aktivní sklady")
        lv = warehouse_levels(db)
        if req.method == "POST":
            src, dst = read_wh(db, req, name="from_wh"), read_wh(db, req, name="to_wh")
            if src == dst:
                flash_redirect("/sklad/prevodky/nova?z=%d" % src, "Zdrojový a cílový sklad musí být různé")
            d = req.f("date") or today()
            moves = []
            for key, val in req.form.items():
                if key.startswith("move_") and val.strip():
                    q = parse_qty(val)
                    iid = int(key[5:])
                    if q < 0:
                        flash_redirect("/sklad/prevodky/nova?z=%d" % src, "Množství nesmí být záporné")
                    if q and db.one("SELECT id FROM items WHERE id = ? AND service = 0", (iid,)):
                        moves.append((iid, q))
            if not moves:
                flash_redirect("/sklad/prevodky/nova?z=%d&do=%d" % (src, dst), "Zadejte množství aspoň u jedné položky")
            short = [db.one("SELECT name FROM items WHERE id = ?", (iid,))["name"] for iid, q in moves
                     if q > lv.get(iid, {}).get(src, 0) + 1e-9]
            if short and not req.f("i_pres_nedostatek"):
                flash_redirect("/sklad/prevodky/nova?z=%d&do=%d" % (src, dst),
                               "Ve zdrojovém skladu není dost zboží: %s" % ", ".join(short))
            with db.tx():
                number = next_invoice_number(db, d, req.settings["transfer_format"], "transfers")
                tid = db.run("INSERT INTO transfers(number, date, from_wh, to_wh, note, username, created) VALUES(?,?,?,?,?,?,?)",
                             (number, d, src, dst, req.f("note"), getattr(req, "user", ""), now()))
                for iid, q in moves:
                    for wh, sign in ((src, -1), (dst, 1)):
                        db.run("INSERT INTO movements(item_id, date, qty, kind, doc, warehouse_id, transfer_id) "
                               "VALUES(?,?,?,'prevod',?,?,?)", (iid, d, sign * q, number, wh, tid))
            flash_redirect("/sklad/prevodky/%d" % tid, "Převodka %s uložena (%d položek)" % (number, len(moves)))
        src = parse_id(req.args.get("z")) or default_wh(db, req)
        ids = [w["id"] for w in ws]
        src = src if src in ids else ids[0]
        dst = parse_id(req.args["do"]) if parse_id(req.args.get("do")) in ids else \
            next(i for i in ids if i != src)
        items = db.q("SELECT * FROM items WHERE active = 1 AND service = 0 ORDER BY name COLLATE NOCASE")
        stocks = {str(i["id"]): {str(w): q for w, q in lv.get(i["id"], {}).items()} for i in items}
        trs = "".join("<tr data-id='%d' data-ean='%s' data-code='%s'><td>%s</td><td>%s</td><td class='num src-q'></td>"
                      "<td class='num dst-q'></td><td><input name='move_%d' class='num count' inputmode='decimal' "
                      "placeholder='—'></td><td>%s</td></tr>" % (
                          i["id"], h(i["ean"]), h(i["code"]), h(i["code"] or i["ean"]), h(i["name"]), i["id"], h(i["unit"]))
                      for i in items)
        sel = lambda name, cur: "".join('<option value="%d"%s>%s</option>' % (w["id"], " selected" if w["id"] == cur else "",
                                                                               h(w["name"])) for w in ws)
        return app.page("Nová převodka", """%s<div class="bar"><h1>Nová převodka</h1><a class="btn" href="/sklad/prevodky">Zpět</a></div>
<form method="post" id="stocktake" class="transfer" data-stocks='%s'>%s
<div class="grid"><label>Ze skladu<select name="from_wh" id="from_wh">%s</select></label>
<label>Do skladu<select name="to_wh" id="to_wh">%s</select></label>
<label>Datum<input type="date" name="date" value="%s"></label>
<label>Poznámka<input name="note"></label></div>
<p class="hint">Pípejte zboží čtečkou (každé pípnutí +1) nebo vepište množství. Řádky bez čísla se nepřevádějí.</p>
<div class="filters"><input id="scan" placeholder="Pípněte EAN…" data-scan autofocus> <span id="scan-msg" class="hint"></span>
<label class="check"><input type="checkbox" id="only-src"> jen zboží, které je ve zdrojovém skladu</label></div>
<table class="list"><thead><tr><th>Kód</th><th>Položka</th><th class=num>Ve zdroji</th><th class=num>V cíli</th>
<th>Převést</th><th></th></tr></thead><tbody>%s</tbody></table>
<label class="check"><input type="checkbox" name="i_pres_nedostatek" value="1"> Převést i když ve zdroji podle evidence chybí
(zdrojový sklad půjde do mínusu)</label>
<div class="actions"><button class="btn primary">Uložit převodku</button><a class="btn" href="/sklad/prevodky">Zrušit</a></div>
</form>""" % (flash(req), h(json.dumps(stocks)), app.csrf(), sel("from_wh", src), sel("to_wh", dst), today(), trs), "/sklad")

    @app.route("/sklad/prevodky/<tid>")
    def transfer_detail(req, tid):
        t = db.one("SELECT * FROM transfers WHERE id = ?", (tid,))
        if not t:
            raise HTTPError(404, "Převodka neexistuje")
        names = wh_names(db)
        rows = db.q("SELECT m.qty, it.id, it.name, it.code, it.unit FROM movements m JOIN items it ON it.id = m.item_id "
                    "WHERE m.transfer_id = ? AND m.qty > 0 ORDER BY it.name", (t["id"],))
        trs = "".join("<tr><td>%s</td><td><a href='/sklad/%d'>%s</a></td><td class=num>%s %s</td></tr>" % (
            h(r["code"]), r["id"], h(r["name"]), qty(r["qty"]), h(r["unit"])) for r in rows)
        return app.page("Převodka " + t["number"], """%s<div class="bar noprint"><a href="/sklad/prevodky">← Převodky</a>
<div class="actions"><button class="btn" onclick="window.print()">Tisk</button>
<form method="post" action="/sklad/prevodky/%d/smazat" class="inline" onsubmit="return confirm('Zrušit převodku? Zboží se vrátí do původního skladu.')">%s
<button class="btn danger">Zrušit převodku</button></form></div></div>
<h1>Převodka %s</h1><p>Datum: <b>%s</b> · Ze skladu: <b>%s</b> → do skladu: <b>%s</b>%s%s</p>
<table class="list"><thead><tr><th>Kód</th><th>Položka</th><th class=num>Množství</th></tr></thead><tbody>%s</tbody></table>
<p class="sign">Vydal: ____________________ &nbsp; Převzal: ____________________</p>""" % (
            flash(req), t["id"], app.csrf(), h(t["number"]), cz_date(t["date"]), h(names.get(t["from_wh"], "?")),
            h(names.get(t["to_wh"], "?")), " · " + h(t["note"]) if t["note"] else "",
            " · vystavil " + h(t["username"]) if t["username"] else "", trs), "/sklad")

    @app.route("/sklad/prevodky/<tid>/smazat", ("POST",))
    def transfer_delete(req, tid):
        t = db.one("SELECT * FROM transfers WHERE id = ?", (tid,))
        if not t:
            raise HTTPError(404, "Převodka neexistuje")
        with db.tx():
            db.run("DELETE FROM movements WHERE transfer_id = ?", (t["id"],))
            db.run("DELETE FROM transfers WHERE id = ?", (t["id"],))
        flash_redirect("/sklad/prevodky", "Převodka %s zrušena" % t["number"])
