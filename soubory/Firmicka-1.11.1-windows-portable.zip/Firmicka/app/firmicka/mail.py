"""Faktura a nabídka e-mailem: PDF (+ ISDOC) v příloze. Buď rovnou přes SMTP firmy,
nebo jako rozepsaný e-mail (.eml s hlavičkou X-Unsent), který otevře poštovní program
(Outlook ho otevře jako koncept k odeslání)."""
from email.message import EmailMessage

from . import pdfdoc
from .db import invoice_totals
from .invoices import lines_of, doc_name, kind_of, references
from .reminders import plain_date, send_mail
from .web import h, money, flash, flash_redirect, HTTPError, Response


def safe(name):
    return "".join(c for c in name if c.isalnum() or c in "-_") or "doklad"


def doc_attachments(db, s, inv, lines):
    """PDF + ISDOC dokladu (pojmenované podle druhu)."""
    from . import isdoc
    slug = {"faktura": "faktura", "zaloha": "zalohova-faktura", "dobropis": "dobropis", "ddkpp": "danovy-doklad"}[kind_of(inv)]
    return [("%s-%s.pdf" % (slug, safe(inv["number"])), pdfdoc.invoice_pdf(inv, lines, s, db.data_dir, references(db, inv)),
             "application/pdf"),
            ("%s-%s.isdoc" % (slug, safe(inv["number"])), isdoc.export(inv, lines, s, db), "application/xml")]


def invoice_mail(db, s, inv):
    from . import isdoc
    lines = lines_of(db, inv["id"])
    total = invoice_totals(lines, inv["vat_payer"])["total"]
    name, k = doc_name(inv), kind_of(inv)
    subject = "%s %s – %s" % (name, inv["number"], s["firm_name"]) if s["firm_name"] else "%s %s" % (name, inv["number"])
    pay = ""
    if inv["payment"] == "prevod" and s["bank_account"] and k in ("faktura", "zaloha") and total > 0:
        pay = "\nÚčet: %s, variabilní symbol: %s\n" % (s["bank_account"], inv["vs"])
    amount = money(abs(total)).replace("\u00a0", " ")
    what = {"faktura": "fakturu č. %s na částku %s se splatností %s." % (inv["number"], amount, plain_date(inv["due_date"])),
            "zaloha": "zálohovou fakturu č. %s na částku %s se splatností %s." % (inv["number"], amount,
                                                                                  plain_date(inv["due_date"])),
            "dobropis": "dobropis č. %s na částku %s." % (inv["number"], amount),
            "ddkpp": "daňový doklad k přijaté platbě č. %s na částku %s." % (inv["number"], amount)}[k]
    body = ("Dobrý den,\n\nv příloze zasíláme %s\n%s\nS pozdravem\n%s" % (
        what, pay, "\n".join(x for x in (s["firm_name"], s["firm_phone"], s["firm_email"]) if x)))
    att = doc_attachments(db, s, inv, lines)
    return subject, body, att


def quote_mail(db, s, q):
    from .quotes import qlines
    lines = qlines(db, q["id"])
    subject = "Cenová nabídka %s%s" % (q["number"], " – " + q["title"] if q["title"] else "")
    body = ("Dobrý den,\n\nv příloze zasíláme cenovou nabídku č. %s%s, platnou do %s.\n\nS pozdravem\n%s" % (
        q["number"], " (%s)" % q["title"] if q["title"] else "", plain_date(q["valid_until"]),
        "\n".join(x for x in (s["firm_name"], s["firm_phone"], s["firm_email"]) if x)))
    return subject, body, [("nabidka-%s.pdf" % safe(q["number"]), pdfdoc.quote_pdf(q, lines, s, db.data_dir), "application/pdf")]


def eml(s, to, subject, body, attachments):
    msg = EmailMessage()
    msg["X-Unsent"] = "1"                    # Outlook: otevřít jako koncept, ne jako přijatou zprávu
    if s["smtp_from"] or s["firm_email"]:
        msg["From"] = s["smtp_from"] or s["firm_email"]
    if to:
        msg["To"] = to
    msg["Subject"] = subject
    msg.set_content(body)
    for name, data, mime in attachments:
        main, sub = mime.split("/", 1)
        msg.add_attachment(data, maintype=main, subtype=sub, filename=name)
    return bytes(msg)


def register(app):
    db = app.db

    def doc(kind, did):
        if kind == "faktury":
            d = db.one("SELECT i.*, c.email FROM invoices i LEFT JOIN contacts c ON c.id = i.contact_id WHERE i.id = ?", (did,))
        else:
            d = db.one("SELECT q.*, c.email FROM quotes q LEFT JOIN contacts c ON c.id = q.contact_id WHERE q.id = ?", (did,))
        if not d:
            raise HTTPError(404, "Doklad neexistuje")
        return d

    @app.route("/faktury/<iid>/pdf")
    def invoice_pdf(req, iid):
        inv = doc("faktury", iid)
        att = doc_attachments(db, req.settings, inv, lines_of(db, inv["id"]))[0]
        return Response(att[1], ctype="application/pdf",
                        headers=[("Content-Disposition", 'attachment; filename="%s"' % att[0])])

    @app.route("/nabidky/<qid>/pdf")
    def quote_pdf(req, qid):
        from .quotes import qlines
        q = doc("nabidky", qid)
        return Response(pdfdoc.quote_pdf(q, qlines(db, q["id"]), req.settings, app.data_dir), ctype="application/pdf",
                        headers=[("Content-Disposition", 'attachment; filename="nabidka-%s.pdf"' % safe(q["number"]))])

    def mail_page(req, kind, did):
        s = req.settings
        d = doc(kind, did)
        subject, body, att = (invoice_mail if kind == "faktury" else quote_mail)(db, s, d)
        if req.method == "POST":
            to, subject, body = req.f("to"), req.f("subject") or subject, req.form.get("body", body)
            if req.f("akce") == "eml":
                return Response(eml(s, to, subject, body, att), ctype="message/rfc822", headers=[
                    ("Content-Disposition", 'attachment; filename="%s.eml"' % att[0][0].rsplit(".", 1)[0])])
            if "@" not in to:
                flash_redirect("/%s/%d/email" % (kind, d["id"]), "Zadejte e-mail příjemce")
            try:
                send_mail(s, to, subject, body, att)
            except Exception as e:
                flash_redirect("/%s/%d/email" % (kind, d["id"]), "Odeslání selhalo: %s" % e)
            if d["contact_id"] and not d["email"]:
                db.run("UPDATE contacts SET email = ? WHERE id = ?", (to, d["contact_id"]))
            if kind == "nabidky" and d["status"] == "koncept":
                db.run("UPDATE quotes SET status = 'odeslana' WHERE id = ?", (d["id"],))
            flash_redirect("/%s/%d" % (kind, d["id"]), "Odesláno na %s" % to)
        files = ", ".join("%s (%d kB)" % (a[0], max(1, len(a[1]) // 1024)) for a in att)
        smtp = bool(s["smtp_host"])
        return app.page("Poslat e-mailem", """%s<div class="bar"><a href="/%s/%d">← Zpět</a></div>
<h1>Poslat e-mailem – %s</h1>
<form method="post" class="grid">%s
<label class="wide">Komu<input name="to" type="email" value="%s"></label>
<label class="wide">Předmět<input name="subject" value="%s"></label>
<label class="wide">Text<textarea name="body" rows="12">%s</textarea></label>
<p class="wide hint">Přílohy: %s</p>
<div class="actions wide">
<button class="btn primary" name="akce" value="poslat"%s>Odeslat</button>
<button class="btn" name="akce" value="eml" formnovalidate>Otevřít v poštovním programu</button></div>
<p class="wide hint">„Otevřít v poštovním programu“ stáhne rozepsaný e-mail i s přílohami – otevřete ho dvojklikem
(Outlook ho otevře jako koncept k odeslání; v Thunderbirdu zvolte „Upravit jako novou zprávu“).%s</p>
</form>""" % (flash(req), kind, d["id"], h(d["number"]), app.csrf(), h(d["email"]), h(subject), h(body), h(files),
              "" if smtp else " disabled title='Nastavte odchozí e-mail v Nastavení'",
              "" if smtp else " Pro přímé odeslání nastavte <a href='/nastaveni#email'>odchozí e-mail</a>."),
            "/" + kind)

    @app.route("/faktury/<iid>/email", ("GET", "POST"))
    def invoice_email(req, iid):
        return mail_page(req, "faktury", iid)

    @app.route("/nabidky/<qid>/email", ("GET", "POST"))
    def quote_email(req, qid):
        return mail_page(req, "nabidky", qid)
