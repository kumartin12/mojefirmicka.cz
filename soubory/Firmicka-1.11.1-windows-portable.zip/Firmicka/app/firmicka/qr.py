"""Minimální generátor QR kódu (bajtový režim, korekce M, verze 1–10) pro QR platbu.
Podle normy ISO/IEC 18004; postup jako v referenční implementaci Project Nayuki (MIT).
Výstup jako SVG – bez závislostí, funguje i v přibaleném Pythonu."""

# korekce M: počet ECC bajtů na blok a počet bloků pro verze 1..10
ECC_PER_BLOCK = [None, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26]
NUM_BLOCKS = [None, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5]
FORMAT_ECL_M = 0


def _raw_modules(ver):
    r = (16 * ver + 128) * ver + 64
    if ver >= 2:
        na = ver // 7 + 2
        r -= (25 * na - 10) * na - 55
        if ver >= 7:
            r -= 36
    return r


def _data_codewords(ver):
    return _raw_modules(ver) // 8 - ECC_PER_BLOCK[ver] * NUM_BLOCKS[ver]


def _gf_mul(x, y):
    z = 0
    for i in reversed(range(8)):
        z = (z << 1) ^ ((z >> 7) * 0x11D)
        z ^= ((y >> i) & 1) * x
    return z


def _rs_divisor(degree):
    res = [0] * (degree - 1) + [1]
    root = 1
    for _ in range(degree):
        for j in range(degree):
            res[j] = _gf_mul(res[j], root)
            if j + 1 < degree:
                res[j] ^= res[j + 1]
        root = _gf_mul(root, 0x02)
    return res


def _rs_remainder(data, divisor):
    res = [0] * len(divisor)
    for b in data:
        factor = b ^ res.pop(0)
        res.append(0)
        for i, c in enumerate(divisor):
            res[i] ^= _gf_mul(c, factor)
    return res


def _encode_data(data, ver):
    bits = []

    def put(val, n):
        bits.extend((val >> i) & 1 for i in reversed(range(n)))

    put(0b0100, 4)                          # bajtový režim
    put(len(data), 8 if ver <= 9 else 16)   # délka
    for b in data:
        put(b, 8)
    cap = _data_codewords(ver) * 8
    put(0, min(4, cap - len(bits)))         # terminátor
    put(0, -len(bits) % 8)
    out = [int("".join(map(str, bits[i:i + 8])), 2) for i in range(0, len(bits), 8)]
    pad = 0xEC
    while len(out) < cap // 8:
        out.append(pad)
        pad ^= 0xEC ^ 0x11
    return out


def _add_ecc(data, ver):
    nb, ecl = NUM_BLOCKS[ver], ECC_PER_BLOCK[ver]
    raw = _raw_modules(ver) // 8
    nshort = nb - raw % nb
    shortlen = raw // nb
    div = _rs_divisor(ecl)
    blocks, k = [], 0
    for i in range(nb):
        dat = data[k:k + shortlen - ecl + (0 if i < nshort else 1)]
        k += len(dat)
        ecc = _rs_remainder(dat, div)
        if i < nshort:
            dat = dat + [0]
        blocks.append(dat + ecc)
    out = []
    for i in range(len(blocks[0])):
        for j, blk in enumerate(blocks):
            if i != shortlen - ecl or j >= nshort:
                out.append(blk[i])
    return out


def _align_positions(ver, size):
    if ver == 1:
        return []
    na = ver // 7 + 2
    step = (ver * 8 + na * 3 + 5) // (na * 4 - 4) * 2
    return list(reversed([size - 7 - i * step for i in range(na - 1)] + [6]))


MASKS = [
    lambda x, y: (x + y) % 2 == 0,
    lambda x, y: y % 2 == 0,
    lambda x, y: x % 3 == 0,
    lambda x, y: (x + y) % 3 == 0,
    lambda x, y: (x // 3 + y // 2) % 2 == 0,
    lambda x, y: x * y % 2 + x * y % 3 == 0,
    lambda x, y: (x * y % 2 + x * y % 3) % 2 == 0,
    lambda x, y: ((x + y) % 2 + x * y % 3) % 2 == 0,
]


class _Matrix:
    def __init__(self, ver):
        self.ver = ver
        self.size = ver * 4 + 17
        self.m = [[False] * self.size for _ in range(self.size)]
        self.fn = [[False] * self.size for _ in range(self.size)]

    def setf(self, x, y, dark):
        self.m[y][x] = dark
        self.fn[y][x] = True

    def function_patterns(self):
        s = self.size
        for i in range(s):
            self.setf(6, i, i % 2 == 0)
            self.setf(i, 6, i % 2 == 0)
        for cx, cy in ((3, 3), (s - 4, 3), (3, s - 4)):
            for dy in range(-4, 5):
                for dx in range(-4, 5):
                    x, y = cx + dx, cy + dy
                    if 0 <= x < s and 0 <= y < s:
                        self.setf(x, y, max(abs(dx), abs(dy)) not in (2, 4))
        ap = _align_positions(self.ver, s)
        n = len(ap)
        for i in range(n):
            for j in range(n):
                if (i, j) in ((0, 0), (0, n - 1), (n - 1, 0)):
                    continue
                for dy in range(-2, 3):
                    for dx in range(-2, 3):
                        self.setf(ap[i] + dx, ap[j] + dy, max(abs(dx), abs(dy)) != 1)
        self.format_bits(0)
        if self.ver >= 7:
            rem = self.ver
            for _ in range(12):
                rem = (rem << 1) ^ ((rem >> 11) * 0x1F25)
            bits = self.ver << 12 | rem
            for i in range(18):
                bit = (bits >> i) & 1 == 1
                a, b = s - 11 + i % 3, i // 3
                self.setf(a, b, bit)
                self.setf(b, a, bit)

    def format_bits(self, mask):
        s = self.size
        data = FORMAT_ECL_M << 3 | mask
        rem = data
        for _ in range(10):
            rem = (rem << 1) ^ ((rem >> 9) * 0x537)
        bits = (data << 10 | rem) ^ 0x5412
        g = lambda i: (bits >> i) & 1 == 1
        for i in range(6):
            self.setf(8, i, g(i))
        self.setf(8, 7, g(6))
        self.setf(8, 8, g(7))
        self.setf(7, 8, g(8))
        for i in range(9, 15):
            self.setf(14 - i, 8, g(i))
        for i in range(8):
            self.setf(s - 1 - i, 8, g(i))
        for i in range(8, 15):
            self.setf(8, s - 15 + i, g(i))
        self.setf(8, s - 8, True)

    def codewords(self, data):
        s, i, total = self.size, 0, len(data) * 8
        right = s - 1
        while right >= 1:
            if right == 6:
                right = 5
            for vert in range(s):
                for j in range(2):
                    x = right - j
                    upward = ((right + 1) & 2) == 0
                    y = s - 1 - vert if upward else vert
                    if not self.fn[y][x] and i < total:
                        self.m[y][x] = (data[i >> 3] >> (7 - (i & 7))) & 1 == 1
                        i += 1
            right -= 2

    def apply_mask(self, k):
        f = MASKS[k]
        for y in range(self.size):
            for x in range(self.size):
                if not self.fn[y][x] and f(x, y):
                    self.m[y][x] = not self.m[y][x]

    def penalty(self):
        s, m, p = self.size, self.m, 0
        lines = [row for row in m] + [[m[y][x] for y in range(s)] for x in range(s)]
        finder_a = [True, False, True, True, True, False, True, False, False, False, False]
        finder_b = finder_a[::-1]
        for ln in lines:
            run = 1
            for i in range(1, s + 1):
                if i < s and ln[i] == ln[i - 1]:
                    run += 1
                else:
                    if run >= 5:
                        p += 3 + run - 5
                    run = 1
            for i in range(s - 10):
                seg = ln[i:i + 11]
                if seg == finder_a or seg == finder_b:
                    p += 40
        for y in range(s - 1):
            for x in range(s - 1):
                c = m[y][x]
                if c == m[y][x + 1] == m[y + 1][x] == m[y + 1][x + 1]:
                    p += 3
        dark = sum(sum(row) for row in m)
        p += abs(dark * 100 // (s * s) - 50) // 5 * 10
        return p


def matrix(text):
    """Vrátí čtvercovou matici bool (True = tmavý modul)."""
    data = text.encode("utf-8")
    for ver in range(1, 11):
        if len(data) + 2 + (ver > 9) <= _data_codewords(ver):
            break
    else:
        raise ValueError("Text je pro QR kód příliš dlouhý (%d B)" % len(data))
    cw = _add_ecc(_encode_data(data, ver), ver)
    best = None
    for k in range(8):
        mx = _Matrix(ver)
        mx.function_patterns()
        mx.codewords(cw)
        mx.apply_mask(k)
        mx.format_bits(k)
        pen = mx.penalty()
        if best is None or pen < best[0]:
            best = (pen, mx)
    return best[1].m


def svg(text, module=4, border=4):
    m = matrix(text)
    n = len(m) + 2 * border
    path = "".join("M%d,%dh1v1h-1z" % (x + border, y + border)
                   for y, row in enumerate(m) for x, d in enumerate(row) if d)
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" width="%d" height="%d" '
            'shape-rendering="crispEdges"><rect width="100%%" height="100%%" fill="#fff"/>'
            '<path d="%s" fill="#000"/></svg>') % (n, n, n * module, n * module, path)


# ---------- QR platba (SPAYD) ----------

def _mod11(digits, weights):
    """Kontrolní součet čísla účtu podle vyhlášky ČNB (váhy zprava 1, 2, 4, 8, 5, 10, 9, 7, 3, 6)."""
    d = digits.zfill(len(weights))
    return sum(int(c) * w for c, w in zip(d, weights)) % 11 == 0


def cz_iban(account):
    """'123-4567890123/0800' nebo už hotový IBAN → IBAN bez mezer, jinak None (i při překlepu v čísle)."""
    a = account.replace(" ", "").upper()
    if a.startswith("CZ") and len(a) == 24 and a[2:].isdigit():
        if int(a[4:] + "1235" + a[2:4]) % 97 != 1:
            return None
        return a
    if "/" not in a:
        return None
    num, bank = a.split("/", 1)
    prefix, _, num = num.rpartition("-")
    if not (bank.isdigit() and len(bank) == 4 and num.isdigit() and (prefix == "" or prefix.isdigit())):
        return None
    if len(prefix) > 6 or len(num) > 10 or not int(num):
        return None
    if not _mod11(prefix, (10, 5, 8, 4, 2, 1)) or not _mod11(num, (6, 3, 7, 9, 10, 5, 8, 4, 2, 1)):
        return None
    bban = bank + prefix.zfill(6) + num.zfill(10)
    check = 98 - int(bban + "123500") % 97   # C=12, Z=35, "00"
    return "CZ%02d%s" % (check, bban)


def spayd(iban, amount_hal, vs="", msg="", due=""):
    parts = ["SPD", "1.0", "ACC:" + iban, "AM:%d.%02d" % divmod(amount_hal, 100), "CC:CZK"]
    if due:
        parts.append("DT:" + due.replace("-", ""))
    if msg:
        parts.append("MSG:" + msg.replace("*", " ")[:60])
    if vs:
        parts.append("X-VS:" + "".join(c for c in vs if c.isdigit())[:10])
    return "*".join(parts)
