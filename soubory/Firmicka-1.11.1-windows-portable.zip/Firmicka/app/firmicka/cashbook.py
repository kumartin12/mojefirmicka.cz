"""Peněžní deník (daňová evidence): příjmy a výdaje v pokladně a na účtu, daňové / nedaňové,
průběžné zůstatky a roční přehled po měsících. Úhrady faktur sem zapisuje modul faktur."""
from .db import CATEGORIES_IN, CATEGORIES_OUT, today
from .web import h, money, parse_money, cz_date, flash, flash_redirect, HTTPError

MONTHS = ["leden", "únor", "březen", "duben", "květen", "červen", "červenec", "srpen", "září", "říjen",
          "listopad", "prosinec"]
ACCOUNTS = {"pokladna": "Pokladna", "banka": "Banka"}


def balances_before(db, s, day):
    """Zůstatky pokladny a banky před daným dnem (počáteční stav z nastavení + pohyby)."""
    out = {"pokladna": int(s["cash_start_pokladna"] or 0), "banka": int(s["cash_start_banka"] or 0)}
    for r in db.q("SELECT account, SUM(CASE direction WHEN 'prijem' THEN amount ELSE -amount END) AS s "
                  "FROM cashbook WHERE date < ? GROUP BY account", (day,)):
        out[r["account"]] += r["s"]
    return out


def year_arg(req):
    y = req.args.get("rok", "")
    return y if y.isdigit() and len(y) == 4 else today()[:4]


def register(app):
    db = app.db

    @app.route("/denik")
    def index(req):
        s = req.settings
        year = year_arg(req)
        month = req.args.get("mesic", today()[5:7] if year == today()[:4] else "")
        acc = req.args.get("ucet", "")
        start = "%s-%s-01" % (year, month or "01")
        end = "%s-%s-31" % (year, month or "12")
        bal = balances_before(db, s, start)
        rows = db.q("SELECT * FROM cashbook WHERE date BETWEEN ? AND ? ORDER BY date, id", (start, end))
        trs, sums = [], {"prijem": 0, "vydaj": 0, "prijem_d": 0, "vydaj_d": 0}
        for r in rows:
            sign = 1 if r["direction"] == "prijem" else -1
            bal[r["account"]] += sign * r["amount"]
            if acc and r["account"] != acc:
                continue
            sums[r["direction"]] += r["amount"]
            if r["taxable"]:
                sums[r["direction"] + "_d"] += r["amount"]
            trs.append("<tr><td>%s</td><td>%s</td><td><a href='/denik/%d'>%s</a>%s</td><td>%s</td><td>%s</td>"
                       "<td class='num in'>%s</td><td class='num out'>%s</td><td class=num>%s</td></tr>" % (
                           cz_date(r["date"]),
                           "<a href='/faktury/%d'>%s</a>" % (r["invoice_id"], h(r["doc"])) if r["invoice_id"] else
                           "<a href='/prijate/%d'>%s</a>" % (r["purchase_id"], h(r["doc"])) if r["purchase_id"] else
                           "<a href='/pokladna/%d'>%s</a>" % (r["receipt_id"], h(r["doc"])) if r["receipt_id"] else h(r["doc"]),
                           r["id"], h(r["text"]), "" if r["taxable"] else " <span class=tag>nedaňový</span>",
                           h(r["category"]), ACCOUNTS[r["account"]],
                           money(r["amount"]) if sign > 0 else "", money(r["amount"]) if sign < 0 else "",
                           money(bal[r["account"]])))
        msel = '<option value="">celý rok</option>' + "".join(
            '<option value="%02d"%s>%s</option>' % (i + 1, " selected" if month == "%02d" % (i + 1) else "", m)
            for i, m in enumerate(MONTHS))
        asel = "".join('<option value="%s"%s>%s</option>' % (k, " selected" if k == acc else "", v)
                       for k, v in [("", "Pokladna i banka")] + list(ACCOUNTS.items()))
        now_bal = balances_before(db, s, "9999-12-31")
        return app.page("Peněžní deník", """%s<div class="bar"><h1>Peněžní deník</h1>
<a class="btn" href="/denik/prehled?rok=%s">Roční přehled</a>
<a class="btn" href="/denik/novy?smer=vydaj">+ Výdaj</a><a class="btn primary" href="/denik/novy?smer=prijem">+ Příjem</a></div>
<div class="stats"><div><span>Pokladna nyní</span><b>%s</b></div><div><span>Banka nyní</span><b>%s</b></div>
<div><span>Příjmy v období</span><b class=in>%s</b><small>daňové %s</small></div>
<div><span>Výdaje v období</span><b class=out>%s</b><small>daňové %s</small></div></div>
<form class="filters"><input name="rok" value="%s" size="4" inputmode="numeric">
<select name="mesic" onchange="this.form.submit()">%s</select><select name="ucet" onchange="this.form.submit()">%s</select>
<button>Zobrazit</button><a class="btn" href="/export/denik.csv?rok=%s">Export CSV</a></form>
<table class="list"><thead><tr><th>Datum</th><th>Doklad</th><th>Text</th><th>Kategorie</th><th>Účet</th>
<th class=num>Příjem</th><th class=num>Výdaj</th><th class=num>Zůstatek</th></tr></thead><tbody>%s</tbody></table>%s""" % (
            flash(req), h(year), money(now_bal["pokladna"]), money(now_bal["banka"]),
            money(sums["prijem"]), money(sums["prijem_d"]), money(sums["vydaj"]), money(sums["vydaj_d"]),
            h(year), msel, asel, h(year), "".join(trs),
            "" if trs else "<p class=empty>V tomto období žádné záznamy.</p>"), "/denik")

    def form(req, r, rid=None):
        direction = r.get("direction", "prijem")
        cats = CATEGORIES_IN if direction == "prijem" else CATEGORIES_OUT
        cat_opts = "".join("<option>%s</option>" % h(c) for c in cats)
        acc = "".join('<option value="%s"%s>%s</option>' % (k, " selected" if k == r.get("account", "banka") else "", v)
                      for k, v in ACCOUNTS.items())
        locked = bool(r.get("invoice_id") or r.get("purchase_id") or r.get("receipt_id"))
        delete = ""
        if rid and not locked:
            delete = ('<form method="post" action="/denik/%d/smazat" onsubmit="return confirm(\'Smazat záznam?\')">%s'
                      '<button class="btn danger">Smazat</button></form>' % (rid, app.csrf()))
        return app.page("Záznam deníku", """<h1>%s</h1>%s<form method="post" class="grid">%s
<label>Směr<select name="direction"><option value="prijem"%s>Příjem</option><option value="vydaj"%s>Výdaj</option></select></label>
<label>Datum<input type="date" name="date" value="%s" required></label>
<label>Účet<select name="account">%s</select></label>
<label>Částka (Kč)<input name="amount" value="%s" inputmode="decimal" required></label>
<label>Doklad č.<input name="doc" value="%s"></label>
<label>Kategorie<input name="category" value="%s" list="cats"></label>
<label class="wide">Text<input name="text" value="%s" required></label>
<label class="check wide"><input type="checkbox" name="taxable" value="1"%s> Daňový (ovlivňuje základ daně)</label>
<div class="actions wide"><button class="btn primary"%s>Uložit</button><a class="btn" href="/denik">Zpět</a></div>
</form><datalist id="cats">%s</datalist>%s""" % (
            "Upravit záznam" if rid else ("Nový příjem" if direction == "prijem" else "Nový výdaj"),
            '<div class="flash">Záznam vznikl úhradou faktury – mění se přes fakturu.</div>' if locked else "",
            app.csrf(), " selected" if direction == "prijem" else "", " selected" if direction == "vydaj" else "",
            h(r.get("date", today())), acc,
            money(r.get("amount", 0), False).replace(" ", "") if r.get("amount") else "",
            h(r.get("doc")), h(r.get("category")), h(r.get("text")), " checked" if r.get("taxable", 1) else "",
            " disabled" if locked else "", cat_opts, delete), "/denik")

    def read(req):
        d = req.f("direction")
        a = req.f("account")
        if d not in ("prijem", "vydaj") or a not in ACCOUNTS:
            raise HTTPError(400, "Neplatný směr nebo účet")
        amount = parse_money(req.f("amount"))
        if amount <= 0:
            raise HTTPError(400, "Částka musí být kladná")
        if not req.f("text"):
            raise HTTPError(400, "Vyplňte text")
        return [req.f("date") or today(), req.f("doc"), req.f("text"), d, a, amount,
                1 if req.f("taxable") else 0, req.f("category")]

    COLS = "date, doc, text, direction, account, amount, taxable, category"

    @app.route("/denik/novy", ("GET", "POST"))
    def new(req):
        if req.method == "POST":
            db.run("INSERT INTO cashbook(%s) VALUES(?,?,?,?,?,?,?,?)" % COLS, read(req))
            flash_redirect("/denik?rok=%s&mesic=%s" % (req.f("date")[:4], req.f("date")[5:7]), "Zapsáno")
        return form(req, {"direction": req.args.get("smer", "prijem"), "taxable": 1,
                          "account": "banka"})

    @app.route("/denik/<rid>", ("GET", "POST"))
    def edit(req, rid):
        r = db.one("SELECT * FROM cashbook WHERE id = ?", (rid,))
        if not r:
            raise HTTPError(404, "Záznam neexistuje")
        if req.method == "POST":
            if r["invoice_id"] or r["purchase_id"] or r["receipt_id"]:
                raise HTTPError(400, "Záznam z faktury se mění přes fakturu")
            db.run("UPDATE cashbook SET %s WHERE id = ?" % ", ".join(c.strip() + "=?" for c in COLS.split(",")),
                   read(req) + [r["id"]])
            flash_redirect("/denik?rok=%s&mesic=%s" % (req.f("date")[:4], req.f("date")[5:7]), "Uloženo")
        return form(req, dict(r), r["id"])

    @app.route("/denik/<rid>/smazat", ("POST",))
    def delete(req, rid):
        r = db.one("SELECT * FROM cashbook WHERE id = ?", (rid,))
        if not r or r["invoice_id"] or r["purchase_id"] or r["receipt_id"]:
            raise HTTPError(400, "Záznam z faktury se ruší zrušením úhrady faktury")
        db.run("DELETE FROM cashbook WHERE id = ?", (rid,))
        flash_redirect("/denik?rok=%s&mesic=%s" % (r["date"][:4], r["date"][5:7]), "Smazáno")

    @app.route("/denik/prehled")
    def summary(req):
        year = year_arg(req)
        rows = db.q("SELECT substr(date, 6, 2) AS m, direction, taxable, SUM(amount) AS s FROM cashbook "
                    "WHERE substr(date, 1, 4) = ? GROUP BY m, direction, taxable", (year,))
        tab = {}
        for r in rows:
            tab.setdefault(r["m"], {})[(r["direction"], r["taxable"])] = r["s"]
        trs, tot = [], {}
        for i, name in enumerate(MONTHS):
            d = tab.get("%02d" % (i + 1), {})
            vals = [d.get(("prijem", 1), 0), d.get(("vydaj", 1), 0), d.get(("prijem", 0), 0), d.get(("vydaj", 0), 0)]
            for k, v in enumerate(vals):
                tot[k] = tot.get(k, 0) + v
            trs.append("<tr><td>%s</td>%s<td class=num><b>%s</b></td></tr>" % (
                name, "".join("<td class=num>%s</td>" % money(v) for v in vals), money(vals[0] - vals[1])))
        foot = "<tr><th>Celkem %s</th>%s<th class=num>%s</th></tr>" % (
            h(year), "".join("<th class=num>%s</th>" % money(tot[k]) for k in range(4)), money(tot[0] - tot[1]))
        cats = db.q("SELECT direction, category, SUM(amount) AS s FROM cashbook WHERE substr(date,1,4) = ? AND taxable = 1 "
                    "GROUP BY direction, category ORDER BY direction, s DESC", (year,))
        ctrs = "".join("<tr><td>%s</td><td>%s</td><td class=num>%s</td></tr>" % (
            "Příjem" if c["direction"] == "prijem" else "Výdaj", h(c["category"] or "—"), money(c["s"])) for c in cats)
        return app.page("Roční přehled", """<div class="bar"><h1>Peněžní deník – přehled %s</h1>
<a class="btn" href="/denik/prehled?rok=%d">← %d</a><a class="btn" href="/denik/prehled?rok=%d">%d →</a>
<button class="btn" onclick="window.print()">Tisk</button></div>
<table class="list"><thead><tr><th>Měsíc</th><th class=num>Příjmy daňové</th><th class=num>Výdaje daňové</th>
<th class=num>Příjmy nedaňové</th><th class=num>Výdaje nedaňové</th><th class=num>Rozdíl (daňový)</th></tr></thead>
<tbody>%s</tbody><tfoot>%s</tfoot></table>
<p class="hint">Rozdíl daňových příjmů a výdajů je podklad pro základ daně (§ 7 ZDP) – před podáním přiznání ověřte s účetní.</p>
<h2>Podle kategorií (daňové)</h2><table class="list"><tbody>%s</tbody></table>""" % (
            h(year), int(year) - 1, int(year) - 1, int(year) + 1, int(year) + 1, "".join(trs), foot, ctrs), "/denik")
