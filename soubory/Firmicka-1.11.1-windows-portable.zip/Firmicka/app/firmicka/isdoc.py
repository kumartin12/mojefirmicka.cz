"""ISDOC 6.0.2 – český standard elektronické faktury (http://isdoc.cz).
Export vydané faktury (účetní ji načte do svého programu bez přepisování) a import přijaté
faktury od dodavatele (.isdoc nebo zabalené .isdocx). Pořadí prvků podle XSD isdoc-invoice-6.0.2."""
import io
import re
import uuid
import xml.etree.ElementTree as ET
import zipfile

from . import __version__, qr
from .db import rnd, invoice_totals, line_fee

NS = "http://isdoc.cz/namespace/2013"
PAYMENT_CODES = {"prevod": "42", "hotove": "10", "karta": "48", "dobirka": "10"}


def _amt(hal):
    return "%.2f" % (hal / 100)


def _split_street(street):
    """'Hlavní 12/3' → ('Hlavní', '12/3')."""
    m = re.match(r"^(.*?)[\s,]+(\d[\w/]*)$", (street or "").strip())
    return (m.group(1), m.group(2)) if m else ((street or "").strip(), "")


def _parse_address(text):
    """Víceřádková adresa z faktury → ulice, č. p., obec, PSČ."""
    lines = [x.strip() for x in (text or "").split("\n") if x.strip()]
    street, num = _split_street(lines[0] if lines else "")
    zip_, city = "", ""
    if len(lines) > 1:
        m = re.match(r"^(\d{3}\s?\d{2})\s+(.*)$", lines[1])
        zip_, city = (m.group(1).replace(" ", ""), m.group(2)) if m else ("", lines[1])
    return street, num, city, zip_


def _el(parent, tag, text=None, **attrs):
    e = ET.SubElement(parent, "{%s}%s" % (NS, tag), attrs)
    if text is not None:
        e.text = str(text)
    return e


def _party(parent, tag, name, ico, dic, street, num, city, zip_):
    p = _el(_el(parent, tag), "Party")
    _el(_el(p, "PartyIdentification"), "ID", ico or "")
    _el(_el(p, "PartyName"), "Name", name)
    a = _el(p, "PostalAddress")
    _el(a, "StreetName", street)
    _el(a, "BuildingNumber", num)
    _el(a, "CityName", city)
    _el(a, "PostalZone", zip_)
    c = _el(a, "Country")
    _el(c, "IdentificationCode", "CZ")
    _el(c, "Name", "Česká republika")
    if dic:
        ts = _el(p, "PartyTaxScheme")
        _el(ts, "CompanyID", dic)
        _el(ts, "TaxScheme", "VAT")


DOC_TYPES = {"faktura": "1", "dobropis": "2", "zaloha": "4", "ddkpp": "5"}


def export(inv, lines, s, db=None):
    """Vydaný doklad → bajty XML ISDOC (faktura 1, dobropis 2, zálohová faktura 4, daňový doklad k platbě 5)."""
    from .invoices import kind_of
    k = kind_of(inv)
    if k == "dobropis":      # ISDOC 5.2.1+: dobropis je vždy v kladných částkách, odečet plyne z typu dokladu
        lines = [dict(ln, qty=-ln["qty"]) for ln in lines]
    ET.register_namespace("", NS)
    vp = bool(inv["vat_payer"])
    t = invoice_totals(lines, vp)
    root = ET.Element("{%s}Invoice" % NS, version="6.0.2")
    _el(root, "DocumentType", DOC_TYPES[k])
    _el(root, "ID", inv["number"])
    _el(root, "UUID", str(uuid.uuid5(uuid.NAMESPACE_URL, "firmicka:%s:%s:%s" % (s["firm_ico"], inv["number"], inv["created"]))).upper())
    _el(root, "IssuingSystem", "Firmička %s" % __version__)
    _el(root, "IssueDate", inv["issue_date"])
    if vp:
        _el(root, "TaxPointDate", inv["tax_date"])
    _el(root, "VATApplicable", "true" if vp else "false")
    _el(root, "ElectronicPossibilityAgreementReference", "")
    if inv["note"]:
        _el(root, "Note", inv["note"])
    _el(root, "LocalCurrencyCode", "CZK")
    _el(root, "CurrRate", "1")
    _el(root, "RefCurrRate", "1")
    fs, fn = _split_street(s["firm_street"])
    _party(root, "AccountingSupplierParty", s["firm_name"], s["firm_ico"], s["firm_dic"], fs, fn, s["firm_city"], s["firm_zip"])
    cs, cn, cc, cz = _parse_address(inv["cust_address"])
    _party(root, "AccountingCustomerParty", inv["cust_name"], inv["cust_ico"], inv["cust_dic"], cs, cn, cc, cz)
    if k == "dobropis":
        keys = inv.keys()
        ref_no = inv["ref_number"] if "ref_number" in keys else ""
        ref_date = inv["ref_issue_date"] if "ref_issue_date" in keys else ""
        if not ref_no and db is not None and inv["ref_id"]:
            r = db.one("SELECT number, issue_date FROM invoices WHERE id = ?", (inv["ref_id"],))
            ref_no, ref_date = (r["number"], r["issue_date"]) if r else ("", "")
        if ref_no:
            odr = _el(_el(root, "OriginalDocumentReferences"), "OriginalDocumentReference")
            _el(odr, "ID", ref_no)
            if ref_date:
                _el(odr, "IssueDate", ref_date)

    il = _el(root, "InvoiceLines")
    parts = []
    for ln in lines:
        rate = ln["vat_rate"] if vp else 0
        pp = [(ln["text"], ln["price"])]
        if line_fee(ln):
            pp.append(("recyklační poplatek – " + ln["text"], line_fee(ln)))
        for text, price in pp:
            b = rnd(ln["qty"] * price)
            parts.append({"ln": ln, "text": text, "price": price, "rate": rate, "base": b, "vat": rnd(b * rate / 100)})
    # DPH se počítá ze součtu základů za sazbu (rekapitulace); haléřový rozdíl po zaokrouhlení řádků dorovnat
    # na největším řádku sazby, ať součet řádků sedí s TaxSubTotal (jinak import v účetním programu hlásí rozdíl)
    for r in t["recap"]:
        same = [x for x in parts if x["rate"] == r["rate"]]
        diff = r["vat"] - sum(x["vat"] for x in same)
        if same and diff:
            max(same, key=lambda x: abs(x["base"]))["vat"] += diff
    for n, x in enumerate(parts, 1):
        ln, rate, base, vat, price = x["ln"], x["rate"], x["base"], x["vat"], x["price"]
        e = _el(il, "InvoiceLine")
        _el(e, "ID", str(n))
        _el(e, "InvoicedQuantity", ("%g" % ln["qty"]), unitCode=ln["unit"] or "ks")
        _el(e, "LineExtensionAmount", _amt(base))
        _el(e, "LineExtensionAmountTaxInclusive", _amt(base + vat))
        _el(e, "LineExtensionTaxAmount", _amt(vat))
        _el(e, "UnitPrice", _amt(price))
        _el(e, "UnitPriceTaxInclusive", _amt(rnd(price * (100 + rate) / 100)))
        ct = _el(e, "ClassifiedTaxCategory")
        _el(ct, "Percent", str(rate))
        _el(ct, "VATCalculationMethod", "0")
        _el(_el(e, "Item"), "Description", x["text"])

    tt = _el(root, "TaxTotal")
    for r in t["recap"]:
        st = _el(tt, "TaxSubTotal")
        for k, v in (("TaxableAmount", r["base"]), ("TaxAmount", r["vat"]), ("TaxInclusiveAmount", r["total"]),
                     ("AlreadyClaimedTaxableAmount", 0), ("AlreadyClaimedTaxAmount", 0),
                     ("AlreadyClaimedTaxInclusiveAmount", 0), ("DifferenceTaxableAmount", r["base"]),
                     ("DifferenceTaxAmount", r["vat"]), ("DifferenceTaxInclusiveAmount", r["total"])):
            _el(st, k, _amt(v))
        _el(_el(st, "TaxCategory"), "Percent", str(r["rate"]))
    _el(tt, "TaxAmount", _amt(t["vat"]))

    lm = _el(root, "LegalMonetaryTotal")
    for k, v in (("TaxExclusiveAmount", t["base"]), ("TaxInclusiveAmount", t["total"]),
                 ("AlreadyClaimedTaxExclusiveAmount", 0), ("AlreadyClaimedTaxInclusiveAmount", 0),
                 ("DifferenceTaxExclusiveAmount", t["base"]), ("DifferenceTaxInclusiveAmount", t["total"]),
                 ("PaidDepositsAmount", 0), ("PayableAmount", t["total"])):
        _el(lm, k, _amt(v))

    pm = _el(_el(root, "PaymentMeans"), "Payment")
    _el(pm, "PaidAmount", _amt(t["total"]))
    _el(pm, "PaymentMeansCode", PAYMENT_CODES.get(inv["payment"], "42"))
    iban = qr.cz_iban(s["bank_account"]) if s["bank_account"] else None
    if inv["payment"] == "prevod" and iban:
        d = _el(pm, "Details")
        _el(d, "PaymentDueDate", inv["due_date"])
        acc = s["bank_account"].replace(" ", "")
        num, _, bank = acc.partition("/") if "/" in acc else (iban[8:].lstrip("0"), "", iban[4:8])
        _el(d, "ID", num)
        _el(d, "BankCode", bank)
        _el(d, "Name", "")
        _el(d, "IBAN", iban)
        _el(d, "BIC", "")
        if inv["vs"]:
            _el(d, "VariableSymbol", "".join(c for c in inv["vs"] if c.isdigit())[:10])
    return b'<?xml version="1.0" encoding="UTF-8"?>\n' + ET.tostring(root, encoding="utf-8")


# ---------- import přijaté faktury ----------

def _t(el, path):
    e = el.find(path, {"i": NS}) if el is not None else None
    return (e.text or "").strip() if e is not None and e.text else ""


def _hal(s):
    try:
        return int(rnd(float(s) * 100))
    except (TypeError, ValueError):
        return 0


def parse(raw):
    """Bajty .isdoc / .isdocx → (hlavička pro formulář přijaté faktury, řádky)."""
    if raw[:2] == b"PK":
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            names = [n for n in z.namelist() if n.lower().endswith(".isdoc")]
            if not names:
                raise ValueError("V souboru .isdocx není faktura .isdoc")
            raw = z.read(names[0])
    try:
        root = ET.fromstring(raw)
    except ET.ParseError:
        raise ValueError("Soubor je poškozený nebo to není faktura ISDOC (neplatné XML)")
    if not root.tag.endswith("Invoice") or NS not in root.tag:
        raise ValueError("Soubor není faktura ISDOC")
    sup = root.find("i:AccountingSupplierParty/i:Party", {"i": NS})
    addr = sup.find("i:PostalAddress", {"i": NS}) if sup is not None else None
    street = ("%s %s" % (_t(addr, "i:StreetName"), _t(addr, "i:BuildingNumber"))).strip()
    city = ("%s %s" % (_t(addr, "i:PostalZone"), _t(addr, "i:CityName"))).strip()
    det = root.find("i:PaymentMeans/i:Payment/i:Details", {"i": NS})
    acc = ""
    if det is not None and _t(det, "i:ID"):
        acc = _t(det, "i:ID") + ("/" + _t(det, "i:BankCode") if _t(det, "i:BankCode") else "")
    elif det is not None:
        acc = _t(det, "i:IBAN")
    code = _t(root, "i:PaymentMeans/i:Payment/i:PaymentMeansCode")
    head = {"number": _t(root, "i:ID"), "issue_date": _t(root, "i:IssueDate"),
            "tax_date": _t(root, "i:TaxPointDate") or _t(root, "i:IssueDate"),
            "due_date": _t(det, "i:PaymentDueDate") if det is not None else "",
            "vs": _t(det, "i:VariableSymbol") if det is not None else "",
            "payment": {"10": "hotove", "48": "karta"}.get(code, "prevod"),
            "cust_name": _t(sup, "i:PartyName/i:Name"), "cust_ico": _t(sup, "i:PartyIdentification/i:ID"),
            "cust_dic": _t(sup, "i:PartyTaxScheme/i:CompanyID"), "cust_address": "\n".join(x for x in (street, city) if x),
            "supp_account": acc, "note": _t(root, "i:Note"),
            # Firmička účtuje v Kč; faktura s jinou místní měnou (např. EUR ze Slovenska) se musí přepočítat
            "currency": (_t(root, "i:LocalCurrencyCode") or "CZK").upper()}
    head["due_date"] = head["due_date"] or head["issue_date"]
    vat_applicable = _t(root, "i:VATApplicable") == "true"
    head["doc_type"] = _t(root, "i:DocumentType") or "1"
    lines, supplier_base = [], {}
    for ln in root.findall("i:InvoiceLines/i:InvoiceLine", {"i": NS}):
        q = ln.find("i:InvoicedQuantity", {"i": NS})
        try:
            qty = float(q.text) if q is not None and q.text else 1.0
        except ValueError:
            qty = 1.0
        price = _hal(_t(ln, "i:UnitPrice"))
        ext = _t(ln, "i:LineExtensionAmount")
        if not price and qty and ext:
            price = rnd(_hal(ext) / qty)
        rate = int(float(_t(ln, "i:ClassifiedTaxCategory/i:Percent") or 0)) if vat_applicable else 0
        if ext:
            supplier_base[rate] = supplier_base.get(rate, 0) + _hal(ext)
        else:
            supplier_base[rate] = supplier_base.get(rate, 0) + rnd(qty * price)
        lines.append({"item_id": None, "text": _t(ln, "i:Item/i:Description") or _t(ln, "i:Note") or "Položka",
                      "qty": qty, "unit": (q.get("unitCode") if q is not None else "") or "ks", "price": price,
                      "vat_rate": rate, "recycling_fee": 0})
    # Firmička drží ceny na haléře; jednotková cena dodavatele na víc desetinných míst (0,4567 Kč/ks) by po
    # zaokrouhlení změnila součet faktury → rozdíl dorovnat řádkem v téže sazbě, ať základ i DPH sedí s dokladem
    for rate, sb in sorted(supplier_base.items(), reverse=True):
        diff = sb - sum(rnd(x["qty"] * x["price"]) for x in lines if x["vat_rate"] == rate)
        if diff:
            lines.append({"item_id": None, "text": "Zaokrouhlení cen dodavatele" + (" (%d %%)" % rate if vat_applicable else ""),
                          "qty": 1.0, "unit": "ks", "price": diff, "vat_rate": rate, "recycling_fee": 0})
    head["warnings"] = []
    if head["doc_type"] == "2":     # dobropis je v ISDOC v kladných částkách – u nás snižuje odpočet → záporně
        lines = [dict(x, qty=-x["qty"]) for x in lines]
        ref = _t(root, "i:OriginalDocumentReferences/i:OriginalDocumentReference/i:ID")
        head["note"] = "\n".join(x for x in ("Opravný daňový doklad (dobropis)" + (" k faktuře %s" % ref if ref else ""),
                                             head["note"]) if x)
    if _hal(_t(root, "i:LegalMonetaryTotal/i:PaidDepositsAmount")) or \
            _hal(_t(root, "i:LegalMonetaryTotal/i:AlreadyClaimedTaxInclusiveAmount")):
        head["warnings"].append("Faktura odečítá zaplacené zálohy – položky jsou v plné výši. Pokud už máte zapsaný "
                                "daňový doklad k záloze, odečtěte zálohu řádkem se zápornou částkou.")
    want = _t(root, "i:LegalMonetaryTotal/i:TaxInclusiveAmount")
    if want and lines:
        from .db import invoice_totals
        got = abs(invoice_totals(lines, vat_applicable)["total"])
        if got != abs(_hal(want)):
            head["warnings"].append("Součet po načtení (%s Kč) nesedí s fakturou dodavatele (%s Kč) – zkontrolujte položky."
                                    % (_kc(got), _kc(abs(_hal(want)))))
    return head, lines


def _kc(hal):
    return ("%.2f" % (hal / 100)).replace(".", ",")
