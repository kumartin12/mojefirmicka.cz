"""Minimální generátor PDF bez závislostí: text s vloženým písmem TrueType (Unicode, Identity-H,
podmnožina jen použitých znaků), čáry, obdélníky. Stačí na faktury a nabídky v češtině.
Souřadnice v bodech (A4 = 595 × 842), počátek vlevo nahoře."""
import os
import struct
import zlib

FONTS = os.path.join(os.path.dirname(__file__), "static", "fonts")
A4 = (595.28, 841.89)
A5 = (419.53, 595.28)


class TrueType:
    """Čtení TTF (cmap, šířky) a výroba podmnožiny glyfů pro vložení do PDF."""

    def __init__(self, path):
        with open(path, "rb") as f:
            self.data = d = f.read()
        n = struct.unpack(">H", d[4:6])[0]
        self.tables = {}
        for i in range(n):
            tag, _, off, ln = struct.unpack(">4sIII", d[12 + 16 * i:28 + 16 * i])
            self.tables[tag.decode("latin-1")] = (off, ln)
        head = self.table("head")
        self.upem = struct.unpack(">H", head[18:20])[0]
        self.bbox = struct.unpack(">hhhh", head[36:44])
        self.loc_long = struct.unpack(">h", head[50:52])[0] == 1
        hhea = self.table("hhea")
        self.ascent, self.descent = struct.unpack(">hh", hhea[4:8])
        n_hm = struct.unpack(">H", hhea[34:36])[0]
        self.num_glyphs = struct.unpack(">H", self.table("maxp")[4:6])[0]
        hmtx = self.table("hmtx")
        adv = [struct.unpack(">H", hmtx[4 * i:4 * i + 2])[0] for i in range(n_hm)]
        self.advances = adv + [adv[-1]] * (self.num_glyphs - n_hm)
        self.cmap = self._cmap()
        self.name = os.path.splitext(os.path.basename(path))[0].replace(" ", "")

    def table(self, tag):
        off, ln = self.tables[tag]
        return self.data[off:off + ln]

    def _cmap(self):
        c = self.table("cmap")
        n = struct.unpack(">H", c[2:4])[0]
        subs = {}
        for i in range(n):
            pid, eid, off = struct.unpack(">HHI", c[4 + 8 * i:12 + 8 * i])
            subs[(pid, eid)] = off
        out = {}
        if (3, 10) in subs:                       # formát 12 – celý Unicode
            off = subs[(3, 10)]
            ngroups = struct.unpack(">I", c[off + 12:off + 16])[0]
            for g in range(ngroups):
                s, e, gid = struct.unpack(">III", c[off + 16 + 12 * g:off + 28 + 12 * g])
                for cp in range(s, e + 1):
                    out[cp] = gid + cp - s
            return out
        off = subs.get((3, 1), subs.get((0, 3)))  # formát 4 – BMP
        segx2 = struct.unpack(">H", c[off + 6:off + 8])[0]
        seg = segx2 // 2
        ends = struct.unpack(">%dH" % seg, c[off + 14:off + 14 + segx2])
        starts = struct.unpack(">%dH" % seg, c[off + 16 + segx2:off + 16 + 2 * segx2])
        deltas = struct.unpack(">%dh" % seg, c[off + 16 + 2 * segx2:off + 16 + 3 * segx2])
        ro_pos = off + 16 + 3 * segx2
        ranges = struct.unpack(">%dH" % seg, c[ro_pos:ro_pos + segx2])
        for i in range(seg):
            for cp in range(starts[i], ends[i] + 1):
                if cp == 0xFFFF:
                    continue
                if ranges[i] == 0:
                    gid = (cp + deltas[i]) & 0xFFFF
                else:
                    p = ro_pos + 2 * i + ranges[i] + 2 * (cp - starts[i])
                    gid = struct.unpack(">H", c[p:p + 2])[0]
                    if gid:
                        gid = (gid + deltas[i]) & 0xFFFF
                if gid:
                    out[cp] = gid
        return out

    def gid(self, ch):
        return self.cmap.get(ord(ch), 0)

    def width(self, text, size):
        return sum(self.advances[self.gid(ch)] for ch in text) * size / self.upem

    def _glyph(self, gid):
        loca = self.table("loca")
        if self.loc_long:
            a, b = struct.unpack(">II", loca[4 * gid:4 * gid + 8])
        else:
            a, b = (x * 2 for x in struct.unpack(">HH", loca[2 * gid:2 * gid + 4]))
        return self.table("glyf")[a:b]

    def subset(self, used):
        """TTF jen s použitými glyfy (ostatní prázdné, čísla glyfů se nemění → CIDToGIDMap Identity)."""
        keep, todo = set(), {0} | set(used)
        while todo:
            g = todo.pop()
            if g in keep or g >= self.num_glyphs:
                continue
            keep.add(g)
            data = self._glyph(g)
            if len(data) >= 10 and struct.unpack(">h", data[:2])[0] < 0:    # složený glyf
                p = 10
                while True:
                    flags, comp = struct.unpack(">HH", data[p:p + 4])
                    todo.add(comp)
                    p += 4 + (4 if flags & 1 else 2)
                    p += 2 if flags & 8 else 4 if flags & 0x40 else 8 if flags & 0x80 else 0
                    if not flags & 0x20:
                        break
        glyf, loca = bytearray(), []
        for g in range(self.num_glyphs):
            loca.append(len(glyf))
            if g in keep:
                glyf += self._glyph(g)
                glyf += b"\0" * (-len(glyf) % 4)
        loca.append(len(glyf))
        head = bytearray(self.table("head"))
        head[8:12] = b"\0\0\0\0"
        head[50:52] = struct.pack(">h", 1)
        tables = {"head": bytes(head), "hhea": self.table("hhea"), "maxp": self.table("maxp"),
                  "hmtx": self.table("hmtx"), "loca": struct.pack(">%dI" % len(loca), *loca), "glyf": bytes(glyf)}
        for t in ("cvt ", "fpgm", "prep"):
            if t in self.tables:
                tables[t] = self.table(t)
        return _build_sfnt(tables)


def _checksum(b):
    b += b"\0" * (-len(b) % 4)
    return sum(struct.unpack(">%dI" % (len(b) // 4), b)) & 0xFFFFFFFF


def _build_sfnt(tables):
    tags = sorted(tables)
    n = len(tags)
    es = max(i for i in range(16) if 2 ** i <= n)
    out = bytearray(struct.pack(">IHHHH", 0x00010000, n, 2 ** es * 16, es, n * 16 - 2 ** es * 16))
    off = 12 + 16 * n
    body = bytearray()
    for t in tags:
        data = tables[t]
        out += struct.pack(">4sIII", t.encode("latin-1"), _checksum(data), off + len(body), len(data))
        body += data + b"\0" * (-len(data) % 4)
    font = out + body
    adj = (0xB1B0AFBA - _checksum(bytes(font))) & 0xFFFFFFFF
    hoff = 12 + 16 * n + sum(len(tables[t]) + (-len(tables[t]) % 4) for t in tags[:tags.index("head")])
    font[hoff + 8:hoff + 12] = struct.pack(">I", adj)
    return bytes(font)


# ---------- obrázky (logo, podpis, razítko) ----------

def _paeth(a, b, c):
    p = a + b - c
    pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
    return a if pa <= pb and pa <= pc else b if pb <= pc else c


def load_image(path):
    """JPEG/PNG → dict(w, h, data, filter, cs, bpc, smask). PNG se rozbalí (i průhlednost → SMask)."""
    with open(path, "rb") as f:
        raw = f.read()
    if raw[:2] == b"\xff\xd8":                       # JPEG – vloží se beze změny
        i = 2
        while i < len(raw):
            if raw[i] != 0xFF:
                i += 1
                continue
            marker = raw[i + 1]
            if marker in (0xC0, 0xC1, 0xC2):
                h, w = struct.unpack(">HH", raw[i + 5:i + 9])
                comps = raw[i + 9]
                cs = {1: "/DeviceGray", 3: "/DeviceRGB", 4: "/DeviceCMYK"}[comps]
                return {"w": w, "h": h, "data": raw, "filter": "/DCTDecode", "cs": cs, "bpc": 8, "smask": None,
                        "decode": " /Decode [1 0 1 0 1 0 1 0]" if comps == 4 else ""}
            i += 2 + struct.unpack(">H", raw[i + 2:i + 4])[0]
        raise ValueError("Neplatný JPEG")
    if raw[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError("Obrázek musí být PNG nebo JPG")
    p, idat, plte, trns = 8, b"", b"", b""
    while p < len(raw):
        ln = struct.unpack(">I", raw[p:p + 4])[0]
        typ, chunk = raw[p + 4:p + 8], raw[p + 8:p + 8 + ln]
        if typ == b"IHDR":
            w, h, depth, ctype, _, _, interlace = struct.unpack(">IIBBBBB", chunk)
        elif typ == b"PLTE":
            plte = chunk
        elif typ == b"tRNS":
            trns = chunk
        elif typ == b"IDAT":
            idat += chunk
        p += 12 + ln
    if interlace:
        raise ValueError("Prokládaný PNG není podporovaný – uložte obrázek znovu bez prokládání")
    chans = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}[ctype]
    bits = depth * chans
    stride = (w * bits + 7) // 8
    bpp = max(1, bits // 8)
    data = zlib.decompress(idat)
    out = bytearray()
    prev = bytearray(stride)
    pos = 0
    for _ in range(h):                                 # odfiltrování řádků PNG
        ft = data[pos]
        line = bytearray(data[pos + 1:pos + 1 + stride])
        pos += 1 + stride
        if ft == 1:
            for i in range(bpp, stride):
                line[i] = (line[i] + line[i - bpp]) & 255
        elif ft == 2:
            for i in range(stride):
                line[i] = (line[i] + prev[i]) & 255
        elif ft == 3:
            for i in range(stride):
                line[i] = (line[i] + ((line[i - bpp] if i >= bpp else 0) + prev[i]) // 2) & 255
        elif ft == 4:
            for i in range(stride):
                line[i] = (line[i] + _paeth(line[i - bpp] if i >= bpp else 0, prev[i], prev[i - bpp] if i >= bpp else 0)) & 255
        out += line
        prev = line
    # převod na 8bit RGB/šedou + alfa
    def samples(row):
        if depth == 8:
            return list(row)
        if depth == 16:
            return list(row[0::2])
        per = 8 // depth
        mask = (1 << depth) - 1
        vals = []
        for b in row:
            for k in range(per):
                vals.append((b >> (8 - depth * (k + 1))) & mask)
        return vals[:w * chans]
    color, alpha = bytearray(), bytearray()
    has_alpha = ctype in (4, 6) or bool(trns)
    for y in range(h):
        vals = samples(out[y * stride:(y + 1) * stride])
        if ctype == 3:
            for v in vals[:w]:
                color += plte[3 * v:3 * v + 3]
                alpha.append(trns[v] if v < len(trns) else 255)
        elif ctype in (0, 4):
            scale = 255 // ((1 << depth) - 1) if depth < 8 else 1
            step = 2 if ctype == 4 else 1
            for x in range(w):
                color.append(vals[x * step] * scale)
                alpha.append(vals[x * step + 1] if ctype == 4 else 255)
        else:
            step = 4 if ctype == 6 else 3
            for x in range(w):
                color += bytes(vals[x * step:x * step + 3])
                alpha.append(vals[x * step + 3] if ctype == 6 else 255)
    gray = ctype in (0, 4)
    return {"w": w, "h": h, "data": zlib.compress(bytes(color), 6), "filter": "/FlateDecode",
            "cs": "/DeviceGray" if gray else "/DeviceRGB", "bpc": 8, "decode": "",
            "smask": zlib.compress(bytes(alpha), 6) if has_alpha and min(alpha) < 255 else None}


_IMG_CACHE = {}


def image(path):
    key = (path, os.path.getmtime(path))
    if key not in _IMG_CACHE:
        _IMG_CACHE.clear()
        _IMG_CACHE[key] = load_image(path)
    return _IMG_CACHE[key]


_FONT_CACHE = {}


def font(name):
    if name not in _FONT_CACHE:
        _FONT_CACHE[name] = TrueType(os.path.join(FONTS, name))
    return _FONT_CACHE[name]


def _pdfstr(s):
    return "(" + s.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)") + ")"


class PDF:
    def __init__(self, title="", author="", size=A4, scale=1.0):
        """size = skutečný formát papíru; kreslí se v jednotkách size/scale (A5 se scale 0.84 ≈ zmenšená A4 rozvržení)."""
        self.fonts = {"R": font("DejaVuSans.ttf"), "B": font("DejaVuSans-Bold.ttf")}
        self.used = {"R": set(), "B": set()}
        self.pages = []
        self.images = []            # (cesta, data obrázku)
        self.title, self.author = title, author
        self.size, self.scale = size, scale
        self.W, self.H = size[0] / scale, size[1] / scale

    def add_page(self):
        self.pages.append([])

    def _out(self, s):
        self.pages[-1].append(s)

    def width(self, text, size, f="R"):
        return self.fonts[f].width(text, size)

    def text(self, x, y, text, size=10, f="R", align="left", gray=0.0):
        """y = účaří odshora."""
        text = str(text)
        if not text:
            return
        ft = self.fonts[f]
        w = ft.width(text, size)
        if align == "right":
            x -= w
        elif align == "center":
            x -= w / 2
        gids = [ft.gid(ch) for ch in text]
        self.used[f].update(gids)
        hexs = "".join("%04X" % g for g in gids)
        self._out("BT %.3f g /F%s %.2f Tf %.2f %.2f Td <%s> Tj ET" % (gray, f, size, x, self.H - y, hexs))

    def wrap(self, text, width, size, f="R"):
        """Zalomí text na řádky do šířky (po slovech, dlouhá slova natvrdo)."""
        out = []
        for para in str(text).split("\n"):
            line = ""
            for word in para.split(" "):
                cand = (line + " " + word) if line else word
                if self.width(cand, size, f) <= width:
                    line = cand
                    continue
                if line:
                    out.append(line)
                while self.width(word, size, f) > width and len(word) > 1:
                    k = len(word)
                    while k > 1 and self.width(word[:k], size, f) > width:
                        k -= 1
                    out.append(word[:k])
                    word = word[k:]
                line = word
            out.append(line)
        return out

    def line(self, x1, y1, x2, y2, w=0.5, gray=0.0):
        self._out("%.3f G %.2f w %.2f %.2f m %.2f %.2f l S" % (gray, w, x1, self.H - y1, x2, self.H - y2))

    def rect(self, x, y, w, h, gray=0.0):
        """Vyplněný obdélník; (x, y) = levý horní roh."""
        self._out("%.3f g %.2f %.2f %.2f %.2f re f" % (gray, x, self.H - y - h, w, h))

    def image(self, x, y, path, max_w, max_h, align="left"):
        """Obrázek vepsaný do rámečku max_w × max_h (zachová poměr stran); vrací skutečnou (šířku, výšku)."""
        img = image(path)
        sc = min(max_w / img["w"], max_h / img["h"])
        w, h = img["w"] * sc, img["h"] * sc
        if align == "right":
            x -= w
        elif align == "center":
            x -= w / 2
        idx = next((i for i, (p, _) in enumerate(self.images) if p == path), None)
        if idx is None:
            self.images.append((path, img))
            idx = len(self.images) - 1
        self._out("q %.2f 0 0 %.2f %.2f %.2f cm /Im%d Do Q" % (w, h, x, self.H - y - h, idx))
        return w, h

    def output(self):
        objs = []

        def add(body):
            objs.append(body)
            return len(objs)

        def stream(data, extra=""):
            z = zlib.compress(data, 9)
            return b"<< /Length %d /Filter /FlateDecode%s >>\nstream\n" % (len(z), extra.encode()) + z + b"\nendstream"

        catalog = add(None)
        pages_id = add(None)
        font_refs = {}
        for key, ft in self.fonts.items():
            used = sorted(self.used[key] | {0})
            if not self.used[key]:
                continue
            tag = "FIRM" + chr(65 + len(font_refs)) + key   # předpona podmnožiny (6 písmen)
            tag = (tag + "AAAAAA")[:6]
            base = "%s+%s" % (tag, ft.name)
            sub = ft.subset(used)
            ff = add(stream(sub, " /Length1 %d" % len(sub)))
            sc = 1000.0 / ft.upem
            desc = add(("<< /Type /FontDescriptor /FontName /%s /Flags 32 /FontBBox [%d %d %d %d] /ItalicAngle 0 "
                        "/Ascent %d /Descent %d /CapHeight %d /StemV %d /FontFile2 %d 0 R >>" % (
                            base, *(round(v * sc) for v in ft.bbox), round(ft.ascent * sc), round(ft.descent * sc),
                            round(ft.ascent * sc), 120 if key == "B" else 80, ff)).encode())
            widths = " ".join("%d [%d]" % (g, round(ft.advances[g] * sc)) for g in used)
            cid = add(("<< /Type /Font /Subtype /CIDFontType2 /BaseFont /%s /CIDSystemInfo << /Registry (Adobe) "
                       "/Ordering (Identity) /Supplement 0 >> /FontDescriptor %d 0 R /W [%s] /CIDToGIDMap /Identity >>"
                       % (base, desc, widths)).encode())
            rev = {}
            for cp, g in ft.cmap.items():
                if g in self.used[key] and g not in rev:
                    rev[g] = cp
            bf = "".join("<%04X> <%s>\n" % (g, chr(cp).encode("utf-16-be").hex().upper()) for g, cp in sorted(rev.items()))
            cmap = ("/CIDInit /ProcSet findresource begin\n12 dict begin\nbegincmap\n/CIDSystemInfo << /Registry (Adobe) "
                    "/Ordering (UCS) /Supplement 0 >> def\n/CMapName /Adobe-Identity-UCS def\n/CMapType 2 def\n"
                    "1 begincodespacerange\n<0000> <FFFF>\nendcodespacerange\n%d beginbfchar\n%sendbfchar\n"
                    "endcmap\nCMapName currentdict /CMap defineresource pop\nend\nend" % (len(rev), bf))
            tu = add(stream(cmap.encode()))
            font_refs[key] = add(("<< /Type /Font /Subtype /Type0 /BaseFont /%s /Encoding /Identity-H "
                                  "/DescendantFonts [%d 0 R] /ToUnicode %d 0 R >>" % (base, cid, tu)).encode())
        xobj = []
        for i, (_, img) in enumerate(self.images):
            smask = ""
            if img["smask"]:
                sm = add(b"<< /Type /XObject /Subtype /Image /Width %d /Height %d /ColorSpace /DeviceGray "
                         b"/BitsPerComponent 8 /Filter /FlateDecode /Length %d >>\nstream\n" % (img["w"], img["h"], len(img["smask"]))
                         + img["smask"] + b"\nendstream")
                smask = " /SMask %d 0 R" % sm
            xobj.append("/Im%d %d 0 R" % (i, add(("<< /Type /XObject /Subtype /Image /Width %d /Height %d /ColorSpace %s "
                                                  "/BitsPerComponent %d /Filter %s%s%s /Length %d >>\nstream\n" % (
                                                      img["w"], img["h"], img["cs"], img["bpc"], img["filter"], img["decode"],
                                                      smask, len(img["data"]))).encode() + img["data"] + b"\nendstream")))
        res = "<< /Font << %s >>%s >>" % (" ".join("/F%s %d 0 R" % (k, v) for k, v in font_refs.items()),
                                          " /XObject << %s >>" % " ".join(xobj) if xobj else "")
        kids = []
        for content in self.pages:
            pre = ["%.4f 0 0 %.4f 0 0 cm" % (self.scale, self.scale)] if self.scale != 1 else []
            c = add(stream("\n".join(pre + content).encode("latin-1")))
            kids.append(add(("<< /Type /Page /Parent %d 0 R /MediaBox [0 0 %.2f %.2f] /Resources %s /Contents %d 0 R >>"
                             % (pages_id, self.size[0], self.size[1], res, c)).encode()))
        objs[pages_id - 1] = ("<< /Type /Pages /Kids [%s] /Count %d >>" % (" ".join("%d 0 R" % k for k in kids),
                                                                          len(kids))).encode()
        objs[catalog - 1] = b"<< /Type /Catalog /Pages %d 0 R >>" % pages_id
        info = add(("<< /Producer (Firmicka) /Title <%s> /Author <%s> >>" % (
            ("﻿" + self.title).encode("utf-16-be").hex(), ("﻿" + self.author).encode("utf-16-be").hex())).encode())
        out = bytearray(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
        offsets = []
        for i, body in enumerate(objs, 1):
            offsets.append(len(out))
            out += b"%d 0 obj\n" % i + body + b"\nendobj\n"
        xref = len(out)
        out += b"xref\n0 %d\n0000000000 65535 f \n" % (len(objs) + 1)
        out += b"".join(b"%010d 00000 n \n" % o for o in offsets)
        out += b"trailer\n<< /Size %d /Root %d 0 R /Info %d 0 R >>\nstartxref\n%d\n%%%%EOF\n" % (
            len(objs) + 1, catalog, info, xref)
        return bytes(out)
