"""Faktura, nabídka a zakázkový list jako PDF (stejný obsah jako náhled v prohlížeči),
s logem, podpisem a razítkem firmy, pokud jsou nahrané v Nastavení."""
from . import images, qr
from .db import rnd, invoice_totals, line_fee, warranty_text
from .pdf import PDF, A5
from .web import money, qty, cz_date

M = 42            # okraj
PAYMENTS = {"prevod": "Převodem", "hotove": "Hotově", "karta": "Kartou", "dobirka": "Dobírkou"}


def _m(hal):
    return money(hal).replace(" ", " ")


def _d(iso):
    return cz_date(iso).replace(" ", " ")


def _party(p, x, y, w, title, lines_, small=False):
    p.text(x, y, title.upper(), 7.5, "B", gray=0.45)
    p.line(x, y + 4, x + w, y + 4, 1.2)
    y += 17
    big, norm = (9, 8) if small else (10, 9)
    for i, ln in enumerate(lines_):
        for part in p.wrap(ln, w, big if i == 0 else norm, "B" if i == 0 else "R"):
            p.text(x, y, part, big if i == 0 else norm, "B" if i == 0 else "R")
            y += (big + 3) if i == 0 else (norm + 2.5)
    return y


def _supplier(s):
    sup = [s["firm_name"] or "—", s["firm_street"], ("%s %s" % (s["firm_zip"], s["firm_city"])).strip()]
    sup += ["IČO: %s" % s["firm_ico"]] if s["firm_ico"] else []
    sup += ["DIČ: %s" % s["firm_dic"]] if s["firm_dic"] else []
    contact = " · ".join(x for x in (s["firm_phone"], s["firm_email"], s["firm_web"]) if x)
    return [x for x in sup + [contact] if x]


def _header(p, kind, number, subtitle, data_dir, qr_text=None, logo_right=False):
    """Logo, nadpis, QR platba. Vrací y pod hlavičkou. logo_right = logo vpravo vedle nadpisu (šetří výšku)."""
    y = M
    logo = images.path(data_dir, "logo") if data_dir else None
    if logo and logo_right:      # vedle nadpisu, ať do sebe nezasahují
        room = p.W - 2 * M - p.width("%s %s" % (kind, number), 20, "B") - 16
        if room >= 60:
            p.image(p.W - M, M - 6, logo, min(150, room), 40, align="right")
            y = M - 12
        else:
            _, lh = p.image(M, M - 6, logo, 170, 30)
            y = M - 6 + lh + 4
    elif logo:
        _, lh = p.image(M, M - 6, logo, 170, 46)
        y = M - 6 + lh + 8
    p.text(M, y + 18, "%s %s" % (kind, number), 20, "B")
    if subtitle:
        p.text(M, y + 34, subtitle, 9, gray=0.4)
    bottom = y + 44
    if qr_text:
        m = qr.matrix(qr_text)
        size, x0, y0 = 88.0, p.W - M - 88.0, M - 4
        cell = size / len(m)
        for r, row in enumerate(m):
            for c, dark in enumerate(row):
                if dark:
                    p.rect(x0 + c * cell, y0 + r * cell, cell + 0.05, cell + 0.05)
        p.text(x0 + size / 2, y0 + size + 9, "QR platba", 7, align="center", gray=0.4)
        bottom = max(bottom, y0 + size + 20)
    return bottom + 10


def _infobox(p, y, info, ncol=3, gap=20):
    info = [(k, v) for k, v in info if v]
    if not info:
        return y
    rows = (len(info) + ncol - 1) // ncol
    box_h = rows * 24 + 10
    p.rect(M, y, p.W - 2 * M, box_h, 0.95)
    cw = (p.W - 2 * M - 20) / ncol
    for i, (k, v) in enumerate(info):
        cx, cy = M + 10 + (i % ncol) * cw, y + 14 + (i // ncol) * 24
        p.text(cx, cy, k, 7, gray=0.45)
        v = str(v)
        fs = 9
        while fs > 7 and p.width(v, fs, "B") > cw - 10:          # nevejde se → nejdřív menší písmo (IBAN)
            fs -= 0.5
        while len(v) > 1 and p.width(v, fs, "B") > cw - 10:      # pořád ne → zkrátit
            v = v[:-2].rstrip() + "…"
        p.text(cx, cy + 10, v, fs, "B")
    return y + box_h + gap


def _items(p, y, lines, vat_payer, total_label):
    W = p.W
    xq, xp, xv = W - M - 241, W - M - 166, W - M - 116       # množství, cena/j., DPH (na A4 jako dřív)
    tw = xq - M - 60                                        # šířka popisu
    cols = [("Popis", M, "left"), ("Množství", xq, "right"), ("Cena/j." + (" bez DPH" if vat_payer else ""), xp, "right")]
    if vat_payer:
        cols.append(("DPH", xv, "right"))
    cols.append(("Celkem" + (" bez DPH" if vat_payer else ""), W - M, "right"))

    def header(yy):
        for label, x, al in cols:
            p.text(x, yy, label, 7.5, "B", al, gray=0.35)
        p.line(M, yy + 5, W - M, yy + 5, 1.2)
        return yy + 18

    y = header(y)
    rows_ = []
    for ln in lines:
        if "advance_id" in ln.keys() and ln["advance_id"]:     # odpočet zálohy: bez „-1“, záporná cena
            rows_.append((ln["text"], None, "", -ln["price"], ln["vat_rate"], False))
            continue
        rows_.append((ln["text"], ln["qty"], ln["unit"], ln["price"], ln["vat_rate"], False))
        if line_fee(ln):
            rows_.append(("recyklační poplatek", ln["qty"], ln["unit"], line_fee(ln), ln["vat_rate"], True))
        if "warranty" in ln.keys() and ln["warranty"]:
            rows_.append((warranty_text(ln["warranty"]).capitalize(), None, "", None, 0, True))
    wrapped = [p.wrap(r_[0], tw, 8 if r_[5] else 9) for r_ in rows_]
    for k, (text, q, unit, price, rate, fee) in enumerate(rows_):
        size = 8 if fee else 9
        parts = wrapped[k]
        need = 13 * len(parts) + 4
        if not fee:      # zboží drž pohromadě s jeho podřádky (recyklační poplatek, záruka) – nezůstanou samy na nové straně
            j = k + 1
            while j < len(rows_) and rows_[j][5]:
                need += 13 * len(wrapped[j]) + 8
                j += 1
        if y + need > p.H - 150:          # nová strana (rezerva na součty)
            p.text(W - M, y + 10, "pokračování na další straně", 7, align="right", gray=0.5)   # pod tabulkou, ne pod patičkou
            p.add_page()
            y = header(M + 20)
        g = 0.35 if fee else 0.0
        for i, part in enumerate(parts):
            p.text(M + (10 if fee else 0), y + 13 * i, part, size, gray=g)
        if price is None:                                 # jen text (záruka) – bez čísel
            y += 13 * len(parts) - 5
            p.line(M, y, W - M, y, 0.3, 0.8)
            y += 13
            continue
        if q is not None:
            p.text(xq, y, "%s %s" % (qty(q), unit), size, align="right", gray=g)
        p.text(xp, y, money(price, False).replace(" ", " "), size, align="right", gray=g)
        if vat_payer:
            p.text(xv, y, "%d %%" % rate, size, align="right", gray=g)
        p.text(W - M, y, money(rnd((1 if q is None else q) * price), False).replace(" ", " "), size, align="right", gray=g)
        y += 13 * len(parts) - 5
        p.line(M, y, W - M, y, 0.3, 0.8)
        y += 13

    t = invoice_totals(lines, vat_payer)
    if y > p.H - 160:
        p.add_page()
        y = M + 20
    y += 6
    bw = 190
    if vat_payer:
        k = min(1.0, (W - 2 * M - bw - 20) / 270)          # rekapitulace se vejde vedle součtu i na A5
        for x, label, al in ((M, "Sazba", "left"), (M + 120 * k, "Základ", "right"), (M + 190 * k, "DPH", "right"),
                             (M + 270 * k, "Celkem", "right")):
            p.text(x, y, label, 7.5, "B", al, gray=0.35)
        yy = y + 13
        for r in t["recap"]:
            p.text(M, yy, "%d %%" % r["rate"], 8.5)
            p.text(M + 120 * k, yy, _m(r["base"]), 8.5, align="right")
            p.text(M + 190 * k, yy, _m(r["vat"]), 8.5, align="right")
            p.text(M + 270 * k, yy, _m(r["total"]), 8.5, align="right")
            yy += 12
    p.rect(W - M - bw, y - 10, bw, 44, 0.07)
    p.text(W - M - 10, y + 3, total_label, 7.5, align="right", gray=0.8)
    p.text(W - M - 10, y + 24, _m(t["total"]), 15, "B", align="right", gray=1.0)
    return y + (max(62, 13 + 12 * len(t["recap"]) + 20) if vat_payer else 62)


def _paragraphs(p, y, texts, size=9):
    for title, text in texts:
        if not text:
            continue
        if title:
            if y > p.H - 90:
                p.add_page()
                y = M + 20
            p.text(M, y, title.upper(), 7.5, "B", gray=0.45)
            y += 13
        for part in p.wrap(text, p.W - 2 * M, size):
            if y > p.H - 70:
                p.add_page()
                y = M + 20
            p.text(M, y, part, size)
            y += size + 3
        y += 8
    return y


def _signoff(p, y, s, data_dir, left_label=None, compact=False):
    """Vystavil + podpis a razítko vpravo; volitelně vlevo čára pro podpis zákazníka."""
    stamp = images.path(data_dir, "razitko") if data_dir else None
    sig = images.path(data_dir, "podpis") if data_dir else None
    if not (stamp or sig or s["invoice_issuer"] or left_label):
        return y
    room = (82 if compact else 105) if (stamp or sig) else 40     # bez obrázků stačí místo na ruční podpis
    if y + room + 20 > p.H - (56 if compact else 70):     # popisek pod čarou musí zůstat nad patičkou
        p.add_page()
        y = M + 20
    base = y + room                      # spodní čára podpisů
    x_r = p.W - M
    if stamp:
        sh = 82 if compact else 105
        p.image(x_r - 70, base - sh - 5, stamp, 130, sh, align="right")
    if sig:
        p.image(x_r, base - (50 if compact else 62), sig, 170, 46 if compact else 58, align="right")
    p.line(x_r - 200, base + 2, x_r, base + 2, 0.5, 0.6)
    p.text(x_r - 100, base + 13, "Vystavil" + (": %s" % s["invoice_issuer"] if s["invoice_issuer"] else " (razítko a podpis)"),
           7.5, align="center", gray=0.45)
    if left_label:
        p.line(M, base + 2, M + 200, base + 2, 0.5, 0.6)
        p.text(M + 100, base + 13, left_label, 7.5, align="center", gray=0.45)
    return base + 30


def _footer(p, s, lines_):
    foot = [x for x in lines_ if x]
    total = len(p.pages)
    cur = p.pages
    for i, page in enumerate(cur):
        p.pages = [page]
        fy = p.H - 34 - 10 * (len(foot) - 1)
        p.line(M, fy - 10, p.W - M, fy - 10, 0.3, 0.8)
        for k, f in enumerate(foot):
            f = f[:140]
            while len(f) > 1 and p.width(f, 7) > p.W - 2 * M - (50 if total > 1 else 0):
                f = f[:-2].rstrip() + "…"
            p.text(M, fy + 10 * k, f, 7, gray=0.45)
        if total > 1:
            p.text(p.W - M, fy, "strana %d/%d" % (i + 1, total), 7, align="right", gray=0.45)
    p.pages = cur


def render(kind, number, subtitle, s, cust, info, lines, vat_payer, notes=(), qr_text=None, stamp="", data_dir=None,
           total_label=None, invoice_like=None):
    """kind = 'Faktura' / 'Cenová nabídka'; cust = (název, adresa, ičo, dič); info = [(popisek, hodnota)]."""
    p = PDF(title="%s %s" % (kind, number), author=s["firm_name"])
    p.add_page()
    y = _header(p, kind, number, subtitle, data_dir, qr_text)
    colw = (p.W - 2 * M - 30) / 2
    name, addr, ico, dic = cust
    cus = [name] + [x for x in (addr or "").split("\n") if x]
    cus += ["IČO: %s" % ico] if ico else []
    cus += ["DIČ: %s" % dic] if dic else []
    y = max(_party(p, M, y, colw, "Dodavatel", _supplier(s)), _party(p, M + colw + 30, y, colw, "Odběratel", cus)) + 8
    y = _infobox(p, y, info)
    invoice_like = kind == "Faktura" if invoice_like is None else invoice_like
    label = total_label or ("Celkem k úhradě" if invoice_like else "Celkem" + (" vč. DPH" if vat_payer else ""))
    y = _items(p, y, lines, vat_payer, label)
    y = _paragraphs(p, y, [("", n) for n in notes])
    _signoff(p, y, s, data_dir)
    if stamp:                                # UHRAZENO / STORNO přes první stranu
        cur = p.pages
        p.pages = [cur[0]]
        p.text(p.W / 2, 330, stamp, 54, "B", "center", gray=0.85)
        p.pages = cur
    _footer(p, s, [s["firm_register"], s["invoice_footer"].replace("\n", " · ") if invoice_like else "",
                   "Vystaveno programem Firmička"])
    return p.output()


def invoice_pdf(inv, lines, s, data_dir=None, refs=None):
    vp = bool(inv["vat_payer"])
    iban = qr.cz_iban(s["bank_account"]) if s["bank_account"] else None
    t = invoice_totals(lines, vp)
    qr_text = None
    from .invoices import kind_of, doc_name, doc_subtitle, references, total_label, PAYABLE
    k = kind_of(inv)
    if iban and inv["payment"] == "prevod" and inv["status"] == "vystavena" and t["total"] > 0 and k in PAYABLE:
        qr_text = qr.spayd(iban, t["total"], inv["vs"], "%s %s" % (doc_name(inv), inv["number"]), inv["due_date"])
    transfer = inv["payment"] == "prevod"
    info = [("Způsob platby", PAYMENTS.get(inv["payment"], inv["payment"])),
            ("Bankovní účet", s["bank_account"] if transfer else ""),
            ("IBAN", " ".join(iban[i:i + 4] for i in range(0, len(iban), 4)) if iban and transfer else ""),
            ("Variabilní symbol", inv["vs"]), ("Datum vystavení", _d(inv["issue_date"])),
            ("Datum zdan. plnění" if k != "ddkpp" else "Datum přijetí platby", _d(inv["tax_date"]) if vp and k != "zaloha" else ""),
            ("Datum splatnosti", _d(inv["due_date"]) if k != "ddkpp" else "")]
    stamp = {"zaplacena": "VRÁCENO" if k == "dobropis" else "UHRAZENO" if k != "ddkpp" else "",
             "stornovana": "STORNO"}.get(inv["status"], "")
    return render(doc_name(inv, True), inv["number"], doc_subtitle(inv), s,
                  (inv["cust_name"], inv["cust_address"], inv["cust_ico"], inv["cust_dic"]), info, lines, vp,
                  list(refs or []) + [inv["note"], "" if vp else "Nejsem plátce DPH."], qr_text, stamp, data_dir,
                  total_label(inv, t["total"]), True)


def quote_pdf(q, lines, s, data_dir=None):
    return render("Cenová nabídka", q["number"], q["title"], s,
                  (q["cust_name"], q["cust_address"], q["cust_ico"], q["cust_dic"]),
                  [("Datum", _d(q["issue_date"])), ("Platnost nabídky do", _d(q["valid_until"]))], lines,
                  bool(q["vat_payer"]), [q["note"], "" if q["vat_payer"] else "Nejsem plátce DPH."], data_dir=data_dir)


def job_pdf(j, lines, s, data_dir=None, writer=""):
    """Zakázkový list = potvrzení o převzetí zařízení / zakázky pro zákazníka."""
    from .jobs import STATUS
    # A5 na výšku; rozvržení jako na A4, jen v měřítku 0,84 (písmo 9 b. → 7,6 b.)
    p = PDF(title="Zakázkový list %s" % j["number"], author=s["firm_name"], size=A5, scale=0.84)
    p.add_page()
    y = _header(p, "Zakázkový list", j["number"], "potvrzení o převzetí zakázky", data_dir, logo_right=True)
    colw = (p.W - 2 * M - 30) / 2
    # zhotovitel kompaktně: adresa, IČO/DIČ a kontakty vždy na jednom řádku (A5 – podpisy mají zůstat na 1. straně)
    sup = [s["firm_name"] or "—",
           ", ".join(x for x in (s["firm_street"], ("%s %s" % (s["firm_zip"], s["firm_city"])).strip()) if x),
           " · ".join("%s: %s" % (k, v) for k, v in (("IČO", s["firm_ico"]), ("DIČ", s["firm_dic"])) if v),
           " · ".join(x for x in (s["firm_phone"], s["firm_email"], s["firm_web"]) if x)]
    cus = [j["cust_name"]] + [x for x in (j["cust_address"] or "").split("\n") if x]
    cus += ["Tel.: %s" % j["phone"]] if j["phone"] else []
    cus += [j["email"]] if j["email"] else []
    cus += ["IČO: %s" % j["cust_ico"]] if j["cust_ico"] else []
    y = max(_party(p, M, y, colw, "Zhotovitel", [x for x in sup if x], small=True),
            _party(p, M + colw + 30, y, colw, "Zákazník", cus)) + 8
    y = _infobox(p, y, [("Číslo zakázky", j["number"]), ("Přijato", _d(j["start_date"])), ("Termín", _d(j["deadline"])),
                        ("Zakázka", j["title"]), ("Zařízení / typ", j["device"]), ("Výrobní číslo", j["serial"]),
                        ("Stav", STATUS.get(j["status"], "")), ("Zapsal(a)", writer)], gap=14)
    y = _paragraphs(p, y, [("Příslušenství převzato", j["accessories"]), ("Popis závady", j["fault"]),
                           ("Provedená práce", j["work_done"])], 10)
    if lines:
        vp = s["vat_payer"] == "1"
        y = _items(p, y + 4, lines, vp, "Předpokládaná cena" + (" vč. DPH" if vp else ""))
    y = _paragraphs(p, y, [("", s["job_terms"])], 8)
    _signoff(p, y, dict(s, invoice_issuer=writer or s["invoice_issuer"]), data_dir, left_label="Zákazník (podpis)", compact=True)
    _footer(p, s, [s["firm_register"], "Při vyzvednutí předložte tento list. · Vystaveno programem Firmička"])
    return p.output()
