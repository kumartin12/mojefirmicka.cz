"""Přiznání k DPH (DPHDP3) a kontrolní hlášení (DPHKH1) jako XML pro podání přes EPO finanční správy
(daneelektronicky.cz → „Elektronická podání pro finanční správu“ → nahrát soubor).

Pokrývá běžného tuzemského plátce: vydané faktury, dobropisy a daňové doklady k přijatým zálohám,
účtenky z pokladny (zjednodušené doklady), přijaté faktury s nárokem na odpočet v plné výši.
Nepokrývá: přenesenou daňovou povinnost, dovoz/vývoz, plnění do/z EU, krácený odpočet, opravy podle § 44/46.
Struktura podle XSD dphdp3_epo2.xsd / dphkh1_epo2.xsd (adisspr.mfcr.cz), verze písemností z 9. 3. 2026."""
import re
import xml.etree.ElementTree as ET
from datetime import date

from . import __version__
from .db import invoice_totals, rnd
from .epo_codes import UFO, PRACUFO

DP3_VERSION = "03.01.03"
KH1_VERSION = "03.01.14"
KH_LIMIT = 1000000          # 10 000 Kč vč. DPH v haléřích – nad limit jednotlivě (A.4 / B.2), jinak souhrnně
RATES = {21: "1", 12: "2"}  # zakl_dane1/dan1 = základní sazba, zakl_dane2/dan2 = snížená


def period_range(year, month=None, quarter=None):
    if month:
        od = date(year, month, 1)
        do = date(year + (month == 12), month % 12 + 1, 1)
    else:
        od = date(year, 3 * quarter - 2, 1)
        do = date(year + (quarter == 4), (3 * quarter) % 12 + 1, 1)
    return od.isoformat(), date.fromordinal(do.toordinal() - 1).isoformat()


def digits(s):
    return "".join(c for c in (s or "") if c.isdigit())


def cz_dic(dic):
    """Tuzemské DIČ bez „CZ“ (jen číslice), u zahraničního/žádného prázdné."""
    d = (dic or "").replace(" ", "").upper()
    if d.startswith("CZ") and d[2:].isdigit():
        return d[2:]
    return ""


def collect(db, od, do):
    """Doklady s DPH za období podle DUZP. Vrací dict se seznamy (doklad, rekapitulace, celkem)."""
    from .invoices import lines_of
    from .purchases import plines
    from .pos import rlines
    out = {"issued": [], "receipts": [], "received": []}
    for inv in db.q("SELECT * FROM invoices WHERE status != 'stornovana' AND vat_payer = 1 AND kind != 'zaloha' "
                    "AND tax_date BETWEEN ? AND ? ORDER BY tax_date, number", (od, do)):
        t = invoice_totals(lines_of(db, inv["id"]), True)
        out["issued"].append((inv, t))
    for r in db.q("SELECT * FROM receipts WHERE status = 'ok' AND vat_payer = 1 AND date BETWEEN ? AND ? ORDER BY id",
                  (od, do)):
        out["receipts"].append((r, invoice_totals(rlines(db, r["id"]), True)))
    for p in db.q("SELECT * FROM purchases WHERE tax_date BETWEEN ? AND ? ORDER BY tax_date, id", (od, do)):
        t = invoice_totals(plines(db, p["id"]), True)
        if t["vat"]:                       # bez DPH (neplátce dodavatel) → nic k odpočtu
            out["received"].append((p, t))
    return out


def sums(items):
    """{sazba: [základ, daň]} v haléřích."""
    s = {}
    for _, t in items:
        for r in t["recap"]:
            b = s.setdefault(r["rate"], [0, 0])
            b[0] += r["base"]
            b[1] += r["vat"]
    return s


def _kc(hal):
    return str(rnd(hal / 100))           # přiznání: celé koruny


def _hal(hal):
    return "%.2f" % (hal / 100)          # kontrolní hlášení: haléře


def _cz_date(iso):
    return "%s.%s.%s" % (iso[8:10], iso[5:7], iso[:4])


def check_settings(s):
    """Chybějící údaje pro podání (prázdný seznam = vše v pořádku)."""
    miss = []
    if s["vat_payer"] != "1":
        miss.append("v Nastavení nejste plátce DPH")
    if not cz_dic(s["firm_dic"]):
        miss.append("DIČ firmy (CZ…)")
    if s["epo_ufo"] not in UFO:
        miss.append("finanční úřad")
    if s["epo_pracufo"] and (s["epo_pracufo"] not in PRACUFO or PRACUFO[s["epo_pracufo"]][1] != s["epo_ufo"]):
        miss.append("územní pracoviště nepatří k vybranému finančnímu úřadu")
    if s["epo_typ_ds"] == "F" and not (s["epo_jmeno"] and s["epo_prijmeni"]):
        miss.append("jméno a příjmení (fyzická osoba)")
    return miss


def _street(street):
    """„Hlavní 1234/5a“ → (ulice, č. p., č. or.)."""
    m = re.match(r"^(.*?)[\s,]+(\d{1,6})(?:/(\w{1,4}))?$", (street or "").strip())
    if not m:
        return (street or "")[:38], "", ""
    return m.group(1)[:38], m.group(2), m.group(3) or ""


def _veta_p(parent, s):
    p = ET.SubElement(parent, "VetaP")
    ulice, cpop, corient = _street(s["firm_street"])
    vals = [("c_ufo", s["epo_ufo"]), ("c_pracufo", s["epo_pracufo"]), ("dic", cz_dic(s["firm_dic"])),
            ("typ_ds", s["epo_typ_ds"] or "P")]
    if (s["epo_typ_ds"] or "P") == "F":
        vals += [("jmeno", s["epo_jmeno"][:30]), ("prijmeni", s["epo_prijmeni"][:36])]
    else:
        vals += [("zkrobchjm", s["firm_name"][:255])]
    vals += [("ulice", ulice), ("c_pop", cpop), ("c_orient", corient), ("naz_obce", (s["firm_city"] or "")[:48]),
             ("psc", digits(s["firm_zip"])[:5]), ("stat", "ČESKÁ REPUBLIKA"), ("email", (s["firm_email"] or "")[:255]),
             ("c_telef", digits(s["firm_phone"])[-14:])]
    for k, v in vals:
        if v:
            p.set(k, v)


def _root(form, version):
    root = ET.Element("Pisemnost", nazevSW="Firmicka", verzeSW=__version__)
    return root, ET.SubElement(root, form, verzePis=version)


def _veta_d(parent, dokument, forma_attr, forma, year, month, quarter, extra=()):
    d = ET.SubElement(parent, "VetaD", dokument=dokument, k_uladis="DPH")
    d.set(forma_attr, forma)
    for k, v in extra:
        d.set(k, v)
    d.set("rok", str(year))
    if month:
        d.set("mesic", str(month))
    else:
        d.set("ctvrt", str(quarter))
    d.set("d_poddp", _cz_date(date.today().isoformat()))
    return d


def _xml(root):
    return ('<?xml version="1.0" encoding="UTF-8"?>\n' + ET.tostring(root, encoding="unicode")).encode("utf-8")


def dp3(s, data, year, month=None, quarter=None, forma="B"):
    """Přiznání k DPH – řádky 1, 2 (výstup 21/12 %), 40, 41, 46 (odpočet v plné výši), 62–65."""
    out = sums(data["issued"] + data["receipts"])
    inp = sums(data["received"])
    root, f = _root("DPHDP3", DP3_VERSION)
    extra = [("typ_platce", "P")]
    if s["epo_okec"]:
        extra.append(("c_okec", digits(s["epo_okec"])[:6]))
    d = _veta_d(f, "DP3", "dapdph_forma", forma, year, month, quarter, extra)
    d.set("trans", "A" if out or inp else "N")
    _veta_p(f, s)
    o21, o12 = out.get(21, [0, 0]), out.get(12, [0, 0])
    i21, i12 = inp.get(21, [0, 0]), inp.get(12, [0, 0])
    v1 = ET.SubElement(f, "Veta1")
    for k, v in (("obrat23", o21[0]), ("dan23", o21[1]), ("obrat5", o12[0]), ("dan5", o12[1])):
        if v:
            v1.set(k, _kc(v))
    dan = rnd(o21[1] / 100) + rnd(o12[1] / 100)
    odp = rnd(i21[1] / 100) + rnd(i12[1] / 100)
    if inp:
        v4 = ET.SubElement(f, "Veta4")
        for k, v in (("pln23", i21[0]), ("odp_tuz23_nar", i21[1]), ("pln5", i12[0]), ("odp_tuz5_nar", i12[1])):
            if v:
                v4.set(k, _kc(v))
        v4.set("odp_sum_nar", str(odp))
    v6 = ET.SubElement(f, "Veta6", dan_zocelk=str(dan), odp_zocelk=str(odp))
    if dan >= odp:
        v6.set("dano_da", str(dan - odp))
    else:
        v6.set("dano_no", str(odp - dan))
    return _xml(root), {"dan": dan, "odp": odp, "out": out, "inp": inp}


def _amounts(el, recap):
    for r in recap:
        n = RATES.get(r["rate"])
        if n and (r["base"] or r["vat"]):
            el.set("zakl_dane" + n, _hal(r["base"]))
            el.set("dan" + n, _hal(r["vat"]))


def kh1(s, data, year, month=None, quarter=None, forma="B"):
    """Kontrolní hlášení – A.4 / A.5 (vydané), B.2 / B.3 (přijaté), C (kontrolní součty).
    Dobropis = záporné částky; do A.4/B.2 jde podle absolutní hodnoty dokladu vč. DPH."""
    root, f = _root("DPHKH1", KH1_VERSION)
    _veta_d(f, "KH1", "khdph_forma", forma, year, month, quarter)
    _veta_p(f, s)
    a5, b3 = [], []
    rows = {"A4": 0, "B2": 0}
    for inv, t in data["issued"]:
        dic = cz_dic(inv["cust_dic"])
        if dic and abs(t["total"]) > KH_LIMIT:
            rows["A4"] += 1
            e = ET.SubElement(f, "VetaA4", c_radku=str(rows["A4"]), dic_odb=dic, c_evid_dd=inv["number"][:60],
                              dppd=_cz_date(inv["tax_date"]))
            _amounts(e, t["recap"])
            e.set("kod_rezim_pl", "0")
            e.set("zdph_44", "N")
        else:
            a5.append((inv, t))
    a5 += data["receipts"]
    if a5:
        e = ET.SubElement(f, "VetaA5")
        _amounts(e, [{"rate": k, "base": v[0], "vat": v[1]} for k, v in sorted(sums(a5).items(), reverse=True)])
    for p, t in data["received"]:
        dic = cz_dic(p["supp_dic"])
        if dic and abs(t["total"]) > KH_LIMIT:
            rows["B2"] += 1
            e = ET.SubElement(f, "VetaB2", c_radku=str(rows["B2"]), dic_dod=dic, c_evid_dd=(p["number"] or p["doc_number"])[:60],
                              dppd=_cz_date(p["tax_date"]))
            _amounts(e, t["recap"])
            e.set("pomer", "N")
            e.set("zdph_44", "N")
        else:
            b3.append((p, t))
    if b3:
        e = ET.SubElement(f, "VetaB3")
        _amounts(e, [{"rate": k, "base": v[0], "vat": v[1]} for k, v in sorted(sums(b3).items(), reverse=True)])
    out, inp = sums(data["issued"] + data["receipts"]), sums(data["received"])
    c = ET.SubElement(f, "VetaC")
    for k, v in (("obrat23", out.get(21, [0])[0]), ("obrat5", out.get(12, [0])[0]),
                 ("pln23", inp.get(21, [0])[0]), ("pln5", inp.get(12, [0])[0])):
        if v:
            c.set(k, _hal(v))
    return _xml(root), {"a4": rows["A4"], "a5": len(a5), "b2": rows["B2"], "b3": len(b3)}
