"""EET 2.0 – evidence tržeb (zákon č. 180/2026 Sb., od 1. 1. 2027).

Každá kontaktní platba (pokladna: hotově, kartou, QR; faktura zaplacená hotově nebo kartou) se pošle
datovou zprávou na společné technické zařízení Finanční správy (SOAP 1.1 + WS-Security, podpis RSA-SHA256
pokladním certifikátem z DIS+). Storno / vrácení = záporná tržba (§ 8). Když stát neodpoví do mezní doby
odezvy, tržba zůstane ve frontě a pošle se dodatečně – zákon dává nejvýš 48 hodin (§ 20).

Specifikace: „Formát a struktura údajů o evidované tržbě…“ verze 1.2 (25. 8. 2026), XSD/WSDL v4.1.
Kanonizace (exc-c14n) se nepočítá obecně – zprávu skládáme sami přesně v kanonickém tvaru
(ověřeno proti vzorové zprávě FS: digest i podpis sedí bajt po bajtu).
"""
import base64
import hashlib
import re
import ssl
import threading
import time
import urllib.error
import urllib.request
import uuid
import xml.etree.ElementTree as ET
from datetime import datetime, timezone

from .web import h, money, cz_date, flash, flash_redirect, HTTPError, parse_id

URLS = {"prod": "https://trzbyeet.gov.cz/eet/services/EETServiceSOAP/v4",
        "pg": "https://pg.trzbyeet.gov.cz/eet/services/EETServiceSOAP/v4"}
ENVS = {"prod": "Ostrý provoz (Finanční správa)", "pg": "Testovací prostředí pro vývojáře (playground) – tržby se neevidují"}
SOAP_ACTION = "http://fs.gov.cz/eet/OdeslaniTrzby"
NS = "http://fs.gov.cz/eet/schema/v4"
NS_SOAP = "http://schemas.xmlsoap.org/soap/envelope/"
NS_WSSE = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd"
NS_WSU = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd"
NS_DS = "http://www.w3.org/2000/09/xmldsig#"
C14N = "http://www.w3.org/2001/10/xml-exc-c14n#"
X509 = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-x509-token-profile-1.0#X509v3"
B64 = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary"

CONTACT_PAY = ("hotove", "karta")          # faktury: platby při osobním kontaktu (převod/dobírka ne)
TIMEOUTS = ("2", "3", "5", "8", "10")
DEADLINE = 48 * 3600                       # § 20: dodatečně nejpozději do 48 hodin
RETRY_AFTER = 60
STATUS = {"ceka": "Čeká na odeslání", "ok": "Zaevidováno", "chyba": "Odmítnuto"}
TEXT_OK = re.compile(r"^[0-9a-zA-Z.,:;/#\-_ ]+$")
EIC_RE = re.compile(r"^CZ[0-9]{8,10}$")
UNIT_RE = re.compile(r"^[1-9][0-9]{0,8}$")


class EETError(Exception):
    pass


class CryptoMissing(EETError):
    pass


# ---------- pomocné ----------

def enabled(s):
    return s.get("eet_on") == "1"


def eic_of(s):
    v = re.sub(r"\s+", "", s.get("eet_eic") or s.get("firm_dic") or "").upper()
    return v


def clean_text(v, n):
    """Povolené znaky pro id_pokl / porad_cis (ASCII bez diakritiky); jiné → „-“."""
    import unicodedata
    v = unicodedata.normalize("NFKD", v or "").encode("ascii", "ignore").decode()
    v = re.sub(r"[^0-9a-zA-Z.,:;/#\-_ ]", "-", v).strip()
    return (v or "1")[:n]


def amount_str(halere):
    a = int(halere)
    if abs(a) >= 10_000_000_000:
        raise EETError("Částka přesahuje limit EET (100 milionů Kč)")
    return "%s%d.%02d" % ("-" if a < 0 else "", abs(a) // 100, abs(a) % 100)


def ts_str(ts):
    """Lokální čas s časovou zónou (+01:00 zima / +02:00 léto), bez zlomků sekund."""
    return datetime.fromtimestamp(int(ts)).astimezone().isoformat(timespec="seconds")


def unit_for(db, s, wh_id):
    r = db.one("SELECT eet_unit FROM warehouses WHERE id = ?", (wh_id or 1,))
    return ((r and r["eet_unit"]) or s.get("eet_unit") or "").strip()


# ---------- certifikát ----------

_cert_cache = {}


def load_p12(data, password):
    """→ (privátní klíč, certifikát DER, CN, platnost do jako datetime UTC)."""
    try:
        from cryptography.hazmat.backends import default_backend
        from cryptography.hazmat.primitives.serialization import pkcs12, Encoding
        from cryptography.x509.oid import NameOID
    except ImportError:
        raise CryptoMissing("Chybí knihovna cryptography (v instalačce pro Windows je přibalená; na Linuxu a Macu: "
                            "pip3 install cryptography).")
    key = (hashlib.sha256(data).hexdigest(), password)
    if key in _cert_cache:
        return _cert_cache[key]
    try:
        pk, cert, _ = pkcs12.load_key_and_certificates(data, (password or "").encode(), default_backend())
    except Exception:
        raise EETError("Certifikát se nepodařilo otevřít – špatné heslo, nebo to není soubor .p12 z MOJE daně.")
    if pk is None or cert is None:
        raise EETError("Soubor neobsahuje certifikát s privátním klíčem.")
    cns = cert.subject.get_attributes_for_oid(NameOID.COMMON_NAME)
    cn = cns[0].value if cns else ""
    until = getattr(cert, "not_valid_after_utc", None)
    until = until.replace(tzinfo=None) if until is not None else cert.not_valid_after   # naivní UTC
    out = (pk, cert.public_bytes(Encoding.DER), cn, until)
    _cert_cache.clear()
    _cert_cache[key] = out
    return out


def cert_of(s):
    if not s.get("eet_p12"):
        raise EETError("Není nahraný pokladní certifikát (Nastavení → EET).")
    return load_p12(base64.b64decode(s["eet_p12"]), s.get("eet_p12_pw", ""))


def cert_info(s):
    """Pro zobrazení: (CN, platnost do, dní zbývá) nebo None; chyba → text."""
    if not s.get("eet_p12"):
        return None
    try:
        _, _, cn, until = cert_of(s)
    except EETError as e:
        return str(e)
    return cn, until, (until - datetime.now(timezone.utc).replace(tzinfo=None)).days


# ---------- zpráva ----------

def body_c14n(body_id, head, data):
    """<soapenv:Body> přesně v kanonickém tvaru exc-c14n s InclusiveNamespaces „v4“ (atributy abecedně,
    prázdné elementy rozepsané)."""
    def attrs(d):
        return "".join(' %s="%s"' % (k, d[k]) for k in sorted(d))
    return ('<soapenv:Body xmlns:soapenv="%s" xmlns:v4="%s" xmlns:wsu="%s" wsu:Id="%s"><v4:Trzba>'
            '<v4:Hlavicka%s></v4:Hlavicka><v4:Data%s></v4:Data></v4:Trzba></soapenv:Body>'
            % (NS_SOAP, NS, NS_WSU, body_id, attrs(head), attrs(data)))


def signed_info(body_id, digest):
    return ('<ds:SignedInfo xmlns:ds="%s" xmlns:soapenv="%s" xmlns:v4="%s">'
            '<ds:CanonicalizationMethod Algorithm="%s"><ec:InclusiveNamespaces xmlns:ec="%s" PrefixList="soapenv v4">'
            '</ec:InclusiveNamespaces></ds:CanonicalizationMethod>'
            '<ds:SignatureMethod Algorithm="http://www.w3.org/2001/04/xmldsig-more#rsa-sha256"></ds:SignatureMethod>'
            '<ds:Reference URI="#%s"><ds:Transforms><ds:Transform Algorithm="%s"><ec:InclusiveNamespaces xmlns:ec="%s" '
            'PrefixList="v4"></ec:InclusiveNamespaces></ds:Transform></ds:Transforms>'
            '<ds:DigestMethod Algorithm="http://www.w3.org/2001/04/xmlenc#sha256"></ds:DigestMethod>'
            '<ds:DigestValue>%s</ds:DigestValue></ds:Reference></ds:SignedInfo>'
            % (NS_DS, NS_SOAP, NS, C14N, C14N, body_id, C14N, C14N, digest))


def build(row, s, first=True, verify=False, now=None):
    """Podepsaná SOAP zpráva pro řádek tabulky eet → (xml bajty, uuid zprávy)."""
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.asymmetric import padding
    pk, der, _, _ = cert_of(s)
    msg_uuid = str(uuid.uuid4())
    head = {"uuid_zpravy": msg_uuid, "dat_odesl": ts_str(now or time.time()),
            "prvni_zaslani": "true" if first else "false", "overeni": "true" if verify else "false"}
    data = {"eic_popl": row["eic"], "id_jednotky": row["id_jednotky"], "id_pokl": row["id_pokl"],
            "porad_cis": row["porad_cis"], "dat_trzby": row["dat_trzby"], "celk_trzba": amount_str(row["amount"])}
    if not EIC_RE.match(data["eic_popl"]):
        raise EETError("DIČ pro EET „%s“ nemá tvar CZ + 8 až 10 číslic (Nastavení → EET)." % data["eic_popl"])
    if not UNIT_RE.match(data["id_jednotky"]):
        raise EETError("Chybí číslo evidenční jednotky (provozovny) z MOJE daně (Nastavení → EET).")
    tag = uuid.uuid4().hex.upper()
    body_id = "id-" + tag
    body = body_c14n(body_id, head, data)
    digest = base64.b64encode(hashlib.sha256(body.encode("ascii")).digest()).decode()
    si = signed_info(body_id, digest)
    sig = base64.b64encode(pk.sign(si.encode("ascii"), padding.PKCS1v15(), hashes.SHA256())).decode()
    # v obálce stojí SignedInfo bez opakovaných deklarací jmenných prostorů (zdědí je) – kanonický tvar je stejný
    si_doc = si.replace(' xmlns:ds="%s" xmlns:soapenv="%s" xmlns:v4="%s"' % (NS_DS, NS_SOAP, NS), "", 1)
    body_doc = body.replace(' xmlns:soapenv="%s" xmlns:v4="%s"' % (NS_SOAP, NS), "", 1)
    xml = ('<soapenv:Envelope xmlns:soapenv="%s" xmlns:v4="%s"><soapenv:Header>'
           '<wsse:Security xmlns:wsse="%s" xmlns:wsu="%s">'
           '<wsse:BinarySecurityToken EncodingType="%s" ValueType="%s" wsu:Id="X509-%s">%s</wsse:BinarySecurityToken>'
           '<ds:Signature Id="SIG-%s" xmlns:ds="%s">%s<ds:SignatureValue>%s</ds:SignatureValue>'
           '<ds:KeyInfo Id="KI-%s"><wsse:SecurityTokenReference wsu:Id="STR-%s"><wsse:Reference URI="#X509-%s" '
           'ValueType="%s"/></wsse:SecurityTokenReference></ds:KeyInfo></ds:Signature></wsse:Security>'
           '</soapenv:Header>%s</soapenv:Envelope>'
           % (NS_SOAP, NS, NS_WSSE, NS_WSU, B64, X509, tag, base64.b64encode(der).decode(), tag, NS_DS, si_doc, sig,
              tag, tag, tag, X509, body_doc))
    return xml.encode("utf-8"), msg_uuid


def parse_response(raw):
    """→ dict(pok, kod, text, warnings, test)."""
    try:
        root = ET.fromstring(raw)
    except ET.ParseError:
        raise EETError("Nečitelná odpověď serveru EET")
    out = {"pok": "", "kod": None, "text": "", "warnings": [], "test": False}
    p = root.find(".//{%s}Potvrzeni" % NS)
    c = root.find(".//{%s}Chyba" % NS)
    if p is not None:
        out["pok"] = p.get("pok", "")
        out["test"] = p.get("test") in ("true", "1")
    elif c is not None:
        out["kod"] = int(c.get("kod", "-1"))
        out["text"] = (c.text or "").strip()
        out["test"] = c.get("test") in ("true", "1")
    else:
        fault = root.find(".//faultstring")
        raise EETError("Server EET vrátil chybu: %s" % ((fault.text or "").strip()[:150] if fault is not None else "bez popisu"))
    out["warnings"] = ["%s %s" % (w.get("kod_varov", ""), (w.text or "").strip()) for w in root.findall(".//{%s}Varovani" % NS)]
    return out


def http_post(url, body, timeout):
    """→ (bajty odpovědi, X-Global-Transaction-Id). Síťová chyba / timeout → OSError."""
    req = urllib.request.Request(url, data=body, method="POST", headers={
        "Content-Type": "text/xml; charset=utf-8", "SOAPAction": SOAP_ACTION})
    ctx = ssl.create_default_context()
    if not ctx.cert_store_stats().get("x509_ca"):      # Python z python.org na Macu bez kořenových certifikátů
        try:
            import certifi
            ctx.load_verify_locations(certifi.where())
        except ImportError:
            pass
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as r:
            return r.read(), r.headers.get("X-Global-Transaction-Id", "")
    except urllib.error.HTTPError as e:      # chybová datová zpráva může přijít s HTTP 500
        data = e.read()
        if data:
            return data, e.headers.get("X-Global-Transaction-Id", "")
        raise OSError("HTTP %s" % e.code)


TRANSPORT = http_post        # testy podstrčí vlastní


# ---------- evidence ----------

def reconcile(db, s, kind, doc_id, number, target, wh_id, when=None):
    """Srovná evidované tržby dokladu s tím, co má být zaevidováno (`target` v haléřích): rozdíl se zapíše
    jako nová tržba (kladná = přijatá platba, záporná = storno/vrácení). Volat uvnitř transakce dokladu;
    vrací id nového řádku (nebo None) – odeslat ho až po commitu přes send()."""
    if not enabled(s):
        return None
    col = "receipt_id" if kind == "receipt" else "invoice_id"
    env = s.get("eet_env") or "prod"
    # jen tržby ve stejném prostředí – zkoušky v testovacím prostředí se do ostré evidence nepočítají
    rows = db.q("SELECT amount FROM eet WHERE %s = ? AND env = ?" % col, (doc_id, env))
    done = sum(r["amount"] for r in rows)
    diff = target - done
    if diff == 0:
        return None
    ts = int(when or time.time())
    eic, unit = eic_of(s), unit_for(db, s, wh_id)
    pokl = clean_text(s.get("eet_pokl") or "1", 20)
    base = clean_text(number, 25)
    porad = base if not rows else "%s/%d" % (base[:25 - 1 - len(str(len(rows) + 1))], len(rows) + 1)
    # (DIČ, provozovna, pokladna, čas) musí být jedinečné – dva prodeje v jedné sekundě (síť) → posun o sekundu
    while db.one("SELECT 1 FROM eet WHERE eic = ? AND id_jednotky = ? AND id_pokl = ? AND dat_trzby = ?",
                 (eic, unit, pokl, ts_str(ts))):
        ts += 1
    return db.run("INSERT INTO eet(%s, doc, porad_cis, id_jednotky, id_pokl, eic, dat_trzby, ts, amount, env, created) "
                  "VALUES(?,?,?,?,?,?,?,?,?,?,?)" % col,
                  (doc_id, number, porad, unit, pokl, eic, ts_str(ts), ts, diff, env, int(time.time())))


_send_lock = threading.Lock()


def _claim(db, rid, now):
    """Zabrání souběžnému odeslání téhož řádku (pokladna × fronta na pozadí)."""
    with db.lock:
        cur = db.conn.execute("UPDATE eet SET last_try = ? WHERE id = ? AND status != 'ok' AND last_try < ?",
                              (now, rid, now - 20))
        return cur.rowcount == 1


def send(db, s, rid, manual=False):
    """Odešle jeden řádek; vrátí ho aktualizovaný. Nikdy nevyhazuje výjimku (prodej se kvůli EET nezastaví)."""
    now = int(time.time())
    row = db.one("SELECT * FROM eet WHERE id = ?", (rid,))
    if not row or row["status"] == "ok":
        return row
    if not _claim(db, rid, now) and not manual:
        return row
    if manual and row["status"] == "chyba" and not row["pok"]:
        # odmítnutá tržba po opravě nastavení: vezme aktuální DIČ / provozovnu (čas a částka zůstávají)
        db.run("UPDATE eet SET eic = ?, id_jednotky = ?, id_pokl = ? WHERE id = ?",
               (eic_of(s), unit_for(db, s, _wh_of(db, row)), clean_text(s.get("eet_pokl") or "1", 20), rid))
        row = db.one("SELECT * FROM eet WHERE id = ?", (rid,))
    status, pok, err, warn, trace = "ceka", "", "", "", ""
    try:
        body, _ = build(row, s, first=row["attempts"] == 0)
        timeout = max(2, int(s.get("eet_timeout") or 3))
        raw, trace = TRANSPORT(URLS.get(row["env"], URLS["prod"]), body, timeout)
        res = parse_response(raw)
        warn = "; ".join(res["warnings"])
        if res["pok"]:
            status, pok = "ok", res["pok"]
        elif res["kod"] is not None and res["kod"] < 0:
            err = "Dočasná chyba serveru EET (%d) – pošle se znovu" % res["kod"]
        else:
            status, err = "chyba", "Kód %s: %s" % (res["kod"], res["text"][:120])
    except CryptoMissing as e:
        err = str(e)
    except EETError as e:
        err = str(e)
    except (OSError, ssl.SSLError) as e:          # bez spojení / překročena mezní doba odezvy
        err = net_error(e) + " – pošle se dodatečně"
    except Exception as e:                         # cokoli jiného nesmí shodit prodej
        err = "Chyba při odesílání: %s" % str(e)[:100]
    db.run("UPDATE eet SET status = ?, pok = ?, error = ?, warnings = ?, attempts = attempts + 1, last_try = ?, "
           "sent = CASE WHEN ? = 'ok' THEN ? ELSE sent END, trace = ? WHERE id = ?",
           (status, pok, err, warn, now, status, int(time.time()), trace or "", rid))
    return db.one("SELECT * FROM eet WHERE id = ?", (rid,))


def _wh_of(db, row):
    if row["receipt_id"]:
        r = db.one("SELECT warehouse_id FROM receipts WHERE id = ?", (row["receipt_id"],))
    elif row["invoice_id"]:
        r = db.one("SELECT warehouse_id FROM invoices WHERE id = ?", (row["invoice_id"],))
    else:
        r = None
    return r["warehouse_id"] if r else 1


def send_pending(db, limit=50):
    """Fronta: neodeslané tržby (nejstarší první). Volá vlákno na pozadí každou minutu."""
    if not _send_lock.acquire(blocking=False):
        return 0
    try:
        s = db.settings()
        n = 0
        for r in db.q("SELECT id FROM eet WHERE status = 'ceka' AND last_try < ? ORDER BY ts LIMIT ?",
                      (int(time.time()) - RETRY_AFTER, limit)):
            row = send(db, s, r["id"])
            if row["status"] == "ok":
                n += 1
            elif row["status"] == "ceka" and row["last_try"] >= int(time.time()) - 5:
                break        # server pořád nedostupný – zbytek fronty zkusit až za minutu (neblokovat desítky timeoutů)
        return n
    finally:
        _send_lock.release()


def worker(db, interval=60):
    while True:
        try:
            send_pending(db)
        except Exception as e:
            print("EET fronta:", e)
        time.sleep(interval)


def verify_connection(s, db):
    """Ověřovací mód (overeni=true): server zprávu zkontroluje, ale tržbu neeviduje. → (ok, text)."""
    row = {"eic": eic_of(s), "id_jednotky": unit_for(db, s, 1), "id_pokl": clean_text(s.get("eet_pokl") or "1", 20),
           "porad_cis": "TEST-SPOJENI", "dat_trzby": ts_str(time.time()), "amount": 100}
    try:
        body, _ = build(row, s, verify=True)
        t0 = time.time()
        raw, _ = TRANSPORT(URLS.get(s.get("eet_env") or "prod", URLS["prod"]), body, max(2, int(s.get("eet_timeout") or 3)) + 5)
        res = parse_response(raw)
    except EETError as e:
        return False, str(e)
    except (OSError, ssl.SSLError) as e:
        return False, net_error(e)
    ms = int((time.time() - t0) * 1000)
    if res["kod"] == 0:
        w = (" Upozornění: " + "; ".join(res["warnings"])) if res["warnings"] else ""
        return True, "Spojení i certifikát jsou v pořádku (odpověď za %d ms).%s" % (ms, w)
    return False, "Server zprávu odmítl – kód %s: %s" % (res["kod"], res["text"])


def line_for(db, kind, doc_id):
    """Poslední stav EET dokladu pro účtenku / detail: (text, třída) nebo None."""
    col = "receipt_id" if kind == "receipt" else "invoice_id"
    rows = db.q("SELECT * FROM eet WHERE %s = ? ORDER BY id" % col, (doc_id,))
    return rows


def receipt_lines(rows):
    """Řádky na účtenku (POK, nebo že se tržba pošle dodatečně)."""
    out = []
    for r in rows:
        prefix = "EET" if r["amount"] >= 0 else "EET storno"
        if r["status"] == "ok":
            out.append("%s POK:" % prefix)
            out.append(r["pok"])
        else:
            out.append("%s: odešle se dodatečně" % prefix)
    return out


def pending_stats(db):
    now = int(time.time())
    r = db.one("SELECT COUNT(*) AS n, MIN(ts) AS oldest, SUM(status = 'chyba') AS bad FROM eet WHERE status != 'ok'")
    late = db.one("SELECT COUNT(*) AS n FROM eet WHERE status != 'ok' AND ts < ?", (now - DEADLINE,))["n"]
    soon = db.one("SELECT COUNT(*) AS n FROM eet WHERE status != 'ok' AND ts < ?", (now - DEADLINE // 2,))["n"]
    return {"n": r["n"] or 0, "bad": r["bad"] or 0, "late": late, "soon": soon, "oldest": r["oldest"]}


def n_trzeb(n, verb=("čeká", "čekají", "čeká")):
    """1 tržba čeká, 2 tržby čekají, 5 tržeb čeká."""
    if n == 1:
        return "1 tržba " + verb[0]
    if 2 <= n <= 4:
        return "%d tržby %s" % (n, verb[1])
    return "%d tržeb %s" % (n, verb[2])


def net_error(e):
    t = str(getattr(e, "reason", "") or e).lower()
    if "timed out" in t or "timeout" in t:
        return "Server EET neodpověděl do mezní doby"
    if "name or service" in t or "getaddrinfo" in t or "nodename" in t or "name resolution" in t:
        return "Není připojení k internetu"
    if "certificate" in t:
        return "Nepodařilo se ověřit certifikát serveru EET (zkontrolujte datum a čas v počítači)"
    if "refused" in t or "unreachable" in t:
        return "Server EET není dostupný"
    return "Bez spojení se serverem EET (%s)" % (str(e)[:60] or e.__class__.__name__)


# ---------- obrazovky ----------

def register(app):
    db = app.db

    def banner():
        s = db.settings()
        if not enabled(s) and not db.one("SELECT 1 FROM eet WHERE status != 'ok' LIMIT 1"):
            return ""
        st = pending_stats(db)
        out = ""
        if st["n"]:
            cls = "flash error"
            if st["late"]:
                txt = "<b>EET: %s déle než 48 hodin</b> (zákonná lhůta) – " % n_trzeb(st["late"], ("není zaevidovaná",
                                                                                               "nejsou zaevidované", "není zaevidováno"))
            elif st["bad"]:
                txt = "<b>EET: %s</b> – " % n_trzeb(st["bad"], ("byla odmítnuta", "byly odmítnuty", "bylo odmítnuto"))
            elif st["soon"]:
                txt = "<b>EET: %s přes 24 hodin</b> – zkontrolujte připojení k internetu – " % n_trzeb(st["soon"])
            else:
                cls = "flash"
                txt = "EET: %s na odeslání (program je posílá sám) – " % n_trzeb(st["n"])
            out += '<div class="%s noprint">%s<a href="/pokladna/eet">zobrazit</a></div>' % (cls, txt)
        if enabled(s):
            ci = cert_info(s)
            if ci is None:
                out += ('<div class="flash error noprint">EET je zapnuté, ale chybí pokladní certifikát – '
                        '<a href="/nastaveni/eet">Nastavení EET</a></div>')
            elif isinstance(ci, tuple) and ci[2] < 30:
                out += ('<div class="flash error noprint">Pokladní certifikát EET %s %s – vygenerujte nový v MOJE daně '
                        'a nahrajte ho v <a href="/nastaveni/eet">Nastavení EET</a>.</div>'
                        % ("vypršel" if ci[2] < 0 else "vyprší za %d dní" % ci[2], cz_date(ci[1].strftime("%Y-%m-%d"))))
        return out
    app.banners.append(banner)

    @app.route("/nastaveni/eet", ("GET", "POST"))
    def settings(req):
        s = req.settings
        from .warehouses import warehouses
        whs = warehouses(db, active_only=False)
        if req.method == "POST":
            if req.f("akce") == "overit":
                ok, txt = verify_connection(s, db)
                flash_redirect("/nastaveni/eet", ("✔ " if ok else "✘ ") + txt)
            vals = {"eet_env": req.f("eet_env") if req.f("eet_env") in ENVS else "prod",
                    "eet_eic": re.sub(r"\s+", "", req.f("eet_eic")).upper(),
                    "eet_unit": req.f("eet_unit"),
                    "eet_pokl": clean_text(req.f("eet_pokl") or "1", 20),
                    "eet_timeout": req.f("eet_timeout") if req.f("eet_timeout") in TIMEOUTS else "3"}
            if vals["eet_eic"] and not EIC_RE.match(vals["eet_eic"]):
                flash_redirect("/nastaveni/eet", "DIČ pro EET musí mít tvar CZ a 8 až 10 číslic (fyzická osoba bez DIČ: CZ + rodné číslo)")
            if vals["eet_unit"] and not UNIT_RE.match(vals["eet_unit"]):
                flash_redirect("/nastaveni/eet", "Číslo evidenční jednotky je číslo přidělené v MOJE daně (DIS+), např. 12")
            units = {}
            for w in whs:
                u = req.f("unit_%d" % w["id"])
                if u and not UNIT_RE.match(u):
                    flash_redirect("/nastaveni/eet", "Číslo evidenční jednotky u skladu „%s“ není platné" % w["name"])
                units[w["id"]] = u
            if "eet_p12" in req.files:
                data = req.files["eet_p12"][1]
                pw = req.form.get("eet_p12_pw", "")
                try:
                    _, _, cn, until = load_p12(data, pw)
                except EETError as e:
                    flash_redirect("/nastaveni/eet", str(e))
                if until < datetime.now(timezone.utc).replace(tzinfo=None):
                    flash_redirect("/nastaveni/eet", "Certifikát už vypršel (%s) – vygenerujte nový v MOJE daně" % until.date())
                vals["eet_p12"], vals["eet_p12_pw"] = base64.b64encode(data).decode(), pw
                if not vals["eet_eic"]:
                    vals["eet_eic"] = cn
            on = req.f("eet_on") == "1"
            if on:
                test = dict(s, **vals)
                missing = [t for t, ok in (("DIČ", EIC_RE.match(eic_of(test))),
                                           ("pokladní certifikát", test.get("eet_p12")),
                                           ("číslo evidenční jednotky", test.get("eet_unit") or all(units.values())))
                           if not ok]
                if missing:
                    db.set_settings(vals)
                    for wid, u in units.items():
                        db.run("UPDATE warehouses SET eet_unit = ? WHERE id = ?", (u, wid))
                    flash_redirect("/nastaveni/eet", "Uloženo, ale EET nejde zapnout – chybí: %s" % ", ".join(missing))
            vals["eet_on"] = "1" if on else "0"
            with db.tx():
                for wid, u in units.items():
                    db.run("UPDATE warehouses SET eet_unit = ? WHERE id = ?", (u, wid))
            db.set_settings(vals)
            flash_redirect("/nastaveni/eet", "Nastavení EET uloženo" + (" – evidence tržeb je zapnutá" if on else ""))
        ci = cert_info(s)
        if ci is None:
            cert_txt = "Certifikát zatím není nahraný."
        elif isinstance(ci, str):
            cert_txt = '<span class="bad">%s</span>' % h(ci)
        else:
            cert_txt = "Nahraný certifikát pro <b>%s</b>, platí do <b>%s</b>%s." % (
                h(ci[0]), cz_date(ci[1].strftime("%Y-%m-%d")),
                ' <span class="bad">(vypršel)</span>' if ci[2] < 0 else " (zbývá %d dní)" % ci[2])
        try:
            __import__("cryptography")
            crypto = ""
        except ImportError:
            crypto = ('<div class="flash error">Pro EET je potřeba knihovna <b>cryptography</b> – na Linuxu a Macu ji '
                      'nainstalujte příkazem <code>pip3 install cryptography</code> a Firmičku spusťte znovu. '
                      '(Instalačka pro Windows ji obsahuje.)</div>')
        wh_rows = "".join('<label>Ev. jednotka – %s<input name="unit_%d" value="%s" inputmode="numeric" placeholder="%s"></label>'
                          % (h(w["name"]), w["id"], h(w["eet_unit"] or ""), "jako výchozí" if len(whs) > 1 else "")
                          for w in whs) if len(whs) > 1 else ""
        if len(whs) == 1:
            wh_rows = '<input type="hidden" name="unit_%d" value="">' % whs[0]["id"]
        return app.page("EET", """%s<div class="bar"><h1>Evidence tržeb (EET 2.0)</h1>
<a class="btn" href="/pokladna/eet">Evidované tržby</a></div>%s
<section class="card"><p>Od <b>1. 1. 2027</b> se eviduje každá platba přijatá při osobním kontaktu – v hotovosti, kartou,
QR kódem, stravenkou ap. Firmička tržbu pošle sama: z <b>pokladny</b> při uložení účtenky a u <b>faktury</b> zaplacené
hotově nebo kartou při označení „uhrazeno“. Storno pošle zápornou tržbu. Platby převodem na účet se neevidují.</p>
<p class="hint">Postup: přihlaste se do <b>MOJE daně → DIS+</b>, založte evidenční jednotku (provozovnu), vygenerujte
pokladní certifikát (soubor .p12 s heslem) a nahrajte ho sem. Když server EET neodpoví včas, prodej proběhne normálně
a tržba se pošle dodatečně (zákon dává 48 hodin).</p></section>
<form method="post" enctype="multipart/form-data" class="grid">%s
<section class="card wide"><h2>Nastavení</h2><div class="grid">
<label class="check wide"><input type="checkbox" name="eet_on" value="1"%s> Evidovat tržby (EET zapnuto)</label>
<label>DIČ (EIČ)<input name="eet_eic" value="%s" placeholder="%s"><span class="hint">prázdné = DIČ firmy</span></label>
<label>Evidenční jednotka (provozovna)<input name="eet_unit" value="%s" inputmode="numeric" placeholder="číslo z DIS+"></label>
%s
<label>Označení pokladny<input name="eet_pokl" value="%s" maxlength="20"><span class="hint">libovolné, např. 1 nebo PRODEJNA</span></label>
<label>Mezní doba odezvy<select name="eet_timeout">%s</select><span class="hint">po ní se prodej dokončí a tržba pošle dodatečně</span></label>
<label class="wide">Prostředí<select name="eet_env">%s</select></label></div></section>
<section class="card wide"><h2>Pokladní certifikát</h2><p>%s</p><div class="grid">
<label>Soubor certifikátu (.p12)<input type="file" name="eet_p12" accept=".p12,.pfx"></label>
<label>Heslo k certifikátu<input type="password" name="eet_p12_pw" autocomplete="new-password"></label></div></section>
<div class="actions wide"><button class="btn primary">Uložit</button></div></form>
<form method="post" class="card">%s<input type="hidden" name="akce" value="overit"><h2>Test spojení</h2>
<p class="hint">Pošle zkušební zprávu v ověřovacím režimu – Finanční správa zkontroluje certifikát a údaje, ale nic neeviduje.</p>
<button class="btn">Ověřit spojení s EET</button></form>""" % (
            flash(req), crypto, app.csrf(), " checked" if enabled(s) else "", h(s.get("eet_eic", "")),
            h(re.sub(r"\s+", "", s.get("firm_dic", "")) or "CZ12345678"), h(s.get("eet_unit", "")), wh_rows,
            h(s.get("eet_pokl", "1")),
            "".join('<option value="%s"%s>%s s</option>' % (t, " selected" if (s.get("eet_timeout") or "3") == t else "", t)
                    for t in TIMEOUTS),
            "".join('<option value="%s"%s>%s</option>' % (k, " selected" if (s.get("eet_env") or "prod") == k else "", v)
                    for k, v in ENVS.items()),
            cert_txt, app.csrf()), "/nastaveni")

    @app.route("/pokladna/eet", ("GET", "POST"))
    def overview(req):
        if req.method == "POST":
            s = req.settings
            if req.f("akce") == "vse":
                n = 0
                for r in db.q("SELECT id FROM eet WHERE status != 'ok' ORDER BY ts"):
                    n += send(db, s, r["id"], manual=True)["status"] == "ok"
                left = db.one("SELECT COUNT(*) AS n FROM eet WHERE status != 'ok'")["n"]
                msg = "Zaevidováno: %d" % n + (" · %s" % n_trzeb(left, ("stále čeká", "stále čekají", "stále čeká")) if left else "")
                flash_redirect("/pokladna/eet", msg)
            rid = parse_id(req.f("id"))
            r = send(db, s, rid, manual=True) if rid else None
            if not r:
                raise HTTPError(404, "Tržba neexistuje")
            flash_redirect("/pokladna/eet", "Zaevidováno, POK %s" % r["pok"] if r["status"] == "ok" else "Neodesláno: %s" % r["error"])
        show = req.args.get("zobrazit", "")
        where = "WHERE status != 'ok'" if show == "neodeslane" else ""
        rows = db.q("SELECT * FROM eet %s ORDER BY ts DESC LIMIT 300" % where)
        now = int(time.time())
        trs = []
        for r in rows:
            link = "/pokladna/%d" % r["receipt_id"] if r["receipt_id"] else "/faktury/%d" % r["invoice_id"] if r["invoice_id"] else ""
            state = STATUS[r["status"]]
            if r["status"] == "ok":
                detail = '<code class="pok">%s</code>' % h(r["pok"])
                if r["env"] == "pg":
                    detail += ' <span class="hint">(testovací)</span>'
            else:
                detail = h(r["error"])
                if now - r["ts"] > DEADLINE:
                    state += " · po lhůtě 48 h"
                detail += ('<form method="post" class="eet-resend">%s<input type="hidden" name="id" value="%d">'
                           '<button class="btn small">Odeslat znovu</button></form>' % (app.csrf(), r["id"]))
            if r["warnings"]:
                detail += '<br><span class="hint">%s</span>' % h(r["warnings"])
            trs.append('<tr%s><td>%s</td><td>%s</td><td>%s</td><td class=num>%s</td><td>%s</td><td>%s</td></tr>' % (
                "" if r["status"] == "ok" else " class=warn",
                datetime.fromtimestamp(r["ts"]).strftime("%d.%m.%Y %H:%M:%S"),
                ('<a href="%s">%s</a>' % (link, h(r["doc"]))) if link else h(r["doc"]), h(r["porad_cis"]),
                money(r["amount"]), state, detail))
        st = pending_stats(db)
        resend = ('<form method="post" class="inline">%s<input type="hidden" name="akce" value="vse">'
                  '<button class="btn primary">Odeslat všechny neodeslané (%d)</button></form>' % (app.csrf(), st["n"])) if st["n"] else ""
        return app.page("EET – evidované tržby", """%s<div class="bar"><h1>Evidované tržby (EET)</h1><div class="actions">%s
<a class="btn" href="/pokladna/eet%s">%s</a><a class="btn" href="/nastaveni/eet">Nastavení EET</a></div></div>
<p class="hint">POK = potvrzovací kód Finanční správy. Neodeslané tržby program posílá sám každou minutu;
zákon dává na dodatečné odeslání 48 hodin.</p>
<table class="list wide"><thead><tr><th>Čas tržby</th><th>Doklad</th><th>Pořadové č.</th><th class=num>Částka</th><th>Stav</th>
<th>POK / chyba</th></tr></thead><tbody>%s</tbody></table>""" % (
            flash(req), resend, "" if show else "?zobrazit=neodeslane", "Všechny" if show else "Jen neodeslané",
            "".join(trs) or '<tr><td colspan=6 class="hint">Zatím žádné tržby.</td></tr>'), "/pokladna")
