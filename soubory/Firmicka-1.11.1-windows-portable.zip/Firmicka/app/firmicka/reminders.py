"""Upomínky neuhrazených faktur: přehled dlužníků, e-mail odběrateli (3 stupně) s ISDOC v příloze,
volitelně automaticky podle počtu dní po splatnosti. Odesílá se přes SMTP firmy (nastavení)."""
import smtplib
import ssl
from datetime import date
from email.message import EmailMessage
from email.utils import formataddr, make_msgid

from . import qr
from .db import invoice_totals, today, now
from .invoices import lines_of
from .web import h, money, cz_date, flash, flash_redirect, HTTPError

LEVELS = {1: "Připomenutí platby", 2: "Upomínka", 3: "Poslední upomínka"}

TEMPLATES = {
    1: """Dobrý den,

dovolujeme si připomenout fakturu č. {number} na částku {amount}, která byla splatná {due}.
Pokud jste ji již uhradili, považujte prosím tuto zprávu za bezpředmětnou.

{payment}

S pozdravem
{firm}""",
    2: """Dobrý den,

evidujeme neuhrazenou fakturu č. {number} na částku {amount}, splatnou {due} (po splatnosti {days} dní).
Prosíme o úhradu v nejbližším možném termínu.

{payment}

S pozdravem
{firm}""",
    3: """Dobrý den,

faktura č. {number} na částku {amount}, splatná {due}, je stále neuhrazená (po splatnosti {days} dní)
i přes předchozí upomínky. Žádáme o její úhradu do 7 dnů od doručení této zprávy. V opačném případě
budeme nuceni pohledávku řešit dalšími kroky.

{payment}

S pozdravem
{firm}""",
}


def plain_date(iso):
    return "%d. %d. %s" % (int(iso[8:10]), int(iso[5:7]), iso[:4])


def overdue(db):
    """Neuhrazené faktury po splatnosti s e-mailem z adresáře a posledním stupněm upomínky."""
    out = []
    t = today()
    for inv in db.q("SELECT i.*, c.email FROM invoices i LEFT JOIN contacts c ON c.id = i.contact_id "
                    "WHERE i.status = 'vystavena' AND i.kind IN ('faktura', 'zaloha') AND i.due_date < ? ORDER BY i.due_date", (t,)):
        last = db.one("SELECT * FROM reminders WHERE invoice_id = ? ORDER BY level DESC, id DESC LIMIT 1", (inv["id"],))
        total = invoice_totals(lines_of(db, inv["id"]), inv["vat_payer"])["total"]
        if total <= 0:            # nic nám nedluží (záloha pokryla víc než fakturu)
            continue
        out.append({"inv": inv, "total": total,
                    "days": (date.today() - date.fromisoformat(inv["due_date"])).days,
                    "email": inv["email"] or "", "last": last})
    return out


def compose(s, inv, total, level):
    days = (date.today() - date.fromisoformat(inv["due_date"])).days
    pay = []
    if s["bank_account"]:
        pay.append("Platební údaje: účet %s, variabilní symbol %s, částka %s." % (s["bank_account"], inv["vs"], money(total)))
        iban = qr.cz_iban(s["bank_account"])
        if iban:
            pay.append("IBAN: %s" % iban)
    body = TEMPLATES[level].format(number=inv["number"], amount=money(total).replace(" ", " "),
                                   due=plain_date(inv["due_date"]), days=days, payment="\n".join(pay),
                                   firm="\n".join(x for x in (s["firm_name"], s["firm_phone"], s["firm_email"]) if x))
    subject = "%s – faktura %s (%s)" % (LEVELS[level], inv["number"], s["firm_name"] or "")
    return subject.strip(" ()"), body


def send_mail(s, to, subject, body, attachments=()):
    if not s["smtp_host"]:
        raise ValueError("Není nastavený odchozí e-mail (Nastavení → E-mail)")
    msg = EmailMessage()
    sender = s["smtp_from"] or s["smtp_user"]
    msg["From"] = formataddr((s["firm_name"], sender)) if s["firm_name"] else sender
    msg["To"] = to
    msg["Subject"] = subject
    msg["Message-ID"] = make_msgid(domain=sender.rsplit("@", 1)[-1] if "@" in sender else None)
    msg.set_content(body)
    for name, data, mime in attachments:
        main, sub = mime.split("/", 1)
        msg.add_attachment(data, maintype=main, subtype=sub, filename=name)
    port = int(s["smtp_port"] or 587)
    ctx = ssl.create_default_context()
    if s["smtp_security"] == "ssl":
        server = smtplib.SMTP_SSL(s["smtp_host"], port, timeout=20, context=ctx)
    else:
        server = smtplib.SMTP(s["smtp_host"], port, timeout=20)
        if s["smtp_security"] == "starttls":
            server.starttls(context=ctx)
    try:
        if s["smtp_user"]:
            server.login(s["smtp_user"], s["smtp_password"])
        server.send_message(msg)
    finally:
        try:
            server.quit()
        except Exception:
            pass


def send_reminder(db, s, inv, total, level, to, subject, body):
    from . import isdoc
    from . import pdfdoc
    lines = lines_of(db, inv["id"])
    from .mail import doc_attachments
    att = doc_attachments(db, s, inv, lines)
    send_mail(s, to, subject, body, att)
    db.run("INSERT INTO reminders(invoice_id, date, level, email, subject, created) VALUES(?,?,?,?,?,?)",
           (inv["id"], today(), level, to, subject, now()))


def auto_run(db):
    """Automatické upomínky (volá se z vlákna jednou za hodinu). Vrací počet odeslaných."""
    s = db.settings()
    if s["reminder_auto"] != "1" or not s["smtp_host"]:
        return 0
    from . import licence
    if licence.state(db)["mode"] == "readonly":   # úhrady teď nejde zapsat → neupomínat ty, kdo už zaplatili
        return 0
    try:
        steps = [int(x) for x in s["reminder_days"].split(",") if x.strip().isdigit()][:3]
    except ValueError:
        return 0
    sent = 0
    for o in overdue(db):
        if not o["email"]:
            continue
        done = o["last"]["level"] if o["last"] else 0
        if o["last"] and o["last"]["date"] == today():
            continue
        level = done + 1
        if level > len(steps) or o["days"] < steps[level - 1]:
            continue
        subject, body = compose(s, o["inv"], o["total"], level)
        try:
            send_reminder(db, s, o["inv"], o["total"], level, o["email"], subject, body)
            sent += 1
            print("Upomínka %d odeslána: %s → %s" % (level, o["inv"]["number"], o["email"]))
        except Exception as e:
            print("Upomínka %s selhala: %s" % (o["inv"]["number"], e))
            break        # nejspíš SMTP – nezkoušet další
    return sent


def register(app):
    db = app.db

    @app.route("/upominky")
    def index(req):
        s = req.settings
        rows = overdue(db)
        trs = "".join(
            "<tr><td><a href='/faktury/%d'>%s</a></td><td>%s</td><td>%s</td><td class=num>%d</td><td class=num>%s</td>"
            "<td>%s</td><td>%s</td><td><a class='btn' href='/faktury/%d/upominka'>%s</a></td></tr>" % (
                o["inv"]["id"], h(o["inv"]["number"]), h(o["inv"]["cust_name"]), cz_date(o["inv"]["due_date"]), o["days"],
                money(o["total"]), h(o["email"]) or "<span class=hint>bez e-mailu</span>",
                "%s %s" % (LEVELS[o["last"]["level"]], cz_date(o["last"]["date"])) if o["last"] else "—",
                o["inv"]["id"], "Poslat %d. stupeň" % min(3, (o["last"]["level"] if o["last"] else 0) + 1))
            for o in rows)
        total = sum(o["total"] for o in rows)
        auto = ("zapnuté (%s dní po splatnosti)" % h(s["reminder_days"])) if s["reminder_auto"] == "1" else "vypnuté"
        return app.page("Upomínky", """%s<div class="bar"><h1>Dlužníci a upomínky</h1>
<a class="btn" href="/nastaveni#email">Nastavení e-mailu</a></div>
<div class="stats"><div><span>Po splatnosti celkem</span><b class=out>%s</b><small>%d faktur</small></div>
<div><span>Automatické upomínky</span><b class=small>%s</b></div></div>
%s<table class="list"><thead><tr><th>Faktura</th><th>Odběratel</th><th>Splatnost</th><th class=num>Dní po</th>
<th class=num>Částka</th><th>E-mail</th><th>Poslední upomínka</th><th></th></tr></thead><tbody>%s</tbody></table>%s""" % (
            flash(req), money(total), len(rows), auto,
            "" if s["smtp_host"] else '<div class="flash">Pro odesílání upomínek nastavte <a href="/nastaveni#email">odchozí e-mail</a>.</div>',
            trs, "" if rows else "<p class=empty>Nikdo nedluží 👍</p>"), "/faktury")

    @app.route("/faktury/<iid>/upominka", ("GET", "POST"))
    def reminder(req, iid):
        s = req.settings
        inv = db.one("SELECT i.*, c.email FROM invoices i LEFT JOIN contacts c ON c.id = i.contact_id WHERE i.id = ?", (iid,))
        if not inv:
            raise HTTPError(404, "Faktura neexistuje")
        total = invoice_totals(lines_of(db, inv["id"]), inv["vat_payer"])["total"]
        last = db.one("SELECT MAX(level) AS l FROM reminders WHERE invoice_id = ?", (inv["id"],))["l"] or 0
        lv = req.f("level") or req.args.get("stupen") or ""
        level = int(lv) if lv in ("1", "2", "3") else min(3, last + 1)
        level = level if level in LEVELS else 1
        if req.method == "POST":
            to = req.f("to")
            if "@" not in to:
                flash_redirect("/faktury/%d/upominka" % inv["id"], "Zadejte e-mail odběratele")
            try:
                send_reminder(db, s, inv, total, level, to, req.f("subject"), req.form.get("body", ""))
            except Exception as e:
                flash_redirect("/faktury/%d/upominka?stupen=%d" % (inv["id"], level), "Odeslání selhalo: %s" % e)
            if inv["contact_id"] and not inv["email"]:
                db.run("UPDATE contacts SET email = ? WHERE id = ?", (to, inv["contact_id"]))
            flash_redirect("/upominky", "%s odesláno na %s" % (LEVELS[level], to))
        subject, body = compose(s, inv, total, level)
        sent = db.q("SELECT * FROM reminders WHERE invoice_id = ? ORDER BY id", (inv["id"],))
        hist = "".join("<li>%s – %s → %s</li>" % (cz_date(r["date"]), LEVELS[r["level"]], h(r["email"])) for r in sent)
        lsel = "".join('<option value="%d"%s>%s</option>' % (k, " selected" if k == level else "", v) for k, v in LEVELS.items())
        return app.page("Upomínka", """%s<div class="bar"><a href="/upominky">← Dlužníci</a></div>
<h1>%s – faktura %s</h1>%s
<form method="post" class="grid">%s
<label>Stupeň<select name="level" onchange="location='?stupen='+this.value">%s</select></label>
<label class="wide">Komu<input name="to" type="email" value="%s" required></label>
<label class="wide">Předmět<input name="subject" value="%s"></label>
<label class="wide">Text<textarea name="body" rows="14">%s</textarea></label>
<p class="wide hint">V příloze se pošle faktura v PDF a ve formátu ISDOC.</p>
<div class="actions wide"><button class="btn primary"%s>Odeslat</button></div></form>""" % (
            flash(req), LEVELS[level], h(inv["number"]), "<ul class=hint>%s</ul>" % hist if hist else "", app.csrf(), lsel,
            h(inv["email"]), h(subject), h(body), "" if s["smtp_host"] else " disabled title='Nastavte e-mail'"), "/faktury")

    @app.route("/nastaveni/email", ("POST",))
    def email_settings(req):
        vals = {k: req.f(k) for k in ("smtp_host", "smtp_port", "smtp_security", "smtp_user", "smtp_from", "reminder_days")}
        if req.form.get("smtp_password"):
            vals["smtp_password"] = req.form["smtp_password"]
        vals["reminder_auto"] = "1" if req.f("reminder_auto") else "0"
        if vals["smtp_security"] not in ("starttls", "ssl", "none"):
            vals["smtp_security"] = "starttls"
        db.set_settings(vals)
        if req.f("test"):
            s = db.settings()
            try:
                send_mail(s, req.f("test"), "Firmička – zkušební e-mail", "Odesílání e-mailů z Firmičky funguje.")
            except Exception as e:
                flash_redirect("/nastaveni#email", "Uloženo, ale zkušební e-mail selhal: %s" % e)
            flash_redirect("/nastaveni#email", "Uloženo a zkušební e-mail odeslán na %s" % req.f("test"))
        flash_redirect("/nastaveni#email", "Nastavení e-mailu uloženo")


def settings_form(app, s):
    sec = "".join('<option value="%s"%s>%s</option>' % (k, " selected" if s["smtp_security"] == k else "", v)
                  for k, v in (("starttls", "STARTTLS (port 587)"), ("ssl", "SSL/TLS (port 465)"), ("none", "bez šifrování")))
    return """<section class="card" id="email"><h2>E-mail (upomínky)</h2>
<form method="post" action="/nastaveni/email" class="grid">%s
<label>SMTP server<input name="smtp_host" value="%s" placeholder="smtp.seznam.cz"></label>
<label>Port<input name="smtp_port" value="%s" inputmode="numeric"></label>
<label>Zabezpečení<select name="smtp_security">%s</select></label>
<label>Uživatel<input name="smtp_user" value="%s" autocomplete="off"></label>
<label>Heslo<input type="password" name="smtp_password" placeholder="%s" autocomplete="new-password"></label>
<label>Odesílatel<input name="smtp_from" value="%s" placeholder="faktury@firma.cz"></label>
<label class="check wide"><input type="checkbox" name="reminder_auto" value="1"%s> Posílat upomínky automaticky</label>
<label>Dní po splatnosti (1., 2., 3. stupeň)<input name="reminder_days" value="%s"></label>
<label>Zkušební e-mail na<input name="test" type="email" placeholder="nepovinné"></label>
<div class="actions wide"><button class="btn">Uložit e-mail</button></div></form></section>""" % (
        app.csrf(), h(s["smtp_host"]), h(s["smtp_port"]), sec, h(s["smtp_user"]),
        "ponechat uložené" if s["smtp_password"] else "", h(s["smtp_from"]),
        " checked" if s["reminder_auto"] == "1" else "", h(s["reminder_days"]))
