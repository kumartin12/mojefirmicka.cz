"""Vydané faktury: číselná řada, položky ze skladu nebo volný text, DPH (plátce/neplátce),
tisk/PDF přes prohlížeč, QR platba. Faktura odepisuje sklad, úhrada se zapíše do peněžního deníku."""
import json
import time
from datetime import date, timedelta

from . import images, qr, eet
from .contacts import address as contact_address
from .docs import auto_number, auto_number_input, page_numbers_css
from .db import rnd, invoice_totals, next_invoice_number, item_costs, line_fee, today, now, VAT_RATES, service_ids, warranty_text
from .stock import items_json, item_options
from .warehouses import wh_select, read_wh, default_wh
from .web import h, money, qty, parse_money, parse_qty, parse_vat, parse_id, cz_date, flash, flash_redirect, HTTPError, Response

PAYMENTS = {"prevod": "Převodem", "hotove": "Hotově", "karta": "Kartou", "dobirka": "Dobírkou"}
STATUS = {"vystavena": "Neuhrazená", "zaplacena": "Uhrazená", "stornovana": "Stornovaná"}
# druhy vydaných dokladů; ddkpp = daňový doklad k přijaté platbě (záloze), vzniká sám při úhradě zálohy plátcem DPH
KINDS = {"faktura": "Faktura", "dobropis": "Dobropis", "zaloha": "Zálohová faktura", "ddkpp": "Daňový doklad k platbě"}
FORMATS = {"faktura": "invoice_format", "dobropis": "credit_format", "zaloha": "advance_format", "ddkpp": "ddkpp_format"}
PAYABLE = ("faktura", "zaloha")          # co se platí nám (upomínky, QR platba, párování příjmů)


def kind_of(inv):
    return inv["kind"] if "kind" in inv.keys() and inv["kind"] else "faktura"


def doc_name(inv, long=False):
    """Název dokladu pro nadpis / PDF / e-mail."""
    k, vp = kind_of(inv), bool(inv["vat_payer"])
    if k == "dobropis":
        return "Opravný daňový doklad" if vp and long else "Dobropis"
    if k == "ddkpp":
        return "Daňový doklad k přijaté platbě" if long else "Daňový doklad k platbě"
    return KINDS[k]


def doc_subtitle(inv):
    k, vp = kind_of(inv), bool(inv["vat_payer"])
    return {"faktura": "daňový doklad" if vp else "", "dobropis": "dobropis" if vp else "opravný doklad",
            "zaloha": "není daňovým dokladem", "ddkpp": "daňový doklad"}[k]


def line_warranty(db, ln):
    """Záruka řádku do editoru: uložená na faktuře, jinak (zakázka, nabídka) aktuální podle položky."""
    row = db.one("SELECT warranty, service FROM items WHERE id = ?", (ln["item_id"],)) if ln.get("item_id") else None
    if row and row["service"]:
        return 0
    if "warranty" in ln.keys():
        return ln["warranty"] or 0
    return row["warranty"] if row else 0


def lines_of(db, iid):
    return db.q("SELECT * FROM invoice_lines WHERE invoice_id = ? ORDER BY pos", (iid,))


def references(db, inv):
    """Text o návaznosti dokladu (k jaké faktuře / záloze se vztahuje)."""
    k = kind_of(inv)
    ref = db.one("SELECT * FROM invoices WHERE id = ?", (inv["ref_id"],)) if inv["ref_id"] else None
    out = []
    if k == "dobropis" and ref:
        out.append("Opravuje fakturu č. %s ze dne %s (DUZP %s)." % (ref["number"], _d(ref["issue_date"]), _d(ref["tax_date"])))
    if k == "dobropis" and inv["reason"]:
        out.append("Důvod opravy: %s" % inv["reason"])
    if k == "ddkpp" and ref:
        out.append("K zálohové faktuře č. %s, platba přijata %s." % (ref["number"], _d(inv["tax_date"])))
    if k == "zaloha":
        out.append("Zálohová faktura není daňovým dokladem. Po úhradě obdržíte daňový doklad, záloha se odečte "
                   "na konečné faktuře." if inv["vat_payer"] else "Záloha se odečte na konečné faktuře.")
    return out


def _d(iso):
    return "%d. %d. %s" % (int(iso[8:10]), int(iso[5:7]), iso[:4]) if iso and len(iso) == 10 else ""


def default_vs(db, inv):
    """Variabilní symbol, když ho uživatel nevyplní: číslice čísla dokladu; záloha s 9 na začátku (ať se v bance
    neplete s fakturou stejného pořadí), dobropis přebírá VS opravované faktury."""
    digits = "".join(c for c in inv["number"] if c.isdigit())
    k = inv.get("kind", "faktura")
    if k == "dobropis" and inv.get("ref_id"):
        r = db.one("SELECT vs FROM invoices WHERE id = ?", (inv["ref_id"],))
        if r and r["vs"]:
            return r["vs"]
    if k == "zaloha":
        return "9" + digits[-9:]
    return digits[-10:]          # VS má nejvýš 10 číslic (víc banka ani QR platba nepřenese)


def total_label(inv, total):
    k = kind_of(inv)
    if k == "dobropis" or total < 0:
        return "K vrácení"
    if k == "ddkpp":
        return "Přijatá platba"
    return "Celkem k úhradě" if total else "Uhrazeno zálohou"


def unsettled_advances(db):
    """Uhrazené zálohové faktury, které ještě nejsou odečtené na žádné (nestornované) faktuře."""
    return db.q("SELECT * FROM invoices z WHERE kind = 'zaloha' AND status = 'zaplacena' AND NOT EXISTS ("
                "SELECT 1 FROM invoice_lines l JOIN invoices f ON f.id = l.invoice_id "
                "WHERE l.advance_id = z.id AND f.status != 'stornovana') ORDER BY issue_date, id")


def advance_lines(db, z):
    """Řádky „odpočet zálohy“ pro konečnou fakturu – po sazbách DPH z daňového dokladu k platbě
    (plátce), jinak celou částkou."""
    dd = db.one("SELECT * FROM invoices WHERE kind = 'ddkpp' AND ref_id = ? AND status != 'stornovana' "
                "ORDER BY id DESC", (z["id"],))
    src = dd or z
    t = invoice_totals(lines_of(db, src["id"]), src["vat_payer"])
    text = "Odpočet zálohy %s%s" % (z["number"], " (daňový doklad %s)" % dd["number"] if dd else "")
    return [{"item_id": None, "text": text, "qty": -1, "unit": "", "price": r["base"], "vat_rate": r["rate"],
             "recycling_fee": 0, "advance_id": z["id"]} for r in t["recap"]]


def sync_side_effects(db, inv_id):
    """Pohyby skladu a zápis v deníku podle aktuálního stavu dokladu (volat uvnitř transakce)."""
    inv = db.one("SELECT * FROM invoices WHERE id = ?", (inv_id,))
    db.run("DELETE FROM movements WHERE invoice_id = ?", (inv_id,))
    db.run("DELETE FROM cashbook WHERE invoice_id = ?", (inv_id,))
    if inv["status"] == "stornovana":
        return
    k = kind_of(inv)
    if k == "faktura" or k == "dobropis" and inv["stock"]:
        svc = service_ids(db)
        for ln in lines_of(db, inv_id):
            if ln["item_id"] and ln["item_id"] not in svc:      # dobropis: záporné množství = zboží zpět na sklad (za cenu, za kterou odešlo)
                db.run("INSERT INTO movements(item_id, date, qty, kind, doc, invoice_id, warehouse_id, unit_cost) "
                       "VALUES(?,?,?,?,?,?,?,?)", (ln["item_id"], inv["tax_date"], -ln["qty"], k, inv["number"], inv_id,
                                                   inv["warehouse_id"], ln["cost"] if k == "dobropis" else 0))
    if inv["status"] == "zaplacena" and k != "ddkpp":      # ddkpp jen daní zálohu, peníze přišly na zálohovou fakturu
        total = invoice_totals(lines_of(db, inv_id), inv["vat_payer"])["total"]
        if total:
            text = {"faktura": "Úhrada faktury", "zaloha": "Úhrada zálohové faktury",
                    "dobropis": "Vrácení peněz – dobropis"}[k]
            db.run("INSERT INTO cashbook(date, doc, text, direction, account, amount, taxable, category, invoice_id) "
                   "VALUES(?,?,?,?,?,?,1,?,?)",
                   (inv["paid_date"] or today(), inv["number"], "%s %s – %s" % (text, inv["number"], inv["cust_name"]),
                    "prijem" if total > 0 else "vydaj", "pokladna" if inv["payment"] == "hotove" else "banka", abs(total),
                    "Tržby" if total > 0 else "Vrácení tržby", inv_id))


def eet_reconcile(db, s, inv_id, action=""):
    """Faktura zaplacená při osobním kontaktu (hotově / kartou) je evidovaná tržba; zrušení úhrady nebo storno
    pošle zápornou opravu. Úhrada spárovaná z bankovního výpisu se neeviduje (není to kontaktní platba)."""
    inv = db.one("SELECT * FROM invoices WHERE id = ?", (inv_id,))
    k = kind_of(inv)
    target = 0
    if inv["status"] == "zaplacena" and k != "ddkpp" and inv["payment"] in eet.CONTACT_PAY:
        target = invoice_totals(lines_of(db, inv_id), inv["vat_payer"])["total"]
    when = None
    if action == "zaplaceno" and inv["paid_date"] and inv["paid_date"] < today():
        when = time.mktime(time.strptime(inv["paid_date"] + " 12:00", "%Y-%m-%d %H:%M"))   # zaplaceno dřív
    return eet.reconcile(db, s, "invoice", inv_id, inv["number"], target, inv["warehouse_id"], when)


def after_status(db, settings, inv_id):
    """Zálohová faktura plátce DPH: po úhradě vznikne daňový doklad k přijaté platbě, po zrušení úhrady
    nebo stornu se stornuje (volat uvnitř transakce, po změně stavu)."""
    z = db.one("SELECT * FROM invoices WHERE id = ?", (inv_id,))
    if kind_of(z) != "zaloha" or not z["vat_payer"]:
        return
    dd = db.one("SELECT * FROM invoices WHERE kind = 'ddkpp' AND ref_id = ? AND status != 'stornovana'", (z["id"],))
    if z["status"] == "zaplacena" and not dd:
        day = z["paid_date"] or today()
        number = next_invoice_number(db, day, settings["ddkpp_format"] or "DD{YYYY}{NNNN}")
        did = db.run("INSERT INTO invoices(kind, ref_id, contact_id, number, cust_name, cust_address, cust_ico, cust_dic, "
                     "issue_date, tax_date, due_date, payment, vs, note, warehouse_id, vat_payer, status, paid_date, created) "
                     "VALUES('ddkpp',?,?,?,?,?,?,?,?,?,?,?,?,?,?,1,'zaplacena',?,?)",
                     (z["id"], z["contact_id"], number, z["cust_name"], z["cust_address"], z["cust_ico"], z["cust_dic"],
                      day, day, day, z["payment"], z["vs"], "", z["warehouse_id"], day, now()))
        for ln in lines_of(db, z["id"]):
            db.run("INSERT INTO invoice_lines(invoice_id, pos, item_id, text, qty, unit, price, vat_rate, recycling_fee, cost) "
                   "VALUES(?,?,NULL,?,?,?,?,?,?,0)", (did, ln["pos"], ln["text"], ln["qty"], ln["unit"], ln["price"],
                                                      ln["vat_rate"], line_fee(ln)))
    elif z["status"] != "zaplacena" and dd:
        db.run("UPDATE invoices SET status = 'stornovana' WHERE id = ?", (dd["id"],))


def register(app):
    db = app.db

    @app.route("/faktury")
    def index(req):
        year = req.args.get("rok", "")
        year = year if year.isdigit() and len(year) == 4 else today()[:4]
        st = req.args.get("stav", "")
        kd = req.args.get("druh", "")
        sql, args = "SELECT * FROM invoices WHERE substr(issue_date, 1, 4) = ?", [year]
        if st:
            sql += " AND status = ?"
            args.append(st)
        if kd in KINDS:
            sql += " AND kind = ?"
            args.append(kd)
        rows = db.q(sql + " ORDER BY issue_date DESC, number DESC", args)
        trs, sums = [], {"vystavena": 0, "zaplacena": 0}
        for r in rows:
            t = invoice_totals(lines_of(db, r["id"]), r["vat_payer"])["total"]
            if r["status"] in sums:
                sums[r["status"]] += t
            k = kind_of(r)
            refund = k == "dobropis" or t < 0
            overdue = r["status"] == "vystavena" and r["due_date"] < today() and k in PAYABLE and t > 0
            st_txt = "Po splatnosti" if overdue else ("K vrácení" if refund and r["status"] == "vystavena" else
                                                       "Vráceno" if refund and r["status"] == "zaplacena" else
                                                       STATUS[r["status"]])
            trs.append("<tr%s><td><a href='/faktury/%d'>%s</a>%s</td><td>%s</td><td>%s</td><td>%s</td>"
                       "<td class=num>%s</td><td><span class='tag %s'>%s</span></td></tr>" % (
                           " class=warn" if overdue else "", r["id"], h(r["number"]),
                           "" if k == "faktura" else " <span class='tag kind'>%s</span>" % KINDS[k], h(r["cust_name"]),
                           cz_date(r["issue_date"]), cz_date(r["due_date"]) if k != "ddkpp" else "", money(t), r["status"],
                           st_txt))
        years = sorted({r["y"] for r in db.q("SELECT DISTINCT substr(issue_date,1,4) AS y FROM invoices")} | {today()[:4]},
                       reverse=True)
        ysel = "".join('<option%s>%s</option>' % (" selected" if y == year else "", y) for y in years)
        ssel = "".join('<option value="%s"%s>%s</option>' % (k, " selected" if k == st else "", v)
                       for k, v in [("", "Všechny")] + list(STATUS.items()))
        ksel = "".join('<option value="%s"%s>%s</option>' % (k, " selected" if k == kd else "", v)
                       for k, v in [("", "Všechny doklady")] + list(KINDS.items()))
        return app.page("Faktury", """%s<div class="bar"><h1>Faktury</h1>
<a class="btn" href="/export">Export pro účetní</a><a class="btn" href="/upominky">Dlužníci a upomínky</a><a class="btn" href="/faktury/nova?druh=zaloha">+ Zálohová faktura</a><a class="btn primary" href="/faktury/nova">+ Nová faktura</a></div>
<form class="filters"><select name="rok" onchange="this.form.submit()">%s</select>
<select name="stav" onchange="this.form.submit()">%s</select><select name="druh" onchange="this.form.submit()">%s</select>
<a class="btn" href="/export/faktury.csv?rok=%s">Export CSV</a></form>
<div class="stats"><div><span>Neuhrazeno</span><b>%s</b></div><div><span>Uhrazeno</span><b>%s</b></div></div>
<table class="list"><thead><tr><th>Číslo</th><th>Odběratel</th><th>Vystaveno</th><th>Splatnost</th>
<th class=num>Celkem</th><th>Stav</th></tr></thead><tbody>%s</tbody></table>%s""" % (
            flash(req), ysel, ssel, ksel, h(year), money(sums["vystavena"]), money(sums["zaplacena"]), "".join(trs),
            "" if rows else "<p class=empty>V tomto roce zatím žádné faktury.</p>"), "/faktury")

    # ---------- formulář ----------
    def form(req, inv, lines, iid=None, err=""):
        s = req.settings
        vat_payer = (inv.get("vat_payer") if iid else s["vat_payer"] == "1")
        k = inv.get("kind") or "faktura"
        fixed = [ln for ln in lines if ln.get("advance_id")]          # odpočty záloh se v editoru nemění
        lines = [dict(ln, qty=-ln["qty"]) if k == "dobropis" else ln for ln in lines if not ln.get("advance_id")]
        ref = db.one("SELECT * FROM invoices WHERE id = ?", (inv.get("ref_id"),)) if inv.get("ref_id") else None
        extra = ""
        if k == "dobropis":
            extra = """<section class="card wide"><h2>Dobropis k faktuře %s</h2><div class="grid">
<label class="wide">Důvod opravy<input name="reason" value="%s" required placeholder="např. vrácení zboží, reklamace, sleva"></label>
<label class="check wide"><input type="checkbox" name="stock" value="1"%s> Vrátit zboží ze skladových položek na sklad</label>
<p class="wide hint">Uveďte kladná množství toho, co se vrací nebo dobropisuje – na dokladu budou se znaménkem minus.
Slevu zadejte jako řádek „Sleva“ s částkou.</p></div></section>""" % (
                h(ref["number"]) if ref else "", h(inv.get("reason")), " checked" if inv.get("stock", 1) else "")
        elif k == "faktura" and not iid:
            adv = unsettled_advances(db)
            pre = {str(x) for x in inv.get("advances", [])}
            if adv:
                extra = '<section class="card wide"><h2>Odečíst uhrazenou zálohu</h2>%s<p class="hint">Záloha se odečte ' \
                        'při uložení (po sazbách DPH z daňového dokladu k platbě).</p></section>' % "".join(
                            '<label class="check"><input type="checkbox" name="advance" value="%d"%s> %s – %s – %s</label>' % (
                                z["id"], " checked" if str(z["id"]) in pre else "", h(z["number"]), h(z["cust_name"]),
                                money(invoice_totals(lines_of(db, z["id"]), z["vat_payer"])["total"])) for z in adv)
        if fixed:
            extra += '<section class="card wide"><h2>Odečtené zálohy</h2>%s</section>' % "".join(
                "<div>%s: %s</div>" % (h(ln["text"]), money(rnd(ln["qty"] * ln["price"]))) for ln in fixed)
        items = db.q("SELECT * FROM items WHERE active = 1 ORDER BY name COLLATE NOCASE")
        items_js = json.dumps(items_json(db, with_cost=False), ensure_ascii=False)
        contacts = db.q("SELECT * FROM contacts ORDER BY name COLLATE NOCASE")
        contacts_js = json.dumps({str(c["id"]): {"name": c["name"], "ico": c["ico"], "dic": c["dic"],
                                                 "address": contact_address(c)} for c in contacts}, ensure_ascii=False)
        copts = '<option value="">— vybrat z adresáře —</option>' + "".join(
            '<option value="%d"%s>%s</option>' % (c["id"], " selected" if str(c["id"]) == str(inv.get("contact_id") or "") else "",
                                                  h(c["name"])) for c in contacts)
        iopts = item_options(items)
        pay = "".join('<option value="%s"%s>%s</option>' % (k, " selected" if k == inv.get("payment", "prevod") else "", v)
                      for k, v in PAYMENTS.items())
        vat_opts = "".join('<option value="%d">%d %%</option>' % (v, v) for v in VAT_RATES)
        rows = json.dumps([{"item": ln.get("item_id") or "", "text": ln["text"], "qty": ln["qty"], "unit": ln["unit"],
                            "price": ln["price"], "vat": ln["vat_rate"], "fee": line_fee(ln),
                            "warranty": line_warranty(db, ln)} for ln in lines],
                          ensure_ascii=False)
        return app.page(KINDS[k], """<h1>%s</h1>%s
<form method="post" id="invoice" data-vat="%d"%s>%s
<input type="hidden" name="src_quote" value="%s"><input type="hidden" name="src_job" value="%s">
<input type="hidden" name="kind" value="%s"><input type="hidden" name="ref_id" value="%s">
<div class="grid">
<section class="card wide"><h2>Odběratel</h2><div class="grid">
<label class="wide">Z adresáře<select name="contact_id" data-contacts='%s'>%s</select></label>
<label class="wide">Název / jméno<input name="cust_name" value="%s" required></label>
<label>IČO<span class="row"><input name="cust_ico" value="%s"><button type="button" class="btn" data-ares-inv>ARES</button></span></label>
<label>DIČ<input name="cust_dic" value="%s"></label>
<label class="wide">Adresa<textarea name="cust_address" rows="3">%s</textarea></label>
<label class="check wide"><input type="checkbox" name="save_contact" value="1"> Uložit / aktualizovat v adresáři</label>
</div></section>
<label>Číslo dokladu<input name="number" value="%s" required>%s</label>
<label>Variabilní symbol<input name="vs" value="%s" placeholder="doplní se samo z čísla dokladu" inputmode="numeric" pattern="[0-9]{1,10}" maxlength="10" title="jen číslice, nejvýš 10"></label>
<label>Datum vystavení<input type="date" name="issue_date" value="%s" required></label>
<label%s>Datum zdan. plnění<input type="date" name="tax_date" value="%s"></label>
<label>Splatnost<input type="date" name="due_date" value="%s" required></label>
<label>Způsob platby<select name="payment">%s</select></label>
%s
</div>%s
<h2>Položky</h2>
<div class="filters"><input id="scan" placeholder="Pípněte EAN – přidá položku" data-scan inputmode="numeric">
<span class="hint" id="scan-msg"></span></div>
<table class="lines"><thead><tr><th>Položka</th><th>Popis</th><th class=num>Množství</th><th>Jedn.</th>
<th class=num>Cena/j. %s</th><th class=num title="recyklační poplatek za jednotku">Rec. popl./j.</th><th%s>DPH</th>
<th class=num>Celkem</th><th></th></tr></thead>
<tbody id="lines" data-items='%s' data-rows='%s'></tbody></table>
<template id="line-tpl"><tr>
<td><select name="line_item">%s</select></td><td><input name="line_text"><input type="hidden" name="line_warranty">
<small class="hint warranty"></small></td>
<td><input name="line_qty" class=num inputmode="decimal" value="1"></td><td><input name="line_unit" value="ks" size="4"></td>
<td><input name="line_price" class=num inputmode="decimal"></td>
<td><input name="line_fee" class=num inputmode="decimal" placeholder="0"></td><td%s><select name="line_vat">%s</select></td>
<td class="num line-total"></td><td><button type="button" class="link danger" data-del>✕</button></td></tr></template>
<p><button type="button" class="btn" id="add-line">+ Přidat řádek</button> <span class="hint" id="stock-warn"></span></p>
<div class="totals" id="totals"></div>
<label class="wide">Poznámka na faktuře<textarea name="note" rows="2">%s</textarea></label>
<div class="actions"><button class="btn primary">Uložit</button><a class="btn" href="%s">Zrušit</a></div>
</form>""" % (
            "Upravit – %s %s" % (KINDS[k].lower(), h(inv["number"])) if iid else
            {"faktura": "Nová faktura", "dobropis": "Nový dobropis", "zaloha": "Nová zálohová faktura"}.get(k, KINDS[k]),
            '<div class="flash error">%s</div>' % h(err) if err else "",
            1 if vat_payer else 0, ' data-sale="1"' if k == "faktura" else "", app.csrf(),
            h(inv.get("src_quote") or ""), h(inv.get("src_job") or ""), k, h(inv.get("ref_id") or ""), h(contacts_js), copts, h(inv.get("cust_name")), h(inv.get("cust_ico")),
            h(inv.get("cust_dic")), h(inv.get("cust_address")), h(inv["number"]),
            "" if iid else auto_number_input(inv, series=k), h(inv.get("vs")),
            h(inv["issue_date"]), "" if vat_payer and k != "zaloha" else " hidden", h(inv["tax_date"]), h(inv["due_date"]), pay,
            "" if k == "zaloha" else wh_select(db, inv.get("warehouse_id") or default_wh(db, req),
                                                label="Vrátit na sklad" if k == "dobropis" else "Odepsat ze skladu"),
            extra,
            "bez DPH" if vat_payer else "", "" if vat_payer else " hidden", h(items_js), h(rows), iopts,
            "" if vat_payer else " hidden", vat_opts, h(inv.get("note")),
            "/faktury/%s" % iid if iid else "/faktury"), "/faktury")

    def read_form(req, vat_payer, fallback=None):
        inv = {k: req.f(k) for k in ("number", "vs", "issue_date", "tax_date", "due_date", "payment", "note",
                                     "cust_name", "cust_ico", "cust_dic", "cust_address", "contact_id", "reason")}
        inv["kind"] = req.f("kind") if req.f("kind") in ("faktura", "dobropis", "zaloha") else "faktura"
        inv["ref_id"] = parse_id(req.f("ref_id")) if inv["kind"] == "dobropis" else None
        inv["stock"] = 1 if req.f("stock") else 0
        inv["advances"] = [int(x) for x in req.lst("advance") if x.isdigit()]
        inv["cust_address"] = req.form.get("cust_address", "").strip()
        inv["note"] = req.form.get("note", "").strip()
        if not inv["tax_date"] or inv["kind"] == "zaloha":
            inv["tax_date"] = inv["issue_date"]
        if inv["payment"] not in PAYMENTS:
            inv["payment"] = "prevod"
        inv["warehouse_id"] = read_wh(db, req, fallback)
        cols = [req.lst(k) for k in ("line_item", "line_text", "line_qty", "line_unit", "line_price", "line_vat")]
        fees = req.lst("line_fee")
        cols.append(fees + [""] * (len(cols[0]) - len(fees)))
        wars = req.lst("line_warranty")
        cols.append(wars + [None] * (len(cols[0]) - len(wars)))
        lines = []
        for it, text, q, unit, price, vat, fee, war in zip(*cols):
            if not text.strip() and not it:
                continue
            iid_ = parse_id(it)
            row = db.one("SELECT warranty, service FROM items WHERE id = ?", (iid_,)) if iid_ else None
            if war is None:                 # formulář bez pole záruky → podle položky
                war = row["warranty"] if row else 0
            if row and row["service"]:      # služba / práce záruku nemá
                war = 0
            war = str(war).strip()
            lines.append({"item_id": iid_, "text": text.strip(),
                          "qty": parse_qty(q), "unit": unit.strip() or "ks", "price": parse_money(price),
                          "vat_rate": parse_vat(vat, vat_payer), "recycling_fee": parse_money(fee),
                          "warranty": int(war) if war.isdigit() and int(war) <= 600 else 0})
        from .docs import check_items
        check_items(db, lines)
        if inv["kind"] == "dobropis":          # v editoru kladně, na dokladu záporně
            lines = [dict(ln, qty=-ln["qty"]) for ln in lines]
        return inv, lines

    def validate(inv, lines, iid=None):
        if not inv["cust_name"]:
            return "Vyplňte odběratele"
        if not inv["number"]:
            return "Vyplňte číslo dokladu"
        if inv["vs"] and not (inv["vs"].isdigit() and len(inv["vs"]) <= 10):
            return "Variabilní symbol může mít jen číslice, nejvýš 10 (jinak ho banka ani QR platba nepřenese)"
        if not lines:
            return "Doklad musí mít aspoň jednu položku"
        if inv["kind"] == "dobropis" and not inv["reason"]:
            return "Uveďte důvod opravy"
        if inv["kind"] == "dobropis" and inv.get("ref_id"):
            err = credit_limit(inv["ref_id"], lines, iid)
            if err:
                return err
        if any(ln["qty"] == 0 for ln in lines):
            return "Množství nesmí být 0"
        dup = db.one("SELECT id FROM invoices WHERE number = ? AND id != ?", (inv["number"], iid or 0))
        if dup:
            return "Doklad s číslem %s už existuje" % inv["number"]
        free = {z["id"] for z in unsettled_advances(db)}
        if any(a not in free for a in inv.get("advances", [])):
            return "Zálohu už nejde odečíst (není uhrazená nebo je odečtená jinde)"
        for k in ("issue_date", "tax_date", "due_date"):
            try:
                date.fromisoformat(inv[k])
            except ValueError:
                return "Neplatné datum"
        return ""

    def credit_limit(ref_id, lines, iid=None):
        """Dobropisy k faktuře (včetně tohoto) nesmí vrátit víc zboží ani peněz, než faktura obsahovala."""
        ref = db.one("SELECT * FROM invoices WHERE id = ?", (ref_id,))
        if not ref or kind_of(ref) != "faktura":
            raise HTTPError(400, "Dobropis jde vystavit jen k faktuře")
        others = db.q("SELECT id FROM invoices WHERE kind = 'dobropis' AND ref_id = ? AND status != 'stornovana' AND id != ?",
                      (ref_id, iid or 0))
        sold, back = {}, {}
        for ln in lines_of(db, ref_id):
            if ln["item_id"]:
                sold[ln["item_id"]] = sold.get(ln["item_id"], 0) + ln["qty"]
        prev = [dict(ln) for o in others for ln in lines_of(db, o["id"])]
        for ln in prev + [dict(x) for x in lines]:
            if ln.get("item_id"):
                back[ln["item_id"]] = back.get(ln["item_id"], 0) - ln["qty"]
        for item, q in back.items():
            if q > sold.get(item, 0) + 1e-9:
                name = db.one("SELECT name FROM items WHERE id = ?", (item,))
                return "Dobropis vrací víc „%s“ (%s), než bylo na faktuře (%s)%s" % (
                    name["name"] if name else item, qty(q), qty(sold.get(item, 0)),
                    " včetně dřívějších dobropisů" if prev else "")
        total = invoice_totals(lines_of(db, ref_id), ref["vat_payer"])["total"]
        credited = sum(invoice_totals(lines_of(db, o["id"]), ref["vat_payer"])["total"] for o in others) + \
            invoice_totals(lines, ref["vat_payer"])["total"]
        if -credited > total:
            return "Dobropisy by dohromady vrátily %s, faktura je jen na %s" % (money(-credited), money(total))
        return ""

    def save(inv, lines, vat_payer, iid=None):
        with db.tx():
            cid = inv["contact_id"] if inv["contact_id"].isdigit() else None
            if inv.get("save_contact") and not cid:
                from .docs import find_by_ico
                cid = find_by_ico(db, inv["cust_ico"])    # stejné IČO = stejný zákazník, ne nový kontakt
            if inv.get("save_contact"):
                street, _, rest = inv["cust_address"].partition("\n")
                zip_, _, city = rest.split("\n")[0].strip().partition(" ")
                vals = (inv["cust_name"], inv["cust_ico"], inv["cust_dic"], street.strip(), city.strip(), zip_)
                if cid:
                    db.run("UPDATE contacts SET name=?, ico=?, dic=?, street=?, city=?, zip=? WHERE id=?", vals + (cid,))
                else:
                    cid = db.run("INSERT INTO contacts(name, ico, dic, street, city, zip) VALUES(?,?,?,?,?,?)", vals)
            vs = inv["vs"] or default_vs(db, inv)
            cols = (cid, inv["number"], inv["cust_name"], inv["cust_address"], inv["cust_ico"], inv["cust_dic"],
                    inv["issue_date"], inv["tax_date"], inv["due_date"], inv["payment"], vs, inv["note"], inv["warehouse_id"],
                    inv.get("reason", ""), inv.get("stock", 1))
            if iid:
                db.run("UPDATE invoices SET contact_id=?, number=?, cust_name=?, cust_address=?, cust_ico=?, cust_dic=?, "
                       "issue_date=?, tax_date=?, due_date=?, payment=?, vs=?, note=?, warehouse_id=?, reason=?, stock=? "
                       "WHERE id=?", cols + (iid,))
                db.run("DELETE FROM invoice_lines WHERE invoice_id = ? AND advance_id IS NULL", (iid,))
            else:
                iid = db.run("INSERT INTO invoices(contact_id, number, cust_name, cust_address, cust_ico, cust_dic, "
                             "issue_date, tax_date, due_date, payment, vs, note, warehouse_id, reason, stock, kind, ref_id, "
                             "vat_payer, created) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                             cols + (inv.get("kind", "faktura"), inv.get("ref_id"), 1 if vat_payer else 0, now()))
                for aid in inv.get("advances", []):
                    z = db.one("SELECT * FROM invoices WHERE id = ?", (aid,))
                    lines = lines + advance_lines(db, z)
            costs = item_costs(db)
            orig = {}
            if inv.get("kind") == "dobropis" and inv.get("ref_id"):      # vrácené zboží za cenu, za kterou odešlo
                orig = {ln["item_id"]: ln["cost"] for ln in lines_of(db, inv["ref_id"]) if ln["item_id"]}
            for pos, ln in enumerate(lines):
                # nákupní cena v okamžiku prodeje → marže zůstane správná i po dalších nákupech
                cost = orig.get(ln["item_id"]) or costs.get(ln["item_id"], (0, 0))[1] if ln["item_id"] else 0
                db.run("INSERT INTO invoice_lines(invoice_id, pos, item_id, text, qty, unit, price, vat_rate, "
                       "recycling_fee, cost, advance_id, warranty) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                       (iid, pos + (1000 if ln.get("advance_id") else 0), ln["item_id"], ln["text"], ln["qty"], ln["unit"],
                        ln["price"], ln["vat_rate"], ln.get("recycling_fee", 0), cost, ln.get("advance_id"),
                        0 if inv.get("kind", "faktura") != "faktura" else ln.get("warranty", 0)))
            # konečná faktura plně uhrazená zálohou (je-li záloha vyšší, zůstává „k vrácení“ – vrácení potvrdí uživatel)
            if inv.get("advances") and invoice_totals(lines_of(db, iid), vat_payer)["total"] == 0:
                db.run("UPDATE invoices SET status = 'zaplacena', paid_date = issue_date WHERE id = ? AND status = 'vystavena'",
                       (iid,))
            sync_side_effects(db, iid)
        return iid

    @app.route("/faktury/cislo")
    def number_for_date(req):
        """Navržené číslo dokladu pro datum vystavení (formulář ho přepočítá při změně roku)."""
        k = req.args.get("druh") if req.args.get("druh") in ("faktura", "dobropis", "zaloha") else "faktura"
        try:
            d = date.fromisoformat(req.args.get("datum", "")).isoformat()
        except ValueError:
            raise HTTPError(400)
        return Response(next_invoice_number(db, d, req.settings[FORMATS[k]] or "{YYYY}{NNNN}"), ctype="text/plain; charset=utf-8")

    @app.route("/faktury/nova", ("GET", "POST"))
    def new(req):
        s = req.settings
        vat_payer = s["vat_payer"] == "1"
        if req.method == "POST":
            inv, lines = read_form(req, vat_payer)
            inv["save_contact"] = req.f("save_contact")
            inv["src_quote"], inv["src_job"] = req.f("src_quote"), req.f("src_job")
            with db.lock:   # kontrola čísla/zálohy a zápis naráz (souběh více uživatelů)
                inv["number"], num_msg = auto_number(db, req, inv["number"], inv["issue_date"],
                                                     s[FORMATS[inv["kind"]]] or "{YYYY}{NNNN}", "invoices")
                inv["number_auto"] = inv["number"] if num_msg else req.f("number_auto")
                err = validate(inv, lines)
                if err:
                    return form(req, inv, [dict(ln, qty=-ln["qty"]) for ln in lines] if inv["kind"] == "dobropis" else lines,
                                err=err)
                if inv["kind"] == "dobropis":
                    ref = db.one("SELECT * FROM invoices WHERE id = ?", (inv["ref_id"],)) if inv["ref_id"] else None
                    if not ref or kind_of(ref) != "faktura":
                        raise HTTPError(400, "Dobropis jde vystavit jen k faktuře")
                    vat_payer = bool(ref["vat_payer"])
                iid = save(inv, lines, vat_payer)
            if inv["kind"] != "faktura":
                flash_redirect("/faktury/%d" % iid, "%s vystaven%s" % (KINDS[inv["kind"]], "a" if inv["kind"] == "zaloha" else "") +
                               (" · " + num_msg if num_msg else ""))
            with db.tx():   # propojit s nabídkou / zakázkou, ze které faktura vznikla
                if inv["src_quote"].isdigit():
                    db.run("UPDATE quotes SET invoice_id = ?, status = 'prijata' WHERE id = ?", (iid, int(inv["src_quote"])))
                if inv["src_job"].isdigit():
                    db.run("UPDATE jobs SET invoice_id = ?, status = 'vyfakturovana' WHERE id = ?", (iid, int(inv["src_job"])))
                    db.run("UPDATE invoices SET job_id = ? WHERE id = ?", (int(inv["src_job"]), iid))
                    from .jobs import log
                    log(db, int(inv["src_job"]), getattr(req, "user", ""), "stav", "Vyfakturovaná – faktura " + inv["number"])
            flash_redirect("/faktury/%d" % iid, "Faktura vystavena" + (" · " + num_msg if num_msg else ""))
        d = today()
        due = (date.today() + timedelta(days=int(s["due_days"] or 14))).isoformat()
        k = req.args.get("druh") if req.args.get("druh") in ("faktura", "zaloha") else "faktura"
        src = req.args.get("dobropis", "")
        ref = db.one("SELECT * FROM invoices WHERE id = ?", (src,)) if src.isdigit() else None
        if ref and (kind_of(ref) != "faktura" or ref["status"] == "stornovana"):
            flash_redirect("/faktury/%d" % ref["id"], "Dobropis jde vystavit jen k platné faktuře")
        if ref:
            k = "dobropis"
        inv = {"number": next_invoice_number(db, d, s[FORMATS[k]] or "{YYYY}{NNNN}"), "issue_date": d, "tax_date": d,
               "due_date": due, "payment": "prevod", "kind": k}
        lines = []
        if ref:
            inv.update({x: ref[x] for x in ("contact_id", "cust_name", "cust_address", "cust_ico", "cust_dic", "payment",
                                            "warehouse_id", "vat_payer")})
            inv.update({"ref_id": ref["id"], "vs": "", "stock": 1})
            # dobropis: kladné řádky původní faktury (bez odpočtů záloh), v editoru se upraví co se vrací
            lines = [dict(ln, qty=-ln["qty"]) for ln in lines_of(db, ref["id"]) if not ln["advance_id"]]
            return form(req, inv, lines)
        from .contacts import prefill
        inv.update({x: v for x, v in prefill(db, req).items() if x in ("contact_id", "cust_name", "cust_address", "cust_ico", "cust_dic")})
        zid = req.args.get("zaloha", "")
        z = db.one("SELECT * FROM invoices WHERE id = ? AND kind = 'zaloha'", (zid,)) if zid.isdigit() else None
        if z:     # vyúčtování zálohy: zákazník a řádky ze zálohy, záloha zaškrtnutá k odečtení
            inv.update({x: z[x] for x in ("contact_id", "cust_name", "cust_address", "cust_ico", "cust_dic", "payment",
                                          "note", "warehouse_id")})
            inv["advances"] = [z["id"]]
            lines = [dict(ln) for ln in lines_of(db, z["id"])]
        for key, table, ltable, fk in (("nabidka", "quotes", "quote_lines", "quote_id"), ("zakazka", "jobs", "job_lines", "job_id")):
            sid = req.args.get(key, "")
            o = db.one("SELECT * FROM %s WHERE id = ?" % table, (sid,)) if sid.isdigit() else None
            if o:
                inv.update({k: o[k] for k in ("contact_id", "cust_name", "cust_address", "cust_ico", "cust_dic", "note")})
                inv["src_quote" if key == "nabidka" else "src_job"] = o["id"]
                lines = [dict(ln) for ln in db.q("SELECT * FROM %s WHERE %s = ? ORDER BY pos" % (ltable, fk), (o["id"],))]
                if key == "zakazka":
                    if o["quote_id"]:
                        inv["src_quote"] = o["quote_id"]
                    inv["note"] = "\n".join(x for x in (
                        "Zakázka %s%s" % (o["number"], " – " + o["title"] if o["title"] else ""),
                        "Zařízení: %s%s" % (o["device"], ", v. č. " + o["serial"] if o["serial"] else "") if o["device"] else "",
                        "Provedená práce: " + o["work_done"] if o["work_done"] else "", o["note"]) if x)
        src = req.args.get("z")   # duplikovat
        if src:
            o = db.one("SELECT * FROM invoices WHERE id = ?", (src,))
            if o:
                inv.update({x: o[x] for x in ("contact_id", "cust_name", "cust_address", "cust_ico", "cust_dic",
                                              "payment", "note", "warehouse_id")})
                inv["kind"] = kind_of(o) if kind_of(o) in ("faktura", "zaloha") else "faktura"
                inv["number"] = next_invoice_number(db, d, s[FORMATS[inv["kind"]]] or "{YYYY}{NNNN}")
                # nový prodej → záruka podle položky dnes (ne ze staré faktury)
                lines = [{k: v for k, v in dict(ln).items() if k != "warranty"}
                         for ln in lines_of(db, o["id"]) if not ln["advance_id"]]
        return form(req, inv, lines)

    def get(iid):
        inv = db.one("SELECT * FROM invoices WHERE id = ?", (iid,))
        if not inv:
            raise HTTPError(404, "Faktura neexistuje")
        return inv

    @app.route("/faktury/<iid>/upravit", ("GET", "POST"))
    def edit(req, iid):
        inv = get(iid)
        if inv["status"] != "vystavena" or kind_of(inv) == "ddkpp":
            flash_redirect("/faktury/%d" % inv["id"], "Upravit jde jen neuhrazený doklad")
        if req.method == "POST":
            new_inv, lines = read_form(req, inv["vat_payer"], inv["warehouse_id"])
            new_inv.update(kind=kind_of(inv), ref_id=inv["ref_id"], advances=[])
            new_inv["save_contact"] = req.f("save_contact")
            with db.lock:   # kontrola čísla/zálohy a zápis naráz (souběh více uživatelů)
                err = validate(new_inv, lines, inv["id"])
                if err:
                    return form(req, dict(new_inv, vat_payer=inv["vat_payer"]),
                            [dict(ln, qty=-ln["qty"]) if new_inv["kind"] == "dobropis" else ln for ln in lines], inv["id"], err)
                save(new_inv, lines, inv["vat_payer"], inv["id"])
            flash_redirect("/faktury/%d" % inv["id"], "Faktura upravena")
        return form(req, dict(inv), [dict(ln) for ln in lines_of(db, inv["id"])], inv["id"])

    @app.route("/faktury/<iid>/stav", ("POST",))
    def set_status(req, iid):
        inv = get(iid)
        action = req.f("akce")
        if kind_of(inv) == "ddkpp":
            raise HTTPError(400, "Daňový doklad k platbě se mění se zálohovou fakturou")
        if action in ("storno", "nezaplaceno") and kind_of(inv) == "zaloha" and inv["status"] == "zaplacena" and \
                inv["id"] not in {z["id"] for z in unsettled_advances(db)}:
            flash_redirect("/faktury/%d" % inv["id"], "Záloha je už odečtená na konečné faktuře – nejdřív stornujte tu")
        with db.tx():
            if action == "zaplaceno" and inv["status"] == "vystavena":
                db.run("UPDATE invoices SET status='zaplacena', paid_date=? WHERE id=?", (req.f("paid_date") or today(), inv["id"]))
                msg = "Označeno jako uhrazené a zapsáno do peněžního deníku"
                if kind_of(inv) == "zaloha" and inv["vat_payer"]:
                    msg += " · vystaven daňový doklad k přijaté platbě"
            elif action == "nezaplaceno" and inv["status"] == "zaplacena":
                db.run("UPDATE invoices SET status='vystavena', paid_date='' WHERE id=?", (inv["id"],))
                msg = "Úhrada zrušena (zápis v deníku odstraněn)"
            elif action == "storno" and inv["status"] != "stornovana" and db.one(
                    "SELECT 1 FROM invoices WHERE kind = 'dobropis' AND ref_id = ? AND status != 'stornovana'", (inv["id"],)):
                flash_redirect("/faktury/%d" % inv["id"], "K faktuře existuje dobropis – nejdřív stornujte ten "
                                                          "(jinak by se zboží vrátilo na sklad dvakrát)")
            elif action == "storno" and inv["status"] != "stornovana":
                db.run("UPDATE invoices SET status='stornovana', paid_date='' WHERE id=?", (inv["id"],))
                db.run("UPDATE jobs SET status='hotova', invoice_id=NULL WHERE invoice_id=?", (inv["id"],))
                db.run("UPDATE quotes SET invoice_id=NULL WHERE invoice_id=?", (inv["id"],))
                msg = "Doklad stornován" + (", zboží vráceno na sklad" if kind_of(inv) == "faktura" else "")
            elif action == "obnovit" and inv["status"] == "stornovana":
                db.run("UPDATE invoices SET status='vystavena' WHERE id=?", (inv["id"],))
                msg = "Storno zrušeno"
            else:
                raise HTTPError(400, "Tuto akci nejde provést")
            sync_side_effects(db, inv["id"])
            after_status(db, req.settings, inv["id"])
            eid = eet_reconcile(db, req.settings, inv["id"], action)
        if eid:
            er = eet.send(db, req.settings, eid)
            neg = er["amount"] < 0
            msg += (" · EET: %s zaevidována" % ("záporná tržba" if neg else "tržba")) if er["status"] == "ok" else \
                " · EET: %s se pošle dodatečně" % ("oprava" if neg else "tržba")
        flash_redirect("/faktury/%d" % inv["id"], msg)

    @app.route("/faktury/<iid>/smazat", ("POST",))
    def delete(req, iid):
        inv = get(iid)
        last = db.one("SELECT id FROM invoices ORDER BY created DESC, id DESC LIMIT 1")
        if inv["status"] == "zaplacena" or last["id"] != inv["id"] or kind_of(inv) == "ddkpp":
            flash_redirect("/faktury/%d" % inv["id"], "Smazat jde jen poslední neuhrazenou fakturu "
                                                       "(číselná řada musí být souvislá) – jinak použijte storno")
        with db.tx():
            db.run("DELETE FROM movements WHERE invoice_id = ?", (inv["id"],))
            db.run("DELETE FROM cashbook WHERE invoice_id = ?", (inv["id"],))
            db.run("UPDATE bank_tx SET status='nesparovano', invoice_id=NULL WHERE invoice_id = ?", (inv["id"],))
            db.run("DELETE FROM reminders WHERE invoice_id = ?", (inv["id"],))
            db.run("UPDATE jobs SET status='hotova', invoice_id=NULL WHERE invoice_id=?", (inv["id"],))
            db.run("UPDATE quotes SET invoice_id=NULL WHERE invoice_id=?", (inv["id"],))
            db.run("UPDATE invoices SET job_id=NULL WHERE id=?", (inv["id"],))
            db.run("DELETE FROM invoices WHERE id = ?", (inv["id"],))
        flash_redirect("/faktury", "Faktura %s smazána" % inv["number"])

    # ---------- detail / tisk ----------
    @app.route("/faktury/<iid>")
    def detail(req, iid):
        inv = get(iid)
        s = req.settings
        lines = lines_of(db, inv["id"])
        t = invoice_totals(lines, inv["vat_payer"])
        vp = inv["vat_payer"]
        trs = []
        for ln in lines:
            vat_td = "<td class=num>%d %%</td>" % ln["vat_rate"] if vp else ""
            adv = ln["advance_id"]      # odpočet zálohy: bez množství „-1“, záporná částka
            war = warranty_text(ln["warranty"])
            trs.append("<tr><td>%s%s</td><td class=num>%s</td><td class=num>%s</td>%s<td class=num>%s</td></tr>" % (
                h(ln["text"]), "<br><small class='warranty'>%s</small>" % war.capitalize() if war else "",
                "" if adv else "%s %s" % (qty(ln["qty"]), h(ln["unit"])),
                money(-ln["price"] if adv else ln["price"], False), vat_td, money(rnd(ln["qty"] * ln["price"]), False)))
            if line_fee(ln):   # recyklační poplatek jako samostatná částka pod zbožím
                trs.append("<tr class='fee'><td>&nbsp;&nbsp;recyklační poplatek</td><td class=num>%s %s</td><td class=num>%s</td>"
                           "%s<td class=num>%s</td></tr>" % (qty(ln["qty"]), h(ln["unit"]), money(line_fee(ln), False), vat_td,
                                                             money(rnd(ln["qty"] * line_fee(ln)), False)))
        trs = "".join(trs)
        cost = sum(rnd(ln["qty"] * ln["cost"]) for ln in lines if ln["cost"])
        sold = sum(rnd(ln["qty"] * ln["price"]) for ln in lines if ln["cost"])
        margin = ('<div class="card noprint hint">Interní (netiskne se): nákup zboží %s · marže %s (%.0f %%)</div>' % (
            money(cost), money(sold - cost), (sold - cost) * 100 / sold) if cost and sold else "")
        recap = ""
        if vp:
            recap = "<table class='recap'><thead><tr><th>Sazba</th><th class=num>Základ</th><th class=num>DPH</th>" \
                    "<th class=num>Celkem</th></tr></thead><tbody>%s</tbody></table>" % "".join(
                        "<tr><td>%d %%</td><td class=num>%s</td><td class=num>%s</td><td class=num>%s</td></tr>" % (
                            r["rate"], money(r["base"]), money(r["vat"]), money(r["total"])) for r in t["recap"])
        iban = qr.cz_iban(s["bank_account"]) if s["bank_account"] else None
        qr_html = ""
        k = kind_of(inv)
        if iban and inv["payment"] == "prevod" and inv["status"] == "vystavena" and t["total"] > 0 and k in PAYABLE:
            code = qr.spayd(iban, t["total"], inv["vs"], "%s %s" % (doc_name(inv), inv["number"]), inv["due_date"])
            qr_html = '<div class="qr">%s<span>QR platba</span></div>' % qr.svg(code, 3, 2)
        firm_addr = "<br>".join(h(x) for x in (s["firm_street"], ("%s %s" % (s["firm_zip"], s["firm_city"])).strip()) if x)
        ids = "".join("<div>%s: %s</div>" % (k, h(v)) for k, v in (("IČO", s["firm_ico"]), ("DIČ", s["firm_dic"])) if v)
        cust_ids = "".join("<div>%s: %s</div>" % (k, h(v)) for k, v in (("IČO", inv["cust_ico"]), ("DIČ", inv["cust_dic"])) if v)
        contact = " · ".join(h(x) for x in (s["firm_phone"], s["firm_email"], s["firm_web"]) if x)
        pay_info = "".join("<div><span>%s</span>%s</div>" % (k, v) for k, v in [
            ("Způsob platby", PAYMENTS.get(inv["payment"], inv["payment"])),
            ("Bankovní účet", h(s["bank_account"]) if inv["payment"] == "prevod" else ""),
            ("IBAN", h(" ".join(iban[i:i + 4] for i in range(0, len(iban), 4))) if iban and inv["payment"] == "prevod" else ""),
            ("Variabilní symbol", h(inv["vs"])),
            ("Datum vystavení", cz_date(inv["issue_date"])),
            ("Datum zdan. plnění" if k != "ddkpp" else "Datum přijetí platby", cz_date(inv["tax_date"]) if vp and k != "zaloha" else ""),
            ("Datum splatnosti", cz_date(inv["due_date"]) if k != "ddkpp" else "")] if v)
        status = inv["status"]
        # návaznosti: dobropisy k faktuře, daňový doklad a vyúčtování zálohy, zdroj dobropisu / ddkpp
        links = []
        if inv["ref_id"]:
            r0 = db.one("SELECT * FROM invoices WHERE id = ?", (inv["ref_id"],))
            if r0:
                links.append("<a href='/faktury/%d'>%s %s</a>" % (r0["id"], KINDS[kind_of(r0)], h(r0["number"])))
        for r1 in db.q("SELECT * FROM invoices WHERE ref_id = ? ORDER BY id", (inv["id"],)):
            links.append("<a href='/faktury/%d'>%s %s</a>%s" % (r1["id"], KINDS[kind_of(r1)], h(r1["number"]),
                                                               " (stornováno)" if r1["status"] == "stornovana" else ""))
        for r2 in db.q("SELECT DISTINCT f.* FROM invoice_lines l JOIN invoices f ON f.id = l.invoice_id "
                       "WHERE l.advance_id = ?", (inv["id"],)):
            links.append("vyúčtováno fakturou <a href='/faktury/%d'>%s</a>%s" % (
                r2["id"], h(r2["number"]), " (stornováno)" if r2["status"] == "stornovana" else ""))
        for z in db.q("SELECT DISTINCT z.* FROM invoice_lines l JOIN invoices z ON z.id = l.advance_id "
                      "WHERE l.invoice_id = ?", (inv["id"],)):
            links.append("odečtena záloha <a href='/faktury/%d'>%s</a>" % (z["id"], h(z["number"])))
        links_html = '<div class="card noprint hint">Souvisí: %s</div>' % " · ".join(links) if links else ""
        ev = eet.line_for(db, "invoice", inv["id"])
        if ev:
            links_html += '<div class="card noprint hint">EET: %s · <a href="/pokladna/eet">evidované tržby</a></div>' % " · ".join(
                "%s %s" % (money(e["amount"]), ("POK <code>%s</code>" % h(e["pok"])) if e["status"] == "ok"
                           else "<b>%s</b>" % eet.STATUS[e["status"]].lower()) for e in ev)
        refs = "".join("<p class='note'>%s</p>" % h(x) for x in references(db, inv))
        actions = ['<a class="btn primary" href="/faktury/%d/pdf">Stáhnout PDF</a>' % inv["id"],
                   '<a class="btn" href="/faktury/%d/email">Poslat e-mailem</a>' % inv["id"],
                   '<button class="btn" onclick="window.print()">Tisk</button>']
        if status == "vystavena" and k != "ddkpp":
            actions.append('<a class="btn" href="/faktury/%d/upravit">Upravit</a>' % inv["id"])
            if inv["due_date"] < today() and k in PAYABLE and t["total"] > 0:
                actions.append('<a class="btn" href="/faktury/%d/upominka">Upomínka</a>' % inv["id"])
            actions.append('<form method="post" action="/faktury/%d/stav" class="inline">%s<input type="hidden" name="akce" '
                           'value="zaplaceno"><input type="date" name="paid_date" value="%s"><button class="btn ok">'
                           '%s</button></form>' % (inv["id"], app.csrf(), today(),
                                                    "Vráceno" if k == "dobropis" or t["total"] < 0 else "Uhrazeno"))
        if status == "zaplacena" and k != "ddkpp":
            actions.append('<form method="post" action="/faktury/%d/stav" class="inline">%s<input type="hidden" name="akce" '
                           'value="nezaplaceno"><button class="btn">Zrušit úhradu</button></form>' % (inv["id"], app.csrf()))
        if k == "faktura" and status != "stornovana":
            actions.append('<a class="btn" href="/faktury/nova?dobropis=%d">Dobropis</a>' % inv["id"])
        if k == "zaloha" and inv["id"] in {z["id"] for z in unsettled_advances(db)}:
            actions.append('<a class="btn ok" href="/faktury/nova?zaloha=%d">Vyúčtovat fakturou</a>' % inv["id"])
        if k in PAYABLE:
            actions.append('<a class="btn" href="/faktury/nova?z=%d">Duplikovat</a>' % inv["id"])
        if inv["job_id"]:
            actions.append('<a class="btn" href="/zakazky/%d">← Zakázka</a>' % inv["job_id"])
        actions.append('<a class="btn" href="/faktury/%d/isdoc" title="Elektronická faktura pro účetní">ISDOC</a>' % inv["id"])
        if k == "ddkpp":
            pass
        elif status != "stornovana":
            actions.append('<form method="post" action="/faktury/%d/stav" class="inline" onsubmit="return confirm('
                           '\'Stornovat doklad?%s\')">%s<input type="hidden" name="akce" value="storno">'
                           '<button class="btn danger">Storno</button></form>' % (
                               inv["id"], " Zboží se vrátí na sklad." if k == "faktura" else "", app.csrf()))
        else:
            actions.append('<form method="post" action="/faktury/%d/stav" class="inline">%s<input type="hidden" name="akce" '
                           'value="obnovit"><button class="btn">Zrušit storno</button></form>' % (inv["id"], app.csrf()))
        if k != "ddkpp":
            actions.append('<form method="post" action="/faktury/%d/smazat" class="inline" onsubmit="return confirm('
                           '\'Smazat doklad natrvalo?\')">%s<button class="link danger">smazat</button></form>' % (inv["id"], app.csrf()))
        stamp = {"zaplacena": "VRÁCENO" if k == "dobropis" or t["total"] < 0 else "UHRAZENO",
                 "stornovana": "STORNO"}.get(status, "")
        if k == "ddkpp" and status == "zaplacena":
            stamp = ""
        doc = """<article class="invoice">%s
<header><div>%s<h1>%s %s</h1><div class="sub">%s</div></div>%s</header>
<div class="parties"><section><h3>Dodavatel</h3><b>%s</b><div>%s</div>%s<div class="small">%s</div></section>
<section><h3>Odběratel</h3><b>%s</b><div>%s</div>%s</section></div>
<div class="payinfo">%s</div>
<table class="items"><thead><tr><th>Popis</th><th class=num>Množství</th><th class=num>Cena/j.%s</th>%s
<th class=num>Celkem%s</th></tr></thead><tbody>%s</tbody></table>
<div class="sum">%s<div class="topay"><span>%s</span><b>%s</b></div></div>
%s%s%s%s<footer><div>%s</div><div>%s</div><div>%s</div></footer></article>""" % (
            '<div class="stamp">%s</div>' % stamp if stamp else "", images.inline(app.data_dir, "logo"),
            h(doc_name(inv, True)), h(inv["number"]), doc_subtitle(inv), qr_html,
            h(s["firm_name"]) or "<i>Vyplňte údaje firmy v Nastavení</i>", firm_addr, ids, contact,
            h(inv["cust_name"]), h(inv["cust_address"]).replace("\n", "<br>"), cust_ids, pay_info,
            " bez DPH" if vp else "", "<th class=num>DPH</th>" if vp else "", " bez DPH" if vp else "", trs,
            recap, total_label(inv, t["total"]), money(t["total"]), refs,
            "<p class='note'>%s</p>" % h(inv["note"]).replace("\n", "<br>") if inv["note"] else "",
            "" if vp else "<p class='note'>Nejsem plátce DPH.</p>", images.signature_block(app.data_dir, s),
            h(s["firm_register"]), h(s["invoice_footer"]).replace("\n", "<br>"),
            "Vystaveno programem Firmička")
        return app.page("%s %s" % (KINDS[k], inv["number"]), flash(req) + '<div class="bar noprint"><a href="/faktury">← Faktury</a>'
                        '<div class="actions">%s</div></div>' % "".join(actions) + margin + links_html +
                        page_numbers_css("%s %s" % (KINDS[k], inv["number"])) + doc, "/faktury")

    @app.route("/faktury/<iid>/isdoc")
    def isdoc_export(req, iid):
        from . import isdoc
        from .web import Response
        inv = get(iid)
        return Response(isdoc.export(inv, lines_of(db, inv["id"]), req.settings, db), ctype="application/xml",
                        headers=[("Content-Disposition", 'attachment; filename="%s-%s.isdoc"' % (
                            kind_of(inv), "".join(c for c in inv["number"] if c.isalnum() or c in "-_")))])

    @app.route("/faktury/<iid>/qr.svg")
    def qr_svg(req, iid):
        from .web import Response
        inv = get(iid)
        iban = qr.cz_iban(req.settings["bank_account"])
        if not iban:
            raise HTTPError(404)
        t = invoice_totals(lines_of(db, inv["id"]), inv["vat_payer"])["total"]
        if t <= 0 or kind_of(inv) not in PAYABLE:
            raise HTTPError(404)
        return Response(qr.svg(qr.spayd(iban, t, inv["vs"], "%s %s" % (doc_name(inv), inv["number"]), inv["due_date"])),
                        ctype="image/svg+xml")
