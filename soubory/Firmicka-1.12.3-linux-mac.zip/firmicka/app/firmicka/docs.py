"""Společné části dokladů s řádky (nabídka, zakázka): výběr odběratele, editor řádků, čtení formuláře,
tisková šablona. Formulář má id="invoice", takže používá stejný skript jako faktura (čtečka, ARES, součty)."""
import json

from .contacts import address as contact_address
from .db import (rnd, invoice_totals, line_fee, line_gross, gross_mode, line_parts, fee_gross, net_price_from_gross,
                 with_vat, today, VAT_RATES)
from .stock import items_json, item_options
from .web import h, money, qty, parse_money, parse_qty, parse_vat, parse_id, BadInput


def customer_box(db, d, title="Odběratel"):
    contacts = db.q("SELECT * FROM contacts ORDER BY name COLLATE NOCASE")
    contacts_js = json.dumps({str(c["id"]): {"name": c["name"], "ico": c["ico"], "dic": c["dic"],
                                             "address": contact_address(c)} for c in contacts}, ensure_ascii=False)
    copts = '<option value="">— vybrat z adresáře —</option>' + "".join(
        '<option value="%d"%s>%s</option>' % (c["id"], " selected" if str(c["id"]) == str(d.get("contact_id") or "") else "",
                                              h(c["name"])) for c in contacts)
    return """<section class="card wide"><h2>%s</h2><div class="grid">
<label class="wide">Z adresáře<select name="contact_id" data-contacts='%s'>%s</select></label>
<label class="wide">Název / jméno<input name="cust_name" value="%s" required></label>
<label>IČO<span class="row"><input name="cust_ico" value="%s"><button type="button" class="btn" data-ares-inv>ARES</button></span></label>
<label>DIČ<input name="cust_dic" value="%s"></label>
<label class="wide">Adresa<textarea name="cust_address" rows="3">%s</textarea></label>
<label class="check wide"><input type="checkbox" name="save_contact" value="1"> Uložit do adresáře</label>
</div></section>""" % (title, h(contacts_js), copts, h(d.get("cust_name")), h(d.get("cust_ico")), h(d.get("cust_dic")),
                        h(d.get("cust_address")))


def gross_flag(req, vat_payer):
    """Zaškrtnuto „Ceny s DPH“ (jen plátce – neplátce DPH nepočítá)."""
    return bool(vat_payer) and req.f("prices_gross") == "1"


def apply_gross(ln, total, on):
    """Doklad s cenami s DPH: uloží částku řádku s DPH (pole „Celkem“) a cenu za jednotku bez DPH z ní odvodí
    (číslo z prohlížeče se nebere – server počítá sám). Bez „Celkem“ = množství × cena/j. s DPH + poplatek s DPH."""
    if not on:
        ln["gross"] = None
        return ln
    rate, fee, q = ln["vat_rate"], ln.get("recycling_fee") or 0, ln["qty"]
    g = parse_money(total) if (total or "").strip() else None
    if g is None:
        g = rnd(q * with_vat(ln["price"], rate)) + (fee_gross(q, fee, rate) if fee else 0)
    if not q:
        g = 0
    ln["gross"] = g
    ln["price"] = net_price_from_gross(g, q, fee, rate)
    return ln


def gross_toggle(on, vat_payer):
    """Přepínač „Ceny s DPH“ nad řádky dokladu (neplátce ho nemá)."""
    if not vat_payer:
        return ""
    return ('<label class="check gross-toggle"><input type="checkbox" name="prices_gross" value="1"%s> Ceny s DPH '
            '<span class="hint">– zadané částky s DPH platí přesně, DPH se z nich vypočítá (výpočet shora)</span></label>'
            % (" checked" if on else ""))


def editor_rows(lines, extra=None):
    """Řádky pro editor (JSON); gross = uložená částka s DPH u dokladu s cenami s DPH."""
    out = []
    for ln in lines:
        d = {"item": ln.get("item_id") or "", "text": ln["text"], "qty": ln["qty"], "unit": ln["unit"],
             "price": ln["price"], "vat": ln["vat_rate"], "fee": line_fee(ln), "gross": line_gross(ln)}
        if extra:
            d.update(extra(ln))
        out.append(d)
    return json.dumps(out, ensure_ascii=False)


def lines_editor(db, lines, vat_payer, default_gross=False):
    items = db.q("SELECT * FROM items WHERE active = 1 ORDER BY name COLLATE NOCASE")
    iopts = item_options(items)
    vat_opts = "".join('<option value="%d">%d %%</option>' % (v, v) for v in VAT_RATES)
    rows = editor_rows(lines)
    hid = "" if vat_payer else " hidden"
    gross_on = gross_mode(lines) if lines else default_gross
    return """<h2>Položky</h2>%s
<div class="filters"><input id="scan" placeholder="Pípněte EAN – přidá položku" data-scan inputmode="numeric">
<span class="hint" id="scan-msg"></span></div>
<table class="lines"><thead><tr><th>Položka</th><th>Popis</th><th class=num>Množství</th><th>Jedn.</th>
<th class=num>Cena/j.%s</th><th class=num%s>Cena/j. s DPH</th><th class=num>Rec. popl./j.</th><th%s>DPH</th><th class="num sum-head">Celkem</th><th></th></tr></thead>
<tbody id="lines" data-items='%s' data-rows='%s'></tbody></table>
<template id="line-tpl"><tr>
<td><select name="line_item">%s</select></td><td><input name="line_text"></td>
<td><input name="line_qty" class=num inputmode="decimal" value="1"></td><td><input name="line_unit" value="ks" size="4"></td>
<td><input name="line_price" class=num inputmode="decimal"></td><td%s><input class="num line-gross" inputmode="decimal" aria-label="Cena za jednotku s DPH"><small class="hint gross-hint" hidden></small></td>
<td><input name="line_fee" class=num inputmode="decimal" placeholder="0"></td><td%s><select name="line_vat">%s</select></td>
<td class="num line-total"><input name="line_total" class="num line-sum" inputmode="decimal" aria-label="Celkem za řádek"><small class="hint sum-hint" hidden></small></td><td><button type="button" class="link danger" data-del>✕</button></td></tr></template>
<p><button type="button" class="btn" id="add-line">+ Přidat řádek</button> <span class="hint" id="stock-warn"></span></p>
<div class="totals" id="totals"></div>""" % (
        gross_toggle(gross_on, vat_payer), " bez DPH" if vat_payer else "", hid, hid, h(json.dumps(items_json(db, with_cost=False), ensure_ascii=False)), h(rows), iopts,
        hid, hid, vat_opts)


def check_items(db, lines):
    """Položka mohla být mezitím smazána (jiný uživatel) – srozumitelná hláška místo chyby databáze."""
    ids = {ln["item_id"] for ln in lines if ln.get("item_id")}
    if not ids:
        return
    have = {r[0] for r in db.q("SELECT id FROM items WHERE id IN (%s)" % ",".join("?" * len(ids)), sorted(ids))}
    for ln in lines:
        if ln.get("item_id") and ln["item_id"] not in have:
            raise BadInput("Položka „%s“ byla mezitím ze skladu smazána. Vraťte se zpět a vyberte ji znovu, nebo u řádku "
                           "nastavte „volný text“." % ln["text"][:80])


def read_lines(req, vat_payer, db=None):
    cols = [req.lst(k) for k in ("line_item", "line_text", "line_qty", "line_unit", "line_price", "line_vat", "line_fee",
                                 "line_total")]
    n = len(cols[0])
    cols = [c + [""] * (n - len(c)) for c in cols]
    on = gross_flag(req, vat_payer)
    out = []
    for it, text, q, unit, price, vat, fee, total in zip(*cols):
        if not text.strip() and not it:
            continue
        out.append(apply_gross({"item_id": parse_id(it), "text": text.strip(), "qty": parse_qty(q),
                                "unit": unit.strip() or "ks", "price": parse_money(price),
                                "vat_rate": parse_vat(vat, vat_payer), "recycling_fee": parse_money(fee)}, total, on))
    if db is not None:
        check_items(db, out)
    return out


def read_customer(req):
    d = {k: req.f(k) for k in ("cust_name", "cust_ico", "cust_dic", "contact_id")}
    d["cust_address"] = req.form.get("cust_address", "").strip()
    d["save_contact"] = req.f("save_contact")
    return d


def find_by_ico(db, ico):
    """Kontakt se stejným IČO – „Uložit do adresáře“ ho má použít, ne založit duplicitu."""
    ico = (ico or "").strip()
    row = db.one("SELECT id FROM contacts WHERE ico = ? AND ico != '' ORDER BY id LIMIT 1", (ico,)) if ico else None
    return row["id"] if row else None


def save_contact(db, d):
    """Vrátí contact_id (případně založí kontakt). Volat v transakci."""
    cid = d["contact_id"] if str(d.get("contact_id") or "").isdigit() else None
    if d.get("save_contact") and not cid:
        cid = find_by_ico(db, d.get("cust_ico"))
    if d.get("save_contact") and not cid:
        street, _, rest = d["cust_address"].partition("\n")
        zip_, _, city = rest.split("\n")[0].strip().partition(" ")
        cid = db.run("INSERT INTO contacts(name, ico, dic, street, city, zip) VALUES(?,?,?,?,?,?)",
                     (d["cust_name"], d["cust_ico"], d["cust_dic"], street.strip(), city.strip(), zip_))
    return cid


def write_lines(db, table, fk, doc_id, lines):
    db.run("DELETE FROM %s WHERE %s = ?" % (table, fk), (doc_id,))
    for pos, ln in enumerate(lines):
        db.run("INSERT INTO %s(%s, pos, item_id, text, qty, unit, price, vat_rate, recycling_fee, gross) "
               "VALUES(?,?,?,?,?,?,?,?,?,?)"
               % (table, fk), (doc_id, pos, ln["item_id"], ln["text"], ln["qty"], ln["unit"], ln["price"],
                               ln["vat_rate"], line_fee(ln), line_gross(ln)))


def lines_table(lines, vat_payer):
    """Tabulka řádků + rekapitulace pro tiskový náhled (stejný vzhled jako faktura)."""
    t = invoice_totals(lines, vat_payer)
    trs = []
    for x in line_parts(lines, vat_payer):
        ln = x["ln"]
        vat_td = "<td class=num>%d %%</td>" % ln["vat_rate"] if vat_payer else ""
        amount = x["gross"] if t["shora"] else x["base"]
        if x["fee"]:
            trs.append("<tr class='fee'><td>&nbsp;&nbsp;recyklační poplatek</td><td class=num>%s %s</td><td class=num>%s</td>"
                       "%s<td class=num>%s</td></tr>" % (qty(ln["qty"]), h(ln["unit"]), money(x["price"], False), vat_td,
                                                         money(amount, False)))
        else:
            trs.append("<tr><td>%s</td><td class=num>%s %s</td><td class=num>%s</td>%s<td class=num>%s</td></tr>" % (
                h(ln["text"]), qty(ln["qty"]), h(ln["unit"]), money(x["price"], False), vat_td, money(amount, False)))
    recap = ""
    if vat_payer:
        recap = "<table class='recap'><thead><tr><th>Sazba</th><th class=num>Základ</th><th class=num>DPH</th>" \
                "<th class=num>Celkem</th></tr></thead><tbody>%s</tbody></table>" % "".join(
                    "<tr><td>%d %%</td><td class=num>%s</td><td class=num>%s</td><td class=num>%s</td></tr>" % (
                        r["rate"], money(r["base"]), money(r["vat"]), money(r["total"])) for r in t["recap"])
    head = "<tr><th>Popis</th><th class=num>Množství</th><th class=num>Cena/j.%s</th>%s<th class=num>Celkem%s</th></tr>" % (
        " bez DPH" if vat_payer else "", "<th class=num>DPH</th>" if vat_payer else "", total_head(t, vat_payer))
    return """<table class="items"><thead>%s</thead><tbody>%s</tbody></table>
<div class="sum">%s<div class="topay"><span>Celkem%s</span><b>%s</b></div></div>""" % (
        head, "".join(trs), recap, " vč. DPH" if vat_payer else "", money(t["total"])), t


def total_head(t, vat_payer):
    """Popisek sloupce „Celkem“ u řádků: zdola bez DPH, u cen s DPH s DPH."""
    if not vat_payer:
        return ""
    return " s DPH" if t["shora"] else " bez DPH"


def firm_block(s):
    addr = "<br>".join(h(x) for x in (s["firm_street"], ("%s %s" % (s["firm_zip"], s["firm_city"])).strip()) if x)
    ids = "".join("<div>%s: %s</div>" % (k, h(v)) for k, v in (("IČO", s["firm_ico"]), ("DIČ", s["firm_dic"])) if v)
    contact = " · ".join(h(x) for x in (s["firm_phone"], s["firm_email"], s["firm_web"]) if x)
    return "<b>%s</b><div>%s</div>%s<div class='small'>%s</div>" % (
        h(s["firm_name"]) or "<i>Vyplňte údaje firmy v Nastavení</i>", addr, ids, contact)


# ---------- navržené číslo dokladu ----------
# Formulář nového dokladu nese vedle čísla skryté pole number_auto = číslo, které program navrhl. Když ho uživatel
# neměnil, server při uložení (pod zámkem) vezme další volné číslo podle roku dokladu: vyřeší to souběh (dva lidé
# se stejným navrženým číslem) i zpětný doklad po Novém roce (datum vystavení v loňském roce → loňská řada).

def auto_number_input(d, field="number", date_field="issue_date", series=""):
    """Skryté pole s navrženým číslem (jen u nového dokladu). series = druh pro /…/cislo (přepočet při změně data)."""
    auto = d.get("number_auto", d.get(field, ""))
    return '<input type="hidden" name="number_auto" value="%s" data-field="%s" data-date="%s" data-series="%s">' % (
        h(auto), field, date_field, h(series))


def auto_number(db, req, number, day, fmt, table, col="number"):
    """(číslo, hláška). Číslo, které uživatel přepsal ručně, se nemění."""
    from .db import next_invoice_number
    auto = req.f("number_auto")
    if not auto or number != auto or not fmt or len(day or "") < 10:
        return number, ""
    try:
        new = next_invoice_number(db, day, fmt, table, col)
    except (ValueError, TypeError):
        return number, ""
    if new == number:
        return number, ""
    if "{YY" in fmt and day[:4] != today()[:4]:
        return new, "Číslo dokladu je z řady roku %s (podle data dokladu): %s" % (day[:4], new)
    return new, "Číslo %s mezitím použil jiný doklad – uloženo jako %s" % (number, new)


def page_numbers_css(label):
    """Tisk z prohlížeče: na 2. a další straně vpravo dole „Faktura 2026001 · strana 2 / 3“ (jako v PDF).
    Okraje stránky (@page @bottom-right) umí Chrome/Edge; jiné prohlížeče to jen vynechají."""
    label = "".join(c for c in label if c not in '"\\\n<>{}')
    return ('<style>@media print { @page { @bottom-right { content: "%s · strana " counter(page) " / " counter(pages); '
            'font: 7pt "DejaVu Sans", Arial, sans-serif; color: #666; } } '
            '@page :first { @bottom-right { content: none; } } }</style>' % label)
