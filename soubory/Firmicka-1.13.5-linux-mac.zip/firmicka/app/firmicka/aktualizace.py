"""Upozornění na novou verzi: jednou denně stáhne https://mojefirmicka.cz/verze.json a když je venku novější verze,
ukáže lištu „Je k dispozici Firmička X – Co je nového · Stáhnout“. Nic o firmě ani uživateli neposílá (jen běžný
požadavek s verzí programu v User-Agent). Instaluje se ručně staženou instalačkou; kontrola jde vypnout v Nastavení.

verze.json: {"verze": "1.13.5", "datum": "2026-11-21", "novinky": "krátký text", "odkaz": "https://mojefirmicka.cz/stahnout.html"}"""
import json
import time
import urllib.request

from . import __version__
from .web import flash_redirect, h

URL = "https://mojefirmicka.cz/verze.json"
WEB = "https://mojefirmicka.cz/"
DEFAULT_LINK = WEB + "stahnout.html"
EVERY = 23 * 3600          # běží v hodinové smyčce → prakticky jednou denně


def parse_version(v):
    try:
        parts = tuple(int(x) for x in str(v).strip().split("."))
        return parts if 1 <= len(parts) <= 4 else None
    except (TypeError, ValueError):
        return None


def newer(latest, current=__version__):
    a, b = parse_version(latest), parse_version(current)
    return bool(a and b and a > b)


def fetch(url=URL, timeout=10):
    req = urllib.request.Request(url, headers={"User-Agent": "Firmicka/%s" % __version__, "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = json.loads(r.read(20000).decode("utf-8"))
    if not isinstance(data, dict) or not parse_version(data.get("verze")):
        raise ValueError("neplatný verze.json")
    link = str(data.get("odkaz") or "")
    return {"verze": str(data["verze"]).strip()[:20],
            "datum": str(data.get("datum") or "")[:20],
            "novinky": " ".join(str(data.get("novinky") or "").split())[:400],
            # odkaz jen na vlastní web – soubor z cizího serveru by šlo podvrhnout
            "odkaz": link if link.startswith(WEB) and len(link) < 200 else DEFAULT_LINK}


def check(db, force=False, fetcher=None):
    """Vrátí None (přeskočeno), nebo dict s výsledkem. Chyby sítě jen zapíše, nikdy nevyhodí."""
    s = db.settings()
    if not force and (s.get("upd_check", "1") != "1" or time.time() - float(s.get("upd_checked") or 0) < EVERY):
        return None
    try:
        d = (fetcher or fetch)()
    except Exception as e:
        db.set_settings({"upd_checked": str(int(time.time())), "upd_error": str(e)[:200]})
        return {"error": str(e)}
    db.set_settings({"upd_checked": str(int(time.time())), "upd_error": "", "upd_latest": d["verze"],
                     "upd_date": d["datum"], "upd_notes": d["novinky"], "upd_link": d["odkaz"]})
    return d


def available(s):
    """Novější verze, kterou uživatel neskryl, jinak None."""
    v = s.get("upd_latest") or ""
    if s.get("upd_check", "1") != "1" or not newer(v) or s.get("upd_skip") == v:
        return None
    return v


def settings_card(app, s):
    t = float(s.get("upd_checked") or 0)
    when = time.strftime("%d. %m. %Y %H:%M", time.localtime(t)) if t else "zatím ne"
    if s.get("upd_error"):
        state = "Poslední kontrola %s se nepovedla (bez internetu?)." % when
    elif newer(s.get("upd_latest")):
        state = "Je k dispozici verze <b>%s</b>. <a href='%s' target='_blank' rel='noopener'>Stáhnout</a>" % (
            h(s["upd_latest"]), h(s.get("upd_link") or DEFAULT_LINK))
    elif t:
        state = "Máte nejnovější verzi (kontrola %s)." % when
    else:
        state = "Kontrola zatím neproběhla."
    return """<section class="card" id="aktualizace"><h2>Nové verze</h2>
<p>Používáte verzi <b>%s</b>. %s</p>
<form method="post" action="/nastaveni/aktualizace">%s
<label class="check"><input type="checkbox" name="upd_check" value="1"%s> Jednou denně zkontrolovat, jestli není nová verze</label>
<p class="hint">Program jen stáhne z webu mojefirmicka.cz číslo poslední verze, nic o vaší firmě neposílá.
Novou verzi nainstalujete staženou instalačkou přes tu starou, data zůstanou.</p>
<p><button class="btn" name="akce" value="ulozit">Uložit</button> <button class="btn" name="akce" value="ted">Zkontrolovat teď</button></p>
</form></section>""" % (h(__version__), state, app.csrf(), " checked" if s.get("upd_check", "1") == "1" else "")


def register(app):
    db = app.db
    app.update_check = lambda force=False: check(db, force)

    def banner():
        s = db.settings()
        v = available(s)
        perms = getattr(app.local, "perms", None)
        if not v or (perms is not None and "nastaveni" not in perms):
            return ""
        notes = (" – " + h(s.get("upd_notes"))) if s.get("upd_notes") else ""
        return ("<div class='flash upd'>⬆️ Je k dispozici <b>Firmička %s</b>%s "
                "<a class='btn primary' href='%s' target='_blank' rel='noopener'>Co je nového a stažení</a> "
                "<form method=post action='/nastaveni/aktualizace' class=inline>%s<input type=hidden name=akce value=skryt>"
                "<input type=hidden name=verze value='%s'><button class='btn'>Skrýt</button></form></div>") % (
                    h(v), notes, h(s.get("upd_link") or DEFAULT_LINK), app.csrf(), h(v))
    app.banners.append(banner)

    @app.route("/nastaveni/aktualizace", ("POST",))
    def save(req):
        a = req.f("akce")
        if a == "skryt":
            db.set_settings({"upd_skip": req.f("verze")[:20]})
            flash_redirect(req.f("back") or "/", "Upozornění skryto – připomenu se až u další verze")
        if a == "ted":
            db.set_settings({"upd_check": "1"})
            r = check(db, force=True)
            if r.get("error"):
                flash_redirect("/nastaveni#aktualizace", "Kontrola se nepovedla – je počítač připojený k internetu?")
            flash_redirect("/nastaveni#aktualizace", "Je k dispozici verze %s" % r["verze"] if newer(r["verze"])
                           else "Máte nejnovější verzi")
        db.set_settings({"upd_check": "1" if req.f("upd_check") else "0"})
        flash_redirect("/nastaveni#aktualizace", "Uloženo")
