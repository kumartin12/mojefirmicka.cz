"""Malý WSGI framework: požadavek, směrování, šablona stránky, přihlášení a ochrana formulářů.
Jen standardní knihovna – aplikace běží v přibaleném Pythonu bez instalace balíčků."""
import datetime
import hashlib
import hmac
import html
import json
import os
import re
import secrets
import sqlite3
import threading
import time
import urllib.parse
from http import cookies

from . import __version__

STATIC = os.path.join(os.path.dirname(__file__), "static")


def h(v):
    return html.escape("" if v is None else str(v), quote=True)


def money(hal, cur=True):
    """Haléře → '1 234,50 Kč'."""
    hal = hal or 0
    sign = "-" if hal < 0 else ""
    kc, h_ = divmod(abs(int(hal)), 100)
    s = "{:,}".format(kc).replace(",", " ") + ",%02d" % h_
    return sign + s + (" Kč" if cur else "")


def qty(v):
    v = float(v or 0)
    return ("%d" % v) if v == int(v) else ("%.3f" % v).rstrip("0").replace(".", ",")


NUM_RX = re.compile(r"^[+-]?(\d+([.,]\d*)?|[.,]\d+)$")
DATE_FIELD = re.compile(r"(^|_)date(_|$)|^deadline$|^valid_until$|^datum$")


def _num(s, what, limit):
    raw = (s or "").strip()
    t = re.sub(r"[\s\u00a0\u202f]", "", raw).replace("Kč", "")
    if not t:
        return None
    if not NUM_RX.match(t):
        raise BadInput("„%s“ není %s. Vraťte se zpět a opravte ho (např. 1 234,50)." % (raw[:40], what))
    v = float(t.replace(",", "."))
    if abs(v) > limit:
        raise BadInput("Číslo „%s“ je příliš velké." % raw[:40])
    return v


def parse_money(s):
    """'1 234,5' → 123450 haléřů. Nesmysl / nekonečno → BadInput (stránka s chybou, ne pád)."""
    v = _num(s, "platná částka", 1e11)
    return 0 if v is None else int(round(v * 100))


def parse_qty(s):
    v = _num(s, "platné množství", 1e9)
    return 0.0 if v is None else v


def parse_vat(s, payer=True):
    """Sazba DPH z formuláře: '' → 0, jinak celé číslo 0–99."""
    s = (s or "").strip()
    if not payer or not s:
        return 0
    if not s.isdigit() or int(s) > 99:
        raise BadInput("Neplatná sazba DPH „%s“." % s[:20])
    return int(s)


def parse_id(s):
    """Číslo záznamu z formuláře, jinak None (i obří čísla, která SQLite neuloží)."""
    s = (s or "").strip()
    return int(s) if s.isdigit() and len(s) <= 15 else None


def cz_date(iso):
    if not iso or len(iso) < 10:
        return ""
    return "%d. %d. %s" % (int(iso[8:10]), int(iso[5:7]), iso[:4])


class HTTPError(Exception):
    def __init__(self, status, msg=""):
        super().__init__(msg)
        self.status, self.msg = status, msg


class BadInput(HTTPError, ValueError):
    """Neplatný údaj ve formuláři → stránka 400 s tlačítkem Zpět (ValueError kvůli starším try/except)."""
    def __init__(self, msg):
        HTTPError.__init__(self, 400, msg)


class Redirect(Exception):
    def __init__(self, url):
        super().__init__(url)
        self.url = url


class Request:
    def __init__(self, environ):
        self.env = environ
        self.method = environ["REQUEST_METHOD"]
        self.path = environ.get("PATH_INFO", "/") or "/"
        self.args = {k: v[-1] for k, v in urllib.parse.parse_qs(environ.get("QUERY_STRING", "")).items()}
        self.form = {}
        self.form_lists = {}
        self.files = {}          # jméno pole → (název souboru, bajty)
        if self.method == "POST":
            n = int(environ.get("CONTENT_LENGTH") or 0)
            if n > 20_000_000:
                raise HTTPError(413, "Příliš velký soubor")
            raw = environ["wsgi.input"].read(n)
            ctype = environ.get("CONTENT_TYPE", "")
            if ctype.startswith("multipart/form-data"):
                self._multipart(ctype, raw)
            else:
                self.form_lists = urllib.parse.parse_qs(raw.decode("utf-8", "replace"), keep_blank_values=True)
            self.form = {k: v[-1] for k, v in self.form_lists.items()}
        c = cookies.SimpleCookie(environ.get("HTTP_COOKIE", ""))
        self.cookies = {k: m.value for k, m in c.items()}

    def _multipart(self, ctype, raw):
        """Nahrané soubory přes standardní e-mailový parser (modul cgi v Pythonu 3.13 už není)."""
        from email.parser import BytesParser
        from email.policy import HTTP
        msg = BytesParser(policy=HTTP).parsebytes(b"Content-Type: " + ctype.encode() + b"\r\n\r\n" + raw)
        for part in msg.iter_parts():
            name = part.get_param("name", header="content-disposition")
            if not name:
                continue
            data = part.get_payload(decode=True) or b""
            filename = part.get_filename()
            if filename is not None:
                if data:
                    self.files[name] = (filename, data)
            else:
                self.form_lists.setdefault(name, []).append(data.decode("utf-8", "replace"))

    def f(self, key, default=""):
        return self.form.get(key, default).strip()

    def lst(self, key):
        return self.form_lists.get(key, [])


class Response:
    def __init__(self, body="", status=200, ctype="text/html; charset=utf-8", headers=None):
        self.body = body.encode("utf-8") if isinstance(body, str) else body
        self.status = status
        self.headers = [("Content-Type", ctype)] + (headers or [])


STATUS = {200: "200 OK", 302: "302 Found", 400: "400 Bad Request", 403: "403 Forbidden",
          404: "404 Not Found", 409: "409 Conflict", 413: "413 Payload Too Large", 500: "500 Internal Server Error"}


def hash_password(pw):
    salt = secrets.token_hex(16)
    d = hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), 200_000).hex()
    return "%s$%s" % (salt, d)


def check_password(pw, stored):
    try:
        salt, d = stored.split("$", 1)
    except ValueError:
        return False
    return hmac.compare_digest(hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), 200_000).hex(), d)


# části programu (oprávnění) → začátky cest; uživatel má množinu klíčů, role jsou jen předvolby
MODULES = [
    ("prehled", "Přehled (tržby, dlužníci)", ["/"]),
    ("pokladna", "Pokladna", ["/pokladna"]),
    ("nabidky", "Nabídky", ["/nabidky"]),
    ("zakazky", "Zakázky", ["/zakazky"]),
    ("faktury", "Vydané faktury, upomínky, export pro účetní", ["/faktury", "/upominky", "/export", "/ucetni"]),
    ("prijate", "Přijaté faktury a podklady k DPH", ["/prijate", "/dph", "/export/prijate"]),
    ("sklad", "Sklad", ["/sklad", "/export/sklad"]),
    ("banka", "Banka (výpisy a párování)", ["/banka"]),
    ("denik", "Peněžní deník", ["/denik", "/export/denik"]),
    ("adresar", "Adresář", ["/adresar", "/export/adresar"]),
    ("nastaveni", "Nastavení firmy, zálohy, e-mail, tiskárna", ["/nastaveni", "/obrazek"]),
    ("uzivatele", "Správa uživatelů, přístup ze sítě, záznam změn", ["/nastaveni/uzivatele", "/nastaveni/pristup", "/nastaveni/licence",
                                                                    "/nastaveni/audit"]),
    ("kalendar", "Kalendář, dovolené a poznámky", ["/kalendar"]),
]
ALL_PERMS = [k for k, _, _ in MODULES]
ROLES = {
    "majitel": {"name": "Majitel", "perms": ALL_PERMS},
    "ucetni": {"name": "Účetní", "perms": [k for k in ALL_PERMS if k != "uzivatele"]},
    "skladnik": {"name": "Skladník", "perms": ["sklad", "kalendar"]},
    "prodavac": {"name": "Prodavač", "perms": ["pokladna", "nabidky", "adresar", "kalendar"]},
}
ALWAYS = ("/login", "/logout", "/quit", "/static/", "/ping")
# pomocná data pro formuláře – stačí kterákoli z uvedených částí programu (jinak by skladník přečetl celý adresář)
API = [("/api/kontakty", {"adresar", "faktury", "nabidky", "zakazky", "prijate", "pokladna"}),
       ("/api/ares/", {"adresar", "nastaveni", "faktury", "nabidky", "zakazky", "prijate"}),
       ("/api/polozky", {"sklad", "faktury", "nabidky", "zakazky", "prijate", "pokladna"}),
       ("/api/ean/", {"sklad", "faktury", "nabidky", "zakazky", "prijate", "pokladna"})]


def module_of(path):
    """Klíč části programu pro cestu (nejdelší shodný začátek), None = volně přístupné přihlášeným."""
    if path == "/":
        return "prehled"
    best, blen = None, 0
    for key, _, prefixes in MODULES:
        for p in prefixes:
            if p != "/" and path.startswith(p) and len(p) > blen:
                best, blen = key, len(p)
    return best


def allowed(perms, path):
    if path.startswith(ALWAYS):
        return True
    if path.startswith("/api/"):
        return any(path.startswith(p) and perms & need for p, need in API)
    m = module_of(path)
    return m is None or m in perms


def user_perms(row):
    """Oprávnění uživatele: uložený výběr, jinak předvolba jeho role."""
    stored = [p for p in (row["perms"] or "").split(",") if p in ALL_PERMS]
    return set(stored) if row["perms"] else set(ROLES.get(row["role"], {"perms": []})["perms"])


def home_of(perms):
    for key, _, prefixes in MODULES:
        if key in perms:
            return prefixes[0]
    return "/logout"


class App:
    def __init__(self, db, data_dir):
        self.db = db
        self.data_dir = data_dir
        self.routes = []
        self.secret = secrets.token_hex(16)      # CSRF + relace platí do restartu
        self.sessions = {}          # token → {"user": jméno, "role": role, "perms": množina částí programu}
        self.local = threading.local()  # přihlášený uživatel aktuálního požadavku (pro menu a audit)
        self.quit_token = secrets.token_hex(16)
        self.on_quit = None
        self.banners = []           # fn() → HTML lišty nad obsahem (licence, nabídka zálohy na USB)
        self.gate = None            # fn(req) → Response místo stránky (licence jen pro čtení), nebo None

    def route(self, pattern, methods=("GET",)):
        # <…id> = jen číslice (aby /sklad/<iid> nespolkl /sklad/pohyby), ostatní cokoli bez lomítka
        rx = re.compile("^" + re.sub(r"<(\w+)>", lambda m: r"(?P<%s>%s)" % (
            m.group(1), r"\d+" if m.group(1).endswith("id") else "[^/]+"), pattern) + "$")

        def deco(fn):
            self.routes.append((rx, methods, fn))
            return fn
        return deco

    def csrf(self):
        return '<input type="hidden" name="_csrf" value="%s">' % self.secret

    # --- WSGI ---
    def __call__(self, environ, start_response):
        try:
            resp = self.handle(environ)
        except Redirect as r:
            resp = Response("", 302, headers=[("Location", r.url)])
        except HTTPError as e:
            back = ('<p><button class="btn primary" onclick="history.back()">← Zpět k formuláři</button></p>'
                    if e.status == 400 else "")
            resp = Response(self.page("Chyba", "<h1>%s</h1><p>%s</p>%s" % (
                "Zkontrolujte údaje" if e.status == 400 else "Chyba %d" % e.status, h(e.msg), back)), e.status)
        except sqlite3.IntegrityError as e:   # odkaz na smazaný záznam (souběh), duplicita…
            resp = Response(self.page("Chyba", "<h1>Nelze uložit</h1><p>Údaj odkazuje na záznam, který už neexistuje, nebo "
                                      "by vznikl duplicitní záznam – možná ho mezitím změnil někdo jiný. Načtěte stránku "
                                      "znovu.</p><p class=hint>%s</p><p><button class='btn' onclick='history.back()'>← Zpět"
                                      "</button></p>" % h(e)), 409)
        except Exception as e:  # noqa – nic nesmí shodit server
            import traceback
            traceback.print_exc()
            resp = Response(self.page("Chyba", "<h1>Něco se pokazilo</h1><pre>%s</pre>"
                                      "<p>Podrobnosti jsou v souboru firmicka.log ve složce dat.</p>" % h(e)), 500)
        headers = [(k, _latin1(v)) for k, v in resp.headers] + [("X-Frame-Options", "DENY"), ("X-Content-Type-Options", "nosniff"),
                                  ("Referrer-Policy", "same-origin"),
                                  ("Cache-Control", "no-store"), ("Content-Length", str(len(resp.body)))]
        start_response(STATUS.get(resp.status, "%d" % resp.status), headers)
        return [resp.body]

    def handle(self, environ):
        s = self.db.settings()
        host = (environ.get("HTTP_HOST") or "").rsplit(":", 1)[0].strip("[]")
        # ochrana proti DNS rebinding: bez síťového režimu jen localhost
        if s["lan"] != "1" and host not in ("127.0.0.1", "localhost", "::1"):
            raise HTTPError(403, "Přístup ze sítě je vypnutý (Nastavení → Přístup ze sítě).")
        req = Request(environ)
        req.settings = s
        if req.path.startswith("/static/"):
            return self.static(req.path[8:])
        if req.path == "/ping":
            return Response("firmicka", ctype="text/plain")
        if req.method == "POST":
            if not hmac.compare_digest(req.form.get("_csrf", ""), self.secret):
                if req.path == "/quit" and hmac.compare_digest(req.form.get("token", ""), self.quit_token):
                    pass
                else:
                    raise HTTPError(403, "Formulář vypršel – načtěte stránku znovu.")
        # přihlášení: uživatelé s rolemi > jedno heslo (starší režim) > bez hesla (jeden uživatel)
        users = self.db.one("SELECT COUNT(*) FROM users WHERE active = 1")[0]
        sess = self.sessions.get(req.cookies.get("firmicka_session", ""))
        if users or s["password_hash"]:
            if not sess and req.path not in ("/login", "/quit"):
                raise Redirect("/login?next=" + urllib.parse.quote(req.path))
        else:
            sess = {"user": "", "role": "majitel", "perms": set(ALL_PERMS)}
        req.user = sess["user"] if sess else ""
        req.role = sess["role"] if sess else ""
        req.perms = sess["perms"] if sess else set()
        self.local.role, self.local.user, self.local.perms = req.role, req.user, req.perms
        if sess and not allowed(req.perms, req.path):
            home = home_of(req.perms)
            if req.path == "/" and home != "/":
                raise Redirect(home)
            raise HTTPError(403, "Na tuto stránku nemáte oprávnění – požádejte správce o přidělení.")
        if req.method == "POST":
            for k, v in req.form.items():
                v = v.strip()
                if v and DATE_FIELD.search(k):
                    try:
                        ok = len(v) == 10 and 1900 <= datetime.date.fromisoformat(v).year <= 2200
                    except ValueError:
                        ok = False
                    if not ok:
                        raise BadInput("Neplatné datum „%s“ – zadejte ho ve tvaru den. měsíc. rok." % v[:30])
        blocked = self.gate(req) if self.gate else None
        if blocked:
            return blocked
        for rx, methods, fn in self.routes:
            m = rx.match(req.path)
            if m and req.method in methods:
                try:
                    out = fn(req, **m.groupdict())
                except Redirect:
                    self.audit(req)
                    raise
                self.audit(req)
                return out if isinstance(out, Response) else Response(out)
        raise HTTPError(404, "Stránka nenalezena")

    AUDIT_KEYS = ("number", "doc_number", "name", "cust_name", "akce", "stav", "kind", "qty", "direction", "amount",
                  "text", "username", "role", "file", "drive", "to", "title")

    def audit(self, req):
        """Záznam změn: kdo, kdy, co (jen POST; hesla a tokeny se nezapisují)."""
        if req.method != "POST" or req.path in ("/login", "/quit"):
            return
        detail = ", ".join("%s=%s" % (k, req.form[k][:60]) for k in self.AUDIT_KEYS if req.form.get(k))
        try:
            self.db.run("INSERT INTO audit(ts, username, action, detail) VALUES(?,?,?,?)",
                        (int(time.time()), req.user or "", req.path, detail))
        except Exception as e:
            print("audit:", e)

    def static(self, name):
        if "/" in name or "\\" in name or name.startswith("."):
            raise HTTPError(404)
        path = os.path.join(STATIC, name)
        if not os.path.isfile(path):
            raise HTTPError(404)
        ctype = {"css": "text/css", "js": "application/javascript", "svg": "image/svg+xml",
                 "ico": "image/x-icon", "png": "image/png"}.get(name.rsplit(".", 1)[-1], "application/octet-stream")
        with open(path, "rb") as f:
            return Response(f.read(), ctype=ctype + ("; charset=utf-8" if ctype.startswith(("text", "application/j")) else ""))

    # --- šablona ---
    NAV = [("/", "Přehled"), ("/pokladna", "Pokladna"), ("/nabidky", "Nabídky"), ("/zakazky", "Zakázky"), ("/faktury", "Faktury"),
           ("/prijate", "Přijaté"), ("/sklad", "Sklad"),
           ("/banka", "Banka"), ("/denik", "Peněžní deník"),
           ("/adresar", "Adresář"), ("/kalendar", "Kalendář"), ("/nastaveni", "Nastavení")]

    def page(self, title, body, active=""):
        role = getattr(self.local, "role", "") or "majitel"
        user = getattr(self.local, "user", "")
        perms = getattr(self.local, "perms", None)
        perms = set(ALL_PERMS) if perms is None else perms
        nav = "".join('<a href="%s"%s>%s</a>' % (u, ' class="on"' if u == active else "", t) for u, t in self.NAV
                      if allowed(perms, u))
        who = ('<form method="post" action="/logout" class="who">%s<span>%s · %s</span><button class="link">odhlásit</button>'
               '</form>' % (self.csrf(), h(user), ROLES.get(role, {}).get("name", ""))) if user else ""
        quit_btn = ('<form method="post" action="/quit" class="quit" onsubmit="return confirm(\'Ukončit Firmičku? Data jsou '
                    'uložená.\')">%s<button title="Ukončit program">⏻</button></form>' % self.csrf()) if "uzivatele" in perms else ""
        banner = ""
        for fn in (self.banners if title != "Přihlášení" else []):
            try:
                banner += fn()
            except Exception as e:  # lišta nesmí shodit stránku
                print("banner:", e)
        return """<!doctype html><html lang="cs"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>%s · Firmička</title><link rel="stylesheet" href="/static/style.css?v=%s">
<link rel="icon" href="/static/icon.svg"></head><body>
<header class="top"><a class="brand" href="/"><img src="/static/icon.svg" alt="">Firmička</a>
<nav>%s</nav>%s
%s</header>
<main>%s%s</main><script src="/static/app.js?v=%s"></script></body></html>""" % (
            h(title), __version__, nav, who, quit_btn, banner, body, __version__)


def json_response(obj):
    return Response(json.dumps(obj, ensure_ascii=False), ctype="application/json; charset=utf-8")


def _latin1(v):
    """Hlavičky HTTP smí mít jen latin-1 – jinak wsgiref odpověď zahodí (diakritika v čísle dokladu, ?next=…)."""
    try:
        v.encode("latin-1")
        return v
    except UnicodeEncodeError:
        return urllib.parse.quote(v, safe="/:?&=%#;,.@!$'()*+-_~ \"")


def safe_next(url, default="/"):
    """Návrat jen na vlastní stránku: '/…', ne '//host', '/\\host' ani řídicí znaky (prohlížeč z nich udělá cizí web)."""
    if not url or not url.startswith("/") or url.startswith("//") or "\\" in url or any(ord(ch) < 32 for ch in url):
        return default
    return url


def flash_redirect(url, msg):
    sep = "&" if "?" in url else "?"
    raise Redirect(url + sep + "msg=" + urllib.parse.quote(msg))


def flash(req):
    m = req.args.get("msg")
    return '<div class="flash">%s</div>' % h(m) if m else ""
