"""Evidence zakázek (i servisních): zákazník – firma i soukromá osoba jen se jménem a telefonem,
zařízení, výrobní číslo, popis závady, provedená práce, termín, stav. Materiál a práce (řádky) jsou
volitelné. Zakázkový list v PDF = potvrzení o převzetí pro zákazníka. Hotovou zakázku jedním
klikem vyfakturujete (sklad odepíše až faktura, aby se materiál nepočítal dvakrát)."""
import time
from datetime import datetime

from .db import invoice_totals, next_invoice_number, today, now
from . import docs
from .web import h, money, cz_date, flash, flash_redirect, HTTPError, Response

STATUS = {"nova": "Nová", "rozpracovana": "Pracuje se", "ceka_dil": "Čeká na díl", "ceka_zakaznik": "Čeká na zákazníka",
          "hotova": "Hotová – k vyzvednutí", "vyfakturovana": "Vyfakturovaná", "zrusena": "Zrušená"}
TAG = {"nova": "", "rozpracovana": "prace", "ceka_dil": "ceka", "ceka_zakaznik": "ceka", "hotova": "hotovo",
       "vyfakturovana": "zaplacena", "zrusena": "stornovana"}
ACTIVE = ("nova", "rozpracovana", "ceka_dil", "ceka_zakaznik", "hotova")
CONTACT = {"telefon": "telefonicky", "sms": "SMS", "email": "e-mailem", "osobne": "osobně"}
EVENT = {"prijata": "Zakázka přijata", "stav": "Stav", "kontakt": "Kontakt se zákazníkem", "email": "E-mail zákazníkovi",
         "poznamka": "Poznámka", "resi": "Řeší"}


def log(db, jid, user, kind, text=""):
    db.run("INSERT INTO job_events(job_id, ts, user, kind, text) VALUES(?,?,?,?,?)", (jid, int(time.time()), user or "", kind, text))


def events(db, jid):
    return db.q("SELECT * FROM job_events WHERE job_id = ? ORDER BY ts DESC, id DESC", (jid,))


def event_text(e):
    t = EVENT.get(e["kind"], e["kind"])
    return "%s: %s" % (t, e["text"]) if e["text"] else t


def done_mail(s, j):
    subject = "Zakázka %s je hotová%s" % (j["number"], " – " + s["firm_name"] if s["firm_name"] else "")
    what = j["device"] or j["title"]
    addr = ", ".join(x for x in (s["firm_street"], ("%s %s" % (s["firm_zip"], s["firm_city"])).strip()) if x)
    body = ("Dobrý den,\n\nVaše zakázka č. %s%s je hotová a můžete si ji vyzvednout%s.\n"
            "Při vyzvednutí prosím předložte zakázkový list.\n\nS pozdravem\n%s" % (
                j["number"], " (%s)" % what if what else "", " na adrese " + addr if addr else "",
                "\n".join(x for x in (s["firm_name"], s["firm_phone"], s["firm_email"]) if x)))
    return subject, body
TEXT_FIELDS = ("title", "number", "status", "start_date", "deadline", "phone", "email", "device", "serial", "accessories",
               "assigned")
LONG_FIELDS = ("fault", "work_done", "note")


def jlines(db, jid):
    return db.q("SELECT * FROM job_lines WHERE job_id = ? ORDER BY pos", (jid,))


def firm_compact(s):
    """Zhotovitel na zakázkovém listu A5: adresa, IČO/DIČ a kontakty vždy na jednom řádku (šetří výšku listu)."""
    rows = [", ".join(x for x in (s["firm_street"], ("%s %s" % (s["firm_zip"], s["firm_city"])).strip()) if x),
            " · ".join("%s: %s" % (k, v) for k, v in (("IČO", s["firm_ico"]), ("DIČ", s["firm_dic"])) if v),
            " · ".join(x for x in (s["firm_phone"], s["firm_email"], s["firm_web"]) if x)]
    return "<b>%s</b>" % (h(s["firm_name"]) or "<i>Vyplňte údaje firmy v Nastavení</i>") + \
        "".join("<div>%s</div>" % h(r) for r in rows if r)


def register(app):
    db = app.db

    @app.route("/zakazky")
    def index(req):
        st = req.args.get("stav", "aktivni")
        qs = req.args.get("q", "").strip()
        sql, args = "SELECT * FROM jobs WHERE 1", []
        if st == "aktivni":
            sql += " AND status IN (%s)" % ",".join("'%s'" % k for k in ACTIVE)
        elif st in STATUS:
            sql += " AND status = ?"
            args.append(st)
        if qs:   # číslo zakázky, jméno, telefon, zařízení, výrobní číslo
            sql += " AND (number LIKE ? OR cust_name LIKE ? OR phone LIKE ? OR device LIKE ? OR serial LIKE ? OR title LIKE ?)"
            args += ["%" + qs + "%"] * 6
        rows = db.q(sql + " ORDER BY CASE WHEN deadline = '' THEN '9999' ELSE deadline END, id DESC LIMIT 500", args)
        vp = req.settings["vat_payer"] == "1"
        last = {}
        if rows:
            ids = [j["id"] for j in rows]
            for e in db.q("SELECT * FROM job_events WHERE job_id IN (%s) AND kind != 'prijata' ORDER BY ts, id"
                          % ",".join("?" * len(ids)), ids):
                last[e["job_id"]] = e

        def last_txt(j):
            e = last.get(j["id"])
            if not e:
                return ""
            return "%s · %s%s" % (h(event_text(e))[:70], datetime.fromtimestamp(e["ts"]).strftime("%d.%m. %H:%M"),
                                  " · " + h(e["user"]) if e["user"] else "")
        trs = "".join("<tr%s><td><a href='/zakazky/%d'>%s</a></td><td>%s<div class=hint>%s</div></td><td>%s<div class=hint>%s</div></td>"
                      "<td>%s</td><td>%s</td><td class=num>%s</td><td><span class='tag %s'>%s</span><div class=hint>%s</div></td></tr>" % (
                          " class=warn" if j["deadline"] and j["deadline"] < today() and j["status"] in ACTIVE[:4] else "",
                          j["id"], h(j["number"]), h(j["title"] or j["device"]), h((j["fault"] or "")[:80]),
                          h(j["cust_name"]), h(j["phone"]), cz_date(j["deadline"]), h(j["assigned"]),
                          money(invoice_totals(jlines(db, j["id"]), vp)["total"]), TAG[j["status"]], STATUS[j["status"]],
                          last_txt(j))
                      for j in rows)
        ssel = "".join('<option value="%s"%s>%s</option>' % (k, " selected" if k == st else "", v)
                       for k, v in [("aktivni", "Aktivní"), ("", "Všechny")] + list(STATUS.items()))
        return app.page("Zakázky", """%s<div class="bar"><h1>Zakázky</h1>
<a class="btn primary" href="/zakazky/nova">+ Nová zakázka</a></div>
<form class="filters"><input name="q" value="%s" placeholder="Číslo, jméno, telefon, zařízení…" autofocus>
<select name="stav" onchange="this.form.submit()">%s</select><button>Hledat</button></form>
<table class="list"><thead><tr><th>Číslo</th><th>Zakázka / závada</th><th>Zákazník</th><th>Termín</th><th>Řeší</th>
<th class=num>Hodnota</th><th>Stav / poslední záznam</th></tr></thead><tbody>%s</tbody></table>%s""" % (
            flash(req), h(qs), ssel, trs, "" if rows else "<p class=empty>Žádné zakázky.</p>"), "/zakazky")

    def form(req, j, lines, jid=None, err=""):
        vp = req.settings["vat_payer"] == "1"
        stsel = "".join('<option value="%s"%s>%s</option>' % (k, " selected" if k == j.get("status", "nova") else "", v)
                        for k, v in STATUS.items() if k != "vyfakturovana" or j.get("status") == "vyfakturovana")
        return app.page("Zakázka", """<h1>%s</h1>%s<form method="post" id="invoice" data-vat="%d">%s
<div class="grid">
<label>Číslo zakázky<input name="number" value="%s" required>%s</label>
<label>Stav<select name="status">%s</select></label>
<label>Přijato<input type="date" name="start_date" value="%s"></label>
<label>Termín<input type="date" name="deadline" value="%s"></label>
<label>Řeší<input name="assigned" value="%s" list="workers" placeholder="kdo na zakázce pracuje"></label>%s
%s
<label>Telefon<input name="phone" value="%s" type="tel"></label>
<label>E-mail<input name="email" value="%s" type="email"></label>
<section class="card wide"><h2>Zařízení a závada</h2><div class="grid">
<label class="wide">Název zakázky / zařízení<input name="title" value="%s" placeholder="např. Notebook Lenovo, oprava plotu…"></label>
<label>Zařízení / typ<input name="device" value="%s"></label>
<label>Výrobní číslo<input name="serial" value="%s"></label>
<label class="wide">Příslušenství převzato<input name="accessories" value="%s" placeholder="např. nabíječka, obal"></label>
<label class="wide">Popis závady (co zákazník uvádí)<textarea name="fault" rows="3">%s</textarea></label>
<label class="wide">Provedená práce<textarea name="work_done" rows="3">%s</textarea></label>
</div></section></div>
<details%s><summary><b>Materiál a práce (nepovinné)</b> – co se pak vyfakturuje</summary>%s</details>
<label class="wide">Interní poznámka<textarea name="note" rows="2">%s</textarea></label>
<div class="actions"><button class="btn primary">Uložit zakázku</button><a class="btn" href="%s">Zrušit</a></div></form>""" % (
            "Upravit zakázku %s" % h(j["number"]) if jid else "Nová zakázka",
            '<div class="flash error">%s</div>' % h(err) if err else "", 1 if vp else 0, app.csrf(),
            h(j["number"]), "" if jid else docs.auto_number_input(j, date_field=""), stsel, h(j.get("start_date")), h(j.get("deadline")), h(j.get("assigned")), workers_list(),
            docs.customer_box(db, j, "Zákazník (stačí jméno a telefon)"), h(j.get("phone")), h(j.get("email")),
            h(j.get("title")), h(j.get("device")), h(j.get("serial")), h(j.get("accessories")), h(j.get("fault")),
            h(j.get("work_done")), " open" if lines else "", docs.lines_editor(db, lines, vp), h(j.get("note")),
            "/zakazky/%s" % jid if jid else "/zakazky"), "/zakazky")

    def workers_list():
        names = [u["name"] or u["username"] for u in db.q("SELECT * FROM users WHERE active = 1 ORDER BY name, username")]
        names += [r["assigned"] for r in db.q("SELECT DISTINCT assigned FROM jobs WHERE assigned != ''")]
        return '<datalist id="workers">%s</datalist>' % "".join('<option value="%s">' % h(n) for n in dict.fromkeys(names))

    def read(req):
        j = docs.read_customer(req)
        j.update({k: req.f(k) for k in TEXT_FIELDS})
        j.update({k: req.form.get(k, "").strip() for k in LONG_FIELDS})
        if j["status"] not in STATUS:
            j["status"] = "nova"
        return j, docs.read_lines(req, req.settings["vat_payer"] == "1")

    def validate(j, jid=None):
        if not j["cust_name"] or not j["number"]:
            return "Vyplňte zákazníka a číslo zakázky"
        if db.one("SELECT id FROM jobs WHERE number = ? AND id != ?", (j["number"], jid or 0)):
            return "Zakázka %s už existuje" % j["number"]
        return ""

    COLS = ("number", "title", "contact_id", "cust_name", "cust_address", "cust_ico", "cust_dic", "status", "start_date",
            "deadline", "note", "phone", "email", "device", "serial", "accessories", "fault", "work_done", "assigned")

    def save(j, lines, jid=None, user=""):
        old = db.one("SELECT status, assigned FROM jobs WHERE id = ?", (jid,)) if jid else None
        with db.tx():
            j["contact_id"] = docs.save_contact(db, j)
            if j["contact_id"] and (j["phone"] or j["email"]):   # doplnit kontakt v adresáři
                db.run("UPDATE contacts SET phone = CASE WHEN phone = '' THEN ? ELSE phone END, "
                       "email = CASE WHEN email = '' THEN ? ELSE email END WHERE id = ?", (j["phone"], j["email"], j["contact_id"]))
            j["title"] = j["title"] or j["device"] or "Zakázka"
            vals = tuple(j[c] for c in COLS)
            if jid:
                db.run("UPDATE jobs SET %s WHERE id = ?" % ", ".join(c + "=?" for c in COLS), vals + (jid,))
            else:
                jid = db.run("INSERT INTO jobs(%s, created) VALUES(%s)" % (", ".join(COLS), ",".join("?" * (len(COLS) + 1))),
                             vals + (now(),))
                log(db, jid, user, "prijata")
            if old and old["status"] != j["status"] or not old and j["status"] != "nova":
                log(db, jid, user, "stav", STATUS[j["status"]])
            if (old["assigned"] if old else "") != j["assigned"] and j["assigned"]:
                log(db, jid, user, "resi", j["assigned"])
            docs.write_lines(db, "job_lines", "job_id", jid, lines)
        return jid

    def get(jid):
        j = db.one("SELECT * FROM jobs WHERE id = ?", (jid,))
        if not j:
            raise HTTPError(404, "Zakázka neexistuje")
        return j

    @app.route("/zakazky/nova", ("GET", "POST"))
    def new(req):
        if req.method == "POST":
            j, lines = read(req)
            with db.lock:   # kontrola čísla/zálohy a zápis naráz (souběh více uživatelů)
                j["number"], num_msg = docs.auto_number(db, req, j["number"], today(), req.settings["job_format"], "jobs")
                j["number_auto"] = j["number"] if num_msg else req.f("number_auto")
                err = validate(j)
                if err:
                    return form(req, j, lines, err=err)
                jid = save(j, lines, user=getattr(req, "user", ""))
            flash_redirect("/zakazky/%d" % jid, "Zakázka %s založena – vytiskněte zákazníkovi zakázkový list" % j["number"] +
                           (" · " + num_msg if num_msg else ""))
        from .contacts import prefill
        return form(req, dict(prefill(db, req), number=next_invoice_number(db, today(), req.settings["job_format"], "jobs"),
                              start_date=today(), status="nova"), [])

    @app.route("/zakazky/<jid>/upravit", ("GET", "POST"))
    def edit(req, jid):
        j = get(jid)
        if j["status"] == "vyfakturovana":
            flash_redirect("/zakazky/%d" % j["id"], "Vyfakturovanou zakázku už nejde měnit")
        if req.method == "POST":
            nj, lines = read(req)
            with db.lock:   # kontrola čísla/zálohy a zápis naráz (souběh více uživatelů)
                err = validate(nj, j["id"])
                if err:
                    return form(req, nj, lines, j["id"], err)
                save(nj, lines, j["id"], getattr(req, "user", ""))
            flash_redirect("/zakazky/%d" % j["id"], "Uloženo")
        d = dict(j)
        if d["contact_id"]:
            d["save_contact"] = ""
        return form(req, d, [dict(ln) for ln in jlines(db, j["id"])], j["id"])

    @app.route("/zakazky/<jid>/stav", ("POST",))
    def set_status(req, jid):
        j = get(jid)
        st = req.f("stav")
        if st not in STATUS or st == "vyfakturovana" or j["status"] == "vyfakturovana":
            raise HTTPError(400, "Stav nejde změnit")
        note = req.f("pozn")
        with db.tx():
            db.run("UPDATE jobs SET status = ? WHERE id = ?", (st, j["id"]))
            if st != j["status"] or note:
                log(db, j["id"], getattr(req, "user", ""), "stav", STATUS[st] + (" – " + note if note else ""))
        flash_redirect("/zakazky/%d" % j["id"], "Stav: %s" % STATUS[st])

    @app.route("/zakazky/<jid>/zaznam", ("POST",))
    def add_event(req, jid):
        j = get(jid)
        kind, how, text = req.f("kind"), req.f("jak"), req.f("text")
        if kind == "kontakt":
            text = ", ".join(x for x in (CONTACT.get(how, ""), text) if x)
        elif kind != "poznamka" or not text:
            flash_redirect("/zakazky/%d" % j["id"], "Napište poznámku")
        log(db, j["id"], getattr(req, "user", ""), kind, text)
        flash_redirect("/zakazky/%d#historie" % j["id"], "Zapsáno")

    @app.route("/zakazky/<jid>/hotovo", ("GET", "POST"))
    def done_email(req, jid):
        from .mail import eml
        from .reminders import send_mail
        j, s = get(jid), req.settings
        subject, body = done_mail(s, j)
        if req.method == "POST":
            to, subject, body = req.f("to"), req.f("subject") or subject, req.form.get("body", body)
            user = getattr(req, "user", "")
            if req.f("akce") == "eml":
                with db.tx():
                    log(db, j["id"], user, "email", "hotovo k vyzvednutí (rozepsáno v poštovním programu)%s" % (" – " + to if to else ""))
                return Response(eml(s, to, subject, body, []), ctype="message/rfc822", headers=[
                    ("Content-Disposition", 'attachment; filename="zakazka-%s.eml"' %
                     "".join(c for c in j["number"] if c.isalnum() or c in "-_"))])
            if "@" not in to:
                flash_redirect("/zakazky/%d/hotovo" % j["id"], "Zadejte e-mail zákazníka")
            try:
                send_mail(s, to, subject, body)
            except Exception as e:
                flash_redirect("/zakazky/%d/hotovo" % j["id"], "Odeslání selhalo: %s" % e)
            with db.tx():
                if not j["email"]:
                    db.run("UPDATE jobs SET email = ? WHERE id = ?", (to, j["id"]))
                if j["status"] in ACTIVE and j["status"] != "hotova":
                    db.run("UPDATE jobs SET status = 'hotova' WHERE id = ?", (j["id"],))
                    log(db, j["id"], user, "stav", STATUS["hotova"])
                log(db, j["id"], user, "email", "hotovo k vyzvednutí – " + to)
            flash_redirect("/zakazky/%d" % j["id"], "Zákazníkovi odesláno na %s" % to)
        smtp = bool(s["smtp_host"])
        return app.page("Hotovo k vyzvednutí", """%s<div class="bar"><a href="/zakazky/%d">← Zpět</a></div>
<h1>Hotovo k vyzvednutí – %s</h1>
<form method="post" class="grid">%s
<label class="wide">Komu<input name="to" type="email" value="%s"></label>
<label class="wide">Předmět<input name="subject" value="%s"></label>
<label class="wide">Text<textarea name="body" rows="10">%s</textarea></label>
<div class="actions wide"><button class="btn primary" name="akce" value="poslat"%s>Odeslat</button>
<button class="btn" name="akce" value="eml" formnovalidate>Otevřít v poštovním programu</button></div>
<p class="wide hint">Po odeslání se zakázka přepne na „Hotová – k vyzvednutí“ a zapíše se do historie.%s</p>
</form>""" % (flash(req), j["id"], h(j["number"]), app.csrf(), h(j["email"]), h(subject), h(body),
              "" if smtp else " disabled title='Nastavte odchozí e-mail v Nastavení'",
              "" if smtp else " Pro přímé odeslání nastavte <a href='/nastaveni#email'>odchozí e-mail</a>."), "/zakazky")

    @app.route("/zakazky/<jid>/smazat", ("POST",))
    def delete(req, jid):
        j = get(jid)
        if j["invoice_id"]:
            flash_redirect("/zakazky/%d" % j["id"], "Vyfakturovanou zakázku nejde smazat")
        with db.tx():
            db.run("UPDATE quotes SET job_id = NULL WHERE job_id = ?", (j["id"],))
            db.run("DELETE FROM jobs WHERE id = ?", (j["id"],))
        flash_redirect("/zakazky", "Zakázka %s smazána" % j["number"])

    @app.route("/zakazky/<jid>/pdf")
    def ticket(req, jid):
        from . import pdfdoc
        j = get(jid)
        return Response(pdfdoc.job_pdf(j, jlines(db, j["id"]), req.settings, app.data_dir), ctype="application/pdf",
                        headers=[("Content-Disposition", 'inline; filename="zakazka-%s.pdf"' %
                                  "".join(c for c in j["number"] if c.isalnum() or c in "-_"))])

    @app.route("/zakazky/<jid>/tisk")
    def print_page(req, jid):
        # tisk z HTML (PDF v rámu tiskne Safari a část Chrome prázdné) – formát A5 na výšku, okno tisku hned
        from . import images
        j, s = get(jid), req.settings
        lines = jlines(db, j["id"])
        vp = s["vat_payer"] == "1"
        cust = [h(j["cust_name"])] + [h(x) for x in (j["cust_address"] or "").split("\n") if x]
        cust += ["Tel.: " + h(j["phone"])] if j["phone"] else []
        cust += [h(j["email"])] if j["email"] else []
        cust += ["IČO: " + h(j["cust_ico"])] if j["cust_ico"] else []
        info = [(k, v) for k, v in (("Číslo zakázky", j["number"]), ("Přijato", cz_date(j["start_date"])),
                                    ("Termín", cz_date(j["deadline"])), ("Zakázka", j["title"]),
                                    ("Zařízení / typ", j["device"]), ("Výrobní číslo", j["serial"]),
                                    ("Stav", STATUS.get(j["status"], ""))) if v]
        texts = "".join("<h3>%s</h3><p>%s</p>" % (k, h(v).replace("\n", "<br>"))
                        for k, v in (("Příslušenství převzato", j["accessories"]), ("Popis závady", j["fault"]),
                                     ("Provedená práce", j["work_done"])) if v)
        table = ""
        if lines:
            table = docs.lines_table(lines, vp)[0].replace("<span>Celkem", "<span>Předpokládaná cena", 1)
        sig = images.inline(app.data_dir, "podpis") + images.inline(app.data_dir, "razitko")
        page = """<!doctype html><html lang="cs"><head><meta charset="utf-8"><title>Zakázkový list %s</title>
<style>
@page { size: A5 portrait; margin: 9mm; }
* { box-sizing: border-box; }
body { margin: 0; font: 9pt/1.35 "DejaVu Sans", Arial, sans-serif; color: #000; background: #e9ebef; }
.sheet { width: 148mm; min-height: 210mm; margin: 12px auto; padding: 9mm; background: #fff; box-shadow: 0 1px 6px #0003; }
.tools { text-align: center; padding: 10px; font-family: system-ui, sans-serif; font-size: 14px; }
.tools button, .tools a { font: inherit; margin: 0 6px; padding: 6px 14px; border-radius: 6px; border: 1px solid #889;
  background: #fff; color: #123; text-decoration: none; cursor: pointer; display: inline-block; white-space: nowrap;
  line-height: 1.3; margin-block: 3px; }
.tools button { background: #2f6fde; color: #fff; border-color: #2f6fde; }
.head { display: flex; justify-content: space-between; align-items: flex-start; gap: 4mm; }
.head img.logo { max-height: 11mm; max-width: 40mm; }
h1 { font-size: 14pt; margin: 0; } .sub { color: #666; font-size: 7.5pt; }
.parties { display: flex; gap: 6mm; margin: 3mm 0; } .parties > div { flex: 1; min-width: 0; }
.firm { font-size: 7.5pt; line-height: 1.3; } .firm b { font-size: 8.5pt; }
.lbl, h3 { font-size: 6.5pt; text-transform: uppercase; letter-spacing: .04em; color: #666; margin: 0 0 1mm;
  border-bottom: 1px solid #000; padding-bottom: .6mm; }
h3 { border: 0; margin: 2.5mm 0 .5mm; } p { margin: 0; }
.info { display: grid; grid-template-columns: repeat(4, 1fr); gap: 1.5mm 3mm; background: #f1f1f1; padding: 2mm 3mm;
  -webkit-print-color-adjust: exact; print-color-adjust: exact; }
.info span { display: block; font-size: 6.5pt; color: #666; } .info b { font-size: 8.5pt; overflow-wrap: anywhere; }
table { width: 100%%; border-collapse: collapse; margin-top: 3mm; font-size: 8pt; }
th { text-align: left; font-size: 6.5pt; color: #555; border-bottom: 1px solid #000; padding: 1mm 0 1mm 2mm; vertical-align: bottom; }
td { border-bottom: 1px solid #ddd; padding: 1mm 0 1mm 2mm; }
th:first-child, td:first-child { padding-left: 0; } th.num { white-space: normal; } .num { text-align: right; white-space: nowrap; }
tr.fee td { color: #666; font-size: 7pt; }
.sum { display: flex; justify-content: flex-end; gap: 4mm; margin-top: 2mm; }
.sum table.recap { width: auto; margin: 0; }
.topay { background: #111; color: #fff; padding: 1.5mm 3mm; text-align: right; -webkit-print-color-adjust: exact;
  print-color-adjust: exact; } .topay span { display: block; font-size: 6.5pt; color: #ccc; } .topay b { font-size: 11pt; }
.terms { margin-top: 3mm; font-size: 7pt; color: #333; }
.sign { display: flex; justify-content: space-between; align-items: flex-end; gap: 10mm; margin-top: 4mm;
  break-inside: avoid; }
.sign > div { flex: 1; text-align: center; font-size: 6.5pt; color: #666; position: relative; }
.sign .line { border-top: 1px solid #888; padding-top: 1mm; }
.sign .marks { height: 13mm; display: flex; justify-content: center; align-items: flex-end; gap: 2mm; }
.sign .marks img { max-height: 13mm; max-width: 30mm; }
.end { break-inside: avoid; }
.sign .marks:empty { height: 9mm; }
.foot { margin-top: 3mm; break-inside: avoid; border-top: 1px solid #ccc; padding-top: 1mm; font-size: 6.5pt; color: #666; }
@media print { body { background: #fff; } .tools { display: none; }
  .sheet { width: auto; min-height: 0; margin: 0; padding: 0; box-shadow: none; } }
</style></head><body>
<div class="tools">Zakázkový list se tiskne na formát A5. <button onclick="print()">Tisknout</button>
<a href="/zakazky/%d/tisk?a4=2">2× na A4</a> <a href="/zakazky/%d/pdf">PDF</a> <a href="/zakazky/%d">← Zpět na zakázku</a></div>
<div class="sheet">
<div class="head"><div><h1>Zakázkový list %s</h1><div class="sub">potvrzení o převzetí zakázky</div></div>%s</div>
<div class="parties"><div class="firm"><div class="lbl">Zhotovitel</div>%s</div><div><div class="lbl">Zákazník</div>%s</div></div>
<div class="info">%s</div>
%s%s
<div class="end"><div class="terms">%s</div>
<div class="sign"><div><div class="marks"></div><div class="line">Zákazník (podpis)</div></div>
<div><div class="marks">%s</div><div class="line">Vystavil%s</div></div></div>
<div class="foot">%s</div></div>
</div>
<script>window.addEventListener("load", function () { setTimeout(function () { window.print(); }, 300); });</script>
</body></html>""" % (
            h(j["number"]), j["id"], j["id"], j["id"], h(j["number"]), images.inline(app.data_dir, "logo"),
            firm_compact(s), "<b>%s</b>" % cust[0] + "".join("<br>" + x for x in cust[1:]),
            "".join("<div><span>%s</span><b>%s</b></div>" % (k, h(v)) for k, v in info), texts, table,
            h(s["job_terms"]).replace("\n", "<br>"), sig,
            (": " + h(s["invoice_issuer"])) if s["invoice_issuer"] else " (razítko a podpis)",
            " · ".join(h(x) for x in (s["firm_register"], "Při vyzvednutí předložte tento list.",
                                       "Vystaveno programem Firmička") if x))
        if req.args.get("a4") != "2":
            return page
        return two_up(page, j["id"])

    def two_up(page, jid):
        """Dva stejné listy A5 vedle sebe na A4 na šířku (pro zákazníka + pro servis), k rozstřižení."""
        head, rest = page.split('<div class="sheet">', 1)
        sheet, tail = rest.rsplit("</div>\n<script>", 1)
        sub = '<div class="sub">potvrzení o převzetí zakázky'

        def copy(label):
            return '<div class="sheet">' + sheet.replace(sub, sub + " · " + label, 1) + "</div>"
        head = head.replace("@page { size: A5 portrait; margin: 9mm; }", "@page { size: A4 landscape; margin: 0; }")
        head = head.replace("</style>", """.pair { display: flex; width: 297mm; margin: 12px auto; background: #fff; box-shadow: 0 1px 6px #0003; }
.pair .sheet { width: 148.5mm; height: 209.5mm; min-height: 0; margin: 0; padding: 9mm; box-shadow: none; overflow: hidden; }
.pair .sheet + .sheet { border-left: 1px dashed #aaa; }
.warn { color: #b00; font-weight: 600; }
@media print { body { margin: 0; } .pair { margin: 0; box-shadow: none; width: 297mm; }
  .pair .sheet { width: 148.5mm; height: 209.5mm; padding: 9mm; } }
</style>""")
        head = head.replace('<div class="tools">Zakázkový list se tiskne na formát A5. ',
                            '<div class="tools">Dva zakázkové listy na jeden papír A4 (na šířku) – po vytištění rozstřihněte. '
                            '<span id="over" class="warn" hidden>Zakázka se nevejde na půl A4, použijte tisk A5.</span> ')
        head = head.replace('<a href="/zakazky/%d/tisk?a4=2">2× na A4</a>' % jid, '<a href="/zakazky/%d/tisk">Jen A5</a>' % jid)
        tail = tail.replace("window.print();", "if (over()) return; window.print();")
        head = head.replace('<button onclick="print()">Tisknout</button>',
                            '<button onclick="if (!over()) print()">Tisknout</button>')   # useknutý list netisknout
        return (head + '<div class="pair">' + copy("pro zákazníka") + copy("pro servis") + "</div>\n"
                + "<script>function over() { var s = document.querySelector('.sheet'); var o = s.scrollHeight > s.clientHeight + 2;"
                + " document.getElementById('over').hidden = !o; return o; }</script>\n<script>" + tail)

    @app.route("/zakazky/<jid>/listek", ("POST",))
    def ticket_slip(req, jid):
        from .pos import escpos, print_raw
        j = get(jid)
        s = req.settings
        width = int(s["printer_width"] or 48)
        rows = [("C", s["firm_name"] or "Zakázka", True)]
        if s["firm_phone"]:
            rows.append(("C", "tel. " + s["firm_phone"], False))
        rows += [("L", "-" * width, False), ("C", "ZAKÁZKA č. %s" % j["number"], True),
                 ("C", "přijato %s" % cz_date(j["start_date"]).replace("\u00a0", " "), False), ("L", "-" * width, False)]

        def wrap(label, text):
            text = "%s: %s" % (label, text)
            while text:
                rows.append(("L", text[:width], False))
                text = text[width:]
        for label, val in (("Zákazník", j["cust_name"]), ("Telefon", j["phone"]), ("Zařízení", j["device"] or j["title"]),
                           ("Výr. číslo", j["serial"]), ("Příslušenství", j["accessories"]), ("Závada", j["fault"]),
                           ("Termín", cz_date(j["deadline"]).replace("\u00a0", " "))):
            if val:
                wrap(label, val.replace("\n", " "))
        rows += [("L", "-" * width, False), ("C", "Při vyzvednutí předložte tento lístek.", False)]
        try:
            print_raw(s, escpos(rows, s["printer_codepage"]))
        except Exception as e:
            flash_redirect("/zakazky/%d" % j["id"], "Tisk lístku selhal: %s" % e)
        flash_redirect("/zakazky/%d" % j["id"], "Lístek vytištěn")

    @app.route("/zakazky/<jid>")
    def detail(req, jid):
        j = get(jid)
        vp = req.settings["vat_payer"] == "1"
        lines = jlines(db, j["id"])
        table, t = docs.lines_table(lines, vp)
        from .db import item_costs
        costs = item_costs(db)
        cost = sum(round(ln["qty"] * costs.get(ln["item_id"], (0, 0))[1]) for ln in lines if ln["item_id"])
        actions = ['<a class="btn primary" href="/zakazky/%d/tisk" target="_blank">Tisk zakázkového listu</a>' % j["id"],
                   '<a class="btn" href="/zakazky/%d/tisk?a4=2" target="_blank" title="Dva listy A5 na jeden papír A4 – pro zákazníka a pro servis">'
                   'Tisk 2× na A4</a>' % j["id"],
                   '<a class="btn" href="/zakazky/%d/pdf" target="_blank">PDF</a>' % j["id"]]
        if req.settings["printer_host"]:
            actions.append('<form method="post" action="/zakazky/%d/listek" class="inline">%s<button class="btn">'
                           'Lístek na pokladní tiskárnu</button></form>' % (j["id"], app.csrf()))
        if j["status"] != "vyfakturovana":
            actions.append('<a class="btn" href="/zakazky/%d/upravit">Upravit</a>' % j["id"])
            actions.append('<a class="btn" href="/zakazky/%d/hotovo">Hotovo – poslat zákazníkovi</a>' % j["id"])
            actions.append('<a class="btn ok" href="/faktury/nova?zakazka=%d">Vyfakturovat</a>' % j["id"])
            actions.append('<form method="post" action="/zakazky/%d/smazat" class="inline" onsubmit="return confirm('
                           '\'Smazat zakázku?\')">%s<button class="link danger">smazat</button></form>' % (j["id"], app.csrf()))
        elif j["invoice_id"]:
            actions.append('<a class="btn" href="/faktury/%d">→ Faktura</a>' % j["invoice_id"])
        if j["quote_id"]:
            actions.append('<a class="btn" href="/nabidky/%d">← Nabídka</a>' % j["quote_id"])
        info = [("Zákazník", h(j["cust_name"])), ("Telefon", h(j["phone"])), ("E-mail", h(j["email"])),
                ("Stav", STATUS[j["status"]]), ("Řeší", h(j["assigned"])), ("Přijato", cz_date(j["start_date"])),
                ("Termín", cz_date(j["deadline"])),
                ("Zařízení", h(j["device"])), ("Výrobní číslo", h(j["serial"])), ("Příslušenství", h(j["accessories"])),
                ("Hodnota", money(t["total"]) if lines else "")]
        if cost:
            info.append(("Materiál v nákupu", money(cost)))
        texts = "".join("<section class='card'><h2>%s</h2><p>%s</p></section>" % (k, h(v).replace("\n", "<br>"))
                        for k, v in (("Popis závady", j["fault"]), ("Provedená práce", j["work_done"]),
                                     ("Interní poznámka", j["note"])) if v)
        hist = "".join("<li><span class=hint>%s%s</span> %s</li>" % (
            datetime.fromtimestamp(e["ts"]).strftime("%d.%m.%Y %H:%M"), " · " + h(e["user"]) if e["user"] else "",
            h(event_text(e))) for e in events(db, j["id"]))
        tools = ""
        if j["status"] != "vyfakturovana":
            stsel = "".join('<option value="%s"%s>%s</option>' % (k, " selected" if k == j["status"] else "", v)
                            for k, v in STATUS.items() if k != "vyfakturovana")
            how = "".join('<option value="%s">%s</option>' % kv for kv in CONTACT.items())
            tools = """<div class="cols">
<form method="post" action="/zakazky/%d/stav" class="card">%s<h2>Změnit stav</h2>
<label>Stav<select name="stav">%s</select></label>
<label>Poznámka<input name="pozn" placeholder="např. objednán displej, dorazí v pátek"></label>
<button class="btn">Uložit stav</button></form>
<form method="post" action="/zakazky/%d/zaznam" class="card">%s<input type="hidden" name="kind" value="kontakt">
<h2>Kontaktoval jsem zákazníka</h2><label>Jak<select name="jak">%s</select></label>
<label>Výsledek<input name="text" placeholder="např. souhlasí s cenou 1 500 Kč / nebere telefon"></label>
<button class="btn">Zapsat kontakt</button></form>
<form method="post" action="/zakazky/%d/zaznam" class="card">%s<input type="hidden" name="kind" value="poznamka">
<h2>Poznámka do historie</h2><label>Text<input name="text" required></label>
<button class="btn">Zapsat</button></form></div>""" % (
                j["id"], app.csrf(), stsel, j["id"], app.csrf(), how, j["id"], app.csrf())
        return app.page("Zakázka " + j["number"], """%s<div class="bar"><a href="/zakazky">← Zakázky</a>
<div class="actions">%s</div></div><h1>%s – %s</h1>
<div class="stats">%s</div>%s%s%s
<section class="card" id="historie"><h2>Historie</h2><ul class="history">%s</ul></section>""" % (
            flash(req), "".join(actions), h(j["number"]), h(j["title"]),
            "".join("<div><span>%s</span><b class=small>%s</b></div>" % kv for kv in info if kv[1]), tools, texts,
            "<section class='card'><h2>Materiál a práce</h2><div class='invoice' style='box-shadow:none;padding:0'>%s</div>"
            "</section>" % table if lines else "<p class=hint>Zatím bez materiálu a práce – doplníte přes Upravit.</p>",
            hist or "<li class=hint>Zatím nic.</li>"),
            "/zakazky")
