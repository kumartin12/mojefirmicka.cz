"""Cenové nabídky: tisk / PDF jako faktura, stav (koncept → odeslaná → přijatá / odmítnutá),
z přijaté nabídky jedním klikem zakázka nebo faktura."""
from datetime import date, timedelta

from . import docs, images
from .db import next_invoice_number, today, now
from .web import h, money, cz_date, flash, flash_redirect, HTTPError, Response

STATUS = {"koncept": "Koncept", "odeslana": "Odeslaná", "prijata": "Přijatá", "odmitnuta": "Odmítnutá"}
TAG = {"koncept": "", "odeslana": "vystavena", "prijata": "zaplacena", "odmitnuta": "stornovana"}


def qlines(db, qid):
    return db.q("SELECT * FROM quote_lines WHERE quote_id = ? ORDER BY pos", (qid,))


def register(app):
    db = app.db

    @app.route("/nabidky")
    def index(req):
        st = req.args.get("stav", "")
        sql, args = "SELECT * FROM quotes", ()
        if st in STATUS:
            sql, args = sql + " WHERE status = ?", (st,)
        rows = db.q(sql + " ORDER BY issue_date DESC, id DESC LIMIT 500", args)
        from .db import invoice_totals
        trs = "".join("<tr><td><a href='/nabidky/%d'>%s</a></td><td>%s</td><td>%s</td><td>%s</td><td class=num>%s</td>"
                      "<td><span class='tag %s'>%s</span></td></tr>" % (
                          q["id"], h(q["number"]), h(q["cust_name"]), h(q["title"]), cz_date(q["valid_until"]),
                          money(invoice_totals(qlines(db, q["id"]), q["vat_payer"])["total"]),
                          TAG[q["status"]], STATUS[q["status"]]) for q in rows)
        ssel = "".join('<option value="%s"%s>%s</option>' % (k, " selected" if k == st else "", v)
                       for k, v in [("", "Všechny")] + list(STATUS.items()))
        return app.page("Nabídky", """%s<div class="bar"><h1>Cenové nabídky</h1>
<a class="btn primary" href="/nabidky/nova">+ Nová nabídka</a></div>
<form class="filters"><select name="stav" onchange="this.form.submit()">%s</select></form>
<table class="list"><thead><tr><th>Číslo</th><th>Odběratel</th><th>Předmět</th><th>Platnost do</th><th class=num>Celkem</th>
<th>Stav</th></tr></thead><tbody>%s</tbody></table>%s""" % (
            flash(req), ssel, trs, "" if rows else "<p class=empty>Zatím žádné nabídky.</p>"), "/nabidky")

    def form(req, q, lines, qid=None, err=""):
        vp = q.get("vat_payer", req.settings["vat_payer"] == "1") if qid else req.settings["vat_payer"] == "1"
        return app.page("Nabídka", """<h1>%s</h1>%s<form method="post" id="invoice" data-vat="%d">%s
<div class="grid">%s
<label class="wide">Předmět nabídky<input name="title" value="%s" placeholder="např. Rekonstrukce koupelny"></label>
<label>Číslo<input name="number" value="%s" required>%s</label>
<label>Datum<input type="date" name="issue_date" value="%s" required></label>
<label>Platná do<input type="date" name="due_date" value="%s" required></label></div>
%s<label class="wide">Poznámka / podmínky<textarea name="note" rows="3">%s</textarea></label>
<div class="actions"><button class="btn primary">Uložit nabídku</button><a class="btn" href="%s">Zrušit</a></div></form>""" % (
            "Upravit nabídku %s" % h(q["number"]) if qid else "Nová nabídka",
            '<div class="flash error">%s</div>' % h(err) if err else "", 1 if vp else 0, app.csrf(),
            docs.customer_box(db, q), h(q.get("title")), h(q["number"]),
            "" if qid else docs.auto_number_input(q, series="nabidka"), h(q["issue_date"]), h(q["valid_until"]),
            docs.lines_editor(db, lines, vp), h(q.get("note")), "/nabidky/%s" % qid if qid else "/nabidky"), "/nabidky")

    def read(req, vp):
        q = docs.read_customer(req)
        q.update({k: req.f(k) for k in ("title", "number", "issue_date")})
        q["valid_until"] = req.f("due_date")
        q["note"] = req.form.get("note", "").strip()
        return q, docs.read_lines(req, vp)

    def validate(q, lines, qid=None):
        if not q["cust_name"] or not q["number"]:
            return "Vyplňte odběratele a číslo"
        if not lines:
            return "Nabídka musí mít aspoň jednu položku"
        if db.one("SELECT id FROM quotes WHERE number = ? AND id != ?", (q["number"], qid or 0)):
            return "Nabídka %s už existuje" % q["number"]
        try:
            date.fromisoformat(q["issue_date"])
            date.fromisoformat(q["valid_until"])
        except ValueError:
            return "Neplatné datum"
        return ""

    def save(q, lines, vp, qid=None):
        with db.tx():
            cid = docs.save_contact(db, q)
            vals = (cid, q["cust_name"], q["cust_address"], q["cust_ico"], q["cust_dic"], q["title"], q["number"],
                    q["issue_date"], q["valid_until"], q["note"])
            cols = "contact_id, cust_name, cust_address, cust_ico, cust_dic, title, number, issue_date, valid_until, note"
            if qid:
                db.run("UPDATE quotes SET %s WHERE id = ?" % ", ".join(c.strip() + "=?" for c in cols.split(",")), vals + (qid,))
            else:
                qid = db.run("INSERT INTO quotes(%s, vat_payer, created) VALUES(%s)" % (cols, ",".join("?" * (len(vals) + 2))),
                             vals + (1 if vp else 0, now()))
            docs.write_lines(db, "quote_lines", "quote_id", qid, lines)
        return qid

    def get(qid):
        q = db.one("SELECT * FROM quotes WHERE id = ?", (qid,))
        if not q:
            raise HTTPError(404, "Nabídka neexistuje")
        return q

    @app.route("/nabidky/cislo")
    def number_for_date(req):
        try:
            d = date.fromisoformat(req.args.get("datum", "")).isoformat()
        except ValueError:
            raise HTTPError(400)
        return Response(next_invoice_number(db, d, req.settings["quote_format"], "quotes"), ctype="text/plain; charset=utf-8")

    @app.route("/nabidky/nova", ("GET", "POST"))
    def new(req):
        vp = req.settings["vat_payer"] == "1"
        if req.method == "POST":
            q, lines = read(req, vp)
            with db.lock:   # kontrola čísla/zálohy a zápis naráz (souběh více uživatelů)
                q["number"], num_msg = docs.auto_number(db, req, q["number"], q["issue_date"], req.settings["quote_format"], "quotes")
                q["number_auto"] = q["number"] if num_msg else req.f("number_auto")
                err = validate(q, lines)
                if err:
                    return form(req, q, lines, err=err)
                flash_redirect("/nabidky/%d" % save(q, lines, vp), "Nabídka uložena" + (" · " + num_msg if num_msg else ""))
        d = today()
        q = {"number": next_invoice_number(db, d, req.settings["quote_format"], "quotes"), "issue_date": d,
             "valid_until": (date.today() + timedelta(days=int(req.settings["quote_days"] or 30))).isoformat()}
        from .contacts import prefill
        q.update({x: v for x, v in prefill(db, req).items() if x in ("contact_id", "cust_name", "cust_address", "cust_ico", "cust_dic")})
        lines = []
        if req.args.get("z"):
            o = db.one("SELECT * FROM quotes WHERE id = ?", (req.args["z"],))
            if o:
                q.update({k: o[k] for k in ("contact_id", "cust_name", "cust_address", "cust_ico", "cust_dic", "title", "note")})
                lines = [dict(ln) for ln in qlines(db, o["id"])]
        return form(req, q, lines)

    @app.route("/nabidky/<qid>/upravit", ("GET", "POST"))
    def edit(req, qid):
        q = get(qid)
        if req.method == "POST":
            nq, lines = read(req, q["vat_payer"])
            with db.lock:   # kontrola čísla/zálohy a zápis naráz (souběh více uživatelů)
                err = validate(nq, lines, q["id"])
                if err:
                    return form(req, dict(nq, vat_payer=q["vat_payer"]), lines, q["id"], err)
                save(nq, lines, q["vat_payer"], q["id"])
            flash_redirect("/nabidky/%d" % q["id"], "Uloženo")
        return form(req, dict(q), [dict(ln) for ln in qlines(db, q["id"])], q["id"])

    @app.route("/nabidky/<qid>/stav", ("POST",))
    def set_status(req, qid):
        q = get(qid)
        st = req.f("stav")
        if st not in STATUS:
            raise HTTPError(400)
        db.run("UPDATE quotes SET status = ? WHERE id = ?", (st, q["id"]))
        flash_redirect("/nabidky/%d" % q["id"], "Stav: %s" % STATUS[st])

    @app.route("/nabidky/<qid>/zakazka", ("POST",))
    def to_job(req, qid):
        q = get(qid)
        if q["job_id"]:
            flash_redirect("/zakazky/%d" % q["job_id"], "Zakázka už existuje")
        with db.tx():
            jid = db.run("INSERT INTO jobs(number, title, contact_id, cust_name, cust_address, cust_ico, cust_dic, status, "
                         "start_date, note, quote_id, created) VALUES(?,?,?,?,?,?,?,'nova',?,?,?,?)", (
                             next_invoice_number(db, today(), req.settings["job_format"], "jobs"),
                             q["title"] or "Zakázka dle nabídky %s" % q["number"], q["contact_id"], q["cust_name"],
                             q["cust_address"], q["cust_ico"], q["cust_dic"], today(), q["note"], q["id"], now()))
            docs.write_lines(db, "job_lines", "job_id", jid, [dict(ln) for ln in qlines(db, q["id"])])
            db.run("UPDATE quotes SET job_id = ?, status = 'prijata' WHERE id = ?", (jid, q["id"]))
        flash_redirect("/zakazky/%d" % jid, "Zakázka založena z nabídky %s" % q["number"])

    @app.route("/nabidky/<qid>/smazat", ("POST",))
    def delete(req, qid):
        q = get(qid)
        db.run("DELETE FROM quotes WHERE id = ?", (q["id"],))
        flash_redirect("/nabidky", "Nabídka %s smazána" % q["number"])

    @app.route("/nabidky/<qid>")
    def detail(req, qid):
        q = get(qid)
        s = req.settings
        table, t = docs.lines_table(qlines(db, q["id"]), q["vat_payer"])
        stsel = "".join('<option value="%s"%s>%s</option>' % (k, " selected" if k == q["status"] else "", v)
                        for k, v in STATUS.items())
        actions = ['<a class="btn primary" href="/nabidky/%d/pdf">Stáhnout PDF</a>' % q["id"],
                   '<a class="btn" href="/nabidky/%d/email">Poslat e-mailem</a>' % q["id"],
                   '<button class="btn" onclick="window.print()">Tisk</button>',
                   '<a class="btn" href="/nabidky/%d/upravit">Upravit</a>' % q["id"],
                   '<form method="post" action="/nabidky/%d/stav" class="inline">%s<select name="stav" '
                   'onchange="this.form.submit()">%s</select></form>' % (q["id"], app.csrf(), stsel)]
        if q["job_id"]:
            actions.append('<a class="btn" href="/zakazky/%d">→ Zakázka</a>' % q["job_id"])
        else:
            actions.append('<form method="post" action="/nabidky/%d/zakazka" class="inline">%s<button class="btn">'
                           'Vytvořit zakázku</button></form>' % (q["id"], app.csrf()))
        if q["invoice_id"]:
            actions.append('<a class="btn" href="/faktury/%d">→ Faktura</a>' % q["invoice_id"])
        else:
            actions.append('<a class="btn ok" href="/faktury/nova?nabidka=%d">Vyfakturovat</a>' % q["id"])
        actions.append('<a class="btn" href="/nabidky/nova?z=%d">Duplikovat</a>' % q["id"])
        actions.append('<form method="post" action="/nabidky/%d/smazat" class="inline" onsubmit="return confirm(\'Smazat '
                       'nabídku?\')">%s<button class="link danger">smazat</button></form>' % (q["id"], app.csrf()))
        doc = """<article class="invoice"><header><div>%s<h1>Cenová nabídka %s</h1><div class="sub">%s</div></div></header>
<div class="parties"><section><h3>Dodavatel</h3>%s</section>
<section><h3>Odběratel</h3><b>%s</b><div>%s</div>%s</section></div>
<div class="payinfo"><div><span>Datum</span>%s</div><div><span>Platnost nabídky do</span>%s</div></div>
%s%s%s<footer><div>%s</div><div>Vystaveno programem Firmička</div></footer></article>""" % (
            images.inline(app.data_dir, "logo"), h(q["number"]), h(q["title"]), docs.firm_block(s), h(q["cust_name"]), h(q["cust_address"]).replace("\n", "<br>"),
            "".join("<div>%s: %s</div>" % (k, h(v)) for k, v in (("IČO", q["cust_ico"]), ("DIČ", q["cust_dic"])) if v),
            cz_date(q["issue_date"]), cz_date(q["valid_until"]), table,
            "<p class='note'>%s</p>" % h(q["note"]).replace("\n", "<br>") if q["note"] else "",
            images.signature_block(app.data_dir, s),
            "" if q["vat_payer"] else "Nejsem plátce DPH.")
        return app.page("Nabídka " + q["number"], flash(req) + '<div class="bar noprint"><a href="/nabidky">← Nabídky</a>'
                        '<div class="actions">%s</div></div>' % "".join(actions) +
                        docs.page_numbers_css("Nabídka " + q["number"]) + doc, "/nabidky")
