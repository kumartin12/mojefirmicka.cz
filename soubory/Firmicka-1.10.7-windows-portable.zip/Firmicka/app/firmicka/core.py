"""Přehled, přihlášení, nastavení, zálohy, exporty CSV a ukončení programu."""
import csv
import io
import os
import re
import secrets
import threading
import time
import urllib.parse

from . import qr
from .cashbook import balances_before
from .db import invoice_totals, stock_levels, today
from .invoices import lines_of, STATUS
from .web import (h, money, qty, cz_date, flash, flash_redirect, Response, Redirect, HTTPError,
                  hash_password, check_password)

FIRM = [("firm_name", "Název firmy / jméno", "wide"), ("firm_street", "Ulice a č. p.", ""), ("firm_city", "Obec", ""),
        ("firm_zip", "PSČ", ""), ("firm_ico", "IČO", ""), ("firm_dic", "DIČ", ""),
        ("firm_register", "Zápis v rejstříku (na fakturu)", "wide"), ("firm_email", "E-mail", ""),
        ("firm_phone", "Telefon", ""), ("firm_web", "Web", ""),
        ("bank_account", "Bankovní účet (123456789/0800 nebo IBAN)", "wide"),
        ("invoice_issuer", "Vystavil (jméno pod podpisem)", "")]


def backups_dir(app):
    return os.path.join(app.data_dir, "zalohy")


NUMBER = re.compile(r"^-?[\d\s]*[,.]?\d*$")


def csv_cell(v):
    """Text začínající = + - @ by Excel spustil jako vzorec (např. název firmy z importu) → předsadit apostrof.
    Záporná čísla „-123,45“ zůstávají čísly."""
    if isinstance(v, str) and v[:1] in ("=", "+", "-", "@", "\t", "\r") and not NUMBER.match(v):
        return "'" + v
    return v


def csv_response(name, header, rows):
    buf = io.StringIO()
    w = csv.writer(buf, delimiter=";")     # český Excel čte středník
    w.writerow(header)
    w.writerows([csv_cell(v) for v in row] for row in rows)
    return Response("﻿" + buf.getvalue(), ctype="text/csv; charset=utf-8",
                    headers=[("Content-Disposition", 'attachment; filename="%s"' % name)])


def num(hal):
    return ("%.2f" % (hal / 100)).replace(".", ",")


def register(app):
    db = app.db

    @app.route("/")
    def dashboard(req):
        s = req.settings
        t = today()
        unpaid = db.q("SELECT * FROM invoices WHERE status = 'vystavena' AND kind IN ('faktura', 'zaloha') ORDER BY due_date")
        unpaid_sum, overdue, n_unpaid = 0, [], 0
        for inv in unpaid:
            tot = invoice_totals(lines_of(db, inv["id"]), inv["vat_payer"])["total"]
            if tot <= 0:          # konečná faktura po odečtení vyšší zálohy = k vrácení, ne pohledávka
                continue
            unpaid_sum += tot
            n_unpaid += 1
            if inv["due_date"] < t:
                overdue.append((inv, tot))
        month = t[:7]
        m = {r["direction"]: r["s"] for r in db.q(
            "SELECT direction, SUM(amount) AS s FROM cashbook WHERE substr(date,1,7) = ? AND taxable = 1 GROUP BY direction", (month,))}
        y = {r["direction"]: r["s"] for r in db.q(
            "SELECT direction, SUM(amount) AS s FROM cashbook WHERE substr(date,1,4) = ? AND taxable = 1 GROUP BY direction", (t[:4],))}
        bal = balances_before(db, s, "9999-12-31")
        levels = stock_levels(db)
        low = [(i, levels.get(i["id"], 0)) for i in db.q("SELECT * FROM items WHERE active = 1 ORDER BY name")
               if (i["min_qty"] > 0 and levels.get(i["id"], 0) <= i["min_qty"]) or levels.get(i["id"], 0) < 0]
        setup = ""
        if not s["firm_name"]:
            setup = '<div class="flash">Vítejte! Nejdřív vyplňte <a href="/nastaveni">údaje své firmy</a> – objeví se na fakturách.</div>'
        DASH_ROWS = 8      # víc řádků by z přehledu udělalo nekonečnou stránku (simulace: 93 faktur po splatnosti)

        def more(rows, href, what):
            if len(rows) <= DASH_ROWS:
                return ""
            return "<p class=hint><a href='%s'>… a dalších %d %s (celkem %s) →</a></p>" % (
                href, len(rows) - DASH_ROWS, what, money(sum(t for _, t in rows)))
        od = "".join("<tr><td><a href='/faktury/%d'>%s</a><small class=sub>%s · splatnost %s</small></td><td class=num>%s</td></tr>" % (
            inv["id"], h(inv["number"]), h(inv["cust_name"]), cz_date(inv["due_date"]), money(tot))
            for inv, tot in overdue[:DASH_ROWS])
        lw = "".join("<tr><td><a href='/sklad/%d'>%s</a></td><td class=num>%s %s</td><td class=num>%s</td></tr>" % (
            i["id"], h(i["name"]), qty(st), h(i["unit"]), qty(i["min_qty"])) for i, st in low[:15])
        from .purchases import plines
        soon = (__import__("datetime").date.today() + __import__("datetime").timedelta(days=7)).isoformat()
        topay = [(p, invoice_totals(plines(db, p["id"]), True)["total"]) for p in
                 db.q("SELECT * FROM purchases WHERE status = 'neuhrazena' AND due_date <= ? ORDER BY due_date", (soon,))]
        tp = "".join("<tr%s><td><a href='/prijate/%d'>%s</a><small class=sub>%s · splatnost %s</small></td><td class=num>%s</td></tr>" % (
            " class=warn" if p["due_date"] < t else "", p["id"], h(p["doc_number"]), h(p["supp_name"]),
            cz_date(p["due_date"]), money(tot)) for p, tot in topay[:DASH_ROWS])
        recent = db.q("SELECT * FROM invoices ORDER BY created DESC, id DESC LIMIT 5")
        rc = "".join("<tr><td><a href='/faktury/%d'>%s</a></td><td>%s</td><td><span class='tag %s'>%s</span></td></tr>" % (
            r["id"], h(r["number"]), h(r["cust_name"]), r["status"], STATUS[r["status"]]) for r in recent)
        return app.page("Přehled", """%s%s<div class="bar"><h1>%s</h1>
<a class="btn primary" href="/faktury/nova">+ Faktura</a><a class="btn" href="/denik/novy?smer=vydaj">+ Výdaj</a></div>
<div class="stats">
<div><span>Neuhrazené faktury</span><b>%s</b><small>%d ks, z toho %d po splatnosti</small></div>
<div><span>Příjmy %s</span><b class=in>%s</b><small>za rok %s</small></div>
<div><span>Výdaje %s</span><b class=out>%s</b><small>za rok %s</small></div>
<div><span>Pokladna / banka</span><b>%s</b><small>banka %s</small></div></div>
<div class="cols">%s
<section class="card"><h2>Po splatnosti <a class="hint" href="/upominky">upomínky →</a></h2>%s</section>
<section class="card"><h2>Zaplatit dodavatelům (7 dní)</h2>%s</section>
<section class="card"><h2>Docházející zboží</h2>%s</section>
<section class="card"><h2>Poslední faktury</h2>%s</section></div>""" % (
            flash(req), setup, h(s["firm_name"]) or "Přehled",
            money(unpaid_sum), n_unpaid, len(overdue),
            cz_month(month), money(m.get("prijem", 0)), money(y.get("prijem", 0)),
            cz_month(month), money(m.get("vydaj", 0)), money(y.get("vydaj", 0)),
            money(bal["pokladna"]), money(bal["banka"]),
            __import__("firmicka.calendar_notes", fromlist=["x"]).upcoming_card(db) if "kalendar" in req.perms else "",
            "<table class=list>%s</table>%s" % (od, more(overdue, "/upominky", "po splatnosti")) if od
            else "<p class=empty>Nic po splatnosti 👍</p>",
            "<table class=list>%s</table>%s" % (tp, more(topay, "/prijate?stav=neuhrazena", "k úhradě")) if tp
            else "<p class=empty>Nic k úhradě.</p>",
            "<table class=list><thead><tr><th>Položka</th><th class=num>Stav</th><th class=num>Min.</th></tr></thead>%s</table>" % lw
            if lw else "<p class=empty>Zásoby v pořádku.</p>",
            "<table class=list>%s</table>" % rc if rc else "<p class=empty>Zatím žádné faktury.</p>"), "/")

    # ---------- přihlášení ----------
    fails, fails_lock, ip_locks = {}, threading.Lock(), {}   # IP → (špatných pokusů, čas posledního), IP → zámek

    def ip_lock(ip):
        """Pokusy z jedné adresy se ověřují postupně – souběžné pokusy limit neobejdou a správná hesla
        (víc lidí za jednou adresou) se nepočítají jako chyby."""
        with fails_lock:
            if len(ip_locks) > 10000:
                ip_locks.clear()
            return ip_locks.setdefault(ip, threading.Lock())

    def login_wait(ip):
        """Po 5 špatných heslech z jedné adresy čekat 30 s, pak pokaždé dvakrát déle (max. 15 min)."""
        with fails_lock:
            n, last = fails.get(ip, (0, 0))
        left = last + min(30 * 2 ** min(n - 5, 10), 900) - time.time() if n >= 5 else 0
        return int(left) + 1 if left > 0 else 0

    def login_result(ip, ok):
        with fails_lock:
            if ok:
                fails.pop(ip, None)
            else:
                if len(fails) > 10000:
                    fails.clear()
                fails[ip] = (fails.get(ip, (0, 0))[0] + 1, time.time())

    @app.route("/login", ("GET", "POST"))
    def login(req):
        from .web import safe_next
        nxt = safe_next(req.args.get("next", "/"))
        err = ""
        multi = db.one("SELECT COUNT(*) FROM users WHERE active = 1")[0] > 0
        ip = req.env.get("REMOTE_ADDR", "")
        if req.method == "POST":
            with ip_lock(ip):
                wait = login_wait(ip)
                sess = None
                if not wait:
                    if multi:
                        u = db.one("SELECT * FROM users WHERE username = ? AND active = 1", (req.f("username"),))
                        if u and check_password(req.form.get("password", ""), u["password_hash"]):
                            from .web import user_perms
                            sess = {"user": u["username"], "role": u["role"], "perms": user_perms(u)}
                    elif check_password(req.form.get("password", ""), req.settings["password_hash"]):
                        from .web import ALL_PERMS
                        sess = {"user": "", "role": "majitel", "perms": set(ALL_PERMS)}
                    login_result(ip, bool(sess))
                    if not sess:
                        time.sleep(0.5)   # zpomalit zkoušení hesel (pod zámkem adresy)
        if req.method == "POST" and wait:
            err = '<div class="flash error">Příliš mnoho špatných pokusů – zkuste to znovu za %d s</div>' % wait
        elif req.method == "POST":
            if sess:
                from .web import home_of
                tok = secrets.token_hex(24)
                app.sessions[tok] = sess
                if nxt == "/" or not __import__("firmicka.web", fromlist=["x"]).allowed(sess["perms"], nxt):
                    nxt = home_of(sess["perms"])
                return Response("", 302, headers=[("Location", nxt), (
                    "Set-Cookie", "firmicka_session=%s; Path=/; HttpOnly; SameSite=Strict" % tok)])
            err = '<div class="flash error">Špatné jméno nebo heslo</div>' if multi else '<div class="flash error">Špatné heslo</div>'
        user_field = '<label>Uživatel<input name="username" autofocus required autocomplete="username"></label>' if multi else ""
        return app.page("Přihlášení", """<form method="post" class="login card">%s<h1>Firmička</h1>%s%s
<label>Heslo<input type="password" name="password" %srequired autocomplete="current-password"></label>
<button class="btn primary">Přihlásit</button></form>""" % (app.csrf(), err, user_field, "" if multi else "autofocus "))

    @app.route("/logout", ("POST",))
    def logout(req):
        app.sessions.pop(req.cookies.get("firmicka_session", ""), None)
        raise Redirect("/login")

    @app.route("/quit", ("POST",))
    def quit_(req):
        # ukončit smí majitel (nebo instalátor s tokenem) – v síti by jinak kdokoli vypnul program všem
        import hmac
        if "uzivatele" not in req.perms and not hmac.compare_digest(req.form.get("token", ""), app.quit_token):
            raise HTTPError(403, "Program může ukončit jen majitel")
        if app.on_quit:
            app.on_quit()
        return app.page("Ukončeno", "<div class='card login'><h1>Firmička je ukončena</h1>"
                        "<p>Data jsou uložená. Okno prohlížeče můžete zavřít.</p></div>")

    # ---------- nastavení ----------
    @app.route("/nastaveni", ("GET", "POST"))
    def settings(req):
        s = req.settings
        if req.method == "POST":
            vals = {k: req.f(k) for k, _, _ in FIRM}
            vals["invoice_footer"] = req.form.get("invoice_footer", "").strip()
            vals["job_terms"] = req.form.get("job_terms", "").strip()
            bad_account = ""
            if vals["bank_account"] and not qr.cz_iban(vals["bank_account"]):
                # ostatní údaje uložit, jen účet nechat původní (dřív se zahodil celý vyplněný formulář)
                bad_account, vals["bank_account"] = vals["bank_account"], s["bank_account"]
            vals["vat_payer"] = "1" if req.f("vat_payer") else "0"
            fmt = req.f("invoice_format") or "{YYYY}{NNNN}"
            if not any("{%s}" % ("N" * k) in fmt for k in range(2, 7)):
                fmt += "{NNNN}"
            vals["invoice_format"] = fmt
            for key, default in (("credit_format", "DB{YYYY}{NNNN}"), ("advance_format", "ZF{YYYY}{NNNN}"),
                                 ("ddkpp_format", "DD{YYYY}{NNNN}")):
                f2 = req.f(key) or default
                if not any("{%s}" % ("N" * k) in f2 for k in range(2, 7)):
                    f2 += "{NNNN}"
                vals[key] = f2
            if len({vals[x] for x in ("invoice_format", "credit_format", "advance_format", "ddkpp_format")}) < 4:
                flash_redirect("/nastaveni", "Faktury, dobropisy, zálohy a daňové doklady musí mít každá jinou číselnou řadu")
            vals["due_days"] = str(max(0, int(req.f("due_days") or 14))) if req.f("due_days").isdigit() else "14"
            from .web import parse_money
            vals["cash_start_pokladna"] = str(parse_money(req.f("cash_start_pokladna")))
            vals["cash_start_banka"] = str(parse_money(req.f("cash_start_banka")))
            db.set_settings(vals)
            if bad_account:
                flash_redirect("/nastaveni", "Uloženo, ale číslo účtu „%s“ nesedí (překlep?) – zadejte ve tvaru "
                               "123456789/0800 nebo CZ… IBAN. Účet zůstal původní." % bad_account[:40])
            flash_redirect("/nastaveni", "Nastavení uloženo")
        from .db import next_invoice_number
        fields = "".join('<label class="%s">%s<input name="%s" value="%s"></label>' % (cls, lab, k, h(s[k]))
                         for k, lab, cls in FIRM)
        iban = qr.cz_iban(s["bank_account"]) if s["bank_account"] else None
        sample = next_invoice_number(db, today(), s["invoice_format"])
        return app.page("Nastavení", """%s<h1>Nastavení</h1>
<form method="post" class="grid">%s<section class="card wide"><h2>Firma</h2><div class="grid">%s
<div class="wide hint">%s</div>
<div class="wide ares"><button type="button" class="btn" data-ares-firm>Načíst firmu z ARES podle IČO</button>
<span class="hint" id="ares-msg"></span></div></div></section>
<section class="card wide"><h2>Faktury a DPH</h2><div class="grid">
<label class="check wide"><input type="checkbox" name="vat_payer" value="1"%s> Jsem plátce DPH
<span class="hint">(mění jen nové faktury; vystavené zůstávají)</span></label>
<label>Číselná řada<input name="invoice_format" value="%s"><span class="hint">{YYYY} rok, {NNNN} pořadí · další: <b>%s</b></span></label>
<label>Splatnost (dní)<input name="due_days" value="%s" inputmode="numeric"></label>
<label>Řada dobropisů<input name="credit_format" value="%s"></label>
<label>Řada zálohových faktur<input name="advance_format" value="%s"></label>
<label>Řada daňových dokladů k platbě<input name="ddkpp_format" value="%s"><span class="hint">vznikají samy po úhradě zálohy (plátce DPH)</span></label>
<label class="wide">Patička faktury<textarea name="invoice_footer" rows="2">%s</textarea></label>
<label class="wide">Podmínky na zakázkovém listu<textarea name="job_terms" rows="2">%s</textarea></label></div></section>
<section class="card wide"><h2>Peněžní deník – počáteční stav</h2><div class="grid">
<label>Pokladna (Kč)<input name="cash_start_pokladna" value="%s" inputmode="decimal"></label>
<label>Banka (Kč)<input name="cash_start_banka" value="%s" inputmode="decimal"></label></div></section>
<div class="actions wide"><button class="btn primary">Uložit nastavení</button></div></form>%s
<section class="card"><h2>Zálohy</h2><p>Program zálohuje sám každý den (posledních 30 dní).
<a class="btn" href="/nastaveni/zalohy">Spravovat zálohy</a></p></section>
<section class="card"><h2>Heslo a přístup ze sítě</h2>%s
<p><a class="btn" href="/nastaveni/uzivatele">Uživatelé a oprávnění</a> <a class="btn" href="/nastaveni/audit">Záznam změn</a></p></section>
<section class="card"><h2>Licence</h2><p>%s</p><p><a class="btn" href="/nastaveni/licence">Licence</a></p></section>%s
<p class="hint">Data: %s · verze %s</p>""" % (
            flash(req), app.csrf(), fields,
            ("IBAN: <b>%s</b> – použije se pro QR platbu" % h(iban)) if iban else "Bez účtu se na faktuře nezobrazí QR platba.",
            " checked" if s["vat_payer"] == "1" else "", h(s["invoice_format"]), h(sample), h(s["due_days"]),
            h(s["credit_format"]), h(s["advance_format"]), h(s["ddkpp_format"]),
            h(s["invoice_footer"]), h(s["job_terms"]),
            money(int(s["cash_start_pokladna"] or 0), False).replace(" ", ""),
            money(int(s["cash_start_banka"] or 0), False).replace(" ", ""),
            __import__("firmicka.images", fromlist=["x"]).settings_form(app, s),
            security_form(req), __import__("firmicka.licence", fromlist=["x"]).summary(db),
            __import__("firmicka.reminders", fromlist=["x"]).settings_form(app, s) +
            __import__("firmicka.pos", fromlist=["x"]).settings_form(app, s) +
            __import__("firmicka.purchases", fromlist=["x"]).epo_settings_form(app, s), h(app.data_dir), __import__("firmicka").__version__), "/nastaveni")

    def security_form(req):
        s = req.settings
        has_pw = bool(s["password_hash"])
        ips = local_ips()
        lan_info = ""
        if s["lan"] == "1":
            lan_info = "<p>Z ostatních počítačů v síti otevřete: %s</p>" % ", ".join(
                "<b>http://%s:%s</b>" % (ip, h(s["port"])) for ip in ips) if ips else ""
        return """<form method="post" action="/nastaveni/pristup" class="grid">%s
<label>%s<input type="password" name="password" autocomplete="new-password" placeholder="%s"></label>
<label>Heslo znovu<input type="password" name="password2" autocomplete="new-password"></label>
<label class="check wide"><input type="checkbox" name="lan" value="1"%s> Povolit přístup z ostatních počítačů v síti
<span class="hint">(vyžaduje heslo a restart programu; Windows se zeptá na povolení ve firewallu)</span></label>
<label>Port<input name="port" value="%s" inputmode="numeric"></label>
<div class="actions wide"><button class="btn">Uložit přístup</button>%s</div></form>%s""" % (
            app.csrf(), "Nové heslo" if has_pw else "Heslo (nepovinné)",
            "ponechat stávající" if has_pw else "bez hesla", " checked" if s["lan"] == "1" else "", h(s["port"]),
            '<label class="check"><input type="checkbox" name="remove_pw" value="1"> zrušit heslo</label>' if has_pw else "",
            lan_info)

    @app.route("/nastaveni/pristup", ("POST",))
    def access(req):
        s = req.settings
        vals = {}
        pw, pw2 = req.form.get("password", ""), req.form.get("password2", "")
        if pw:
            if pw != pw2:
                flash_redirect("/nastaveni", "Hesla se neshodují")
            if len(pw) < 6:
                flash_redirect("/nastaveni", "Heslo musí mít aspoň 6 znaků")
            vals["password_hash"] = hash_password(pw)
        elif req.f("remove_pw"):
            vals["password_hash"] = ""
        has_pw = vals.get("password_hash", s["password_hash"]) or db.one("SELECT COUNT(*) FROM users WHERE active = 1")[0]
        lan = "1" if req.f("lan") else "0"
        if lan == "1" and not has_pw:
            flash_redirect("/nastaveni", "Pro přístup ze sítě nejdřív nastavte heslo nebo uživatele")
        vals["lan"] = lan
        port = req.f("port")
        if port.isdigit() and 1024 <= int(port) <= 65535:
            vals["port"] = port
        db.set_settings(vals)
        restart = vals["lan"] != s["lan"] or vals.get("port", s["port"]) != s["port"]
        flash_redirect("/nastaveni", "Uloženo" + (" – projeví se po restartu programu" if restart else ""))

    # ---------- zálohy ----------
    @app.route("/nastaveni/zalohy")
    def backups(req):
        d = backups_dir(app)
        files = sorted((f for f in os.listdir(d) if f.endswith(".sqlite")), reverse=True) if os.path.isdir(d) else []
        trs = "".join("<tr><td>%s</td><td class=num>%d kB</td><td><a class=btn href='/nastaveni/zalohy/%s'>Stáhnout</a></td>"
                      "<td><form method=post action='/nastaveni/zalohy/%s/obnovit' onsubmit=\"return confirm("
                      "'Obnovit data z této zálohy? Současný stav se předtím sám zazálohuje.')\">%s"
                      "<button class='btn danger'>Obnovit</button></form></td></tr>" % (
                          h(f), os.path.getsize(os.path.join(d, f)) // 1024, h(f), h(f), app.csrf()) for f in files)
        return app.page("Zálohy", """%s<div class="bar"><h1>Zálohy</h1>
<form method="post" action="/nastaveni/zalohy/ted">%s<button class="btn primary">Zálohovat teď</button></form></div>
<p class="hint">Složka záloh: %s – doporučujeme ji občas zkopírovat na flashku nebo do cloudu.</p>
<table class="list"><tbody>%s</tbody></table>%s""" % (flash(req), app.csrf(), h(d), trs, usb_section(req)), "/nastaveni")

    @app.route("/nastaveni/zalohy/ted", ("POST",))
    def backup_now(req):
        import time
        path = os.path.join(backups_dir(app), "firmicka-%s-rucni.sqlite" % time.strftime("%Y%m%d-%H%M%S"))
        os.makedirs(backups_dir(app), exist_ok=True)
        db.backup(path)
        flash_redirect("/nastaveni/zalohy", "Záloha vytvořena")

    def backup_path(name):
        if "/" in name or "\\" in name or not name.endswith(".sqlite") or name.startswith("."):
            raise HTTPError(404)
        p = os.path.join(backups_dir(app), name)
        if not os.path.isfile(p):
            raise HTTPError(404, "Záloha neexistuje")
        return p

    @app.route("/nastaveni/zalohy/<name>")
    def backup_download(req, name):
        with open(backup_path(name), "rb") as f:
            return Response(f.read(), ctype="application/octet-stream",
                            headers=[("Content-Disposition", 'attachment; filename="%s"' % name)])

    def restore_from(p, name):
        """Nahradí data obsahem databáze p (současný stav se předtím zazálohuje)."""
        import sqlite3
        import time
        try:
            src = sqlite3.connect("file:%s?mode=ro" % urllib.parse.quote(p), uri=True)
            src.execute("SELECT COUNT(*) FROM invoices").fetchone()
            ver = src.execute("PRAGMA user_version").fetchone()[0]
        except sqlite3.Error:
            flash_redirect("/nastaveni/zalohy", "Soubor není platná záloha Firmičky")
        from .db import SCHEMA_VERSION
        if ver > SCHEMA_VERSION:
            src.close()
            flash_redirect("/nastaveni/zalohy", "Záloha je z novější verze Firmičky – nejdřív nainstalujte nejnovější verzi")
        os.makedirs(backups_dir(app), exist_ok=True)
        db.backup(os.path.join(backups_dir(app), "firmicka-%s-pred-obnovou.sqlite" % time.strftime("%Y%m%d-%H%M%S")))
        keep = {k: v for k, v in db.settings().items() if k in ("usb_password", "port", "lan")}
        with db.lock:
            src.backup(db.conn)
        src.close()
        db.migrate()
        db.set_settings(keep)     # heslo k USB a síť zůstanou z tohoto počítače
        from . import images
        images.sync(db, app.data_dir)   # logo, podpis a razítko ze zálohy
        flash_redirect("/", "Data obnovena ze zálohy %s" % name)

    @app.route("/nastaveni/zalohy/<name>/obnovit", ("POST",))
    def backup_restore(req, name):
        restore_from(backup_path(name), name)

    # ---------- záloha na USB ----------
    def usb_age_days(s):
        last = int(s["usb_last"] or 0)
        return None if not last else (time.time() - last) / 86400

    def usb_section(req):
        s = req.settings
        if not s["usb_password"]:
            return """<section class="card"><h2>Záloha na USB (šifrovaná)</h2>
<p>Záloha na flashku nebo externí disk chrání data i při požáru, krádeži nebo viru – disk pak odneste z kanceláře.
Záloha je zašifrovaná heslem: kdo flashku najde, data nepřečte.</p>
<form method="post" action="/nastaveni/usb/heslo" class="grid">%s
<label>Heslo zálohy<input type="password" name="password" autocomplete="new-password" required minlength="8"></label>
<label>Heslo znovu<input type="password" name="password2" autocomplete="new-password" required></label>
<p class="wide hint"><b>Heslo si zapište a uschovejte mimo počítač</b> (např. do trezoru). Bez něj zálohu na jiném
počítači neobnovíte – nikdo, ani autor programu, ho nedokáže zjistit.</p>
<div class="actions wide"><button class="btn primary">Nastavit heslo</button></div></form></section>""" % app.csrf()
        try:
            from . import usb
            ds = usb.drives()
        except Exception as e:
            ds, err = [], str(e)
        else:
            err = ""
        age = usb_age_days(s)
        last = ("naposledy před %s na disk %s" % (
            "méně než dnem" if age < 1 else "%d dny" % age, h(s["usb_last_label"]))) if age is not None else "zatím nikdy"
        rows = "".join("<tr><td><b>%s</b> %s%s</td><td class=num>volno %.1f GB</td><td>%d záloh</td><td>"
                       "<form method=post action='/nastaveni/usb/zalohovat' class=inline>%s<input type=hidden name=drive value='%s'>"
                       "<button class='btn primary'>Zálohovat sem</button></form> "
                       "<a class=btn href='/nastaveni/usb/obnovit?drive=%s'>Obnovit odsud…</a></td></tr>" % (
                           h(d["path"]), h(d["label"]), "" if d["removable"] else " <span class=tag>externí disk</span>",
                           d["free"] / 1e9, len(usb.backups_on(d["path"])), app.csrf(), h(d["path"]),
                           urllib.parse.quote(d["path"])) for d in ds)
        return """<section class="card"><h2>Záloha na USB (šifrovaná)</h2><p>Stav: <b>%s</b>.
Připomenutí, když je záloha starší než %s dní.</p>%s
<table class="list"><tbody>%s</tbody></table>
<details><summary class="hint">Změnit heslo zálohy</summary>
<form method="post" action="/nastaveni/usb/heslo" class="grid">%s
<label>Nové heslo<input type="password" name="password" autocomplete="new-password" required minlength="8"></label>
<label>Heslo znovu<input type="password" name="password2" autocomplete="new-password" required></label>
<p class="wide hint">Staré zálohy na flashkách zůstanou zašifrované starým heslem.</p>
<div class="actions wide"><button class="btn">Změnit heslo</button></div></form></details></section>""" % (
            last, h(s["usb_remind_days"]), '<div class="flash error">%s</div>' % h(err) if err else "",
            rows or "<tr><td class=empty>Žádný USB disk není připojen – připojte flashku a obnovte stránku.</td></tr>",
            app.csrf())

    def drive_from_form(req, key="drive"):
        from . import usb
        path = req.f(key) or req.args.get(key, "")
        for d in usb.drives():
            if d["path"] == path:
                return d
        flash_redirect("/nastaveni/zalohy", "Disk %s není připojen" % path)

    @app.route("/nastaveni/usb/heslo", ("POST",))
    def usb_password(req):
        pw, pw2 = req.form.get("password", ""), req.form.get("password2", "")
        if len(pw) < 8:
            flash_redirect("/nastaveni/zalohy", "Heslo musí mít aspoň 8 znaků")
        if pw != pw2:
            flash_redirect("/nastaveni/zalohy", "Hesla se neshodují")
        db.set_settings({"usb_password": pw})
        flash_redirect("/nastaveni/zalohy", "Heslo zálohy nastaveno – nezapomeňte si ho zapsat")

    @app.route("/nastaveni/usb/zalohovat", ("POST",))
    def usb_backup(req):
        from . import usb
        d = drive_from_form(req)
        s = req.settings
        try:
            path = usb.backup_to(db, d["path"], s["usb_password"], s["firm_name"])
        except Exception as e:
            flash_redirect("/nastaveni/zalohy", "Záloha na USB selhala: %s" % e)
        db.set_settings({"usb_last": str(int(time.time())), "usb_last_label": d["label"] or d["path"]})
        from .web import safe_next
        back = safe_next(req.f("back"), "/nastaveni/zalohy")
        flash_redirect(back, "Zálohováno na %s (%s, ověřeno). Disk můžete odpojit a odnést." % (
            d["path"], os.path.basename(path)))

    @app.route("/nastaveni/usb/obnovit", ("GET", "POST"))
    def usb_restore(req):
        from . import usb
        d = drive_from_form(req)
        if req.method == "POST":
            name = req.f("file")
            if name not in usb.backups_on(d["path"]):
                raise HTTPError(404, "Záloha neexistuje")
            try:
                tmp = usb.read_backup(os.path.join(d["path"], usb.FOLDER, name), req.form.get("password", ""))
            except Exception as e:
                flash_redirect("/nastaveni/usb/obnovit?drive=" + urllib.parse.quote(d["path"]), str(e))
            try:
                restore_from(tmp, name)
            finally:
                if os.path.exists(tmp):
                    os.remove(tmp)
        opts = "".join("<option>%s</option>" % h(f) for f in usb.backups_on(d["path"]))
        return app.page("Obnova z USB", """%s<h1>Obnova z USB – %s</h1>
<div class="flash error">Obnova nahradí všechna současná data obsahem zálohy. Současný stav se předtím uloží do složky záloh.</div>
<form method="post" class="grid">%s<input type="hidden" name="drive" value="%s">
<label class="wide">Záloha<select name="file">%s</select></label>
<label>Heslo zálohy<input type="password" name="password" required></label>
<div class="actions wide"><button class="btn danger" onclick="return confirm('Opravdu nahradit data zálohou?')">Obnovit</button>
<a class="btn" href="/nastaveni/zalohy">Zpět</a></div></form>""" % (
            flash(req), h(d["path"]), app.csrf(), h(d["path"]), opts or "<option value=''>Na disku nejsou zálohy</option>"),
            "/nastaveni")

    _cache = {"t": 0, "drives": []}

    def usb_banner():
        s = db.settings()
        if not s["usb_password"]:
            return ""
        if time.time() - _cache["t"] > 5:
            from . import usb
            _cache.update(t=time.time(), drives=usb.drives())
        age = usb_age_days(s)
        ds = _cache["drives"]
        if ds and (age is None or age >= 0.8):
            return "<div class='flash usb'>💾 Připojen disk %s – %s <form method=post action='/nastaveni/usb/zalohovat' " \
                   "class=inline>%s<input type=hidden name=drive value='%s'><input type=hidden name=back value='/'>" \
                   "<button class='btn primary'>Zálohovat teď</button></form></div>" % (
                       h(ds[0]["path"]), "poslední záloha na USB " + ("nikdy" if age is None else "před %d dny" % age),
                       app.csrf(), h(ds[0]["path"]))
        remind = int(s["usb_remind_days"] or 7)
        if age is None or age > remind:
            return "<div class='flash'>💾 Záloha na USB %s – připojte flashku, nabídnu zálohu.</div>" % (
                "zatím neproběhla" if age is None else "je stará %d dní" % age)
        return ""
    app.banners.append(usb_banner)

    # ---------- export ----------
    @app.route("/export/<name>")
    def export(req, name):
        year = req.args.get("rok", "")
        if name == "faktury.csv":
            sql, args = "SELECT * FROM invoices", ()
            if year:
                sql, args = sql + " WHERE substr(issue_date,1,4) = ?", (year,)
            rows = []
            for i in db.q(sql + " ORDER BY issue_date, number", args):
                t = invoice_totals(lines_of(db, i["id"]), i["vat_payer"])
                rows.append([i["number"], i["issue_date"], i["tax_date"], i["due_date"], i["cust_name"], i["cust_ico"],
                             i["cust_dic"], num(t["base"]), num(t["vat"]), num(t["total"]), STATUS[i["status"]],
                             i["paid_date"], i["vs"]])
            return csv_response("faktury%s.csv" % (("-" + year) if year else ""),
                                ["Číslo", "Vystaveno", "DUZP", "Splatnost", "Odběratel", "IČO", "DIČ", "Základ",
                                 "DPH", "Celkem", "Stav", "Uhrazeno", "VS"], rows)
        if name == "denik.csv":
            sql, args = "SELECT * FROM cashbook", ()
            if year:
                sql, args = sql + " WHERE substr(date,1,4) = ?", (year,)
            rows = [[r["date"], r["doc"], r["text"], r["category"], "pokladna" if r["account"] == "pokladna" else "banka",
                     num(r["amount"]) if r["direction"] == "prijem" else "", num(r["amount"]) if r["direction"] == "vydaj" else "",
                     "ano" if r["taxable"] else "ne"] for r in db.q(sql + " ORDER BY date, id", args)]
            return csv_response("penezni-denik%s.csv" % (("-" + year) if year else ""),
                                ["Datum", "Doklad", "Text", "Kategorie", "Účet", "Příjem", "Výdaj", "Daňový"], rows)
        if name == "prijate.csv":
            from .purchases import plines
            sql, args = "SELECT * FROM purchases", ()
            if year:
                sql, args = sql + " WHERE substr(tax_date,1,4) = ?", (year,)
            rows = []
            for p in db.q(sql + " ORDER BY tax_date, id", args):
                t = invoice_totals(plines(db, p["id"]), True)
                rows.append([p["doc_number"], p["number"], p["issue_date"], p["tax_date"], p["due_date"], p["supp_name"],
                             p["supp_ico"], p["supp_dic"], num(t["base"]), num(t["vat"]), num(t["total"]),
                             "uhrazena" if p["status"] == "uhrazena" else "neuhrazena", p["paid_date"], p["vs"]])
            return csv_response("prijate-faktury%s.csv" % (("-" + year) if year else ""),
                                ["Evid. číslo", "Číslo dodavatele", "Vystaveno", "DUZP", "Splatnost", "Dodavatel", "IČO",
                                 "DIČ", "Základ", "DPH", "Celkem", "Stav", "Uhrazeno", "VS"], rows)
        if name == "sklad.csv":
            from .db import item_costs, warehouse_levels
            lv = item_costs(db)
            per = warehouse_levels(db)
            ws = db.q("SELECT * FROM warehouses ORDER BY id")
            ws = ws if len(ws) > 1 else []          # jeden sklad → CSV beze změny
            fmt = lambda v: ("%g" % v).replace(".", ",")
            rows = []
            for i in db.q("SELECT * FROM items ORDER BY name"):
                st, avg = lv.get(i["id"], (0, 0))
                rows.append([i["code"], i["ean"], i["name"], fmt(st)] +
                            [fmt(per.get(i["id"], {}).get(w["id"], 0)) for w in ws] +
                            [i["unit"], num(avg), num(round(max(st, 0) * avg)),
                             num(i["price"]), num(i["recycling_fee"]), i["vat_rate"], fmt(i["min_qty"]),
                             "ano" if i["active"] else "ne"])
            return csv_response("sklad.csv", ["Kód", "EAN", "Název", "Stav"] + ["Stav – " + w["name"] for w in ws] +
                                ["Jednotka", "Nákup ø", "Hodnota", "Prodejní cena",
                                 "Rec. poplatek", "DPH %", "Min. stav", "Aktivní"], rows)
        if name == "adresar.csv":
            rows = [[c["name"], c["ico"], c["dic"], c["street"], c["city"], c["zip"], c["country"], c["email"], c["phone"]]
                    for c in db.q("SELECT * FROM contacts ORDER BY name")]
            return csv_response("adresar.csv", ["Název", "IČO", "DIČ", "Ulice", "Obec", "PSČ", "Stát", "E-mail", "Telefon"], rows)
        raise HTTPError(404)


def cz_month(ym):
    from .cashbook import MONTHS
    return MONTHS[int(ym[5:7]) - 1]


def local_ips():
    import socket
    ips = set()
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))   # nic se neposílá, jen zjistí výchozí rozhraní
        ips.add(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    return sorted(ips)
