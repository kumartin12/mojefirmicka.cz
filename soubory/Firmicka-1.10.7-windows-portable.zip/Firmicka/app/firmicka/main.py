"""Spuštění: složka dat, záloha, server na pozadí a otevření prohlížeče.
  python -m firmicka           spustí (běží-li už, jen otevře prohlížeč)
  python -m firmicka --stop    ukončí běžící Firmičku (používá instalátor před aktualizací)
  python -m firmicka --no-browser   (--console = výpis do terminálu místo firmicka.log)
Data: %APPDATA%\\Firmicka (Windows), ~/.local/share/firmicka (jinde), nebo proměnná FIRMICKA_DATA."""
import json
import os
import socket
import sys
import threading
import time
import urllib.parse
import urllib.request
import webbrowser
from socketserver import ThreadingMixIn
from wsgiref.simple_server import WSGIServer, WSGIRequestHandler, make_server

from . import __version__


def data_dir():
    d = os.environ.get("FIRMICKA_DATA")
    if not d:
        if os.name == "nt":
            d = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), "Firmicka")
        else:
            d = os.path.join(os.environ.get("XDG_DATA_HOME") or os.path.expanduser("~/.local/share"), "firmicka")
    os.makedirs(d, exist_ok=True)
    return d


def create_app(ddir):
    from .db import DB
    from .web import App
    from . import core, contacts, stock, invoices, purchases, cashbook, bank, reminders, quotes, jobs, users, pos, mail, accountant, images, licence, warehouses, calendar_notes
    db = DB(os.path.join(ddir, "firmicka.sqlite"))
    db.data_dir = ddir            # logo/podpis/razítko pro PDF
    app = App(db, ddir)
    for mod in (core, contacts, stock, warehouses, invoices, purchases, cashbook, bank, reminders, quotes, jobs, users, pos, mail,
                accountant, images, licence, calendar_notes):
        mod.register(app)
    return app


class ThreadingServer(ThreadingMixIn, WSGIServer):
    daemon_threads = True
    # Windows: SO_REUSEADDR by dovolil dvěma procesům sdílet port → vypnuto (Windows port po ukončení neblokuje).
    # Linux/Mac: bez něj by port po restartu (aktualizaci) ~1 min blokoval TIME_WAIT a program by skočil na jiný port.
    allow_reuse_address = os.name != "nt"


class QuietHandler(WSGIRequestHandler):
    def log_message(self, *a):
        pass


def instance_file(ddir):
    return os.path.join(ddir, "instance.json")


def running_instance(ddir):
    """Port běžící Firmičky pro tuto složku dat, jinak None."""
    try:
        with open(instance_file(ddir)) as f:
            inst = json.load(f)
        with urllib.request.urlopen("http://127.0.0.1:%d/ping" % inst["port"], timeout=2) as r:
            if r.read() == b"firmicka":
                return inst
    except Exception:
        pass
    return None


def stop(ddir):
    inst = running_instance(ddir)
    if not inst:
        return False
    data = urllib.parse.urlencode({"token": inst["token"]}).encode()
    try:
        urllib.request.urlopen("http://127.0.0.1:%d/quit" % inst["port"], data=data, timeout=5).read()
    except Exception:
        pass
    for _ in range(50):
        if not running_instance(ddir):
            return True
        time.sleep(0.1)
    return False


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    ddir = data_dir()
    if "--stop" in argv:
        sys.exit(0 if stop(ddir) else 1)
    # výstup vždy do logu v UTF-8: pythonw.exe konzoli nemá a konzole Windows (cp1252/cp852)
    # by na české hlášce spadla; --console = nechat výpis v terminálu
    if "--console" not in argv or sys.stdout is None:
        log = open(os.path.join(ddir, "firmicka.log"), "a", encoding="utf-8", buffering=1)
        sys.stdout = sys.stderr = log
    else:
        for stream in (sys.stdout, sys.stderr):
            stream.reconfigure(errors="replace")
    print("[%s] Firmička %s, data %s" % (time.strftime("%Y-%m-%d %H:%M:%S"), __version__, ddir))
    browser = "--no-browser" not in argv

    inst = running_instance(ddir)
    if inst:
        if browser:
            webbrowser.open("http://127.0.0.1:%d/" % inst["port"])
        return

    from .db import NewerDataError
    try:
        app = create_app(ddir)
    except NewerDataError as e:
        print(e)
        return show_error(str(e), browser)
    s = app.db.settings()
    port = int(s["port"] or 8765)
    protected = s["password_hash"] or app.db.one("SELECT COUNT(*) FROM users WHERE active = 1")[0]
    host = "0.0.0.0" if s["lan"] == "1" and protected else "127.0.0.1"
    httpd = None
    for p in [port] + list(range(port + 1, port + 20)):   # port obsazený jiným programem → zkusit další
        try:
            httpd = make_server(host, p, app, server_class=ThreadingServer, handler_class=QuietHandler)
            port = p
            break
        except OSError:
            continue
    if httpd is None:
        print("Nenašel se volný port")
        sys.exit(1)

    tmp = instance_file(ddir) + ".tmp"
    with open(tmp, "w") as f:
        json.dump({"port": port, "token": app.quit_token, "pid": os.getpid()}, f)
    os.replace(tmp, instance_file(ddir))

    def shutdown():
        threading.Thread(target=httpd.shutdown, daemon=True).start()
    app.on_quit = shutdown

    def backups():
        from . import reminders
        while True:
            try:
                app.db.daily_backup(os.path.join(ddir, "zalohy"))
            except Exception as e:
                print("Záloha selhala:", e)
            try:
                reminders.auto_run(app.db)
            except Exception as e:
                print("Upomínky selhaly:", e)
            time.sleep(3600)
    threading.Thread(target=backups, daemon=True).start()

    url = "http://127.0.0.1:%d/" % port
    print("Běží na %s (%s)" % (url, "i ze sítě" if host == "0.0.0.0" else "jen tento počítač"))
    if browser:
        threading.Timer(0.5, webbrowser.open, (url,)).start()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()
        try:
            os.remove(instance_file(ddir))
        except OSError:
            pass
        print("[%s] ukončeno" % time.strftime("%Y-%m-%d %H:%M:%S"))


def show_error(msg, browser=True, minutes=10):
    """Data nejdou otevřít: místo tichého pádu (pythonw nemá okno) ukáže hlášku v prohlížeči a za chvíli skončí."""
    from .web import h
    page = ("<!doctype html><meta charset=utf-8><title>Firmička</title><body style='font:16px system-ui;max-width:40rem;"
            "margin:4rem auto;padding:0 1rem'><h1>Firmičku nejde spustit</h1><p>%s</p><p style='color:#666'>Složka dat: %s"
            "</p></body>" % (h(msg), h(data_dir()))).encode()

    def err_app(env, sr):
        sr("200 OK", [("Content-Type", "text/html; charset=utf-8")])
        return [page]
    for p in range(8765, 8785):
        try:
            httpd = make_server("127.0.0.1", p, err_app, handler_class=QuietHandler)
            break
        except OSError:
            continue
    else:
        sys.exit(1)
    threading.Timer(minutes * 60, lambda: threading.Thread(target=httpd.shutdown, daemon=True).start()).start()
    if browser:
        threading.Timer(0.5, webbrowser.open, ("http://127.0.0.1:%d/" % p,)).start()
    try:
        httpd.serve_forever()
    finally:
        httpd.server_close()
    sys.exit(1)


if __name__ == "__main__":
    main()
