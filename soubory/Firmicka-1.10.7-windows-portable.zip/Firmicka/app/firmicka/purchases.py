"""Přijaté faktury (od dodavatelů): kniha přijatých faktur, naskladnění s nákupní cenou,
úhrada do peněžního deníku, podklady k DPH (výstup z vydaných, odpočet z přijatých).
Formulář sdílí skript s vydanou fakturou (pole cust_* = dodavatel)."""
import json
from datetime import date, timedelta

from .contacts import address as contact_address
from .db import rnd, invoice_totals, next_invoice_number, line_fee, today, now, VAT_RATES
from .invoices import PAYMENTS, lines_of
from .docs import auto_number, auto_number_input
from .stock import items_json
from .warehouses import wh_select, read_wh, default_wh
from .web import h, money, qty, parse_money, parse_qty, parse_vat, parse_id, cz_date, flash, flash_redirect, HTTPError, Response

STATUS = {"neuhrazena": "Neuhrazená", "uhrazena": "Uhrazená"}


def plines(db, pid):
    return db.q("SELECT * FROM purchase_lines WHERE purchase_id = ? ORDER BY pos", (pid,))


def unit_cost(ln, vat_payer):
    """Skladová cena za jednotku: plátce bez DPH (odpočte si ji), neplátce včetně DPH."""
    c = ln["price"] + line_fee(ln)
    return c if vat_payer else rnd(c * (100 + ln["vat_rate"]) / 100)


def sync_purchase(db, pid, vat_payer):
    """Naskladnění a zápis úhrady podle aktuálního stavu (volat v transakci)."""
    p = db.one("SELECT * FROM purchases WHERE id = ?", (pid,))
    db.run("DELETE FROM movements WHERE purchase_id = ?", (pid,))
    db.run("DELETE FROM cashbook WHERE purchase_id = ?", (pid,))
    lines = plines(db, pid)
    if p["stock_in"]:
        for ln in lines:
            if ln["item_id"]:
                db.run("INSERT INTO movements(item_id, date, qty, kind, unit_cost, doc, purchase_id, warehouse_id) "
                       "VALUES(?,?,?,'nakup',?,?,?,?)", (ln["item_id"], p["tax_date"], ln["qty"],
                                                          unit_cost(ln, vat_payer), p["number"], pid, p["warehouse_id"]))
    if p["status"] == "uhrazena":
        total = invoice_totals(lines, True)["total"]
        db.run("INSERT INTO cashbook(date, doc, text, direction, account, amount, taxable, category, purchase_id) "
               "VALUES(?,?,?,'vydaj',?,?,1,'Materiál a zboží',?)",
               (p["paid_date"] or today(), p["doc_number"], "Úhrada faktury %s – %s" % (p["number"], p["supp_name"]),
                "pokladna" if p["payment"] == "hotove" else "banka", total, pid))


def register(app):
    db = app.db

    @app.route("/prijate")
    def index(req):
        year = req.args.get("rok", "")
        year = year if year.isdigit() and len(year) == 4 else today()[:4]
        st = req.args.get("stav", "")
        sql, args = "SELECT * FROM purchases WHERE substr(tax_date, 1, 4) = ?", [year]
        if st in STATUS:
            sql += " AND status = ?"
            args.append(st)
        rows = db.q(sql + " ORDER BY tax_date DESC, id DESC", args)
        trs, unpaid = [], 0
        for r in rows:
            t = invoice_totals(plines(db, r["id"]), True)["total"]
            if r["status"] == "neuhrazena":
                unpaid += t
            overdue = r["status"] == "neuhrazena" and r["due_date"] < today()
            trs.append("<tr%s><td><a href='/prijate/%d'>%s</a></td><td>%s</td><td>%s</td><td>%s</td><td>%s</td>"
                       "<td class=num>%s</td><td><span class='tag %s'>%s</span></td></tr>" % (
                           " class=warn" if overdue else "", r["id"], h(r["doc_number"]), h(r["number"]), h(r["supp_name"]),
                           cz_date(r["tax_date"]), cz_date(r["due_date"]), money(t),
                           "vystavena" if r["status"] == "neuhrazena" else "zaplacena",
                           "Po splatnosti" if overdue else STATUS[r["status"]]))
        ssel = "".join('<option value="%s"%s>%s</option>' % (k, " selected" if k == st else "", v)
                       for k, v in [("", "Všechny")] + list(STATUS.items()))
        return app.page("Přijaté faktury", """%s<div class="bar"><h1>Přijaté faktury</h1>
<a class="btn" href="/export">Export pro účetní</a><a class="btn" href="/dph">Podklady k DPH</a><a class="btn primary" href="/prijate/nova">+ Přijatá faktura</a></div>
<form class="filters"><input name="rok" value="%s" size="4" inputmode="numeric">
<select name="stav" onchange="this.form.submit()">%s</select><button>Zobrazit</button>
<a class="btn" href="/export/prijate.csv?rok=%s">Export CSV</a></form>
<div class="stats"><div><span>Neuhrazeno dodavatelům</span><b class=out>%s</b></div></div>
<table class="list"><thead><tr><th>Evid. č.</th><th>Číslo dodavatele</th><th>Dodavatel</th><th>DUZP</th><th>Splatnost</th>
<th class=num>Celkem</th><th>Stav</th></tr></thead><tbody>%s</tbody></table>%s""" % (
            flash(req), h(year), ssel, h(year), money(unpaid), "".join(trs),
            "" if rows else "<p class=empty>V tomto roce žádné přijaté faktury.</p>"), "/prijate")

    def form(req, p, lines, pid=None, err=""):
        contacts = db.q("SELECT * FROM contacts ORDER BY name COLLATE NOCASE")
        contacts_js = json.dumps({str(c["id"]): {"name": c["name"], "ico": c["ico"], "dic": c["dic"],
                                                 "address": contact_address(c)} for c in contacts}, ensure_ascii=False)
        copts = '<option value="">— vybrat z adresáře —</option>' + "".join(
            '<option value="%d"%s>%s</option>' % (c["id"], " selected" if str(c["id"]) == str(p.get("contact_id") or "") else "",
                                                  h(c["name"])) for c in contacts)
        items = db.q("SELECT * FROM items WHERE active = 1 ORDER BY name COLLATE NOCASE")
        iopts = '<option value="">volný text / služba</option>' + "".join(
            '<option value="%d">%s</option>' % (i["id"], h(i["name"])) for i in items)
        pay = "".join('<option value="%s"%s>%s</option>' % (k, " selected" if k == p.get("payment", "prevod") else "", v)
                      for k, v in PAYMENTS.items())
        vat_opts = "".join('<option value="%d">%d %%</option>' % (v, v) for v in VAT_RATES)
        rows = json.dumps([{"item": ln.get("item_id") or "", "text": ln["text"], "qty": ln["qty"], "unit": ln["unit"],
                            "price": ln["price"], "vat": ln["vat_rate"], "fee": line_fee(ln)} for ln in lines], ensure_ascii=False)
        vp = req.settings["vat_payer"] == "1"
        isdoc_form = "" if pid else """<form method="post" action="/prijate/isdoc" enctype="multipart/form-data" class="filters card">
%s<b>Máte fakturu v ISDOC?</b><input type="file" name="isdoc" accept=".isdoc,.isdocx,.xml" required>
<button class="btn">Načíst a předvyplnit</button></form>""" % app.csrf()
        action = "/prijate/%s/upravit" % pid if pid else "/prijate/nova"
        return app.page("Přijatá faktura", ("""<h1>%s</h1>%s""" + isdoc_form + """
<form method="post" action=\"""" + action + """\" id="invoice" data-vat="1" data-purchase="1">%s
<div class="grid">
<section class="card wide"><h2>Dodavatel</h2><div class="grid">
<label class="wide">Z adresáře<select name="contact_id" data-contacts='%s'>%s</select></label>
<label class="wide">Název<input name="cust_name" value="%s" required></label>
<label>IČO<span class="row"><input name="cust_ico" value="%s"><button type="button" class="btn" data-ares-inv>ARES</button></span></label>
<label>DIČ<input name="cust_dic" value="%s"></label>
<label class="wide">Adresa<textarea name="cust_address" rows="2">%s</textarea></label>
<label>Účet dodavatele<input name="supp_account" value="%s"></label>
<label class="check"><input type="checkbox" name="save_contact" value="1"> Uložit do adresáře</label>
</div></section>
<label>Evidenční číslo<input name="doc_number" value="%s" required>%s</label>
<label>Číslo faktury dodavatele<input name="number" value="%s" required></label>
<label>Variabilní symbol<input name="vs" value="%s"></label>
<label>Datum vystavení<input type="date" name="issue_date" value="%s" required></label>
<label>DUZP<input type="date" name="tax_date" value="%s"></label>
<label>Splatnost<input type="date" name="due_date" value="%s" required></label>
<label>Způsob platby<select name="payment">%s</select></label>
<label class="check"><input type="checkbox" name="stock_in" value="1"%s> Naskladnit položky ze skladu</label>
%s
</div>
<h2>Položky</h2><p class="hint">Ceny bez DPH a sazba podle faktury dodavatele (neplátce DPH: sazba 0 %%).%s</p>
<div class="filters"><input id="scan" placeholder="Pípněte EAN – přidá položku" data-scan inputmode="numeric">
<span class="hint" id="scan-msg"></span></div>
<table class="lines"><thead><tr><th>Do skladu</th><th>Popis</th><th class=num>Množství</th><th>Jedn.</th>
<th class=num>Cena/j. bez DPH</th><th class=num>Rec. popl./j.</th><th>DPH</th><th class=num>Celkem</th><th></th></tr></thead>
<tbody id="lines" data-items='%s' data-rows='%s'></tbody></table>
<template id="line-tpl"><tr>
<td><select name="line_item">%s</select></td><td><input name="line_text"></td>
<td><input name="line_qty" class=num inputmode="decimal" value="1"></td><td><input name="line_unit" value="ks" size="4"></td>
<td><input name="line_price" class=num inputmode="decimal"></td>
<td><input name="line_fee" class=num inputmode="decimal" placeholder="0"></td><td><select name="line_vat">%s</select></td>
<td class="num line-total"></td><td><button type="button" class="link danger" data-del>✕</button></td></tr></template>
<p><button type="button" class="btn" id="add-line">+ Přidat řádek</button> <span class="hint" id="stock-warn"></span></p>
<div class="totals" id="totals"></div>
<label class="wide">Poznámka<textarea name="note" rows="2">%s</textarea></label>
<div class="actions"><button class="btn primary">Uložit</button><a class="btn" href="%s">Zrušit</a></div>
</form>""") % (
            "Upravit přijatou fakturu %s" % h(p["doc_number"]) if pid else "Nová přijatá faktura",
            '<div class="flash error">%s</div>' % h(err) if err else "", app.csrf(), h(contacts_js), copts,
            h(p.get("cust_name")), h(p.get("cust_ico")), h(p.get("cust_dic")), h(p.get("cust_address")),
            h(p.get("supp_account")), h(p["doc_number"]),
            "" if pid else auto_number_input(p, field="doc_number", date_field=""), h(p.get("number")), h(p.get("vs")), h(p["issue_date"]),
            h(p["tax_date"]), h(p["due_date"]), pay, " checked" if p.get("stock_in", 1) else "",
            wh_select(db, p.get("warehouse_id") or default_wh(db, req), label="Naskladnit do skladu"),
            "" if vp else " Nejste plátce DPH – do skladu se zboží zapíše za cenu včetně DPH.",
            h(json.dumps(items_json(db), ensure_ascii=False)), h(rows), iopts, vat_opts, h(p.get("note")),
            "/prijate/%s" % pid if pid else "/prijate"), "/prijate")

    def read_form(req, fallback=None):
        p = {k: req.f(k) for k in ("doc_number", "number", "vs", "issue_date", "tax_date", "due_date", "payment",
                                   "cust_name", "cust_ico", "cust_dic", "supp_account", "contact_id")}
        p["cust_address"] = req.form.get("cust_address", "").strip()
        p["note"] = req.form.get("note", "").strip()
        p["stock_in"] = 1 if req.f("stock_in") else 0
        p["warehouse_id"] = read_wh(db, req, fallback)
        p["save_contact"] = req.f("save_contact")
        p["tax_date"] = p["tax_date"] or p["issue_date"]
        if p["payment"] not in PAYMENTS:
            p["payment"] = "prevod"
        cols = [req.lst(k) for k in ("line_item", "line_text", "line_qty", "line_unit", "line_price", "line_vat", "line_fee")]
        n = len(cols[0])
        cols = [c + [""] * (n - len(c)) for c in cols]
        lines = []
        for it, text, q, unit, price, vat, fee in zip(*cols):
            if not text.strip() and not it:
                continue
            lines.append({"item_id": parse_id(it), "text": text.strip(), "qty": parse_qty(q),
                          "unit": unit.strip() or "ks", "price": parse_money(price), "vat_rate": parse_vat(vat),
                          "recycling_fee": parse_money(fee)})
        return p, lines

    def validate(p, lines, pid=None):
        if not p["cust_name"]:
            return "Vyplňte dodavatele"
        if not p["number"] or not p["doc_number"]:
            return "Vyplňte číslo faktury dodavatele i evidenční číslo"
        if not lines:
            return "Faktura musí mít aspoň jednu položku"
        if db.one("SELECT id FROM purchases WHERE doc_number = ? AND id != ?", (p["doc_number"], pid or 0)):
            return "Evidenční číslo %s už existuje" % p["doc_number"]
        for k in ("issue_date", "tax_date", "due_date"):
            try:
                date.fromisoformat(p[k])
            except ValueError:
                return "Neplatné datum"
        return ""

    def save(req, p, lines, pid=None):
        vp = req.settings["vat_payer"] == "1"
        with db.tx():
            cid = p["contact_id"] if p["contact_id"].isdigit() else None
            if p["save_contact"] and not cid:
                from .docs import find_by_ico
                cid = find_by_ico(db, p["cust_ico"])
            if p["save_contact"] and not cid:
                street, _, rest = p["cust_address"].partition("\n")
                zip_, _, city = rest.split("\n")[0].strip().partition(" ")
                cid = db.run("INSERT INTO contacts(name, ico, dic, street, city, zip) VALUES(?,?,?,?,?,?)",
                             (p["cust_name"], p["cust_ico"], p["cust_dic"], street.strip(), city.strip(), zip_))
            vals = (p["number"], p["doc_number"], cid, p["cust_name"], p["cust_address"], p["cust_ico"], p["cust_dic"],
                    p["supp_account"], p["issue_date"], p["tax_date"], p["due_date"], p["payment"], p["vs"], p["note"],
                    p["stock_in"], p["warehouse_id"])
            cols = ("number, doc_number, contact_id, supp_name, supp_address, supp_ico, supp_dic, supp_account, "
                    "issue_date, tax_date, due_date, payment, vs, note, stock_in, warehouse_id")
            if pid:
                db.run("UPDATE purchases SET %s WHERE id = ?" % ", ".join(c.strip() + "=?" for c in cols.split(",")),
                       vals + (pid,))
                db.run("DELETE FROM purchase_lines WHERE purchase_id = ?", (pid,))
            else:
                pid = db.run("INSERT INTO purchases(%s, created) VALUES(%s)" % (cols, ",".join("?" * (len(vals) + 1))),
                             vals + (now(),))
            for pos, ln in enumerate(lines):
                db.run("INSERT INTO purchase_lines(purchase_id, pos, item_id, text, qty, unit, price, vat_rate, recycling_fee) "
                       "VALUES(?,?,?,?,?,?,?,?,?)", (pid, pos, ln["item_id"], ln["text"], ln["qty"], ln["unit"],
                                                     ln["price"], ln["vat_rate"], ln["recycling_fee"]))
            sync_purchase(db, pid, vp)
        return pid

    def get(pid):
        p = db.one("SELECT * FROM purchases WHERE id = ?", (pid,))
        if not p:
            raise HTTPError(404, "Přijatá faktura neexistuje")
        return p

    def as_form(p):
        d = dict(p)
        d.update(cust_name=p["supp_name"], cust_ico=p["supp_ico"], cust_dic=p["supp_dic"], cust_address=p["supp_address"])
        return d

    @app.route("/prijate/nova", ("GET", "POST"))
    def new(req):
        if req.method == "POST":
            p, lines = read_form(req)
            with db.lock:   # kontrola čísla/zálohy a zápis naráz (souběh více uživatelů)
                p["doc_number"], num_msg = auto_number(db, req, p["doc_number"], today(), req.settings["purchase_format"],
                                                       "purchases", "doc_number")
                p["number_auto"] = p["doc_number"] if num_msg else req.f("number_auto")
                err = validate(p, lines)
                if err:
                    return form(req, p, lines, err=err)
                pid = save(req, p, lines)
            flash_redirect("/prijate/%d" % pid, "Přijatá faktura zapsána" + (" a zboží naskladněno" if p["stock_in"] else "") +
                           (" · " + num_msg if num_msg else ""))
        return form(req, new_defaults(req), [])

    def new_defaults(req):
        d = today()
        return {"doc_number": next_invoice_number(db, d, req.settings["purchase_format"], "purchases", "doc_number"),
                "issue_date": d, "tax_date": d, "due_date": (date.today() + timedelta(days=14)).isoformat(), "stock_in": 1}

    @app.route("/prijate/isdoc", ("POST",))
    def from_isdoc(req):
        from . import isdoc
        f = req.files.get("isdoc")
        if not f:
            flash_redirect("/prijate/nova", "Vyberte soubor ISDOC")
        try:
            head, lines = isdoc.parse(f[1])
        except Exception as e:
            return form(req, new_defaults(req), [], err="ISDOC se nepodařilo načíst: %s" % e)
        p = new_defaults(req)
        cur = head.pop("currency", "CZK")
        doc_type, warnings = head.pop("doc_type", "1"), head.pop("warnings", [])
        if doc_type == "4":
            return form(req, new_defaults(req), [], err="Tohle je zálohová faktura – není to daňový doklad a DPH z ní "
                        "odečíst nejde. Zapište ji až jako daňový doklad k přijaté platbě nebo konečnou fakturu.")
        p.update({k: v for k, v in head.items() if v})
        if cur != "CZK":
            p["note"] = "\n".join(x for x in ("Faktura vystavena v měně %s – částky přepočteny na Kč." % cur, p.get("note")) if x)
        known = db.one("SELECT id FROM contacts WHERE ico = ? AND ico != ''", (head["cust_ico"],))
        if known:
            p["contact_id"] = known["id"]
        # řádky se jménem shodným se skladovou položkou rovnou napojit na sklad
        for ln in lines:
            it = db.one("SELECT id FROM items WHERE name = ? COLLATE NOCASE AND active = 1", (ln["text"],))
            if it:
                ln["item_id"] = it["id"]
        if cur != "CZK":
            return form(req, p, lines, err="POZOR: faktura je v měně %s – ceny položek níže jsou v %s, ne v Kč. Přepočtěte je "
                                           "na Kč kurzem ČNB ke dni zdanitelného plnění a teprve pak uložte." % (cur, cur))
        msg = "Načteno z ISDOC – zkontrolujte a uložte" if lines else "V ISDOC nejsou položky"
        if doc_type == "2":
            msg = "Načten DOBROPIS od dodavatele – položky jsou záporné (snižují odpočet DPH). Zkontrolujte a uložte"
        return form(req, p, lines, err=" · ".join([msg] + warnings))

    @app.route("/prijate/<pid>/upravit", ("GET", "POST"))
    def edit(req, pid):
        p = get(pid)
        if p["status"] == "uhrazena":
            flash_redirect("/prijate/%d" % p["id"], "Uhrazenou fakturu nejdřív vraťte na neuhrazenou")
        if req.method == "POST":
            np, lines = read_form(req, p["warehouse_id"])
            with db.lock:   # kontrola čísla/zálohy a zápis naráz (souběh více uživatelů)
                err = validate(np, lines, p["id"])
                if err:
                    return form(req, np, lines, p["id"], err)
                save(req, np, lines, p["id"])
            flash_redirect("/prijate/%d" % p["id"], "Uloženo")
        return form(req, as_form(p), [dict(ln) for ln in plines(db, p["id"])], p["id"])

    @app.route("/prijate/<pid>/stav", ("POST",))
    def set_status(req, pid):
        p = get(pid)
        a = req.f("akce")
        with db.tx():
            if a == "zaplaceno" and p["status"] == "neuhrazena":
                db.run("UPDATE purchases SET status='uhrazena', paid_date=? WHERE id=?", (req.f("paid_date") or today(), p["id"]))
                msg = "Uhrazeno – výdaj zapsán do peněžního deníku"
            elif a == "nezaplaceno" and p["status"] == "uhrazena":
                db.run("UPDATE purchases SET status='neuhrazena', paid_date='' WHERE id=?", (p["id"],))
                msg = "Úhrada zrušena"
            else:
                raise HTTPError(400, "Tuto akci nejde provést")
            sync_purchase(db, p["id"], req.settings["vat_payer"] == "1")
        flash_redirect("/prijate/%d" % p["id"], msg)

    @app.route("/prijate/<pid>/smazat", ("POST",))
    def delete(req, pid):
        p = get(pid)
        with db.tx():
            db.run("DELETE FROM movements WHERE purchase_id = ?", (p["id"],))
            db.run("DELETE FROM cashbook WHERE purchase_id = ?", (p["id"],))
            db.run("DELETE FROM purchases WHERE id = ?", (p["id"],))
        flash_redirect("/prijate", "Přijatá faktura %s smazána (i naskladnění a úhrada)" % p["doc_number"])

    @app.route("/prijate/<pid>")
    def detail(req, pid):
        p = get(pid)
        lines = plines(db, p["id"])
        t = invoice_totals(lines, True)
        trs = "".join("<tr><td>%s%s</td><td class=num>%s %s</td><td class=num>%s</td><td class=num>%s</td>"
                      "<td class=num>%d %%</td><td class=num>%s</td></tr>" % (
                          h(ln["text"]), " <span class=tag>sklad</span>" if ln["item_id"] and p["stock_in"] else "",
                          qty(ln["qty"]), h(ln["unit"]), money(ln["price"]),
                          money(line_fee(ln)) if line_fee(ln) else "", ln["vat_rate"],
                          money(rnd(ln["qty"] * (ln["price"] + line_fee(ln))))) for ln in lines)
        recap = "".join("<tr><td>%d %%</td><td class=num>%s</td><td class=num>%s</td><td class=num>%s</td></tr>" % (
            r["rate"], money(r["base"]), money(r["vat"]), money(r["total"])) for r in t["recap"])
        if p["status"] == "neuhrazena":
            act = ('<a class="btn" href="/prijate/%d/upravit">Upravit</a><form method="post" action="/prijate/%d/stav" '
                   'class="inline">%s<input type="hidden" name="akce" value="zaplaceno"><input type="date" name="paid_date" '
                   'value="%s"><button class="btn ok">Uhrazeno</button></form>' % (p["id"], p["id"], app.csrf(), today()))
        else:
            act = ('<form method="post" action="/prijate/%d/stav" class="inline">%s<input type="hidden" name="akce" '
                   'value="nezaplaceno"><button class="btn">Zrušit úhradu</button></form>' % (p["id"], app.csrf()))
        act += ('<form method="post" action="/prijate/%d/smazat" class="inline" onsubmit="return confirm(\'Smazat přijatou '
                'fakturu včetně naskladnění?\')">%s<button class="link danger">smazat</button></form>' % (p["id"], app.csrf()))
        info = [(k, v) for k, v in [
            ("Číslo dodavatele", h(p["number"])), ("VS", h(p["vs"])), ("Vystaveno", cz_date(p["issue_date"])),
            ("DUZP", cz_date(p["tax_date"])), ("Splatnost", cz_date(p["due_date"])),
            ("Platba", PAYMENTS.get(p["payment"], "")), ("Účet dodavatele", h(p["supp_account"])),
            ("Stav", STATUS[p["status"]] + (" " + cz_date(p["paid_date"]) if p["paid_date"] else ""))] if v]
        return app.page("Přijatá " + p["doc_number"], """%s<div class="bar"><a href="/prijate">← Přijaté</a>
<div class="actions">%s</div></div>
<section class="card"><h1>Přijatá faktura %s</h1><b>%s</b><div>%s</div><div class="hint">%s</div></section>
<div class="stats">%s</div>
<table class="list"><thead><tr><th>Popis</th><th class=num>Množství</th><th class=num>Cena/j.</th><th class=num>Rec./j.</th>
<th class=num>DPH</th><th class=num>Základ</th></tr></thead><tbody>%s</tbody></table>
<h2>Rekapitulace</h2><table class="list"><thead><tr><th>Sazba</th><th class=num>Základ</th><th class=num>DPH</th>
<th class=num>Celkem</th></tr></thead><tbody>%s</tbody>
<tfoot><tr><th>Celkem k úhradě</th><th></th><th></th><th class=num>%s</th></tr></tfoot></table>%s""" % (
            flash(req), act, h(p["doc_number"]), h(p["supp_name"]), h(p["supp_address"]).replace("\n", ", "),
            " · ".join(x for x in ("IČO " + h(p["supp_ico"]) if p["supp_ico"] else "",
                                    "DIČ " + h(p["supp_dic"]) if p["supp_dic"] else "") if x),
            "".join("<div><span>%s</span><b class=small>%s</b></div>" % kv for kv in info),
            trs, recap, money(t["total"]),
            "<p class=note>%s</p>" % h(p["note"]) if p["note"] else ""), "/prijate")

    # ---------- podklady k DPH ----------
    @app.route("/dph")
    def vat(req):
        year = req.args.get("rok", "")
        year = year if year.isdigit() and len(year) == 4 else today()[:4]
        per = req.args.get("obdobi", "mesic")
        periods = ([("%02d" % m, "%d. měsíc" % m) for m in range(1, 13)] if per == "mesic"
                   else [("Q%d" % q, "%d. čtvrtletí" % q) for q in range(1, 5)])

        def key(d):
            m = int(d[5:7])
            return "%02d" % m if per == "mesic" else "Q%d" % ((m - 1) // 3 + 1)
        out, inp = {}, {}

        def add(target, docs_sql, lines_table, fk, date_col):
            """Řádky všech dokladů roku jedním dotazem (dřív dotaz na každou účtenku → 1 s při 30 000 účtenkách)."""
            docs = db.q(docs_sql, (year,))
            lines = {}
            for ln in db.q("SELECT l.* FROM %s l JOIN (%s) d ON d.id = l.%s ORDER BY l.%s, l.pos" % (
                    lines_table, docs_sql, fk, fk), (year,)):
                lines.setdefault(ln[fk], []).append(ln)
            for d in docs:
                for r in invoice_totals(lines.get(d["id"], []), True)["recap"]:
                    b = target.setdefault(key(d[date_col]), {}).setdefault(r["rate"], [0, 0])
                    b[0] += r["base"]
                    b[1] += r["vat"]
        add(out, "SELECT id, tax_date FROM invoices WHERE status != 'stornovana' AND vat_payer = 1 AND kind != 'zaloha' "
                 "AND substr(tax_date,1,4) = ?", "invoice_lines", "invoice_id", "tax_date")
        add(out, "SELECT id, date FROM receipts WHERE status = 'ok' AND vat_payer = 1 AND substr(date,1,4) = ?",
            "receipt_lines", "receipt_id", "date")
        add(inp, "SELECT id, tax_date FROM purchases WHERE substr(tax_date,1,4) = ?", "purchase_lines", "purchase_id", "tax_date")
        trs = []
        for k, name in periods:
            o, i = out.get(k, {}), inp.get(k, {})
            vo = sum(v[1] for v in o.values())
            vi = sum(v[1] for r, v in i.items() if r)
            if not o and not i:
                continue
            cells = []
            for rate in (21, 12):
                cells += [money(o.get(rate, [0, 0])[0]), money(o.get(rate, [0, 0])[1]),
                          money(i.get(rate, [0, 0])[0]), money(i.get(rate, [0, 0])[1])]
            trs.append("<tr><td>%s</td>%s<td class=num><b>%s</b></td></tr>" % (
                name, "".join("<td class=num>%s</td>" % c for c in cells), money(vo - vi)))
        sel = "".join('<option value="%s"%s>%s</option>' % (v, " selected" if v == per else "", t)
                      for v, t in (("mesic", "Měsíčně"), ("ctvrtleti", "Čtvrtletně")))
        warn = "" if req.settings["vat_payer"] == "1" else '<div class="flash">V nastavení nejste plátce DPH.</div>'
        return app.page("Podklady k DPH", """%s<div class="bar"><h1>Podklady k DPH %s</h1>
<button class="btn" onclick="window.print()">Tisk</button></div>
<form class="filters"><input name="rok" value="%s" size="4"><select name="obdobi" onchange="this.form.submit()">%s</select>
<button>Zobrazit</button></form>
<table class="list"><thead><tr><th rowspan=2>Období</th><th colspan=4>Sazba 21 %%</th><th colspan=4>Sazba 12 %%</th>
<th rowspan=2 class=num>Daň k úhradě<br>(− nadměrný odpočet)</th></tr>
<tr><th class=num>Výstup základ</th><th class=num>Výstup daň</th><th class=num>Vstup základ</th><th class=num>Odpočet</th>
<th class=num>Výstup základ</th><th class=num>Výstup daň</th><th class=num>Vstup základ</th><th class=num>Odpočet</th></tr></thead>
<tbody>%s</tbody></table>
%s
<p class="hint">Výstup = vydané faktury, dobropisy, daňové doklady k přijatým zálohám a účtenky z pokladny podle DUZP
(bez stornovaných a bez zálohových faktur), vstup = přijaté faktury podle DUZP. Podklad pro přiznání
k DPH a kontrolní hlášení – nárok na odpočet a zařazení do řádků přiznání ověřte s účetní.</p>""" % (
            warn, h(year), h(year), sel, "".join(trs) or "<tr><td colspan=10 class=empty>Žádné doklady.</td></tr>",
            epo_card(req, year, per)), "/prijate")

    def epo_card(req, year, per):
        from . import epo
        s = req.settings
        miss = epo.check_settings(s)
        cur = date.today()
        if per == "mesic":
            opts = [("m%d" % m, "%d. měsíc" % m) for m in range(1, 13)]
            default = "m%d" % (cur.month - 1 or 12)
        else:
            opts = [("q%d" % q, "%d. čtvrtletí" % q) for q in range(1, 5)]
            default = "q%d" % ((cur.month - 1) // 3 or 4)
        psel = "".join('<option value="%s"%s>%s</option>' % (v, " selected" if v == default else "", t) for v, t in opts)
        if miss:
            body = '<p class="flash error">Pro export doplňte v <a href="/nastaveni#epo">Nastavení → Finanční úřad</a>: %s.</p>' % \
                   h(", ".join(miss))
        else:
            body = """<form class="filters" action="/dph/epo"><input name="rok" value="%s" size="4">
<select name="obdobi">%s</select>
<select name="forma"><option value="B">řádné</option><option value="O">řádné-opravné</option></select>
<button class="btn primary" name="co" value="dp3">Přiznání k DPH (XML)</button>
<button class="btn primary" name="co" value="kh1">Kontrolní hlášení (XML)</button></form>""" % (h(year), psel)
        return """<section class="card"><h2>Podání přes EPO</h2>%s
<p class="hint">Soubor nahrajete na <b>adisspr.mfcr.cz → EPO → Elektronická podání pro finanční správu → Načíst ze souboru</b>,
kde ho EPO zkontroluje a odešlete (datovou schránkou nebo s ověřením). Pokrývá běžné tuzemské plnění v sazbách 21 a 12 %%
a odpočet v plné výši – přenesenou daňovou povinnost, EU, dovoz, vývoz a krácený odpočet doplňte v EPO ručně.
Před odesláním si údaje projděte; za správnost podání odpovídáte vy.</p></section>""" % body

    @app.route("/dph/epo")
    def epo_xml(req):
        from . import epo
        s = req.settings
        if epo.check_settings(s):
            flash_redirect("/dph", "Doplňte údaje pro finanční úřad v Nastavení")
        y = req.args.get("rok", "")
        p = req.args.get("obdobi", "")
        if not (y.isdigit() and len(y) == 4 and p[:1] in ("m", "q") and p[1:].isdigit()):
            raise HTTPError(400, "Neplatné období")
        year, n = int(y), int(p[1:])
        month, quarter = (n, None) if p[0] == "m" else (None, n)
        if month and not 1 <= month <= 12 or quarter and not 1 <= quarter <= 4:
            raise HTTPError(400, "Neplatné období")
        od, do = epo.period_range(year, month, quarter)
        data = epo.collect(db, od, do)
        forma = req.args.get("forma") if req.args.get("forma") in ("B", "O") else "B"
        co = req.args.get("co")
        if co == "dp3":
            xml, _ = epo.dp3(s, data, year, month, quarter, forma)
        elif co == "kh1":
            xml, _ = epo.kh1(s, data, year, month, quarter, forma)
        else:
            raise HTTPError(400, "Neznámý formulář")
        name = "%s-%d-%s.xml" % ("priznani-dph" if co == "dp3" else "kontrolni-hlaseni", year,
                                 "%02d" % month if month else "Q%d" % quarter)
        return Response(xml, ctype="application/xml", headers=[("Content-Disposition", 'attachment; filename="%s"' % name)])

    @app.route("/nastaveni/epo", ("POST",))
    def epo_settings(req):
        from .epo_codes import UFO, PRACUFO
        vals = {"epo_ufo": req.f("epo_ufo") if req.f("epo_ufo") in UFO else "",
                "epo_pracufo": req.f("epo_pracufo") if req.f("epo_pracufo") in PRACUFO else "",
                "epo_typ_ds": "F" if req.f("epo_typ_ds") == "F" else "P",
                "epo_jmeno": req.f("epo_jmeno"), "epo_prijmeni": req.f("epo_prijmeni"),
                "epo_okec": "".join(c for c in req.f("epo_okec") if c.isdigit())[:6]}
        if vals["epo_pracufo"] and PRACUFO[vals["epo_pracufo"]][1] != vals["epo_ufo"]:
            flash_redirect("/nastaveni#epo", "Územní pracoviště nepatří k vybranému finančnímu úřadu")
        db.set_settings(vals)
        flash_redirect("/nastaveni#epo", "Údaje pro finanční úřad uloženy")


def epo_settings_form(app, s):
    from .epo_codes import UFO, PRACUFO
    ufo = '<option value="">— vyberte —</option>' + "".join(
        '<option value="%s"%s>%s</option>' % (k, " selected" if k == s["epo_ufo"] else "", h(v))
        for k, v in sorted(UFO.items(), key=lambda kv: kv[1]))
    prac = '<option value="">— vyberte —</option>' + "".join(
        '<option value="%s" data-ufo="%s"%s>%s</option>' % (k, u, " selected" if k == s["epo_pracufo"] else "", h(n))
        for k, (n, u) in sorted(PRACUFO.items(), key=lambda kv: kv[1][0]))
    return """<section class="card" id="epo"><h2>Finanční úřad (přiznání k DPH a kontrolní hlášení)</h2>
<form method="post" action="/nastaveni/epo" class="grid">%s
<label>Finanční úřad<select name="epo_ufo" id="epo_ufo">%s</select></label>
<label>Územní pracoviště<select name="epo_pracufo" id="epo_pracufo">%s</select></label>
<label>Daňový subjekt<select name="epo_typ_ds"><option value="P"%s>právnická osoba (s.r.o., a.s.…)</option>
<option value="F"%s>fyzická osoba (OSVČ)</option></select></label>
<label>CZ-NACE hlavní činnosti<input name="epo_okec" value="%s" inputmode="numeric" placeholder="např. 952100"></label>
<label>Jméno (OSVČ)<input name="epo_jmeno" value="%s"></label><label>Příjmení (OSVČ)<input name="epo_prijmeni" value="%s"></label>
<p class="wide hint">DIČ, adresa, e-mail a telefon se berou z údajů firmy výše.</p>
<div class="actions wide"><button class="btn">Uložit</button></div></form>
<script>(function () { var u = document.getElementById("epo_ufo"), p = document.getElementById("epo_pracufo");
function f() { for (var o of p.options) { o.hidden = o.value && o.dataset.ufo !== u.value; }
  if (p.selectedOptions[0] && p.selectedOptions[0].hidden) p.value = ""; }
u.addEventListener("change", f); f(); })();</script></section>""" % (
        app.csrf(), ufo, prac, " selected" if s["epo_typ_ds"] != "F" else "", " selected" if s["epo_typ_ds"] == "F" else "",
        h(s["epo_okec"]), h(s["epo_jmeno"]), h(s["epo_prijmeni"]))
