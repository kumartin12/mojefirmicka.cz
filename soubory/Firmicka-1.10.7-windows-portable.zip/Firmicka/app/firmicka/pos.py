"""Pokladna: rychlý prodej (čtečka EAN), účtenka na síťovou termotiskárnu (ESC/POS, port 9100)
nebo do prohlížeče, odpis ze skladu, tržba do peněžního deníku, denní uzávěrka.
Ceny řádků jsou jako na faktuře (plátce bez DPH + sazba), na účtence se tisknou s DPH."""
import socket
import time
from datetime import datetime

from . import docs, qr
from .warehouses import wh_select, read_wh, default_wh
from .db import rnd, invoice_totals, item_costs, line_fee, next_invoice_number, today, now
from .web import h, money, qty, parse_id, cz_date, flash, flash_redirect, HTTPError

PAY = {"hotove": "Hotově", "karta": "Kartou", "qr": "QR platba"}
QR_MODES = {"native": "Příkazem tiskárny (většina tiskáren)", "image": "Jako obrázek (starší tiskárny)",
            "off": "Netisknout QR"}
CODEPAGES = {"18": "cp852", "17": "cp866", "16": "cp1252", "0": "cp437"}


def rlines(db, rid):
    return db.q("SELECT * FROM receipt_lines WHERE receipt_id = ? ORDER BY pos", (rid,))


def gross(ln, vat_payer):
    """Cena za jednotku s DPH (včetně recyklačního poplatku jako samostatné částky)."""
    rate = ln["vat_rate"] if vat_payer else 0
    return rnd(ln["price"] * (100 + rate) / 100), rnd(line_fee(ln) * (100 + rate) / 100)


# ---------- QR platba ----------

def receipt_vs(number):
    """Variabilní symbol z čísla účtenky (jen číslice, nejvýš 10 posledních)."""
    return "".join(c for c in number if c.isdigit())[-10:]


def _col(r, name, default=""):
    return r[name] if name in r.keys() else default


def receipt_spayd(s, r, total):
    """Obsah QR platby k účtence, nebo None (není účet / nejde o čekající QR platbu)."""
    if r["payment"] != "qr" or r["status"] != "ok" or total <= 0 or _col(r, "paid_date"):
        return None
    iban = qr.cz_iban(s["bank_account"]) if s["bank_account"] else None
    if not iban:
        return None
    return qr.spayd(iban, total, receipt_vs(r["number"]), "Uctenka " + r["number"])


# ---------- text účtenky (pro tiskárnu i náhled) ----------

def receipt_text(s, r, lines, width=48):
    vp = bool(r["vat_payer"])
    t = invoice_totals(lines, vp)
    W = width

    def lr(left, right):
        left = left[:W - len(right) - 1]
        return left + " " * (W - len(left) - len(right)) + right

    def add_lr(left, right, bold=False):
        """Levý text + částka vpravo; když se nevejdou na jeden řádek (58 mm), částka jde na další řádek."""
        if len(left) + 1 + len(right) <= W:
            out.append(("L", lr(left, right), bold))
        else:
            for part in wrap(left, W):
                out.append(("L", part, bold))
            out.append(("L", right.rjust(W), bold))

    def wrap(text, w):
        import textwrap
        return textwrap.wrap(text, w, subsequent_indent="  " if text.startswith("  ") else "",
                             break_long_words=True) or [""]

    def add_c(text, bold=False):
        """Na střed; delší text (název firmy) zalomit, ať je každý řádek na středu jako ostatní."""
        for part in wrap(text, W):
            out.append(("C", part, bold))

    out = []
    add_c(s["firm_name"] or "Firmička", True)
    for x in (s["firm_street"], ("%s %s" % (s["firm_zip"], s["firm_city"])).strip(),
              "IČO %s" % s["firm_ico"] if s["firm_ico"] else "", "DIČ %s" % s["firm_dic"] if s["firm_dic"] else ""):
        if x:
            add_c(x)
    out.append(("L", "-" * W, False))
    add_lr("Účtenka č. %s" % r["number"], datetime.fromtimestamp(r["ts"]).strftime("%d.%m.%Y %H:%M"))
    out.append(("L", "-" * W, False))
    for ln in lines:
        g, gf = gross(ln, vp)
        for part in wrap(ln["text"], W):     # dlouhý název zalomit, ne uříznout
            out.append(("L", part, False))
        add_lr("  %s %s × %s" % (qty(ln["qty"]), ln["unit"], money(g, False)), money(rnd(ln["qty"] * g), False))
        if gf:
            add_lr("  recyklační poplatek %s × %s" % (qty(ln["qty"]), money(gf, False)), money(rnd(ln["qty"] * gf), False))
    out.append(("L", "=" * W, False))
    out.append(("L", lr("CELKEM", money(t["total"]).replace(" ", " ")), True))
    if vp:
        out.append(("L", lr("Sazba", "Základ      DPH"), False))
        for x in t["recap"]:
            out.append(("L", lr("%d %%" % x["rate"], "%s %s" % (money(x["base"], False).rjust(10), money(x["vat"], False).rjust(8))), False))
    else:
        out.append(("L", "Nejsem plátce DPH.", False))
    out.append(("L", lr("Platba", PAY.get(r["payment"], r["payment"])), False))
    if r["payment"] == "hotove" and r["received"]:
        out.append(("L", lr("Přijato", money(r["received"], False)), False))
        out.append(("L", lr("Vráceno", money(r["received"] - t["total"], False)), False))
    code = receipt_spayd(s, r, t["total"])
    if code:
        out.append(("L", lr("VS", receipt_vs(r["number"])), False))
        out.append(("Q", code, False))
        out.append(("C", "Naskenujte v bankovní aplikaci", False))
    elif r["payment"] == "qr" and _col(r, "paid_date"):
        out.append(("L", lr("Připsáno na účet", cz_date(r["paid_date"])), False))
    if r["cashier"]:
        out.append(("L", "Obsluha: %s" % r["cashier"], False))
    if r["status"] == "storno":
        out.append(("C", "*** STORNO ***", True))
    out.append(("C", "Děkujeme za nákup", False))
    return [(a, x if a == "Q" else x.replace("\u00a0", " "), b) for a, x, b in out]


def qr_native(text, module=6):
    """QR kód příkazy ESC/POS GS ( k (model 2, korekce M)."""
    data = text.encode("utf-8")
    n = len(data) + 3
    return (b"\x1d(k\x04\x00\x31\x41\x32\x00"                  # model 2
            + b"\x1d(k\x03\x00\x31\x43" + bytes([module])     # velikost modulu
            + b"\x1d(k\x03\x00\x31\x45\x31"                  # korekce M
            + b"\x1d(k" + bytes([n & 0xFF, n >> 8]) + b"\x31\x50\x30" + data
            + b"\x1d(k\x03\x00\x31\x51\x30")                 # tisk


def qr_image(text, module=6, border=2):
    """QR kód jako rastrový obrázek (GS v 0) – pro tiskárny bez příkazu GS ( k."""
    m = qr.matrix(text)
    n = len(m) + 2 * border
    w = n * module
    wb = (w + 7) // 8
    rows = []
    for y in range(n):
        bits = [0] * (wb * 8)
        my = y - border
        for x in range(n):
            mx = x - border
            if 0 <= my < len(m) and 0 <= mx < len(m) and m[my][mx]:
                for k in range(module):
                    bits[x * module + k] = 1
        row = bytes(int("".join(map(str, bits[i:i + 8])), 2) for i in range(0, len(bits), 8))
        rows.extend([row] * module)
    h = len(rows)
    return b"\x1dv0\x00" + bytes([wb & 0xFF, wb >> 8, h & 0xFF, h >> 8]) + b"".join(rows)


def escpos(rows, codepage="18", qr_mode="native", module=6):
    enc = CODEPAGES.get(str(codepage), "cp852")
    b = bytearray(b"\x1b@")                       # inicializace
    b += b"\x1bt" + bytes([int(codepage) if str(codepage).isdigit() else 18])   # kódová stránka
    for align, text, bold in rows:
        if align == "Q":
            if qr_mode != "off":
                b += b"\x1ba\x01"
                b += qr_image(text, module) if qr_mode == "image" else qr_native(text, module)
                b += b"\n"
            continue
        b += b"\x1ba" + (b"\x01" if align == "C" else b"\x00")
        b += b"\x1bE" + (b"\x01" if bold else b"\x00")
        b += text.encode(enc, "replace") + b"\n"
    b += b"\x1bE\x00\x1ba\x00" + b"\n" * 4 + b"\x1dV\x42\x00"     # odsun a částečné uříznutí
    return bytes(b)


def print_receipt(s, r, lines):
    width = int(s["printer_width"] or 48)
    print_raw(s, escpos(receipt_text(s, r, lines, width), s["printer_codepage"], s["printer_qr"] or "native",
                        4 if width == 32 else 6))


def print_raw(s, data):
    host = s["printer_host"].strip()
    if not host:
        raise ValueError("Tiskárna není nastavená")
    with socket.create_connection((host, int(s["printer_port"] or 9100)), timeout=5) as c:
        c.sendall(data)


def register(app):
    db = app.db

    def sync(rid):
        r = db.one("SELECT * FROM receipts WHERE id = ?", (rid,))
        db.run("DELETE FROM movements WHERE receipt_id = ?", (rid,))
        db.run("DELETE FROM cashbook WHERE receipt_id = ?", (rid,))
        if r["status"] == "storno":
            return
        lines = rlines(db, rid)
        for ln in lines:
            if ln["item_id"]:
                db.run("INSERT INTO movements(item_id, date, qty, kind, doc, receipt_id, warehouse_id) VALUES(?,?,?,'prodej',?,?,?)",
                       (ln["item_id"], r["date"], -ln["qty"], r["number"], rid, r["warehouse_id"]))
        total = invoice_totals(lines, r["vat_payer"])["total"]
        db.run("INSERT INTO cashbook(date, doc, text, direction, account, amount, taxable, category, receipt_id) "
               "VALUES(?,?,?,'prijem',?,?,1,'Tržby',?)", (r["date"], r["number"], "Prodej – účtenka %s" % r["number"],
                                                          "pokladna" if r["payment"] == "hotove" else "banka", total, rid))

    @app.route("/pokladna", ("GET", "POST"))
    def index(req):
        s = req.settings
        vp = s["vat_payer"] == "1"
        if req.method == "POST":
            lines = docs.read_lines(req, vp)
            if not lines:
                flash_redirect("/pokladna", "Prázdný nákup")
            pay = req.f("payment") if req.f("payment") in PAY else "hotove"
            from .web import parse_money
            total = invoice_totals(lines, vp)["total"]
            received = parse_money(req.f("received")) if pay == "hotove" else 0
            if pay == "qr" and not qr.cz_iban(s["bank_account"] or ""):
                flash_redirect("/pokladna", "Pro QR platbu vyplňte číslo účtu v Nastavení")
            if pay == "qr" and total <= 0:
                flash_redirect("/pokladna", "QR platba jde jen u kladné částky")
            if received and received < total:
                flash_redirect("/pokladna", "Přijatá částka je nižší než cena nákupu")
            costs = item_costs(db)
            wh = read_wh(db, req)
            with db.tx():
                number = next_invoice_number(db, today(), s["receipt_format"], "receipts")
                rid = db.run("INSERT INTO receipts(number, ts, date, payment, received, cashier, vat_payer, created, warehouse_id) "
                             "VALUES(?,?,?,?,?,?,?,?,?)", (number, int(time.time()), today(), pay, received,
                                                           getattr(req, "user", ""), 1 if vp else 0, now(), wh))
                for pos, ln in enumerate(lines):
                    db.run("INSERT INTO receipt_lines(receipt_id, pos, item_id, text, qty, unit, price, vat_rate, recycling_fee, cost) "
                           "VALUES(?,?,?,?,?,?,?,?,?,?)", (rid, pos, ln["item_id"], ln["text"], ln["qty"], ln["unit"], ln["price"],
                                                           ln["vat_rate"], ln["recycling_fee"],
                                                           costs.get(ln["item_id"], (0, 0))[1] if ln["item_id"] else 0))
                sync(rid)
            msg = "Účtenka %s uložena" % number
            if s["printer_host"]:
                try:
                    r = db.one("SELECT * FROM receipts WHERE id = ?", (rid,))
                    print_receipt(s, r, rlines(db, rid))
                    msg += " a vytištěna"
                except Exception as e:
                    msg += " – tisk selhal: %s" % e
            if pay == "hotove" and received:
                msg += " · VRÁTIT %s" % money(received - total)
            if pay == "qr":
                msg += " · nechte zákazníka naskenovat QR kód"
            flash_redirect("/pokladna/%d" % rid, msg)
        wh_pos = parse_id(req.args.get("sklad")) or default_wh(db, req)
        today_sum = db.one("SELECT COUNT(*) AS n FROM receipts WHERE date = ? AND status = 'ok'", (today(),))["n"]
        return app.page("Pokladna", """%s<div class="bar"><h1>Pokladna</h1>
<a class="btn" href="/pokladna/prehled">Uzávěrka dne (%d účtenek)</a></div>
<form method="post" id="invoice" data-vat="%d" data-sale="1" class="pos">%s
%s
<section class="card payment"><div class="grid">
%s<label>Platba<select name="payment" id="payment"><option value="hotove">Hotově</option><option value="karta">Kartou</option>%s</select></label>
<label id="received-l">Přijato (Kč)<input name="received" id="received" inputmode="decimal" placeholder="nepovinné"></label>
<div><span class="hint">Vrátit</span><div id="change" class="big">—</div></div></div>
<div class="actions"><button class="btn primary big">Zaplatit a vytisknout</button>
<a class="btn" href="/pokladna">Zrušit nákup</a></div></section></form>%s""" % (
            flash(req), today_sum, 1 if vp else 0, app.csrf(), docs.lines_editor(db, [], vp),
            wh_select(db, wh_pos, label="Prodej ze skladu"),
            '<option value="qr">QR platba (převodem)</option>' if qr.cz_iban(s["bank_account"] or "")
            else '<option value="qr" disabled>QR platba – nastavte číslo účtu</option>',
            "" if s["printer_host"] else '<p class="hint">Tiskárna účtenek není nastavená (Nastavení → Tiskárna) – '
                                         'účtenku vytisknete z prohlížeče.</p>'), "/pokladna")

    def get(rid):
        r = db.one("SELECT * FROM receipts WHERE id = ?", (rid,))
        if not r:
            raise HTTPError(404, "Účtenka neexistuje")
        return r

    @app.route("/pokladna/<rid>")
    def detail(req, rid):
        r = get(rid)
        lines = rlines(db, r["id"])
        width = int(req.settings["printer_width"] or 42)
        rows = receipt_text(req.settings, r, lines, width)   # náhled = šířka papíru
        pre = "\n".join('<span class="rqr">%s</span>' % qr.svg(t, 3, 2) if a == "Q" else
                        ("<b>%s</b>" if b else "%s") % h(t.center(width).rstrip() if a == "C" else t) for a, t, b in rows)
        total = invoice_totals(lines, r["vat_payer"])["total"]
        code = receipt_spayd(req.settings, r, total)
        qr_box = ""
        if code:
            qr_box = """<section class="card qrpay noprint"><div class="qr">%s</div><div>
<h2>QR platba %s</h2><p>Zákazník naskenuje kód v bankovní aplikaci (VS %s).</p>
<p class="hint">Firmička nevidí, jestli peníze přišly – u okamžité platby si nechte ukázat potvrzení v telefonu.
Po načtení výpisu v <a href="/banka">Bance</a> se platba k účtence spáruje sama.</p></div></section>""" % (
                qr.svg(code, 8, 4), money(total), receipt_vs(r["number"]))
        elif r["payment"] == "qr" and r["paid_date"]:
            qr_box = '<p class="hint noprint">QR platba připsána na účet %s.</p>' % cz_date(r["paid_date"])
        acts = ['<a class="btn primary" href="/pokladna?sklad=%d">Nový prodej</a>' % r["warehouse_id"],
                '<button class="btn" onclick="window.print()">Tisk z prohlížeče</button>']
        if req.settings["printer_host"]:
            acts.append('<form method="post" action="/pokladna/%d/tisk" class="inline">%s<button class="btn">Tisk na tiskárnu'
                        '</button></form>' % (r["id"], app.csrf()))
        if r["status"] == "ok" and "denik" in req.perms:
            acts.append('<form method="post" action="/pokladna/%d/storno" class="inline" onsubmit="return confirm(\'Stornovat '
                        'účtenku? Zboží se vrátí na sklad.\')">%s<button class="btn danger">Storno</button></form>' % (r["id"], app.csrf()))
        return app.page("Účtenka " + r["number"], """%s<div class="bar noprint"><a href="/pokladna">← Pokladna</a>
<div class="actions">%s</div></div>%s<pre class="receipt" style="--w: %d">%s</pre>""" % (
            flash(req), "".join(acts), qr_box, width, pre), "/pokladna")

    @app.route("/pokladna/<rid>/tisk", ("POST",))
    def reprint(req, rid):
        r = get(rid)
        s = req.settings
        try:
            print_receipt(s, r, rlines(db, r["id"]))
        except Exception as e:
            flash_redirect("/pokladna/%d" % r["id"], "Tisk selhal: %s" % e)
        flash_redirect("/pokladna/%d" % r["id"], "Vytištěno")

    @app.route("/pokladna/<rid>/storno", ("POST",))
    def storno(req, rid):
        r = get(rid)
        if "denik" not in req.perms:
            raise HTTPError(403, "Stornovat účtenku smí jen uživatel s přístupem k peněžnímu deníku")
        with db.tx():
            db.run("UPDATE receipts SET status = 'storno' WHERE id = ?", (r["id"],))
            sync(r["id"])
        flash_redirect("/pokladna/%d" % r["id"], "Účtenka stornována")

    @app.route("/pokladna/prehled")
    def summary(req):
        day = req.args.get("den", today())
        try:
            datetime.strptime(day, "%Y-%m-%d")
        except ValueError:
            day = today()
        rows = db.q("SELECT * FROM receipts WHERE date = ? ORDER BY id", (day,))
        by_pay, recap, n = {}, {}, 0
        trs = []
        for r in rows:
            t = invoice_totals(rlines(db, r["id"]), r["vat_payer"])
            if r["status"] == "ok":
                n += 1
                by_pay[r["payment"]] = by_pay.get(r["payment"], 0) + t["total"]
                for x in t["recap"]:
                    b = recap.setdefault(x["rate"], [0, 0])
                    b[0] += x["base"]
                    b[1] += x["vat"]
            trs.append("<tr%s><td><a href='/pokladna/%d'>%s</a></td><td>%s</td><td>%s</td><td>%s</td><td class=num>%s</td></tr>" % (
                " class=warn" if r["status"] == "storno" else "", r["id"], h(r["number"]),
                datetime.fromtimestamp(r["ts"]).strftime("%H:%M"), PAY.get(r["payment"]), h(r["cashier"]),
                money(t["total"]) + (" (storno)" if r["status"] == "storno" else "")
                + (" · čeká na výpis" if r["payment"] == "qr" and r["status"] == "ok" and not r["paid_date"] else "")))
        waiting = sum(1 for r in rows if r["payment"] == "qr" and r["status"] == "ok" and not r["paid_date"])
        stats = "".join("<div><span>%s</span><b>%s</b></div>" % (PAY[k], money(v)) for k, v in by_pay.items())
        rec = "".join("<tr><td>%d %%</td><td class=num>%s</td><td class=num>%s</td></tr>" % (k, money(v[0]), money(v[1]))
                      for k, v in sorted(recap.items(), reverse=True))
        return app.page("Uzávěrka", """<div class="bar"><h1>Uzávěrka %s</h1><button class="btn" onclick="window.print()">Tisk</button></div>
<form class="filters"><input type="date" name="den" value="%s" onchange="this.form.submit()"></form>
<div class="stats"><div><span>Účtenek</span><b>%d</b></div>%s<div><span>Celkem</span><b>%s</b></div></div>
%s%s<table class="list"><thead><tr><th>Účtenka</th><th>Čas</th><th>Platba</th><th>Obsluha</th><th class=num>Částka</th></tr></thead>
<tbody>%s</tbody></table>""" % (
            cz_date(day), h(day), n, stats, money(sum(by_pay.values())),
            "<p class=hint>QR platby čekající na spárování s výpisem: %d</p>" % waiting if waiting else "",
            "<table class=list><thead><tr><th>DPH</th><th class=num>Základ</th><th class=num>Daň</th></tr></thead>%s</table>" % rec
            if req.settings["vat_payer"] == "1" and rec else "", "".join(trs)), "/pokladna")

    @app.route("/nastaveni/tiskarna", ("POST",))
    def printer_settings(req):
        vals = {"printer_host": req.f("printer_host"), "printer_port": req.f("printer_port") or "9100",
                "printer_width": req.f("printer_width") if req.f("printer_width") in ("32", "42", "48") else "48",
                "printer_codepage": req.f("printer_codepage") if req.f("printer_codepage") in CODEPAGES else "18",
                "printer_qr": req.f("printer_qr") if req.f("printer_qr") in QR_MODES else "native"}
        db.set_settings(vals)
        if req.f("test"):
            s = db.settings()
            fake = {"number": "TEST", "ts": int(time.time()), "vat_payer": 1 if s["vat_payer"] == "1" else 0,
                    "payment": "qr" if qr.cz_iban(s["bank_account"] or "") else "hotove", "received": 0, "cashier": "",
                    "status": "ok", "paid_date": ""}
            lines = [{"text": "Zkušební tisk – ěščřžýáíéůú ĚŠČŘŽÝÁÍÉŮÚ", "qty": 1, "unit": "ks", "price": 10000, "vat_rate": 21,
                      "recycling_fee": 0}]
            try:
                print_receipt(s, fake, lines)
            except Exception as e:
                flash_redirect("/nastaveni#tiskarna", "Uloženo, ale zkušební tisk selhal: %s" % e)
            flash_redirect("/nastaveni#tiskarna", "Uloženo a zkušební účtenka odeslána na tiskárnu")
        flash_redirect("/nastaveni#tiskarna", "Tiskárna uložena")


def settings_form(app, s):
    w = "".join('<option value="%s"%s>%s</option>' % (k, " selected" if s["printer_width"] == k else "", v)
                for k, v in (("48", "80 mm (48 znaků)"), ("42", "80 mm úzké písmo (42)"), ("32", "58 mm (32 znaků)")))
    cp = "".join('<option value="%s"%s>%s</option>' % (k, " selected" if s["printer_codepage"] == k else "", v)
                 for k, v in (("18", "18 – PC852 (čeština, Epson a většina)"), ("16", "16 – Windows-1252 (bez háčků)"),
                              ("0", "0 – PC437 (bez háčků)")))
    return """<section class="card" id="tiskarna"><h2>Tiskárna účtenek (síťová, ESC/POS)</h2>
<form method="post" action="/nastaveni/tiskarna" class="grid">%s
<label>IP adresa tiskárny<input name="printer_host" value="%s" placeholder="192.168.1.50"></label>
<label>Port<input name="printer_port" value="%s" inputmode="numeric"></label>
<label>Šířka papíru<select name="printer_width">%s</select></label>
<label>Kódová stránka<select name="printer_codepage">%s</select></label>
<label>QR kód (QR platba)<select name="printer_qr">%s</select></label>
<label class="check wide"><input type="checkbox" name="test" value="1"> Po uložení vytisknout zkušební účtenku</label>
<div class="actions wide"><button class="btn">Uložit tiskárnu</button></div></form></section>""" % (
        app.csrf(), h(s["printer_host"]), h(s["printer_port"]), w, cp,
        "".join('<option value="%s"%s>%s</option>' % (k, " selected" if (s["printer_qr"] or "native") == k else "", v)
                for k, v in QR_MODES.items()))
