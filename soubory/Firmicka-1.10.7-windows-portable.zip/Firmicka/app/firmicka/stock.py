"""Sklad: karty položek (EAN, nákupní průměr, recyklační poplatek), příjem / výdej / inventura,
historie pohybů, inventura čtečkou. Stav = součet pohybů; faktury vydané i přijaté zapisují samy."""
import json

from .db import item_costs, warehouse_levels, today, VAT_RATES
from .warehouses import warehouses, wh_names, wh_select, read_wh, default_wh, multi
from .web import h, money, qty, parse_money, parse_qty, parse_vat, cz_date, flash, flash_redirect, json_response, HTTPError

KINDS = {"prijem": "Příjem", "vydej": "Výdej", "inventura": "Inventura", "faktura": "Faktura", "dobropis": "Dobropis",
         "pocatek": "Počáteční stav", "nakup": "Přijatá faktura", "prodej": "Účtenka", "prevod": "Převodka"}


def find_by_code(db, code):
    """EAN nebo interní kód (čtečka posílá jen číslice + Enter)."""
    code = code.strip()
    if not code:
        return None
    return (db.one("SELECT * FROM items WHERE ean = ? AND active = 1", (code,)) or
            db.one("SELECT * FROM items WHERE code = ? AND active = 1", (code,)) or
            db.one("SELECT * FROM items WHERE ean = ? OR code = ?", (code, code)))


def items_json(db, active_only=True, with_cost=True):
    """Položky pro formuláře (výběr, čtečka) – {id: {...}}; nákupní cena jen pro sklad a přijaté faktury."""
    costs = item_costs(db)
    lv = warehouse_levels(db)
    rows = db.q("SELECT * FROM items%s ORDER BY name COLLATE NOCASE" % (" WHERE active = 1" if active_only else ""))
    return {str(i["id"]): {"name": i["name"], "unit": i["unit"], "price": i["price"], "vat": i["vat_rate"],
                           "fee": i["recycling_fee"], "ean": i["ean"], "code": i["code"],
                           "stock": costs.get(i["id"], (0, 0))[0], "cost": costs.get(i["id"], (0, 0))[1] if with_cost else None,
                           "stocks": {str(w): q for w, q in lv.get(i["id"], {}).items()}}
            for i in rows}


def register(app):
    db = app.db

    @app.route("/sklad")
    def index(req):
        qs = req.args.get("q", "").strip()
        show = req.args.get("zobrazit", "")
        if qs and req.args.get("scan"):
            it = find_by_code(db, qs)        # pípnutí čtečkou → rovnou karta položky
            if it:
                flash_redirect("/sklad/%d" % it["id"], "Nalezeno podle kódu %s" % qs)
        costs = item_costs(db)
        lv = warehouse_levels(db)
        ws = warehouses(db)
        wsel = req.args.get("sklad", "")
        wid = int(wsel) if wsel.isdigit() and int(wsel) in wh_names(db) else None
        many = len(ws) > 1
        cols = ws if many and not wid else []     # všechny sklady → sloupec pro každý

        def stock_of(iid):
            return lv.get(iid, {}).get(wid, 0) if wid else costs.get(iid, (0, 0))[0]
        sql, args = "SELECT * FROM items WHERE 1", []
        if show != "vse":
            sql += " AND active = 1"
        if qs:
            sql += " AND (name LIKE ? OR code LIKE ? OR ean = ?)"
            args += ["%" + qs + "%"] * 2 + [qs]
        rows = db.q(sql + " ORDER BY name COLLATE NOCASE", args)
        def negative(iid):     # záporný stav celkem nebo v kterémkoli skladu (u vybraného skladu jen v něm)
            if wid:
                return stock_of(iid) < -1e-9
            return any(q < -1e-9 for q in lv.get(iid, {}).values()) or costs.get(iid, (0, 0))[0] < -1e-9
        n_neg = sum(1 for r in db.q("SELECT id FROM items WHERE active = 1") if negative(r["id"]))
        if show == "nizke":
            rows = [r for r in rows if stock_of(r["id"]) <= r["min_qty"]]
        elif show == "zaporne":
            rows = [r for r in rows if negative(r["id"])]
        elif wid and show != "vse":
            rows = [r for r in rows if abs(stock_of(r["id"])) > 1e-9]   # sklad: jen co na něm je
        trs, value = [], 0
        for r in rows:
            avg = costs.get(r["id"], (0, 0))[1]
            st = stock_of(r["id"])
            if st > 0:
                value += round(st * avg)
            low = r["min_qty"] > 0 and st <= r["min_qty"] or st < 0
            per = "".join("<td class=num>%s</td>" % (qty(lv.get(r["id"], {}).get(w["id"], 0))
                                                      if lv.get(r["id"], {}).get(w["id"]) else "") for w in cols)
            trs.append("<tr%s><td>%s</td><td><a href='/sklad/%d'>%s</a>%s</td>%s<td class=num><b>%s</b> %s</td>"
                       "<td class=num>%s</td><td class=num>%s</td><td class=num>%s</td><td class=num>%s</td></tr>" % (
                           " class=warn" if low else "", h(r["code"] or r["ean"]), r["id"], h(r["name"]),
                           "" if r["active"] else " <span class=tag>vyřazeno</span>", per,
                           qty(st), h(r["unit"]), qty(r["min_qty"]) if r["min_qty"] else "",
                           money(avg) if avg else "", money(r["price"]), money(round(max(st, 0) * avg)) if avg else ""))
        opts = "".join('<option value="%s"%s>%s</option>' % (v, " selected" if v == show else "", t)
                       for v, t in (("", "Aktivní"), ("nizke", "Nízký stav"), ("zaporne", "Záporný stav"),
                                    ("vse", "Vše včetně vyřazených")))
        neg_note = ""
        if n_neg and show != "zaporne":
            neg_note = ('<div class="flash error">%d %s se záporným stavem – prodalo se víc, než bylo naskladněno. '
                        '<a class="btn" href="/sklad?zobrazit=zaporne%s">Zobrazit</a> Dorovnejte příjemkou (přijatá faktura '
                        'nebo příjem na kartě položky) nebo inventurou.</div>') % (
                n_neg, "položka" if n_neg == 1 else "položky" if n_neg < 5 else "položek",
                "&sklad=%d" % wid if wid else "")
        wopts = ""
        if many:
            wopts = '<select name="sklad" onchange="this.form.submit()"><option value="">Všechny sklady</option>%s</select>' % "".join(
                '<option value="%d"%s>%s</option>' % (w["id"], " selected" if w["id"] == wid else "", h(w["name"])) for w in ws)
        wname = wh_names(db).get(wid, "") if wid else ""
        return app.page("Sklad", """%s<div class="bar"><h1>Sklad%s</h1>
<a class="btn" href="/sklad/sklady">Sklady</a>%s<a class="btn" href="/sklad/inventura%s">Inventura čtečkou</a>
<a class="btn" href="/sklad/pohyby%s">Pohyby</a><a class="btn primary" href="/sklad/nova">+ Nová položka</a></div>
<div class="stats"><div><span>Hodnota zásob (nákup)%s</span><b>%s</b><small>%d položek</small></div></div>
<form class="filters"><input type="hidden" name="scan" value="1">
<input name="q" value="%s" placeholder="Hledat název, kód – nebo pípnout EAN" autofocus>
%s<select name="zobrazit" onchange="this.form.submit()">%s</select><button>Hledat</button>
<a class="btn" href="/export/sklad.csv">Export CSV</a></form>
<table class="list"><thead><tr><th>Kód</th><th>Název</th>%s<th class=num>%s</th><th class=num>Min.</th>
<th class=num>Nákup ø</th><th class=num>Prodej</th><th class=num>Hodnota</th></tr></thead><tbody>%s</tbody></table>%s""" % (
            flash(req) + neg_note, " – " + h(wname) if wname else "",
            '<a class="btn" href="/sklad/prevodky">Převodky</a>' if many else "",
            "?sklad=%d" % wid if wid else "", "?sklad=%d" % wid if wid else "",
            " – " + h(wname) if wname else "", money(value), len(rows), h(qs), wopts, opts,
            "".join("<th class=num>%s</th>" % h(w["name"]) for w in cols), "Celkem" if cols else "Skladem", "".join(trs),
            "" if rows else "<p class=empty>Žádné položky.</p>"), "/sklad")

    def item_form(req, it, iid=None, costs=None):
        vat = "".join('<option value="%d"%s>%d %%</option>' % (v, " selected" if v == it.get("vat_rate", 21) else "", v)
                      for v in VAT_RATES)
        vat_payer = req.settings["vat_payer"] == "1"
        avg_info = ""
        if iid and costs:
            st, avg = costs.get(iid, (0, 0))
            avg_info = '<div class="wide hint">Průměrná nákupní cena: <b>%s</b>%s</div>' % (
                money(avg) if avg else "zatím neznámá (zadávejte nákupní cenu u příjmu)",
                " · marže při prodejní ceně %s" % ("%.0f %%" % ((it["price"] - avg) * 100 / it["price"]))
                if avg and it.get("price") else "")
        dec = lambda v: money(v or 0, False).replace(" ", "")
        body = """<h1>%s</h1><form method="post" class="grid">%s
<label>Kód<input name="code" value="%s"></label>
<label>EAN (čárový kód)<input name="ean" value="%s" inputmode="numeric" placeholder="pípněte čtečkou" data-scan-field></label>
<label class="wide">Název<input name="name" value="%s" required></label>
<label>Jednotka<input name="unit" value="%s" list="units"></label>
<label>Prodejní cena %s<input name="price" value="%s" inputmode="decimal"></label>
<label>Recyklační poplatek / j.<input name="recycling_fee" value="%s" inputmode="decimal" placeholder="0">
<span class="hint">účtuje se navíc k ceně</span></label>
<label%s>Sazba DPH<select name="vat_rate">%s</select></label>
<label>Minimální stav<input name="min_qty" value="%s" inputmode="decimal"></label>
%s
<label class="wide">Poznámka<input name="note" value="%s"></label>
<label class="check wide"><input type="checkbox" name="active" value="1"%s> Aktivní (nabízet na dokladech)</label>
%s
<div class="actions wide"><button class="btn primary">Uložit</button><a class="btn" href="/sklad">Zpět</a></div>
</form><datalist id="units"><option>ks<option>kg<option>g<option>l<option>m<option>m²<option>bal<option>hod</datalist>""" % (
            "Upravit položku" if iid else "Nová položka", app.csrf(), h(it.get("code")), h(it.get("ean")),
            h(it.get("name")), h(it.get("unit", "ks")), "bez DPH" if vat_payer else "", dec(it.get("price")),
            dec(it.get("recycling_fee")) if it.get("recycling_fee") else "",
            "" if vat_payer else " hidden", vat, qty(it.get("min_qty", 0)),
            "" if iid else '<label>Počáteční stav<input name="initial" inputmode="decimal" placeholder="0"></label>'
                           '<label>Nákupní cena / j.<input name="initial_cost" inputmode="decimal" placeholder="nepovinné"></label>'
                           + wh_select(db, default_wh(db, req), label="Počáteční stav do skladu"),
            h(it.get("note")), " checked" if it.get("active", 1) else "", avg_info)
        return body

    ITEM_COLS = ["code", "ean", "name", "unit", "price", "recycling_fee", "vat_rate", "min_qty", "note", "active"]

    def read_item(req, iid=None):
        name = req.f("name")
        if not name:
            raise HTTPError(400, "Název je povinný")
        ean = req.f("ean")
        if ean and db.one("SELECT id FROM items WHERE ean = ? AND id != ?", (ean, iid or 0)):
            raise HTTPError(400, "EAN %s už má jiná položka" % ean)
        return [req.f("code"), ean, name, req.f("unit") or "ks", parse_money(req.f("price")),
                parse_money(req.f("recycling_fee")), parse_vat(req.f("vat_rate") or "21"), parse_qty(req.f("min_qty")),
                req.f("note"), 1 if req.f("active") else 0]

    @app.route("/sklad/nova", ("GET", "POST"))
    def new(req):
        if req.method == "POST":
            with db.tx():
                iid = db.run("INSERT INTO items(%s) VALUES(%s)" % (", ".join(ITEM_COLS), ",".join("?" * len(ITEM_COLS))),
                             read_item(req))
                init = parse_qty(req.f("initial"))
                if init:
                    db.run("INSERT INTO movements(item_id, date, qty, kind, unit_cost, warehouse_id) VALUES(?,?,?,'pocatek',?,?)",
                           (iid, today(), init, parse_money(req.f("initial_cost")), read_wh(db, req)))
            flash_redirect("/sklad/%d" % iid, "Položka uložena")
        it = {"active": 1, "ean": req.args.get("ean", "")}
        return app.page("Nová položka", item_form(req, it), "/sklad")

    @app.route("/sklad/<iid>", ("GET", "POST"))
    def item(req, iid):
        it = db.one("SELECT * FROM items WHERE id = ?", (iid,))
        if not it:
            raise HTTPError(404, "Položka neexistuje")
        if req.method == "POST":
            db.run("UPDATE items SET %s WHERE id = ?" % ", ".join(c + "=?" for c in ITEM_COLS),
                   read_item(req, it["id"]) + [it["id"]])
            flash_redirect("/sklad/%d" % it["id"], "Uloženo")
        costs = item_costs(db)
        st = costs.get(it["id"], (0, 0))[0]
        names = wh_names(db)
        many = multi(db)
        per = warehouse_levels(db).get(it["id"], {})
        movs = db.q("SELECT m.*, i.number, p.doc_number FROM movements m LEFT JOIN invoices i ON i.id = m.invoice_id "
                    "LEFT JOIN purchases p ON p.id = m.purchase_id "
                    "WHERE m.item_id = ? ORDER BY m.date DESC, m.id DESC LIMIT 300", (it["id"],))

        def doc(m):
            if m["invoice_id"]:
                return "<a href='/faktury/%d'>%s</a>" % (m["invoice_id"], h(m["number"]))
            if m["purchase_id"]:
                return "<a href='/prijate/%d'>%s</a>" % (m["purchase_id"], h(m["doc_number"]))
            if m["receipt_id"]:
                return "<a href='/pokladna/%d'>%s</a>" % (m["receipt_id"], h(m["doc"]))
            if m["transfer_id"]:
                return "<a href='/sklad/prevodky/%d'>%s</a>" % (m["transfer_id"], h(m["doc"]))
            return h(m["doc"])
        trs = "".join(
            "<tr><td>%s</td><td>%s</td>%s<td class=num>%s</td><td class=num>%s</td><td>%s</td><td>%s</td></tr>" % (
                cz_date(m["date"]), KINDS.get(m["kind"], m["kind"]),
                "<td>%s</td>" % h(names.get(m["warehouse_id"], "?")) if many else "",
                ("+" if m["qty"] > 0 else "") + qty(m["qty"]), money(m["unit_cost"]) if m["unit_cost"] else "", doc(m),
                "" if m["invoice_id"] or m["purchase_id"] or m["receipt_id"] or m["transfer_id"] else
                "<form method=post action='/sklad/pohyb/%d/smazat' onsubmit=\"return confirm('Smazat pohyb?')\">%s"
                "<button class='link danger'>smazat</button></form>" % (m["id"], app.csrf()))
            for m in movs)
        per_tbl = ""
        if many or len(per) > 1:
            per_tbl = "<table class=list><thead><tr><th>Sklad</th><th class=num>Stav</th></tr></thead><tbody>%s</tbody></table>%s" % (
                "".join("<tr><td>%s</td><td class=num>%s %s</td></tr>" % (h(names.get(w, "?")), qty(q), h(it["unit"]))
                        for w, q in sorted(per.items()) if abs(q) > 1e-9) or "<tr><td colspan=2>nikde</td></tr>",
                '<p><a class="btn" href="/sklad/prevodky/nova">Převést mezi sklady</a></p>' if many else "")
        move = """<section class="card"><h2>Skladem: %s %s</h2>%s
<form method="post" action="/sklad/%d/pohyb" class="grid move">%s%s
<label>Druh<select name="kind"><option value="prijem">Příjem (+)</option><option value="vydej">Výdej (−)</option>
<option value="inventura">Inventura (skutečný stav)</option></select></label>
<label>Množství<input name="qty" inputmode="decimal" required></label>
<label>Nákupní cena / j.<input name="unit_cost" inputmode="decimal" placeholder="u příjmu"></label>
<label>Datum<input type="date" name="date" value="%s"></label>
<label>Doklad<input name="doc" placeholder="č. dodacího listu…"></label>
<div class="actions"><button class="btn primary">Zapsat</button></div></form></section>""" % (
            qty(st), h(it["unit"]), per_tbl, it["id"], app.csrf(), wh_select(db, default_wh(db, req)), today())
        return app.page(it["name"], flash(req) + item_form(req, dict(it), it["id"], costs) + move +
                        "<h2>Historie pohybů</h2><table class=list><thead><tr><th>Datum</th><th>Druh</th>" +
                        ("<th>Sklad</th>" if many else "") + "<th class=num>Množství</th><th class=num>Cena/j.</th><th>Doklad</th><th></th></tr></thead>"
                        "<tbody>%s</tbody></table>" % trs, "/sklad")

    @app.route("/sklad/<iid>/pohyb", ("POST",))
    def move(req, iid):
        it = db.one("SELECT * FROM items WHERE id = ?", (iid,))
        if not it:
            raise HTTPError(404)
        kind, q = req.f("kind"), parse_qty(req.f("qty"))
        wh = read_wh(db, req)
        if kind == "vydej":
            q = -abs(q)
        elif kind == "inventura":
            q = q - warehouse_levels(db).get(it["id"], {}).get(wh, 0)   # zapíše se rozdíl proti evidenci skladu
        elif kind == "prijem":
            q = abs(q)
        else:
            raise HTTPError(400, "Neznámý druh pohybu")
        if q == 0 and kind != "inventura":
            flash_redirect("/sklad/%d" % it["id"], "Zadejte množství")
        if q != 0:
            db.run("INSERT INTO movements(item_id, date, qty, kind, unit_cost, doc, warehouse_id) VALUES(?,?,?,?,?,?,?)",
                   (it["id"], req.f("date") or today(), q, kind,
                    parse_money(req.f("unit_cost")) if kind == "prijem" else 0, req.f("doc"), wh))
        flash_redirect("/sklad/%d" % it["id"], "Inventura souhlasí" if q == 0 else "Pohyb zapsán")

    @app.route("/sklad/pohyb/<mid>/smazat", ("POST",))
    def move_delete(req, mid):
        m = db.one("SELECT * FROM movements WHERE id = ?", (mid,))
        if not m or m["invoice_id"] or m["purchase_id"] or m["receipt_id"] or m["transfer_id"]:
            raise HTTPError(400, "Pohyb z faktury se mění jen úpravou faktury")
        db.run("DELETE FROM movements WHERE id = ?", (mid,))
        flash_redirect("/sklad/%d" % m["item_id"], "Pohyb smazán")

    @app.route("/sklad/pohyby")
    def movements(req):
        od, do = req.args.get("od", today()[:8] + "01"), req.args.get("do", today())
        names = wh_names(db)
        many = multi(db)
        wsel = req.args.get("sklad", "")
        wid = int(wsel) if wsel.isdigit() and int(wsel) in names else None
        rows = db.q("SELECT m.*, it.name, it.unit, i.number, p.doc_number FROM movements m JOIN items it ON it.id = m.item_id "
                    "LEFT JOIN invoices i ON i.id = m.invoice_id LEFT JOIN purchases p ON p.id = m.purchase_id "
                    "WHERE m.date BETWEEN ? AND ?%s ORDER BY m.date DESC, m.id DESC" % (" AND m.warehouse_id = ?" if wid else ""),
                    (od, do) + ((wid,) if wid else ()))
        trs = "".join("<tr><td>%s</td>%s<td><a href='/sklad/%d'>%s</a></td><td>%s</td><td class=num>%s %s</td><td>%s</td></tr>" % (
            cz_date(m["date"]), "<td>%s</td>" % h(names.get(m["warehouse_id"], "?")) if many else "",
            m["item_id"], h(m["name"]), KINDS.get(m["kind"], m["kind"]),
            ("+" if m["qty"] > 0 else "") + qty(m["qty"]), h(m["unit"]),
            "<a href='/faktury/%d'>%s</a>" % (m["invoice_id"], h(m["number"])) if m["invoice_id"] else
            "<a href='/prijate/%d'>%s</a>" % (m["purchase_id"], h(m["doc_number"])) if m["purchase_id"] else
            "<a href='/sklad/prevodky/%d'>%s</a>" % (m["transfer_id"], h(m["doc"])) if m["transfer_id"] else h(m["doc"]))
            for m in rows)
        wf = ""
        if many:
            wf = '<select name="sklad"><option value="">Všechny sklady</option>%s</select>' % "".join(
                '<option value="%d"%s>%s</option>' % (k, " selected" if k == wid else "", h(v)) for k, v in names.items())
        return app.page("Pohyby skladu", """<div class="bar"><h1>Pohyby skladu</h1></div>
<form class="filters">od <input type="date" name="od" value="%s"> do <input type="date" name="do" value="%s">
%s<button>Zobrazit</button></form><table class=list><thead><tr><th>Datum</th>%s<th>Položka</th><th>Druh</th>
<th class=num>Množství</th><th>Doklad</th></tr></thead><tbody>%s</tbody></table>%s""" % (
            h(od), h(do), wf, "<th>Sklad</th>" if many else "", trs,
            "" if rows else "<p class=empty>V tomto období žádné pohyby.</p>"), "/sklad")

    # ---------- inventura čtečkou ----------
    @app.route("/sklad/inventura", ("GET", "POST"))
    def stocktake(req):
        if req.method == "POST":
            wh = read_wh(db, req)
            lv = warehouse_levels(db)
            n, d = 0, req.f("date") or today()
            with db.tx():
                for key, val in req.form.items():
                    if not key.startswith("count_") or not val.strip():
                        continue
                    iid = int(key[6:])
                    diff = parse_qty(val) - lv.get(iid, {}).get(wh, 0)
                    if diff:
                        db.run("INSERT INTO movements(item_id, date, qty, kind, doc, warehouse_id) VALUES(?,?,?,'inventura',?,?)",
                               (iid, d, diff, "Inventura %s" % d, wh))
                        n += 1
            flash_redirect("/sklad" + ("?sklad=%d" % wh if multi(db) else ""), "Inventura zapsána – opraveno %d položek" % n)
        items = items_json(db)
        a = req.args.get("sklad", "")
        wh = int(a) if a.isdigit() and int(a) in [w["id"] for w in warehouses(db)] else default_wh(db, req)
        wsel = ""
        if multi(db):
            wsel = '<label>Sklad <select name="warehouse_id" onchange="location=\'/sklad/inventura?sklad=\'+this.value">%s</select></label>' % "".join(
                '<option value="%d"%s>%s</option>' % (w["id"], " selected" if w["id"] == wh else "", h(w["name"])) for w in warehouses(db))
        else:
            wsel = '<input type="hidden" name="warehouse_id" value="%d">' % wh
        trs = "".join("<tr data-id='%s' data-ean='%s' data-code='%s'><td>%s</td><td>%s</td><td class=num>%s %s</td>"
                      "<td><input name='count_%s' class='num count' inputmode='decimal' placeholder='nepočítáno'></td></tr>" % (
                          k, h(v["ean"]), h(v["code"]), h(v["code"] or v["ean"]), h(v["name"]), qty(v["stocks"].get(str(wh), 0)),
                          h(v["unit"]), k)
                      for k, v in items.items())
        return app.page("Inventura", """<div class="bar"><h1>Inventura čtečkou</h1></div>
<p class="hint">Pípejte zboží čtečkou – každé pípnutí přičte 1 ks. Počet jde i přepsat ručně. Položky, které
nespočítáte (prázdné), zůstanou beze změny. Rozdíly se zapíší jako inventurní pohyby.</p>
<form method="post" id="stocktake">%s
<div class="filters"><input id="scan" placeholder="Pípněte EAN…" data-scan autofocus> <span id="scan-msg" class="hint"></span>
%s <label>Datum <input type="date" name="date" value="%s"></label></div>
<table class="list"><thead><tr><th>Kód</th><th>Položka</th><th class=num>V evidenci</th><th>Spočítáno</th></tr></thead>
<tbody>%s</tbody></table>
<div class="actions"><button class="btn primary" onclick="return confirm('Zapsat inventuru?')">Zapsat inventuru</button>
<a class="btn" href="/sklad">Zrušit</a></div></form>""" % (app.csrf(), wsel, today(), trs), "/sklad")

    @app.route("/api/ean/<code>")
    def api_ean(req, code):
        it = find_by_code(db, code)
        if not it:
            return json_response({"ok": False})
        st, avg = item_costs(db).get(it["id"], (0, 0))
        if not req.perms & {"sklad", "prijate"}:
            avg = None                      # nákupní cenu vidí jen sklad a přijaté faktury
        return json_response({"ok": True, "id": it["id"], "name": it["name"], "unit": it["unit"], "price": it["price"],
                              "vat": it["vat_rate"], "fee": it["recycling_fee"], "stock": st, "cost": avg})

    @app.route("/api/polozky")
    def api_items(req):
        return json_response(items_json(db, with_cost=bool(req.perms & {"sklad", "prijate"})))
