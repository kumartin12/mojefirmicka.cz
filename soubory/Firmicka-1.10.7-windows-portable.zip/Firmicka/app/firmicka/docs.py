"""Společné části dokladů s řádky (nabídka, zakázka): výběr odběratele, editor řádků, čtení formuláře,
tisková šablona. Formulář má id="invoice", takže používá stejný skript jako faktura (čtečka, ARES, součty)."""
import json

from .contacts import address as contact_address
from .db import rnd, invoice_totals, line_fee, today, VAT_RATES
from .stock import items_json
from .web import h, money, qty, parse_money, parse_qty, parse_vat, parse_id


def customer_box(db, d, title="Odběratel"):
    contacts = db.q("SELECT * FROM contacts ORDER BY name COLLATE NOCASE")
    contacts_js = json.dumps({str(c["id"]): {"name": c["name"], "ico": c["ico"], "dic": c["dic"],
                                             "address": contact_address(c)} for c in contacts}, ensure_ascii=False)
    copts = '<option value="">— vybrat z adresáře —</option>' + "".join(
        '<option value="%d"%s>%s</option>' % (c["id"], " selected" if str(c["id"]) == str(d.get("contact_id") or "") else "",
                                              h(c["name"])) for c in contacts)
    return """<section class="card wide"><h2>%s</h2><div class="grid">
<label class="wide">Z adresáře<select name="contact_id" data-contacts='%s'>%s</select></label>
<label class="wide">Název / jméno<input name="cust_name" value="%s" required></label>
<label>IČO<span class="row"><input name="cust_ico" value="%s"><button type="button" class="btn" data-ares-inv>ARES</button></span></label>
<label>DIČ<input name="cust_dic" value="%s"></label>
<label class="wide">Adresa<textarea name="cust_address" rows="3">%s</textarea></label>
<label class="check wide"><input type="checkbox" name="save_contact" value="1"> Uložit do adresáře</label>
</div></section>""" % (title, h(contacts_js), copts, h(d.get("cust_name")), h(d.get("cust_ico")), h(d.get("cust_dic")),
                        h(d.get("cust_address")))


def lines_editor(db, lines, vat_payer):
    items = db.q("SELECT * FROM items WHERE active = 1 ORDER BY name COLLATE NOCASE")
    iopts = '<option value="">volný text</option>' + "".join(
        '<option value="%d">%s%s</option>' % (i["id"], h(i["name"]), " (%s)" % h(i["code"]) if i["code"] else "") for i in items)
    vat_opts = "".join('<option value="%d">%d %%</option>' % (v, v) for v in VAT_RATES)
    rows = json.dumps([{"item": ln.get("item_id") or "", "text": ln["text"], "qty": ln["qty"], "unit": ln["unit"],
                        "price": ln["price"], "vat": ln["vat_rate"], "fee": line_fee(ln)} for ln in lines], ensure_ascii=False)
    hid = "" if vat_payer else " hidden"
    return """<h2>Položky</h2>
<div class="filters"><input id="scan" placeholder="Pípněte EAN – přidá položku" data-scan inputmode="numeric">
<span class="hint" id="scan-msg"></span></div>
<table class="lines"><thead><tr><th>Ze skladu</th><th>Popis</th><th class=num>Množství</th><th>Jedn.</th>
<th class=num>Cena/j.%s</th><th class=num>Rec. popl./j.</th><th%s>DPH</th><th class=num>Celkem</th><th></th></tr></thead>
<tbody id="lines" data-items='%s' data-rows='%s'></tbody></table>
<template id="line-tpl"><tr>
<td><select name="line_item">%s</select></td><td><input name="line_text"></td>
<td><input name="line_qty" class=num inputmode="decimal" value="1"></td><td><input name="line_unit" value="ks" size="4"></td>
<td><input name="line_price" class=num inputmode="decimal"></td>
<td><input name="line_fee" class=num inputmode="decimal" placeholder="0"></td><td%s><select name="line_vat">%s</select></td>
<td class="num line-total"></td><td><button type="button" class="link danger" data-del>✕</button></td></tr></template>
<p><button type="button" class="btn" id="add-line">+ Přidat řádek</button> <span class="hint" id="stock-warn"></span></p>
<div class="totals" id="totals"></div>""" % (
        " bez DPH" if vat_payer else "", hid, h(json.dumps(items_json(db, with_cost=False), ensure_ascii=False)), h(rows), iopts, hid, vat_opts)


def read_lines(req, vat_payer):
    cols = [req.lst(k) for k in ("line_item", "line_text", "line_qty", "line_unit", "line_price", "line_vat", "line_fee")]
    n = len(cols[0])
    cols = [c + [""] * (n - len(c)) for c in cols]
    out = []
    for it, text, q, unit, price, vat, fee in zip(*cols):
        if not text.strip() and not it:
            continue
        out.append({"item_id": parse_id(it), "text": text.strip(), "qty": parse_qty(q),
                    "unit": unit.strip() or "ks", "price": parse_money(price),
                    "vat_rate": parse_vat(vat, vat_payer), "recycling_fee": parse_money(fee)})
    return out


def read_customer(req):
    d = {k: req.f(k) for k in ("cust_name", "cust_ico", "cust_dic", "contact_id")}
    d["cust_address"] = req.form.get("cust_address", "").strip()
    d["save_contact"] = req.f("save_contact")
    return d


def find_by_ico(db, ico):
    """Kontakt se stejným IČO – „Uložit do adresáře“ ho má použít, ne založit duplicitu."""
    ico = (ico or "").strip()
    row = db.one("SELECT id FROM contacts WHERE ico = ? AND ico != '' ORDER BY id LIMIT 1", (ico,)) if ico else None
    return row["id"] if row else None


def save_contact(db, d):
    """Vrátí contact_id (případně založí kontakt). Volat v transakci."""
    cid = d["contact_id"] if str(d.get("contact_id") or "").isdigit() else None
    if d.get("save_contact") and not cid:
        cid = find_by_ico(db, d.get("cust_ico"))
    if d.get("save_contact") and not cid:
        street, _, rest = d["cust_address"].partition("\n")
        zip_, _, city = rest.split("\n")[0].strip().partition(" ")
        cid = db.run("INSERT INTO contacts(name, ico, dic, street, city, zip) VALUES(?,?,?,?,?,?)",
                     (d["cust_name"], d["cust_ico"], d["cust_dic"], street.strip(), city.strip(), zip_))
    return cid


def write_lines(db, table, fk, doc_id, lines):
    db.run("DELETE FROM %s WHERE %s = ?" % (table, fk), (doc_id,))
    for pos, ln in enumerate(lines):
        db.run("INSERT INTO %s(%s, pos, item_id, text, qty, unit, price, vat_rate, recycling_fee) VALUES(?,?,?,?,?,?,?,?,?)"
               % (table, fk), (doc_id, pos, ln["item_id"], ln["text"], ln["qty"], ln["unit"], ln["price"],
                               ln["vat_rate"], line_fee(ln)))


def lines_table(lines, vat_payer):
    """Tabulka řádků + rekapitulace pro tiskový náhled (stejný vzhled jako faktura)."""
    t = invoice_totals(lines, vat_payer)
    trs = []
    for ln in lines:
        vat_td = "<td class=num>%d %%</td>" % ln["vat_rate"] if vat_payer else ""
        trs.append("<tr><td>%s</td><td class=num>%s %s</td><td class=num>%s</td>%s<td class=num>%s</td></tr>" % (
            h(ln["text"]), qty(ln["qty"]), h(ln["unit"]), money(ln["price"], False), vat_td,
            money(rnd(ln["qty"] * ln["price"]), False)))
        if line_fee(ln):
            trs.append("<tr class='fee'><td>&nbsp;&nbsp;recyklační poplatek</td><td class=num>%s %s</td><td class=num>%s</td>"
                       "%s<td class=num>%s</td></tr>" % (qty(ln["qty"]), h(ln["unit"]), money(line_fee(ln), False), vat_td,
                                                         money(rnd(ln["qty"] * line_fee(ln)), False)))
    recap = ""
    if vat_payer:
        recap = "<table class='recap'><thead><tr><th>Sazba</th><th class=num>Základ</th><th class=num>DPH</th>" \
                "<th class=num>Celkem</th></tr></thead><tbody>%s</tbody></table>" % "".join(
                    "<tr><td>%d %%</td><td class=num>%s</td><td class=num>%s</td><td class=num>%s</td></tr>" % (
                        r["rate"], money(r["base"]), money(r["vat"]), money(r["total"])) for r in t["recap"])
    head = "<tr><th>Popis</th><th class=num>Množství</th><th class=num>Cena/j.%s</th>%s<th class=num>Celkem%s</th></tr>" % (
        " bez DPH" if vat_payer else "", "<th class=num>DPH</th>" if vat_payer else "", " bez DPH" if vat_payer else "")
    return """<table class="items"><thead>%s</thead><tbody>%s</tbody></table>
<div class="sum">%s<div class="topay"><span>Celkem%s</span><b>%s</b></div></div>""" % (
        head, "".join(trs), recap, " vč. DPH" if vat_payer else "", money(t["total"])), t


def firm_block(s):
    addr = "<br>".join(h(x) for x in (s["firm_street"], ("%s %s" % (s["firm_zip"], s["firm_city"])).strip()) if x)
    ids = "".join("<div>%s: %s</div>" % (k, h(v)) for k, v in (("IČO", s["firm_ico"]), ("DIČ", s["firm_dic"])) if v)
    contact = " · ".join(h(x) for x in (s["firm_phone"], s["firm_email"], s["firm_web"]) if x)
    return "<b>%s</b><div>%s</div>%s<div class='small'>%s</div>" % (
        h(s["firm_name"]) or "<i>Vyplňte údaje firmy v Nastavení</i>", addr, ids, contact)


# ---------- navržené číslo dokladu ----------
# Formulář nového dokladu nese vedle čísla skryté pole number_auto = číslo, které program navrhl. Když ho uživatel
# neměnil, server při uložení (pod zámkem) vezme další volné číslo podle roku dokladu: vyřeší to souběh (dva lidé
# se stejným navrženým číslem) i zpětný doklad po Novém roce (datum vystavení v loňském roce → loňská řada).

def auto_number_input(d, field="number", date_field="issue_date", series=""):
    """Skryté pole s navrženým číslem (jen u nového dokladu). series = druh pro /…/cislo (přepočet při změně data)."""
    auto = d.get("number_auto", d.get(field, ""))
    return '<input type="hidden" name="number_auto" value="%s" data-field="%s" data-date="%s" data-series="%s">' % (
        h(auto), field, date_field, h(series))


def auto_number(db, req, number, day, fmt, table, col="number"):
    """(číslo, hláška). Číslo, které uživatel přepsal ručně, se nemění."""
    from .db import next_invoice_number
    auto = req.f("number_auto")
    if not auto or number != auto or not fmt or len(day or "") < 10:
        return number, ""
    try:
        new = next_invoice_number(db, day, fmt, table, col)
    except (ValueError, TypeError):
        return number, ""
    if new == number:
        return number, ""
    if "{YY" in fmt and day[:4] != today()[:4]:
        return new, "Číslo dokladu je z řady roku %s (podle data dokladu): %s" % (day[:4], new)
    return new, "Číslo %s mezitím použil jiný doklad – uloženo jako %s" % (number, new)


def page_numbers_css(label):
    """Tisk z prohlížeče: na 2. a další straně vpravo dole „Faktura 2026001 · strana 2 / 3“ (jako v PDF).
    Okraje stránky (@page @bottom-right) umí Chrome/Edge; jiné prohlížeče to jen vynechají."""
    label = "".join(c for c in label if c not in '"\\\n<>{}')
    return ('<style>@media print { @page { @bottom-right { content: "%s · strana " counter(page) " / " counter(pages); '
            'font: 7pt "DejaVu Sans", Arial, sans-serif; color: #666; } } '
            '@page :first { @bottom-right { content: none; } } }</style>' % label)
