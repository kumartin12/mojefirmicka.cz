"""Databáze (SQLite v jednom souboru) – schéma, migrace, zálohy a výpočty, které sdílí víc stránek.
Peníze se ukládají v haléřích (int), množství jako REAL (kg, m…)."""
import math
import os
import sqlite3
import threading
import time
from datetime import date


SCHEMA = """
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS contacts (
  id INTEGER PRIMARY KEY, name TEXT NOT NULL, ico TEXT DEFAULT '', dic TEXT DEFAULT '',
  street TEXT DEFAULT '', city TEXT DEFAULT '', zip TEXT DEFAULT '', country TEXT DEFAULT 'Česká republika',
  email TEXT DEFAULT '', phone TEXT DEFAULT '', note TEXT DEFAULT '');

CREATE TABLE IF NOT EXISTS items (
  id INTEGER PRIMARY KEY, code TEXT DEFAULT '', name TEXT NOT NULL, unit TEXT DEFAULT 'ks',
  price INTEGER DEFAULT 0, vat_rate INTEGER DEFAULT 21, min_qty REAL DEFAULT 0,
  note TEXT DEFAULT '', active INTEGER DEFAULT 1);

-- pohyb skladu: qty kladné = příjem, záporné = výdej
CREATE TABLE IF NOT EXISTS movements (
  id INTEGER PRIMARY KEY, item_id INTEGER NOT NULL REFERENCES items(id), date TEXT NOT NULL,
  qty REAL NOT NULL, kind TEXT NOT NULL, unit_cost INTEGER DEFAULT 0, doc TEXT DEFAULT '',
  invoice_id INTEGER REFERENCES invoices(id), note TEXT DEFAULT '');

CREATE TABLE IF NOT EXISTS invoices (
  id INTEGER PRIMARY KEY, number TEXT NOT NULL UNIQUE, contact_id INTEGER REFERENCES contacts(id),
  -- odběratel se kopíruje do faktury: pozdější úprava adresáře nesmí změnit vystavený doklad
  cust_name TEXT NOT NULL, cust_address TEXT DEFAULT '', cust_ico TEXT DEFAULT '', cust_dic TEXT DEFAULT '',
  issue_date TEXT NOT NULL, tax_date TEXT NOT NULL, due_date TEXT NOT NULL,
  payment TEXT DEFAULT 'prevod', vs TEXT DEFAULT '', note TEXT DEFAULT '',
  vat_payer INTEGER NOT NULL, status TEXT DEFAULT 'vystavena', paid_date TEXT DEFAULT '',
  created INTEGER NOT NULL);

CREATE TABLE IF NOT EXISTS invoice_lines (
  id INTEGER PRIMARY KEY, invoice_id INTEGER NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
  pos INTEGER NOT NULL, item_id INTEGER REFERENCES items(id), text TEXT NOT NULL,
  qty REAL NOT NULL, unit TEXT DEFAULT 'ks', price INTEGER NOT NULL, vat_rate INTEGER DEFAULT 0);

CREATE TABLE IF NOT EXISTS cashbook (
  id INTEGER PRIMARY KEY, date TEXT NOT NULL, doc TEXT DEFAULT '', text TEXT NOT NULL,
  direction TEXT NOT NULL CHECK (direction IN ('prijem','vydaj')),
  account TEXT NOT NULL CHECK (account IN ('pokladna','banka')),
  amount INTEGER NOT NULL, taxable INTEGER DEFAULT 1, category TEXT DEFAULT '',
  invoice_id INTEGER REFERENCES invoices(id));

CREATE INDEX IF NOT EXISTS mov_item ON movements(item_id);
CREATE INDEX IF NOT EXISTS mov_inv ON movements(invoice_id);
CREATE INDEX IF NOT EXISTS cash_date ON cashbook(date);
"""

# Migrace: (verze, SQL). SCHEMA výše je verze 1 a už se nemění – nové sloupce a tabulky jen sem,
# ať se aktualizace instalace dostane ze staré databáze na novou bez ztráty dat.
MIGRATIONS = [
    (2, """
ALTER TABLE items ADD COLUMN ean TEXT DEFAULT '';
ALTER TABLE items ADD COLUMN recycling_fee INTEGER DEFAULT 0;
ALTER TABLE invoice_lines ADD COLUMN recycling_fee INTEGER DEFAULT 0;
ALTER TABLE invoice_lines ADD COLUMN cost INTEGER DEFAULT 0;
ALTER TABLE movements ADD COLUMN purchase_id INTEGER REFERENCES purchases(id);
ALTER TABLE cashbook ADD COLUMN purchase_id INTEGER REFERENCES purchases(id);
CREATE INDEX IF NOT EXISTS items_ean ON items(ean);
-- přijaté faktury (od dodavatelů)
CREATE TABLE purchases (
  id INTEGER PRIMARY KEY, number TEXT NOT NULL, doc_number TEXT NOT NULL UNIQUE,
  contact_id INTEGER REFERENCES contacts(id),
  supp_name TEXT NOT NULL, supp_address TEXT DEFAULT '', supp_ico TEXT DEFAULT '', supp_dic TEXT DEFAULT '',
  supp_account TEXT DEFAULT '', issue_date TEXT NOT NULL, tax_date TEXT NOT NULL, due_date TEXT NOT NULL,
  payment TEXT DEFAULT 'prevod', vs TEXT DEFAULT '', note TEXT DEFAULT '', stock_in INTEGER DEFAULT 1,
  status TEXT DEFAULT 'neuhrazena', paid_date TEXT DEFAULT '', created INTEGER NOT NULL);
CREATE TABLE purchase_lines (
  id INTEGER PRIMARY KEY, purchase_id INTEGER NOT NULL REFERENCES purchases(id) ON DELETE CASCADE,
  pos INTEGER NOT NULL, item_id INTEGER REFERENCES items(id), text TEXT NOT NULL, qty REAL NOT NULL,
  unit TEXT DEFAULT 'ks', price INTEGER NOT NULL, vat_rate INTEGER DEFAULT 0, recycling_fee INTEGER DEFAULT 0);
CREATE INDEX mov_pur ON movements(purchase_id);
"""),
    (3, """
-- pohyby z bankovního výpisu (import GPC / camt.053 / CSV) a jejich spárování
CREATE TABLE bank_tx (
  id INTEGER PRIMARY KEY, ref TEXT NOT NULL UNIQUE, date TEXT NOT NULL, amount INTEGER NOT NULL,
  vs TEXT DEFAULT '', ks TEXT DEFAULT '', ss TEXT DEFAULT '', counter_account TEXT DEFAULT '',
  counter_name TEXT DEFAULT '', message TEXT DEFAULT '', source TEXT DEFAULT '',
  status TEXT DEFAULT 'nesparovano', invoice_id INTEGER REFERENCES invoices(id),
  purchase_id INTEGER REFERENCES purchases(id), cashbook_id INTEGER REFERENCES cashbook(id), created INTEGER NOT NULL);
CREATE INDEX bank_status ON bank_tx(status);
-- odeslané upomínky
CREATE TABLE reminders (
  id INTEGER PRIMARY KEY, invoice_id INTEGER NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
  date TEXT NOT NULL, level INTEGER NOT NULL, email TEXT NOT NULL, subject TEXT DEFAULT '', created INTEGER NOT NULL);
"""),
    (4, """
-- nabídky a zakázky (řádky stejné jako u faktury)
CREATE TABLE quotes (
  id INTEGER PRIMARY KEY, number TEXT NOT NULL UNIQUE, contact_id INTEGER REFERENCES contacts(id),
  cust_name TEXT NOT NULL, cust_address TEXT DEFAULT '', cust_ico TEXT DEFAULT '', cust_dic TEXT DEFAULT '',
  title TEXT DEFAULT '', issue_date TEXT NOT NULL, valid_until TEXT NOT NULL, status TEXT DEFAULT 'koncept',
  note TEXT DEFAULT '', vat_payer INTEGER NOT NULL, job_id INTEGER, invoice_id INTEGER, created INTEGER NOT NULL);
CREATE TABLE quote_lines (
  id INTEGER PRIMARY KEY, quote_id INTEGER NOT NULL REFERENCES quotes(id) ON DELETE CASCADE, pos INTEGER NOT NULL,
  item_id INTEGER REFERENCES items(id), text TEXT NOT NULL, qty REAL NOT NULL, unit TEXT DEFAULT 'ks',
  price INTEGER NOT NULL, vat_rate INTEGER DEFAULT 0, recycling_fee INTEGER DEFAULT 0);
CREATE TABLE jobs (
  id INTEGER PRIMARY KEY, number TEXT NOT NULL UNIQUE, title TEXT NOT NULL, contact_id INTEGER REFERENCES contacts(id),
  cust_name TEXT NOT NULL, cust_address TEXT DEFAULT '', cust_ico TEXT DEFAULT '', cust_dic TEXT DEFAULT '',
  status TEXT DEFAULT 'nova', start_date TEXT DEFAULT '', deadline TEXT DEFAULT '', note TEXT DEFAULT '',
  quote_id INTEGER REFERENCES quotes(id), invoice_id INTEGER REFERENCES invoices(id), created INTEGER NOT NULL);
CREATE TABLE job_lines (
  id INTEGER PRIMARY KEY, job_id INTEGER NOT NULL REFERENCES jobs(id) ON DELETE CASCADE, pos INTEGER NOT NULL,
  item_id INTEGER REFERENCES items(id), text TEXT NOT NULL, qty REAL NOT NULL, unit TEXT DEFAULT 'ks',
  price INTEGER NOT NULL, vat_rate INTEGER DEFAULT 0, recycling_fee INTEGER DEFAULT 0);
ALTER TABLE invoices ADD COLUMN job_id INTEGER REFERENCES jobs(id);
-- uživatelé, role a záznam změn
CREATE TABLE users (
  id INTEGER PRIMARY KEY, username TEXT NOT NULL UNIQUE COLLATE NOCASE, name TEXT DEFAULT '', role TEXT NOT NULL,
  password_hash TEXT NOT NULL, active INTEGER DEFAULT 1, created INTEGER NOT NULL);
CREATE TABLE audit (
  id INTEGER PRIMARY KEY, ts INTEGER NOT NULL, username TEXT DEFAULT '', action TEXT NOT NULL, detail TEXT DEFAULT '');
CREATE INDEX audit_ts ON audit(ts);
-- pokladna (účtenky)
CREATE TABLE receipts (
  id INTEGER PRIMARY KEY, number TEXT NOT NULL UNIQUE, ts INTEGER NOT NULL, date TEXT NOT NULL,
  payment TEXT NOT NULL, received INTEGER DEFAULT 0, cashier TEXT DEFAULT '', vat_payer INTEGER NOT NULL,
  status TEXT DEFAULT 'ok', created INTEGER NOT NULL);
CREATE TABLE receipt_lines (
  id INTEGER PRIMARY KEY, receipt_id INTEGER NOT NULL REFERENCES receipts(id) ON DELETE CASCADE, pos INTEGER NOT NULL,
  item_id INTEGER REFERENCES items(id), text TEXT NOT NULL, qty REAL NOT NULL, unit TEXT DEFAULT 'ks',
  price INTEGER NOT NULL, vat_rate INTEGER DEFAULT 0, recycling_fee INTEGER DEFAULT 0, cost INTEGER DEFAULT 0);
ALTER TABLE movements ADD COLUMN receipt_id INTEGER REFERENCES receipts(id);
ALTER TABLE cashbook ADD COLUMN receipt_id INTEGER REFERENCES receipts(id);
"""),
    (5, """
-- zakázky pro servis: zákazník bez IČO (telefon, e-mail), zařízení, výrobní číslo, závada, provedená práce
ALTER TABLE jobs ADD COLUMN phone TEXT DEFAULT '';
ALTER TABLE jobs ADD COLUMN email TEXT DEFAULT '';
ALTER TABLE jobs ADD COLUMN device TEXT DEFAULT '';
ALTER TABLE jobs ADD COLUMN serial TEXT DEFAULT '';
ALTER TABLE jobs ADD COLUMN fault TEXT DEFAULT '';
ALTER TABLE jobs ADD COLUMN work_done TEXT DEFAULT '';
ALTER TABLE jobs ADD COLUMN accessories TEXT DEFAULT '';
"""),
    (6, """
-- vlastní oprávnění uživatele (seznam částí programu); prázdné = předvolba role
ALTER TABLE users ADD COLUMN perms TEXT DEFAULT '';
"""),
    (7, """
-- indexy pro roky provozu (desítky tisíc dokladů): řádky dokladů, seznamy po letech, vazby
CREATE INDEX IF NOT EXISTS inv_lines ON invoice_lines(invoice_id);
CREATE INDEX IF NOT EXISTS pur_lines ON purchase_lines(purchase_id);
CREATE INDEX IF NOT EXISTS rec_lines ON receipt_lines(receipt_id);
CREATE INDEX IF NOT EXISTS job_lines_j ON job_lines(job_id);
CREATE INDEX IF NOT EXISTS quote_lines_q ON quote_lines(quote_id);
CREATE INDEX IF NOT EXISTS inv_issue ON invoices(issue_date);
CREATE INDEX IF NOT EXISTS inv_status ON invoices(status);
CREATE INDEX IF NOT EXISTS inv_contact ON invoices(contact_id);
CREATE INDEX IF NOT EXISTS pur_tax ON purchases(tax_date);
CREATE INDEX IF NOT EXISTS pur_status ON purchases(status);
CREATE INDEX IF NOT EXISTS rec_date ON receipts(date);
CREATE INDEX IF NOT EXISTS mov_date ON movements(date, id);
CREATE INDEX IF NOT EXISTS mov_rec ON movements(receipt_id);
CREATE INDEX IF NOT EXISTS cash_inv ON cashbook(invoice_id);
CREATE INDEX IF NOT EXISTS cash_pur ON cashbook(purchase_id);
CREATE INDEX IF NOT EXISTS cash_rec ON cashbook(receipt_id);
CREATE INDEX IF NOT EXISTS rem_inv ON reminders(invoice_id);
CREATE INDEX IF NOT EXISTS jobs_start ON jobs(start_date);
CREATE INDEX IF NOT EXISTS quotes_issue ON quotes(issue_date);
"""),
    (8, """
-- více skladů: každý pohyb patří do jednoho skladu; dosavadní data = Hlavní sklad (id 1)
CREATE TABLE warehouses (
  id INTEGER PRIMARY KEY, name TEXT NOT NULL, note TEXT DEFAULT '', active INTEGER DEFAULT 1);
INSERT INTO warehouses(id, name) VALUES(1, 'Hlavní sklad');
-- převodka mezi sklady (pohyby: − ve zdrojovém, + v cílovém; nákupní průměr se nemění)
CREATE TABLE transfers (
  id INTEGER PRIMARY KEY, number TEXT NOT NULL UNIQUE, date TEXT NOT NULL, from_wh INTEGER NOT NULL REFERENCES warehouses(id),
  to_wh INTEGER NOT NULL REFERENCES warehouses(id), note TEXT DEFAULT '', username TEXT DEFAULT '', created INTEGER NOT NULL);
ALTER TABLE movements ADD COLUMN warehouse_id INTEGER NOT NULL DEFAULT 1;
ALTER TABLE movements ADD COLUMN transfer_id INTEGER REFERENCES transfers(id);
ALTER TABLE invoices ADD COLUMN warehouse_id INTEGER NOT NULL DEFAULT 1;
ALTER TABLE purchases ADD COLUMN warehouse_id INTEGER NOT NULL DEFAULT 1;
ALTER TABLE receipts ADD COLUMN warehouse_id INTEGER NOT NULL DEFAULT 1;
-- výchozí sklad uživatele (pokladna, faktury); NULL = první aktivní
ALTER TABLE users ADD COLUMN warehouse_id INTEGER;
CREATE INDEX mov_wh ON movements(warehouse_id, item_id);
CREATE INDEX mov_tr ON movements(transfer_id);
"""),
    (9, """
-- QR platba v pokladně: připsání na účet a vazba z výpisu
ALTER TABLE receipts ADD COLUMN paid_date TEXT DEFAULT '';
ALTER TABLE bank_tx ADD COLUMN receipt_id INTEGER REFERENCES receipts(id);
"""),
    (10, """
-- zakázky: kdo ji řeší a historie (změny stavu, kontakt se zákazníkem, poznámky)
ALTER TABLE jobs ADD COLUMN assigned TEXT DEFAULT '';
CREATE TABLE job_events (
  id INTEGER PRIMARY KEY, job_id INTEGER NOT NULL REFERENCES jobs(id) ON DELETE CASCADE, ts INTEGER NOT NULL,
  user TEXT DEFAULT '', kind TEXT NOT NULL, text TEXT DEFAULT '');
CREATE INDEX job_ev ON job_events(job_id, ts);
"""),
    (11, """
-- druhy vydaných dokladů: faktura, dobropis (opravný daňový doklad), zálohová faktura,
-- daňový doklad k přijaté platbě (ddkpp, jen plátce DPH)
ALTER TABLE invoices ADD COLUMN kind TEXT NOT NULL DEFAULT 'faktura';
ALTER TABLE invoices ADD COLUMN ref_id INTEGER REFERENCES invoices(id);
ALTER TABLE invoices ADD COLUMN reason TEXT DEFAULT '';
ALTER TABLE invoices ADD COLUMN stock INTEGER DEFAULT 1;
-- řádek „odpočet zálohy“ na konečné faktuře ukazuje na zálohovou fakturu
ALTER TABLE invoice_lines ADD COLUMN advance_id INTEGER REFERENCES invoices(id);
CREATE INDEX inv_kind ON invoices(kind);
CREATE INDEX inv_ref ON invoices(ref_id);
CREATE INDEX invl_adv ON invoice_lines(advance_id);
"""),
    (12, """
-- logo, podpis a razítko přímo v databázi → jsou v každé záloze (složka obrazky/ je jen kopie pro PDF)
CREATE TABLE images (kind TEXT PRIMARY KEY, ext TEXT NOT NULL, data BLOB NOT NULL, updated INTEGER NOT NULL);
"""),
    (13, """
-- kalendář (dovolená, nemoc, schůzky, termíny) a interní poznámky
CREATE TABLE events (
  id INTEGER PRIMARY KEY, title TEXT NOT NULL, kind TEXT NOT NULL DEFAULT 'jine', person TEXT DEFAULT '',
  date_from TEXT NOT NULL, date_to TEXT NOT NULL, time_from TEXT DEFAULT '', time_to TEXT DEFAULT '',
  note TEXT DEFAULT '', username TEXT DEFAULT '', created INTEGER NOT NULL);
CREATE INDEX events_dates ON events(date_from, date_to);
CREATE TABLE notes (
  id INTEGER PRIMARY KEY, title TEXT DEFAULT '', body TEXT DEFAULT '', pinned INTEGER DEFAULT 0, private INTEGER DEFAULT 0,
  username TEXT DEFAULT '', created INTEGER NOT NULL, updated INTEGER NOT NULL);
-- nová část programu: dostanou ji všichni stávající uživatelé s vlastním výběrem práv
UPDATE users SET perms = perms || ',kalendar' WHERE perms != '';
"""),
    (14, """
-- služby / ceník práce (položka bez skladové evidence), dodavatel a záruka u položky
ALTER TABLE items ADD COLUMN service INTEGER DEFAULT 0;
ALTER TABLE items ADD COLUMN supplier TEXT DEFAULT '';
ALTER TABLE items ADD COLUMN warranty INTEGER DEFAULT 0;
"""),
    (15, """
-- záruka na řádku faktury (kopie z položky v okamžiku vystavení)
ALTER TABLE invoice_lines ADD COLUMN warranty INTEGER DEFAULT 0;
"""),
    (16, """
-- EET 2.0: evidované tržby (účtenky a faktury placené hotově/kartou; storno = záporná tržba)
CREATE TABLE eet (
  id INTEGER PRIMARY KEY,
  receipt_id INTEGER REFERENCES receipts(id) ON DELETE SET NULL,
  invoice_id INTEGER REFERENCES invoices(id) ON DELETE SET NULL,
  doc TEXT NOT NULL, porad_cis TEXT NOT NULL, id_jednotky TEXT NOT NULL, id_pokl TEXT NOT NULL, eic TEXT NOT NULL,
  dat_trzby TEXT NOT NULL, ts INTEGER NOT NULL, amount INTEGER NOT NULL, env TEXT NOT NULL DEFAULT 'prod',
  status TEXT NOT NULL DEFAULT 'ceka', pok TEXT DEFAULT '', error TEXT DEFAULT '', warnings TEXT DEFAULT '',
  attempts INTEGER DEFAULT 0, last_try INTEGER DEFAULT 0, sent INTEGER DEFAULT 0, trace TEXT DEFAULT '',
  created INTEGER NOT NULL);
CREATE INDEX eet_status ON eet(status, ts);
CREATE INDEX eet_receipt ON eet(receipt_id);
CREATE INDEX eet_invoice ON eet(invoice_id);
ALTER TABLE warehouses ADD COLUMN eet_unit TEXT DEFAULT '';
"""),
    (17, """
-- ceny s DPH (výpočet DPH shora, § 37 ZDPH): částka řádku včetně DPH (a recyklačního poplatku s DPH);
-- NULL = doklad počítaný zdola z ceny bez DPH jako dosud. Cena/j. bez DPH (price) se pak jen odvozuje.
ALTER TABLE invoice_lines ADD COLUMN gross INTEGER;
ALTER TABLE purchase_lines ADD COLUMN gross INTEGER;
ALTER TABLE quote_lines ADD COLUMN gross INTEGER;
ALTER TABLE job_lines ADD COLUMN gross INTEGER;
ALTER TABLE receipt_lines ADD COLUMN gross INTEGER;
"""),
    (18, """
-- zálohová faktura vystavená z nabídky (z zakázky slouží už existující invoices.job_id)
ALTER TABLE invoices ADD COLUMN quote_id INTEGER REFERENCES quotes(id);
"""),
    (19, """
-- evidence majetku (inventární čísla, umístění, vyřazení, štítky s QR)
CREATE TABLE assets (
  id INTEGER PRIMARY KEY, number TEXT NOT NULL UNIQUE, name TEXT NOT NULL, category TEXT DEFAULT '',
  serial TEXT DEFAULT '', acquired TEXT DEFAULT '', price INTEGER DEFAULT 0, supplier TEXT DEFAULT '',
  doc TEXT DEFAULT '', purchase_id INTEGER REFERENCES purchases(id) ON DELETE SET NULL, location TEXT DEFAULT '',
  holder TEXT DEFAULT '', warranty TEXT DEFAULT '', note TEXT DEFAULT '', disposed TEXT DEFAULT '',
  dispose_reason TEXT DEFAULT '', created INTEGER NOT NULL);
CREATE INDEX assets_purchase ON assets(purchase_id);
-- nová část programu: dostanou ji uživatelé s vlastním výběrem oprávnění, kteří spravují uživatele nebo přijaté faktury
UPDATE users SET perms = perms || ',majetek'
  WHERE perms != '' AND (',' || perms || ',' LIKE '%,uzivatele,%' OR ',' || perms || ',' LIKE '%,prijate,%');
"""),
    (20, """
-- hromadné importy a párování hledají podle IČO, kódu zboží a čísla faktury dodavatele (20 000 kontaktů: 13 s → pod 2 s)
CREATE INDEX IF NOT EXISTS contacts_ico ON contacts(ico);
CREATE INDEX IF NOT EXISTS items_code ON items(code);
CREATE INDEX IF NOT EXISTS purchases_number ON purchases(number);
"""),
    (21, """
-- režim DPH (přenesená daňová povinnost, plnění do/z EU, mimo EU – viz regimes.py) a kód předmětu plnění pro KH
ALTER TABLE invoices ADD COLUMN regime TEXT DEFAULT '';
ALTER TABLE invoices ADD COLUMN pdp_code TEXT DEFAULT '';
ALTER TABLE purchases ADD COLUMN regime TEXT DEFAULT '';
ALTER TABLE purchases ADD COLUMN pdp_code TEXT DEFAULT '';
"""),
    (22, """
-- dodací listy: průvodní doklad o předání zboží (není daňový doklad); výdej ze skladu dělá dodací list,
-- faktura vystavená z dodacích listů (from_delivery = 1) už sklad znovu neodepisuje
CREATE TABLE delivery_notes (
  id INTEGER PRIMARY KEY, number TEXT NOT NULL UNIQUE, contact_id INTEGER REFERENCES contacts(id),
  cust_name TEXT NOT NULL, cust_address TEXT DEFAULT '', cust_ico TEXT DEFAULT '', cust_dic TEXT DEFAULT '',
  issue_date TEXT NOT NULL, warehouse_id INTEGER NOT NULL DEFAULT 1, note TEXT DEFAULT '', show_prices INTEGER DEFAULT 1,
  status TEXT DEFAULT 'vydan', invoice_id INTEGER REFERENCES invoices(id) ON DELETE SET NULL, vat_payer INTEGER DEFAULT 0,
  created INTEGER NOT NULL);
CREATE TABLE delivery_lines (
  id INTEGER PRIMARY KEY, delivery_id INTEGER NOT NULL REFERENCES delivery_notes(id) ON DELETE CASCADE, pos INTEGER NOT NULL,
  item_id INTEGER REFERENCES items(id), text TEXT NOT NULL, qty REAL NOT NULL, unit TEXT DEFAULT 'ks',
  price INTEGER NOT NULL DEFAULT 0, vat_rate INTEGER DEFAULT 0, recycling_fee INTEGER DEFAULT 0, gross INTEGER);
CREATE INDEX dl_invoice ON delivery_notes(invoice_id);
ALTER TABLE movements ADD COLUMN delivery_id INTEGER REFERENCES delivery_notes(id);
CREATE INDEX mov_dl ON movements(delivery_id);
ALTER TABLE invoices ADD COLUMN from_delivery INTEGER DEFAULT 0;
"""),
    (23, """
-- sady zboží: položka složená ze součástí; prodej sady odepíše ze skladu součásti (sada nemá vlastní stav)
CREATE TABLE item_components (
  id INTEGER PRIMARY KEY, kit_id INTEGER NOT NULL REFERENCES items(id) ON DELETE CASCADE,
  item_id INTEGER NOT NULL REFERENCES items(id), qty REAL NOT NULL);
CREATE INDEX comp_kit ON item_components(kit_id);
CREATE INDEX comp_item ON item_components(item_id);
"""),
]
SCHEMA_VERSION = MIGRATIONS[-1][0]

DEFAULTS = {
    "firm_name": "", "firm_street": "", "firm_city": "", "firm_zip": "", "firm_ico": "", "firm_dic": "",
    "firm_register": "Fyzická osoba zapsaná v živnostenském rejstříku.",
    "firm_email": "", "firm_phone": "", "firm_web": "",
    "bank_account": "", "vat_payer": "0", "invoice_format": "{YYYY}{NNNN}", "due_days": "14",
    "invoice_footer": "", "cash_start_pokladna": "0", "cash_start_banka": "0",
    "port": "8765", "lan": "0", "password_hash": "", "purchase_format": "PF{YYYY}{NNNN}",
    "usb_password": "", "usb_last": "0", "usb_last_label": "", "usb_remind_days": "7",
    "smtp_host": "", "smtp_port": "587", "smtp_security": "starttls", "smtp_user": "", "smtp_password": "",
    "smtp_from": "", "reminder_auto": "0", "reminder_days": "3,14,30",
    "quote_format": "NAB{YYYY}{NNN}", "delivery_format": "DL{YYYY}{NNNN}", "job_format": "ZAK{YYYY}{NNN}", "receipt_format": "UCT{YYYY}{NNNNN}",
    "quote_days": "30", "printer_host": "", "printer_port": "9100", "printer_width": "48", "printer_codepage": "18", "printer_qr": "native",
    "invoice_issuer": "", "job_terms": "Zákazník souhlasí s provedením diagnostiky. Neopravené zařízení si vyzvedněte do 30 dnů od oznámení.",
    "license_key": "", "trial_start": "", "lic_seen": "", "transfer_format": "PR{YYYY}{NNNN}",
    "epo_ufo": "", "epo_pracufo": "", "epo_typ_ds": "P", "epo_jmeno": "", "epo_prijmeni": "", "epo_okec": "",
    "epo_period": "mesic",
    "session_timeout": "30",
    "eet_on": "0", "eet_env": "prod", "eet_eic": "", "eet_unit": "", "eet_pokl": "1", "eet_timeout": "3",
    "eet_p12": "", "eet_p12_pw": "",
    "credit_format": "DB{YYYY}{NNNN}", "advance_format": "ZF{YYYY}{NNNN}", "ddkpp_format": "DD{YYYY}{NNNN}",
}

CATEGORIES_IN = ["Tržby", "Ostatní příjmy", "Vklad", "Převod"]
CATEGORIES_OUT = ["Materiál a zboží", "Služby", "Nájem a energie", "Doprava", "Telefon a internet",
                  "Pojištění", "Daně a poplatky", "Mzdy", "Ostatní výdaje", "Výběr", "Převod"]
VAT_RATES = [21, 12, 0]


class NewerDataError(RuntimeError):
    """Data založila novější verze Firmičky – starší program by je mohl poškodit (neví o nových sloupcích)."""
    def __init__(self, version):
        super().__init__("Data jsou z novější verze Firmičky (verze dat %d, tento program zná nejvýš %d). "
                         "Nainstalujte nejnovější verzi Firmičky – data zůstala beze změny." % (version, SCHEMA_VERSION))
        self.version = version


class DB:
    def __init__(self, path):
        self.path = path
        self.data_dir = os.path.dirname(path)
        self.lock = threading.RLock()  # jeden zapisovatel – stačí pro pár uživatelů v síti
        self.backup_lock = threading.Lock()   # průběžná záloha z vlákna × záloha při ukončení
        self.conn = sqlite3.connect(path, check_same_thread=False, isolation_level=None)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys = ON")
        self.conn.execute("PRAGMA journal_mode = WAL")
        self.migrate()

    def migrate(self):
        with self.lock:
            v = self.conn.execute("PRAGMA user_version").fetchone()[0]
            if v > SCHEMA_VERSION:
                raise NewerDataError(v)
            if v == 0:
                self.conn.executescript(SCHEMA)
                v = 1
                self.conn.execute("PRAGMA user_version = 1")
            for ver, sql in MIGRATIONS:
                if v < ver:
                    # každá migrace celá, nebo vůbec (executescript sám commitne – proto ruční BEGIN)
                    try:
                        self.conn.executescript("BEGIN;\n%s\nPRAGMA user_version = %d;\nCOMMIT;" % (sql, ver))
                    except sqlite3.Error:
                        if self.conn.in_transaction:
                            self.conn.execute("ROLLBACK")
                        raise
                    v = ver

    # --- dotazy ---
    def q(self, sql, args=()):
        with self.lock:
            return self.conn.execute(sql, args).fetchall()

    def one(self, sql, args=()):
        with self.lock:
            return self.conn.execute(sql, args).fetchone()

    def run(self, sql, args=()):
        with self.lock:
            return self.conn.execute(sql, args).lastrowid

    def tx(self):
        return Transaction(self)

    # --- nastavení ---
    def settings(self):
        s = dict(DEFAULTS)
        s.update({r["key"]: r["value"] for r in self.q("SELECT key, value FROM settings")})
        return s

    def set_settings(self, values):
        with self.tx():
            for k, v in values.items():
                self.run("INSERT INTO settings(key, value) VALUES(?, ?) "
                         "ON CONFLICT(key) DO UPDATE SET value = excluded.value", (k, str(v)))

    # --- zálohy ---
    def backup(self, dest):
        with self.lock:
            out = sqlite3.connect(dest)
            try:
                self.conn.backup(out)
                out.execute("PRAGMA journal_mode = DELETE")   # záloha = jeden samostatný soubor (bez -wal/-shm)
            finally:
                out.close()

    def changed_since(self, path):
        """Změnila se data od zálohy `path`? (zápis jde do -wal, checkpoint do hlavního souboru)"""
        m = os.path.getmtime(path)
        return any(os.path.exists(f) and os.path.getmtime(f) > m for f in (self.path, self.path + "-wal"))

    def daily_backup(self, folder, keep=30, refresh=False):
        """Jedna záloha na den, drží posledních `keep` dní. Vznikne při startu; s refresh=True (každou hodinu
        a při ukončení) se dnešní záloha přepíše aktuálním stavem, pokud se od ní něco změnilo – dnešní
        práce tak v záloze je hned, ne až zítra."""
        os.makedirs(folder, exist_ok=True)
        path = os.path.join(folder, "firmicka-%s.sqlite" % date.today().strftime("%Y%m%d"))
        with self.backup_lock:
            if not os.path.exists(path) or (refresh and self.changed_since(path)):
                self.backup(path + ".tmp")
                os.replace(path + ".tmp", path)
        old = sorted(f for f in os.listdir(folder) if f.startswith("firmicka-") and f.endswith(".sqlite"))
        for f in old[:-keep]:
            os.remove(os.path.join(folder, f))
        return path


class Transaction:
    def __init__(self, db):
        self.db = db

    def __enter__(self):
        self.db.lock.acquire()
        self.db.conn.execute("BEGIN")
        return self.db

    def __exit__(self, exc_type, *_):
        try:
            self.db.conn.execute("ROLLBACK" if exc_type else "COMMIT")
        finally:
            self.db.lock.release()


# ---------- výpočty ----------

def stock_levels(db):
    return {r["item_id"]: r["qty"] for r in
            db.q("SELECT item_id, SUM(qty) AS qty FROM movements GROUP BY item_id")}


def warehouse_levels(db):
    """Stav po skladech: {item_id: {warehouse_id: množství}}."""
    out = {}
    for r in db.q("SELECT item_id, warehouse_id, SUM(qty) AS qty FROM movements GROUP BY item_id, warehouse_id"):
        out.setdefault(r["item_id"], {})[r["warehouse_id"]] = r["qty"]
    return out


def qty_text(q, places=6):
    """Množství pro XML (ISDOC, Pohoda, Money): desetinné číslo bez exponentu a bez zaokrouhlení na 6 platných
    číslic jako u %g (1234567 → '1234567', 123,4567 → '123.4567'); Money S3 dovolí nejvýš 4 desetinná místa."""
    t = "%.*f" % (places, q or 0)
    t = t.rstrip("0").rstrip(".")
    return "0" if t in ("", "-0") else t


def rnd(x):
    """Zaokrouhlení na celé (haléře) matematicky – půlka od nuly (1102,5 → 1103, −1102,5 → −1103).
    Vestavěné round() zaokrouhluje půlky k sudé, což u DPH nesedí."""
    return int(math.floor(abs(x) + 0.5 + 1e-9)) * (1 if x >= 0 else -1)


def warranty_text(months):
    """24 → „záruka 24 měsíců“ (1 měsíc, 2–4 měsíce, 5+ měsíců)."""
    m = int(months or 0)
    if not m:
        return ""
    return "záruka %d %s" % (m, "měsíc" if m == 1 else "měsíce" if 2 <= m <= 4 else "měsíců")


def kit_map(db):
    """Sady zboží: {id sady: [(id součásti, množství na 1 sadu)]}."""
    out = {}
    for r in db.q("SELECT kit_id, item_id, qty FROM item_components ORDER BY id"):
        out.setdefault(r["kit_id"], []).append((r["item_id"], r["qty"]))
    return out


def expand_kit(km, item_id, q):
    """Řádek dokladu → skladové pohyby: sada se rozloží na součásti, ostatní položka zůstane. [(id položky, množství)]"""
    if item_id in km:
        return [(c, q * cq) for c, cq in km[item_id]]
    return [(item_id, q)]


def kit_cost(km, costs, item_id):
    """Nákupní cena sady = součet průměrných nákupních cen součástí × množství."""
    return rnd(sum(costs.get(c, (0, 0))[1] * cq for c, cq in km.get(item_id, [])))


def kit_available(km, levels, item_id):
    """Kolik sad jde sestavit ze součástí na skladě (levels = {id: stav})."""
    comps = km.get(item_id)
    if not comps:
        return 0
    import math
    return max(0, min(math.floor((levels.get(c, 0) + 1e-9) / cq) for c, cq in comps if cq > 0))


def service_ids(db):
    """Služby (ceník práce) – na dokladech jako zboží, ale bez pohybů skladu."""
    return {r[0] for r in db.q("SELECT id FROM items WHERE service = 1")}


def with_vat(price, rate):
    """Cena s DPH stejně jako ji spočítá rekapitulace dokladu (daň zaokrouhlená na haléře)."""
    return price + rnd(price * rate / 100)


def item_costs(db):
    """Průměrná nákupní cena (vážený klouzavý průměr) a stav každé položky:
    příjem s cenou průměr přepočítá, výdej ho nemění. {item_id: (stav, průměr v haléřích)}"""
    out = {}
    for m in db.q("SELECT item_id, qty, unit_cost FROM movements ORDER BY date, id"):
        st, avg = out.get(m["item_id"], (0.0, 0))
        if m["qty"] > 0 and m["unit_cost"]:
            base = max(st, 0)
            avg = rnd((base * avg + m["qty"] * m["unit_cost"]) / (base + m["qty"]))
        out[m["item_id"]] = (st + m["qty"], avg)
    return out


def line_fee(ln):
    """Recyklační poplatek za jednotku (řádky ze starší verze ho nemají)."""
    return ln["recycling_fee"] if "recycling_fee" in ln.keys() and ln["recycling_fee"] else 0


def rdiv(a, b):
    """Celočíselné a / b zaokrouhlené na celé, půlka od nuly (jako rnd, ale bez chyb desetinných čísel)."""
    q = (2 * abs(a) + b) // (2 * b)
    return q if a >= 0 else -q


def line_gross(ln):
    """Částka řádku s DPH u dokladu s cenami s DPH (výpočet shora), jinak None."""
    return ln["gross"] if "gross" in ln.keys() and ln["gross"] is not None else None


def is_advance(ln):
    """Řádek „odpočet zálohy“ na konečné faktuře."""
    return "advance_id" in ln.keys() and ln["advance_id"] is not None


def advance_vat(ln):
    """DPH odpočtu zálohy přesně podle daňového dokladu k platbě (záporná), None = neznámá (starší doklady)."""
    g = line_gross(ln) if is_advance(ln) else None
    return None if g is None else g - line_base(ln)


def gross_mode(lines):
    """Doklad s cenami s DPH: DPH se počítá shora ze součtu částek s DPH za sazbu. Odpočet zálohy nese částku
    s DPH vždy (kvůli přesné DPH zálohy), o způsobu výpočtu rozhodují ostatní řádky."""
    return any(line_gross(ln) is not None for ln in lines if not is_advance(ln))


def vat_from_gross(gross, rate):
    """DPH obsažená v částce s DPH (§ 37 odst. 2 ZDPH): částka × sazba / (100 + sazba), na haléře."""
    return rdiv(gross * rate, 100 + rate)


def line_base(ln):
    """Základ řádku zdola: množství × cena bez DPH + množství × recyklační poplatek."""
    return rnd(ln["qty"] * ln["price"]) + rnd(ln["qty"] * line_fee(ln))


def fee_gross(qty, fee, rate):
    """Recyklační poplatek řádku s DPH (poplatek je za jednotku bez DPH)."""
    b = rnd(qty * fee)
    return b + rnd(b * rate / 100)


def net_price_from_gross(gross, qty, fee, rate):
    """Cena za jednotku bez DPH odvozená z částky řádku s DPH (pro tisk, sklad a marži; DPH se z ní nepočítá)."""
    if not qty:
        return 0
    return rnd((gross - vat_from_gross(gross, rate)) / qty - fee)


def _gross_of(ln, rate):
    """Částka řádku s DPH; řádek bez uložené částky (např. starší odpočet zálohy) dopočítat zdola."""
    g = line_gross(ln)
    if g is None:
        b = line_base(ln)
        g = b + rnd(b * rate / 100)
    return g


def negate_line(ln):
    """Řádek s opačným znaménkem (dobropis: v editoru kladně, na dokladu záporně) – včetně částky s DPH."""
    d = dict(ln)
    d["qty"] = -d["qty"]
    if line_gross(d) is not None:
        d["gross"] = -d["gross"]
    return d


def invoice_totals(lines, vat_payer):
    """Rekapitulace DPH po sazbách a celkem k úhradě. Recyklační poplatek je samostatná částka ve stejné
    sazbě jako zboží. Neplátce: vše jako základ bez daně.
    Zdola (ceny bez DPH): DPH = součet základů za sazbu × sazba / 100, na haléře.
    Shora (ceny s DPH, řádky s gross): DPH = součet částek s DPH za sazbu × sazba / (100 + sazba), na haléře;
    základ = částka − DPH. Částky s DPH tak platí přesně, jak byly zadané.
    Odpočet zálohy (§ 37a ZDPH): základ i DPH se snižují přesně o základ a DPH z daňového dokladu k platbě,
    DPH konečné faktury = DPH z plnění − DPH zálohy (ne DPH ze zbylého základu, to by se lišilo o haléř)."""
    shora = gross_mode(lines)
    by_rate = {}
    adv = {}         # sazba → (základ, DPH) odpočtů záloh se známou DPH
    for ln in lines:
        rate = ln["vat_rate"] if vat_payer else 0
        by_rate.setdefault(rate, 0)
        av = advance_vat(ln) if vat_payer else None
        if av is not None:
            b, v = adv.get(rate, (0, 0))
            adv[rate] = (b + line_base(ln), v + av)
            continue
        by_rate[rate] += _gross_of(ln, rate) if shora else line_base(ln)
    recap = []
    total = 0
    for rate in sorted(by_rate, reverse=True):
        ab, av = adv.get(rate, (0, 0))
        if shora:
            gross = by_rate[rate]
            vat = vat_from_gross(gross, rate) if vat_payer else 0
            base = gross - vat + ab
            vat += av
        else:
            base = by_rate[rate]
            vat = (rnd(base * rate / 100) if vat_payer else 0) + av
            base += ab
        recap.append({"rate": rate, "base": base, "vat": vat, "total": base + vat})
        total += base + vat
    return {"recap": recap, "total": total, "shora": shora,
            "base": sum(r["base"] for r in recap), "vat": sum(r["vat"] for r in recap)}


def line_parts(lines, vat_payer):
    """Rozpis dokladu po částech řádků (zboží a zvlášť recyklační poplatek): základ, DPH a částka s DPH každé
    části tak, aby součty za sazbu přesně seděly s rekapitulací (pro tisk, ISDOC a Pohodu). Haléřový rozdíl
    po zaokrouhlení jednotlivých částí se dorovná na největší části v sazbě.
    Části: {"ln", "fee" (poplatek?), "qty", "price" (cena/j. bez DPH), "rate", "base", "vat", "gross"}."""
    t = invoice_totals(lines, vat_payer)
    shora = t["shora"]
    parts = []
    for ln in lines:
        rate = ln["vat_rate"] if vat_payer else 0
        fee = line_fee(ln)
        av = advance_vat(ln) if vat_payer else None
        if av is not None:        # odpočet zálohy: DPH přesně podle daňového dokladu k platbě
            b = line_base(ln)
            parts.append({"ln": ln, "fee": False, "qty": ln["qty"], "price": ln["price"], "rate": rate,
                          "base": b, "vat": av, "gross": b + av, "adv": True})
            continue
        if shora:
            fg = fee_gross(ln["qty"], fee, rate) if fee else 0
            amounts = [(False, ln["price"], _gross_of(ln, rate) - fg)] + ([(True, fee, fg)] if fee else [])
            for is_fee, price, g in amounts:
                parts.append({"ln": ln, "fee": is_fee, "qty": ln["qty"], "price": price, "rate": rate,
                              "gross": g, "vat": vat_from_gross(g, rate)})
        else:
            for is_fee, price in [(False, ln["price"])] + ([(True, fee)] if fee else []):
                b = rnd(ln["qty"] * price)
                parts.append({"ln": ln, "fee": is_fee, "qty": ln["qty"], "price": price, "rate": rate,
                              "base": b, "vat": rnd(b * rate / 100)})
    key = "gross" if shora else "base"
    for r in t["recap"]:
        same = [x for x in parts if x["rate"] == r["rate"] and not x.get("adv")]
        diff = r["vat"] - sum(x["vat"] for x in parts if x["rate"] == r["rate"])
        if same and diff:
            max(same, key=lambda x: abs(x[key]))["vat"] += diff
    for x in parts:
        if x.get("adv"):
            continue
        if shora:
            x["base"] = x["gross"] - x["vat"]
        else:
            x["gross"] = x["base"] + x["vat"]
    return parts


def next_invoice_number(db, issue_date, fmt, table="invoices", col="number"):
    """{YYYY}/{YY} = rok, {NNNN}/{NNN}… = pořadí v roce (počet N = počet číslic). Ostatní znaky (i %) doslova."""
    year = issue_date[:4]
    text = fmt.replace("{YYYY}", year).replace("{YY}", year[2:])
    n_len = 0
    for k in ("NNNNNN", "NNNNN", "NNNN", "NNN", "NN"):
        if "{%s}" % k in text:
            n_len = len(k)
            head, tail = text.split("{%s}" % k, 1)
            break
    if not n_len:
        head, tail, n_len = text, "", 4
    make = lambda n: "%s%0*d%s" % (head, n_len, n, tail)
    used = {r[0] for r in db.q("SELECT %s FROM %s" % (col, table))}
    n = 1
    for num in used:
        mid = num[len(head):len(num) - len(tail)] if tail else num[len(head):]
        if num.startswith(head) and num.endswith(tail) and mid.isdigit():
            n = max(n, int(mid) + 1)
    while make(n) in used:
        n += 1
    return make(n)


def today():
    return date.today().isoformat()


def now():
    return int(time.time())
