"""Upomínky neuhrazených faktur: přehled dlužníků, e-mail odběrateli (3 stupně) s ISDOC v příloze,
volitelně automaticky podle počtu dní po splatnosti. Odesílá se přes SMTP firmy (nastavení)."""
import re
import smtplib
import ssl
from datetime import date
from email.message import EmailMessage
from email.utils import formataddr, make_msgid

from . import qr
from .db import invoice_totals, today, now
from .invoices import lines_of
from .web import h, money, cz_date, flash, flash_redirect, HTTPError

LEVELS = {1: "Připomenutí platby", 2: "Upomínka", 3: "Poslední upomínka"}

TEMPLATES = {
    1: """Dobrý den,

dovolujeme si připomenout fakturu č. {cislo} na částku {castka}, která byla splatná {splatnost}.
Pokud jste ji již uhradili, považujte prosím tuto zprávu za bezpředmětnou.

{platba}

S pozdravem
{podpis}""",
    2: """Dobrý den,

evidujeme neuhrazenou fakturu č. {cislo} na částku {castka}, splatnou {splatnost} (po splatnosti {dni}).
Prosíme o úhradu v nejbližším možném termínu.

{platba}

S pozdravem
{podpis}""",
    3: """Dobrý den,

faktura č. {cislo} na částku {castka}, splatná {splatnost}, je stále neuhrazená (po splatnosti {dni})
i přes předchozí upomínky. Žádáme o její úhradu do 7 dnů od doručení této zprávy. V opačném případě
budeme nuceni pohledávku řešit dalšími kroky.

{platba}

S pozdravem
{podpis}""",
}
SUBJECTS = {k: "%s – faktura {cislo} ({firma})" % v for k, v in LEVELS.items()}
# značky, které jde použít ve vlastním textu (Nastavení → E-mail)
FIELDS = (("cislo", "číslo faktury"), ("castka", "dlužná částka"), ("splatnost", "datum splatnosti"),
          ("dni", "kolik dní po splatnosti, např. „14 dní“"), ("odberatel", "jméno odběratele"),
          ("platba", "účet, VS, částka a IBAN"), ("firma", "název vaší firmy"),
          ("podpis", "název firmy, telefon a e-mail pod sebou"))
TOKEN = re.compile(r"\{([a-z_]+)\}")
MAX_TEXT = 5000


def template(s, level):
    """(předmět, text) – vlastní z nastavení, jinak výchozí."""
    return (s.get("reminder_subject_%d" % level) or SUBJECTS[level],
            s.get("reminder_text_%d" % level) or TEMPLATES[level])


def fill(tpl, vals):
    """Dosadí známé značky; neznámé nechá být (žádné format → ani chyba, ani přístup k atributům)."""
    return TOKEN.sub(lambda m: vals.get(m.group(1), m.group(0)), tpl)


def unknown_fields(text):
    known = {k for k, _ in FIELDS}
    return sorted({t for t in TOKEN.findall(text) if t not in known})


def days_text(days):
    return "%d %s" % (days, "den" if days == 1 else "dny" if 2 <= days <= 4 else "dní")


def plain_date(iso):
    return "%d. %d. %s" % (int(iso[8:10]), int(iso[5:7]), iso[:4])


def overdue(db):
    """Neuhrazené faktury po splatnosti s e-mailem z adresáře a posledním stupněm upomínky."""
    out = []
    t = today()
    for inv in db.q("SELECT i.*, c.email FROM invoices i LEFT JOIN contacts c ON c.id = i.contact_id "
                    "WHERE i.status = 'vystavena' AND i.kind IN ('faktura', 'zaloha') AND i.due_date < ? ORDER BY i.due_date", (t,)):
        last = db.one("SELECT * FROM reminders WHERE invoice_id = ? ORDER BY level DESC, id DESC LIMIT 1", (inv["id"],))
        total = invoice_totals(lines_of(db, inv["id"]), inv["vat_payer"])["total"]
        if total <= 0:            # nic nám nedluží (záloha pokryla víc než fakturu)
            continue
        out.append({"inv": inv, "total": total,
                    "days": (date.today() - date.fromisoformat(inv["due_date"])).days,
                    "email": inv["email"] or "", "last": last})
    return out


def compose(s, inv, total, level):
    days = (date.today() - date.fromisoformat(inv["due_date"])).days
    pay = []
    if s["bank_account"]:
        pay.append("Platební údaje: účet %s, variabilní symbol %s, částka %s." % (s["bank_account"], inv["vs"], money(total)))
        iban = qr.cz_iban(s["bank_account"])
        if iban:
            pay.append("IBAN: %s" % iban)
    vals = {"cislo": inv["number"], "castka": money(total).replace("\u00a0", " "),
            "splatnost": plain_date(inv["due_date"]), "dni": days_text(days), "odberatel": inv["cust_name"] or "",
            "platba": "\n".join(pay), "firma": s["firm_name"] or "",
            "podpis": "\n".join(x for x in (s["firm_name"], s["firm_phone"], s["firm_email"]) if x)}
    subj_tpl, text_tpl = template(s, level)
    subject = " ".join(fill(subj_tpl, vals).replace("()", "").split())     # bez názvu firmy nezůstane „()“
    body = re.sub(r"\n{3,}", "\n\n", fill(text_tpl, vals)).strip() + "\n"   # prázdná {platba} nenechá díru
    return subject, body


def smtp_notice(s, eml=False):
    """Viditelné upozornění, když není nastavený odchozí e-mail (zašedlé tlačítko samo nestačí – na mobilu není vidět proč)."""
    if s["smtp_host"]:
        return ""
    return ('<div class="flash error">Odchozí e-mail není nastavený, takže odeslat přímo z Firmičky zatím nejde. '
            '<a href="/nastaveni#email">Nastavit e-mail →</a>%s</div>'
            % (" Mezitím můžete zprávu i s přílohami otevřít ve svém poštovním programu (tlačítko dole)." if eml else ""))


def send_mail(s, to, subject, body, attachments=()):
    if not s["smtp_host"]:
        raise ValueError("Není nastavený odchozí e-mail (Nastavení → E-mail)")
    msg = EmailMessage()
    sender = s["smtp_from"] or s["smtp_user"]
    msg["From"] = formataddr((s["firm_name"], sender)) if s["firm_name"] else sender
    msg["To"] = to
    msg["Subject"] = subject
    msg["Message-ID"] = make_msgid(domain=sender.rsplit("@", 1)[-1] if "@" in sender else None)
    msg.set_content(body)
    for name, data, mime in attachments:
        main, sub = mime.split("/", 1)
        msg.add_attachment(data, maintype=main, subtype=sub, filename=name)
    port = int(s["smtp_port"]) if (s["smtp_port"] or "").isdigit() else 587
    ctx = ssl.create_default_context()
    if s["smtp_security"] == "ssl":
        server = smtplib.SMTP_SSL(s["smtp_host"], port, timeout=20, context=ctx)
    else:
        server = smtplib.SMTP(s["smtp_host"], port, timeout=20)
        if s["smtp_security"] == "starttls":
            server.starttls(context=ctx)
    try:
        if s["smtp_user"]:
            server.login(s["smtp_user"], s["smtp_password"])
        server.send_message(msg)
    finally:
        try:
            server.quit()
        except Exception:
            pass


def send_reminder(db, s, inv, total, level, to, subject, body):
    from . import isdoc
    from . import pdfdoc
    lines = lines_of(db, inv["id"])
    from .mail import doc_attachments
    att = doc_attachments(db, s, inv, lines)
    send_mail(s, to, subject, body, att)
    db.run("INSERT INTO reminders(invoice_id, date, level, email, subject, created) VALUES(?,?,?,?,?,?)",
           (inv["id"], today(), level, to, subject, now()))


def auto_run(db):
    """Automatické upomínky (volá se z vlákna jednou za hodinu). Vrací počet odeslaných."""
    s = db.settings()
    if s["reminder_auto"] != "1" or not s["smtp_host"]:
        return 0
    from . import licence
    if licence.state(db)["mode"] == "readonly":   # úhrady teď nejde zapsat → neupomínat ty, kdo už zaplatili
        return 0
    try:
        steps = [int(x) for x in s["reminder_days"].split(",") if x.strip().isdigit()][:3]
    except ValueError:
        return 0
    sent = 0
    for o in overdue(db):
        if not o["email"]:
            continue
        done = o["last"]["level"] if o["last"] else 0
        if o["last"] and o["last"]["date"] == today():
            continue
        level = done + 1
        if level > len(steps) or o["days"] < steps[level - 1]:
            continue
        subject, body = compose(s, o["inv"], o["total"], level)
        try:
            send_reminder(db, s, o["inv"], o["total"], level, o["email"], subject, body)
            sent += 1
            print("Upomínka %d odeslána: %s → %s" % (level, o["inv"]["number"], o["email"]))
        except Exception as e:
            print("Upomínka %s selhala: %s" % (o["inv"]["number"], e))
            break        # nejspíš SMTP – nezkoušet další
    return sent


def register(app):
    db = app.db

    def preselect(o):
        """Předvybrat k hromadnému odeslání: má e-mail, ještě nemá 3. stupeň a poslední upomínka je starší než týden."""
        if not o["email"] or (o["last"] and o["last"]["level"] >= 3):
            return False
        return not o["last"] or (date.today() - date.fromisoformat(o["last"]["date"])).days >= 7

    @app.route("/upominky")
    def index(req):
        s = req.settings
        rows = overdue(db)
        trs = "".join(
            "<tr><td><input type=checkbox name=vybrat value=%d%s%s aria-label='Vybrat %s'></td>"
            "<td><a href='/faktury/%d'>%s</a></td><td>%s<br><small class=hint>%s</small></td><td class=nowrap>%s</td>"
            "<td class=num>%d</td><td class='num nowrap'>%s</td>"
            "<td>%s</td><td><a class='btn' href='/faktury/%d/upominka'>%s</a></td></tr>" % (
                o["inv"]["id"], " checked" if preselect(o) else "", "" if o["email"] else " disabled", h(o["inv"]["number"]),
                o["inv"]["id"], h(o["inv"]["number"]), h(o["inv"]["cust_name"]), h(o["email"]) or "bez e-mailu",
                cz_date(o["inv"]["due_date"]), o["days"], money(o["total"]),
                "%s %s" % (LEVELS[o["last"]["level"]], cz_date(o["last"]["date"])) if o["last"] else "—",
                o["inv"]["id"], "Poslat %d. stupeň" % min(3, (o["last"]["level"] if o["last"] else 0) + 1))
            for o in rows)
        total = sum(o["total"] for o in rows)
        dl = [x.strip() for x in s["reminder_days"].split(",") if x.strip()]
        dl = ", ".join(dl[:-1]) + " a " + dl[-1] if len(dl) > 1 else "".join(dl)
        auto = ("zapnuté (%s dní po splatnosti)" % h(dl)) if s["reminder_auto"] == "1" else "vypnuté"
        no_mail = sum(1 for o in rows if not o["email"])
        bulk = ""
        if rows:
            bulk = ("<div class='actions'><button class='btn primary'%s>Poslat upomínky vybraným</button>"
                    "<span class=hint>Každému odejde další stupeň (1. připomenutí → 2. upomínka → 3. poslední upomínka) "
                    "s textem z Nastavení a fakturou v PDF a ISDOC.%s Kdo dnes upomínku už dostal, se přeskočí.</span></div>") % (
                "" if s["smtp_host"] else " disabled",
                (" Faktury bez e-mailu (%d) vybrat nejde – doplňte e-mail v adresáři." % no_mail) if no_mail else "")
        return app.page("Upomínky", """%s<div class="bar"><h1>Dlužníci a upomínky</h1>
<a class="btn" href="/nastaveni#email">Nastavení e-mailu</a></div>
<div class="stats"><div><span>Po splatnosti celkem</span><b class=out>%s</b><small>%s</small></div>
<div><span>Automatické upomínky</span><b class=small>%s</b></div></div>
%s<form method="post" action="/upominky/hromadne">%s<table class="list"><thead><tr><th></th><th>Faktura</th><th>Odběratel / e-mail</th>
<th>Splatnost</th><th class=num>Dní po</th><th class=num>Částka</th><th>Poslední upomínka</th><th></th></tr></thead>
<tbody>%s</tbody></table>%s</form>%s""" % (
            flash(req), money(total), "%d %s" % (len(rows), "faktura" if len(rows) == 1 else "faktury" if 2 <= len(rows) <= 4 else "faktur"), auto,
            "" if s["smtp_host"] else '<div class="flash error">Odchozí e-mail není nastavený – upomínky teď odeslat nejde%s. '
            '<a href="/nastaveni#email">Nastavit e-mail →</a></div>' % (", ani automatické" if s["reminder_auto"] == "1" else ""),
            app.csrf(), trs, bulk, "" if rows else "<p class=empty>Nikdo nedluží 👍</p>"), "/faktury")

    @app.route("/upominky/hromadne", ("POST",))
    def bulk(req):
        import smtplib
        s = req.settings
        if not s["smtp_host"]:
            flash_redirect("/upominky", "Není nastavený odchozí e-mail (Nastavení → E-mail)")
        ids = [int(x) for x in req.lst("vybrat") if x.isdigit()][:200]
        if not ids:
            flash_redirect("/upominky", "Vyberte faktury, kterým se má poslat upomínka")
        open_ = {o["inv"]["id"]: o for o in overdue(db)}
        sent, skipped, failed = {1: 0, 2: 0, 3: 0}, [], []
        for i, iid in enumerate(ids):
            o = open_.get(iid)
            if not o:
                skipped.append("faktura už není po splatnosti nebo je uhrazená")
                continue
            num = o["inv"]["number"]
            if not o["email"]:
                skipped.append("%s bez e-mailu" % num)
                continue
            if o["last"] and o["last"]["date"] == today():
                skipped.append("%s dnes už upomínku dostala" % num)
                continue
            level = min(3, (o["last"]["level"] if o["last"] else 0) + 1)
            subject, body = compose(s, o["inv"], o["total"], level)
            with db.tx():      # zamluvit: souběžné hromadné odeslání stejnou fakturu znovu nepošle
                if db.one("SELECT 1 FROM reminders WHERE invoice_id = ? AND date = ?", (iid, today())):
                    skipped.append("%s dnes už upomínku dostala" % num)
                    continue
                rid = db.run("INSERT INTO reminders(invoice_id, date, level, email, subject, created) VALUES(?,?,?,?,?,?)",
                             (iid, today(), level, o["email"], subject, now()))
            try:
                from .mail import doc_attachments
                send_mail(s, o["email"], subject, body, doc_attachments(db, s, o["inv"], lines_of(db, iid)))
                sent[level] += 1
            except (smtplib.SMTPRecipientsRefused, smtplib.SMTPSenderRefused) as e:
                db.run("DELETE FROM reminders WHERE id = ?", (rid,))     # problém jen s touto adresou → pokračovat
                failed.append("%s: %s" % (num, e))
            except Exception as e:
                db.run("DELETE FROM reminders WHERE id = ?", (rid,))
                failed.append("%s: %s – další se neposílaly (%d)" % (num, e, len(ids) - i - 1))
                break                 # e-mailový server nebo nastavení nefunguje → nezkoušet další (každý pokus by čekal)
        n = sum(sent.values())
        parts = ["%d× %s" % (c, LEVELS[k].lower()) for k, c in sent.items() if c]
        msg = "Odesláno %d %s%s" % (n, "upomínka" if n == 1 else "upomínky" if 2 <= n <= 4 else "upomínek",
                                    " (%s)" % ", ".join(parts) if parts else "")
        if skipped:
            msg += " · přeskočeno: " + "; ".join(skipped[:5]) + (" …" if len(skipped) > 5 else "")
        if failed:
            msg += " · NEODESLÁNO: " + "; ".join(failed[:3])
        flash_redirect("/upominky", msg)

    @app.route("/faktury/<iid>/upominka", ("GET", "POST"))
    def reminder(req, iid):
        s = req.settings
        inv = db.one("SELECT i.*, c.email FROM invoices i LEFT JOIN contacts c ON c.id = i.contact_id WHERE i.id = ?", (iid,))
        if not inv:
            raise HTTPError(404, "Faktura neexistuje")
        total = invoice_totals(lines_of(db, inv["id"]), inv["vat_payer"])["total"]
        last = db.one("SELECT MAX(level) AS l FROM reminders WHERE invoice_id = ?", (inv["id"],))["l"] or 0
        lv = req.f("level") or req.args.get("stupen") or ""
        level = int(lv) if lv in ("1", "2", "3") else min(3, last + 1)
        level = level if level in LEVELS else 1
        if req.method == "POST":
            to = req.f("to")
            if "@" not in to:
                flash_redirect("/faktury/%d/upominka" % inv["id"], "Zadejte e-mail odběratele")
            try:
                send_reminder(db, s, inv, total, level, to, req.f("subject"), req.form.get("body", ""))
            except Exception as e:
                flash_redirect("/faktury/%d/upominka?stupen=%d" % (inv["id"], level), "Odeslání selhalo: %s" % e)
            if inv["contact_id"] and not inv["email"]:
                db.run("UPDATE contacts SET email = ? WHERE id = ?", (to, inv["contact_id"]))
            flash_redirect("/upominky", "%s odesláno na %s" % (LEVELS[level], to))
        subject, body = compose(s, inv, total, level)
        sent = db.q("SELECT * FROM reminders WHERE invoice_id = ? ORDER BY id", (inv["id"],))
        hist = "".join("<li>%s – %s → %s</li>" % (cz_date(r["date"]), LEVELS[r["level"]], h(r["email"])) for r in sent)
        lsel = "".join('<option value="%d"%s>%s</option>' % (k, " selected" if k == level else "", v) for k, v in LEVELS.items())
        return app.page("Upomínka", """%s<div class="bar"><a href="/upominky">← Dlužníci</a></div>
<h1>%s – faktura %s</h1>%s%s
<form method="post" class="grid">%s
<label>Stupeň<select name="level" onchange="location='?stupen='+this.value">%s</select></label>
<label class="wide">Komu<input name="to" type="email" value="%s" required></label>
<label class="wide">Předmět<input name="subject" value="%s"></label>
<label class="wide">Text<textarea name="body" rows="14">%s</textarea></label>
<p class="wide hint">V příloze se pošle faktura v PDF a ve formátu ISDOC.</p>
<div class="actions wide"><button class="btn primary"%s>Odeslat</button></div></form>""" % (
            flash(req), LEVELS[level], h(inv["number"]), "<ul class=hint>%s</ul>" % hist if hist else "", smtp_notice(s), app.csrf(), lsel,
            h(inv["email"]), h(subject), h(body), "" if s["smtp_host"] else " disabled title='Nastavte odchozí e-mail v Nastavení'"), "/faktury")

    @app.route("/nastaveni/email", ("POST",))
    def email_settings(req):
        vals = {k: req.f(k) for k in ("smtp_host", "smtp_port", "smtp_security", "smtp_user", "smtp_from", "reminder_days")}
        if vals["smtp_port"] and not (vals["smtp_port"].isdigit() and 1 <= int(vals["smtp_port"]) <= 65535):
            flash_redirect("/nastaveni#email", "Port serveru musí být číslo 1–65535 (obvykle 587, nebo 465 u SSL)")
        if req.form.get("smtp_password"):
            vals["smtp_password"] = req.form["smtp_password"]
        vals["reminder_auto"] = "1" if req.f("reminder_auto") else "0"
        if vals["smtp_security"] not in ("starttls", "ssl", "none"):
            vals["smtp_security"] = "starttls"
        bad = set()
        for lv in LEVELS:
            subj = " ".join(req.form.get("reminder_subject_%d" % lv, "").split())[:300]
            text = req.form.get("reminder_text_%d" % lv, "").replace("\r\n", "\n").replace("\r", "\n").strip()[:MAX_TEXT]
            if "reminder_text_%d" % lv not in req.form:      # starý formulář bez textů → nic neměnit
                continue
            bad.update(unknown_fields(subj + text))
            # stejný jako výchozí (nebo prázdný) = výchozí; uloží se prázdně, aby šly budoucí úpravy výchozích textů
            vals["reminder_subject_%d" % lv] = "" if subj == SUBJECTS[lv] else subj
            vals["reminder_text_%d" % lv] = "" if text == TEMPLATES[lv].strip() else text
        db.set_settings(vals)
        if vals["reminder_auto"] == "1" and not vals["smtp_host"]:
            flash_redirect("/nastaveni#email", "Uloženo, ale automatické upomínky se posílat nebudou, dokud nevyplníte SMTP server.")
        if bad:
            flash_redirect("/nastaveni#email", "Uloženo, ale tyto značky program nezná a nechá je v textu, jak jsou: %s. "
                           "Seznam značek je pod texty upomínek." % ", ".join("{%s}" % b for b in bad))
        if req.f("test"):
            s = db.settings()
            try:
                send_mail(s, req.f("test"), "Firmička – zkušební e-mail", "Odesílání e-mailů z Firmičky funguje.")
            except Exception as e:
                flash_redirect("/nastaveni#email", "Uloženo, ale zkušební e-mail selhal: %s" % e)
            flash_redirect("/nastaveni#email", "Uloženo a zkušební e-mail odeslán na %s" % req.f("test"))
        flash_redirect("/nastaveni#email", "Nastavení e-mailu uloženo")


def settings_form(app, s):
    sec = "".join('<option value="%s"%s>%s</option>' % (k, " selected" if s["smtp_security"] == k else "", v)
                  for k, v in (("starttls", "STARTTLS (port 587)"), ("ssl", "SSL/TLS (port 465)"), ("none", "bez šifrování")))
    return """<section class="card" id="email"><h2>E-mail (upomínky)</h2>
<form method="post" action="/nastaveni/email" class="grid">%s
<label>SMTP server<input name="smtp_host" value="%s" placeholder="smtp.seznam.cz"></label>
<label>Port<input name="smtp_port" value="%s" inputmode="numeric"></label>
<label>Zabezpečení<select name="smtp_security">%s</select></label>
<label>Uživatel<input name="smtp_user" value="%s" autocomplete="off"></label>
<label>Heslo<input type="password" name="smtp_password" placeholder="%s" autocomplete="new-password"></label>
<label>Odesílatel<input name="smtp_from" value="%s" placeholder="faktury@firma.cz"></label>
<label class="check wide"><input type="checkbox" name="reminder_auto" value="1"%s> Posílat upomínky automaticky</label>
<label>Dní po splatnosti (1., 2., 3. stupeň)<input name="reminder_days" value="%s"></label>
<label>Zkušební e-mail na<input name="test" type="email" placeholder="nepovinné"></label>
%s
<div class="actions wide"><button class="btn">Uložit e-mail</button></div></form></section>""" % (
        app.csrf(), h(s["smtp_host"]), h(s["smtp_port"]), sec, h(s["smtp_user"]),
        "ponechat uložené" if s["smtp_password"] else "", h(s["smtp_from"]),
        " checked" if s["reminder_auto"] == "1" else "", h(s["reminder_days"]), texts_form(s))


def texts_form(s):
    custom = [lv for lv in LEVELS if s.get("reminder_subject_%d" % lv) or s.get("reminder_text_%d" % lv)]
    parts = []
    for lv, name in LEVELS.items():
        subj, text = template(s, lv)
        parts.append('<fieldset class="tpl"><legend>%d. %s%s</legend>'
                     '<label>Předmět<input name="reminder_subject_%d" value="%s" maxlength="300"></label>'
                     '<label>Text<textarea name="reminder_text_%d" rows="11" maxlength="%d">%s</textarea></label></fieldset>'
                     % (lv, h(name), " – upraveno" if lv in custom else "", lv, h(subj), lv, MAX_TEXT, h(text)))
    marks = "".join("<li><code>{%s}</code> %s</li>" % (k, h(v)) for k, v in FIELDS)
    return ('<details class="wide tpl"%s><summary>Texty upomínek%s</summary>%s'
            '<p class="hint">Značky ve složených závorkách program při odeslání nahradí údaji z faktury. '
            'Když text smažete a uložíte, vrátí se výchozí. Před ručním odesláním jde text upomínky ještě upravit.</p>'
            '<ul class="tpl-marks">%s</ul></details>'
            % (" open" if custom else "", " (upraveno)" if custom else "", "".join(parts), marks))
