"""Záložka Datová schránka: připojení (jméno + heslo jen v paměti), odeslání podání k DPH na finanční úřad
s náhledem a výslovným potvrzením, odeslané zprávy s doručenkou, přijaté zprávy (načtení = doručení!)."""
import os
import re
import time

from . import epo, isds
from .epo_codes import UFO
from .web import h, flash, flash_redirect, HTTPError, Response

ID_RX = re.compile(r"^[a-z0-9]{7}$")
MIME = {"xml": "application/xml", "pdf": "application/pdf", "zfo": "application/vnd.software602.filler.form-xml-zip",
        "isdoc": "application/xml", "txt": "text/plain", "zip": "application/zip"}


def cz_time(t):
    """2026-11-17T20:15:33.123+01:00 → 17. 11. 2026 20:15"""
    m = re.match(r"(\d{4})-(\d\d)-(\d\d)T(\d\d):(\d\d)", t or "")
    return "%d. %d. %s %s:%s" % (int(m.group(3)), int(m.group(2)), m.group(1), m.group(4), m.group(5)) if m else ""


def period_label(p, year):
    return ("%s/%s" % (p[1:], year)) if p[:1] == "m" else ("%s. čtvrtletí %s" % (p[1:], year))


def plain(name):
    """Název schránky pro porovnání – bez předpony „TEST“ z testovacího prostředí."""
    n = (name or "").strip().lower()
    return n[5:].strip() if n.startswith("test ") else n


def safe_name(n):
    n = re.sub(r"[^\w.\- ]", "_", n or "priloha", flags=re.UNICODE).strip() or "priloha"
    return n[:120]


def register(app):
    db = app.db
    app.isds = getattr(app, "isds", None) or isds.Sessions()
    base = os.environ.get("FIRMICKA_ISDS_BASE") or None     # jen pro automatické testy (náhradní server)

    def key(req):
        return req.cookies.get("firmicka_session", "") or "mistni"

    def box(req, need=True):
        b = app.isds.get(key(req))
        if need and not b:
            flash_redirect("/datovka", "Nejdřív se připojte k datové schránce")
        return b

    def head(b):
        return ('<section class="card"><p>Připojeno: <b>%s</b> (ID schránky %s) – %s%s</p>'
                '<form method="post" action="/datovka/odpojit">%s<button class="btn">Odpojit</button></form></section>' % (
                    h(b.owner.get("name", "")), h(b.owner.get("id", "")), h(isds.ENV_NAMES[b.env]),
                    ' · <b>nic se nepodává doopravdy</b>' if b.env == "test" else "", app.csrf()))

    @app.route("/datovka")
    def index(req):
        s = req.settings
        b = box(req, False)
        if not b:
            env = s.get("isds_env") or "ostre"
            opts = "".join('<option value="%s"%s>%s</option>' % (k, " selected" if k == env else "", h(v))
                           for k, v in isds.ENV_NAMES.items())
            body = """<section class="card"><h2>Připojení k datové schránce</h2>
<form method="post" action="/datovka/pripojit" class="grid">%s
<label>Prostředí<select name="prostredi">%s</select></label>
<label>Přihlašovací jméno<input name="isds_jmeno" value="%s" autocomplete="username" required></label>
<label>Heslo<input type="password" name="isds_heslo" autocomplete="current-password" required></label>
<div class="actions wide"><button class="btn primary">Připojit</button></div></form>
<p class="hint">Heslo se nikam neukládá – Firmička ho drží jen v paměti, dokud pracujete (po 30 minutách nečinnosti
nebo ukončení programu je potřeba se připojit znovu). Přihlašovací údaje nesmí odejít mimo váš počítač, proto
Firmičku pro datovou schránku používejte jen na vlastním počítači nebo ve vlastní síti.
Připojení jde jen jménem a heslem – pokud máte ve schránce přihlašování heslem zakázané (jen Mobilní klíč nebo
Identita občana), tímto způsobem se nepřipojíte.</p></section>""" % (app.csrf(), opts, h(s.get("isds_user", "")))
            return app.page("Datová schránka", "<h1>Datová schránka</h1>" + flash(req) + body, "/datovka")
        miss = epo.check_settings(s)
        cur = time.localtime()
        popts = [("m%d" % m, "%d. měsíc" % m) for m in range(1, 13)] + [("q%d" % i, "%d. čtvrtletí" % i) for i in range(1, 5)]
        pdef = "m%d" % (cur.tm_mon - 1 or 12)
        year = cur.tm_year if cur.tm_mon > 1 else cur.tm_year - 1
        psel = "".join('<option value="%s"%s>%s</option>' % (v, " selected" if v == pdef else "", t) for v, t in popts)
        if miss:
            send = '<p class="flash error">Pro podání doplňte v <a href="/nastaveni#epo">Nastavení → Finanční úřad</a>: %s.</p>' % \
                   h(", ".join(miss))
        else:
            send = """<form class="filters" action="/datovka/podani"><input name="rok" value="%d" size="4">
<select name="obdobi">%s</select><select name="forma"><option value="B">řádné</option><option value="O">řádné-opravné</option></select>
<select name="co"><option value="dp3">Přiznání k DPH</option><option value="kh1">Kontrolní hlášení</option>
<option value="shv">Souhrnné hlášení (EU)</option></select><button class="btn primary">Připravit k odeslání</button></form>""" % (year, psel)
        out = db.q("SELECT * FROM isds_messages WHERE env = ? AND direction = 'out' ORDER BY id DESC LIMIT 200", (b.env,))
        trs = "".join("<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td class=nowrap>%s%s</td></tr>" % (
            h(cz_time(m["delivery_time"]) or time.strftime("%d. %m. %Y %H:%M", time.localtime(m["created"]))),
            h(m["dm_id"]), h(m["annotation"]), h(m["counterpart"]), h(isds.STATUS.get(m["status"] or "", m["status"] or "")),
            "<a href='/datovka/zprava/%d'>detail</a>" % m["id"],
            " · <a href='/datovka/zprava/%d/zfo'>ZFO</a>" % m["id"] if m["zfo"] else "") for m in out)
        inc = db.q("SELECT * FROM isds_messages WHERE env = ? AND direction = 'in' ORDER BY delivery_time DESC LIMIT 200", (b.env,))
        trs_in = "".join("<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td><a href='/datovka/zprava/%d'>otevřít</a></td></tr>" % (
            h(cz_time(m["delivery_time"])), h(m["counterpart"]), h(m["annotation"]),
            h(isds.STATUS.get(m["status"] or "", m["status"] or "")), m["id"]) for m in inc)
        body = head(b) + """<section class="card"><h2>Odeslat podání na finanční úřad</h2>%s
<p class="hint">Nejdřív uvidíte náhled (adresát ověřený v datové schránce, období, částky) a podání odešlete až po potvrzení.
Podání z datové schránky firmy se nemusí podepisovat. Doručenka potvrzuje jen doručení – o tom, zda je podání v pořádku,
rozhoduje finanční úřad.</p></section>
<section class="card"><h2>Odeslané zprávy</h2>
<form method="post" action="/datovka/stav">%s<button class="btn">Aktualizovat stav</button></form>
<div class="tablewrap"><table class="list"><tr><th>Odesláno</th><th>Číslo zprávy</th><th>Věc</th><th>Adresát</th><th>Stav</th><th></th></tr>
%s</table></div></section>
<section class="card"><h2>Přijaté zprávy</h2>
<form method="post" action="/datovka/prijate" onsubmit="return confirm('Načtením seznamu se zprávy ve schránce DORUČÍ – začnou běžet lhůty (stejně jako po přihlášení na portálu). Pokračovat?')">%s
<button class="btn">Načíst přijaté zprávy (posledních 90 dní)</button></form>
<p class="hint">Pozor: načtení seznamu přijatých zpráv má stejné účinky jako přihlášení do schránky – dodané zprávy
se tím doručí a začnou běžet lhůty.</p>
<div class="tablewrap"><table class="list"><tr><th>Dodáno</th><th>Odesílatel</th><th>Věc</th><th>Stav</th><th></th></tr>
%s</table></div></section>""" % (send, app.csrf(), trs or "<tr><td colspan=6 class=empty>Zatím nic.</td></tr>", app.csrf(),
                                trs_in or "<tr><td colspan=5 class=empty>Zatím nenačteno.</td></tr>")
        return app.page("Datová schránka", "<h1>Datová schránka</h1>" + flash(req) + body, "/datovka")

    @app.route("/datovka/pripojit", ("POST",))
    def connect(req):
        env = req.f("prostredi") if req.f("prostredi") in isds.HOSTS else "ostre"
        user, pwd = req.f("isds_jmeno")[:64], req.form.get("isds_heslo", "")[:256]
        if not user or not pwd:
            flash_redirect("/datovka", "Vyplňte přihlašovací jméno a heslo")
        b = isds.Box(env, user, pwd, base)
        try:
            b.owner_info()
        except isds.IsdsError as e:
            flash_redirect("/datovka", str(e))
        app.isds.put(key(req), b)
        db.set_settings({"isds_env": env, "isds_user": user})
        flash_redirect("/datovka", "Připojeno k datové schránce %s" % b.owner.get("name", ""))

    @app.route("/datovka/odpojit", ("POST",))
    def disconnect(req):
        app.isds.drop(key(req))
        flash_redirect("/datovka", "Odpojeno")

    def build(req, src):
        s = req.settings
        if epo.check_settings(s):
            flash_redirect("/datovka", "Doplňte údaje pro finanční úřad v Nastavení")
        co, y, p, forma = src("co"), src("rok"), src("obdobi"), src("forma")
        try:
            xml, name, info = epo.build(db, s, co, y, p, forma)
            xml = xml if isinstance(xml, bytes) else xml.encode("utf-8")
        except epo.Empty as e:
            flash_redirect("/datovka", str(e))
        except ValueError as e:
            raise HTTPError(400, str(e))
        ann = "%s – %s%s" % (epo.NAMES[co][1], period_label(p, y), " (opravné)" if forma == "O" else "")
        return co, y, p, forma if forma in ("B", "O") else "B", xml, name, info, ann

    @app.route("/datovka/podani")
    def preview(req):
        b = box(req)
        co, y, p, forma, xml, name, info, ann = build(req, lambda k: req.args.get(k, ""))
        s = req.settings
        expected = UFO.get(s["epo_ufo"], "")
        rid = req.args.get("adresat", "").strip().lower()
        if not rid and b.env == "test" and expected:
            # testovací prostředí má vlastní schránky úřadů („TEST Finanční úřad pro …“) s jinými ID
            try:
                rid = next((i for i, n, _ in b.search(expected) if plain(n) == expected.lower()), "")
            except isds.IsdsError:
                rid = ""
        rid = rid or isds.FU_BOX.get(s["epo_ufo"], "")
        rname = err = ""
        if not ID_RX.match(rid):
            err = "Zadejte ID datové schránky finančního úřadu (7 znaků)"
        else:
            try:
                rname, raddr = b.box_name(rid)
                rname += (" – " + raddr) if raddr else ""
            except isds.IsdsError as e:
                err = str(e)
        mismatch = rname and expected and not plain(rname).startswith(expected.lower())
        dup = db.one("SELECT dm_id, created FROM isds_messages WHERE env = ? AND direction = 'out' AND kind = ? AND period = ? "
                     "ORDER BY id DESC LIMIT 1", (b.env, co, "%s-%s-%s" % (y, p, forma)))
        warns = []
        if dup:
            warns.append("Stejné podání za toto období už bylo odesláno %s (zpráva %s). Znovu odesílejte jen opravné." % (
                time.strftime("%d. %m. %Y", time.localtime(dup["created"])), dup["dm_id"]))
        bad = epo.bad_dics(db, "%s-01-01" % y, "%s-12-31" % y)
        if bad and co == "kh1":
            warns.append("U některých dokladů je chybné DIČ – EPO by kontrolní hlášení odmítlo: %s" %
                         ", ".join("%s %s" % (k, n) for k, n, _ in bad[:5]))
        if mismatch:
            warns.append("Název schránky neodpovídá finančnímu úřadu z nastavení (%s)." % expected)
        summary = ""
        if co == "dp3":
            r = info["dan"] - info["odp"]
            summary = "<p>Daň na výstupu %s Kč, odpočet %s Kč → <b>%s %s Kč</b></p>" % (
                info["dan"], info["odp"], "vlastní daňová povinnost" if r >= 0 else "nadměrný odpočet", abs(r))
        elif co == "kh1":
            summary = "<p>Řádků: A.1 %(a1)s, A.2 %(a2)s, A.4 %(a4)s, B.1 %(b1)s, B.2 %(b2)s</p>" % info
        elif co == "shv":
            summary = "<p>Řádků souhrnného hlášení: %d</p>" % len(info["rows"])
        ok = not err
        found = ""
        phrase = req.args.get("hledat", "").strip() or (expected if err else "")
        if phrase:
            try:
                res = b.search(phrase)
            except isds.IsdsError as e:
                res, found = [], '<p class="flash error">Vyhledávání: %s</p>' % h(str(e))
            link = "/datovka/podani?co=%s&rok=%s&obdobi=%s&forma=%s&adresat=" % (h(co), h(y), h(p), h(forma))
            found += "<h3>Schránky úřadů pro „%s“</h3>" % h(phrase) + ("<ul>%s</ul>" % "".join(
                "<li><a href='%s%s'>%s</a> – %s <small>(%s)</small></li>" % (link, h(i), h(n), h(a), h(i)) for i, n, a in res)
                if res else '<p class="hint">Nic nenalezeno.</p>')
        found += """<form action="/datovka/podani" class="filters"><input type="hidden" name="co" value="%s">
<input type="hidden" name="rok" value="%s"><input type="hidden" name="obdobi" value="%s"><input type="hidden" name="forma" value="%s">
<label>Najít schránku úřadu podle názvu<input name="hledat" value="%s" placeholder="Finanční úřad pro …"></label>
<button class="btn">Hledat</button></form>""" % (h(co), h(y), h(p), h(forma), h(phrase))
        body = head(b) + """<section class="card"><h2>Náhled podání</h2>
<table class="kv"><tr><th>Věc zprávy</th><td>%s</td></tr><tr><th>Adresát</th><td>%s%s</td></tr>
<tr><th>Soubor</th><td><a href="/dph/epo?co=%s&rok=%s&obdobi=%s&forma=%s">%s</a> (%d kB)</td></tr></table>%s%s
<form action="/datovka/podani" class="filters"><input type="hidden" name="co" value="%s"><input type="hidden" name="rok" value="%s">
<input type="hidden" name="obdobi" value="%s"><input type="hidden" name="forma" value="%s">
<label>Jiné ID schránky adresáta<input name="adresat" value="%s" size="9" maxlength="7"></label><button class="btn">Ověřit</button></form>
%s%s</section>""" % (
            h(ann), h(rid), (" – <b>%s</b>" % h(rname)) if rname else (' – <span class="flash error">%s</span>' % h(err)),
            h(co), h(y), h(p), h(forma), h(name), max(1, len(xml) // 1024), summary,
            "".join('<p class="flash error">%s</p>' % h(w) for w in warns), h(co), h(y), h(p), h(forma), h(rid),
            """<form method="post" action="/datovka/odeslat">%s<input type="hidden" name="co" value="%s">
<input type="hidden" name="rok" value="%s"><input type="hidden" name="obdobi" value="%s"><input type="hidden" name="forma" value="%s">
<input type="hidden" name="adresat" value="%s">
<label class="check"><input type="checkbox" name="potvrzuji" value="1" required> Zkontroloval(a) jsem podání a adresáta;
rozumím, že odesláním je podání učiněno%s.</label>
<div class="actions"><button class="btn primary">Odeslat datovou schránkou</button> <a class="btn" href="/datovka">Zpět</a></div></form>""" % (
                app.csrf(), h(co), h(y), h(p), h(forma), h(rid), " (testovací prostředí – nanečisto)" if b.env == "test" else "")
            if ok else '<p><a class="btn" href="/datovka">Zpět</a></p>', found)
        return app.page("Odeslat podání", "<h1>Odeslat podání</h1>" + flash(req) + body, "/datovka")

    @app.route("/datovka/odeslat", ("POST",))
    def send(req):
        b = box(req)
        if req.f("potvrzuji") != "1":
            flash_redirect("/datovka", "Odeslání je potřeba potvrdit")
        co, y, p, forma, xml, name, info, ann = build(req, req.f)
        rid = req.f("adresat").strip().lower()
        if not ID_RX.match(rid):
            flash_redirect("/datovka", "Neplatné ID schránky adresáta")
        try:
            rname = b.box_name(rid)[0]
        except isds.IsdsError as e:
            flash_redirect("/datovka", str(e))
        try:
            mid = b.send(rid, ann, [(name, "application/xml", xml)])
        except isds.IsdsError as e:
            flash_redirect("/datovka", "Neodesláno: %s" % e)
        with db.tx():
            msg = db.run("INSERT INTO isds_messages(env, dm_id, direction, box_id, counterpart, annotation, status, kind, period, "
                         "created, sent_by) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                         (b.env, mid, "out", rid, rname, ann, "1", co, "%s-%s-%s" % (y, p, forma), int(time.time()), req.user or ""))
            db.run("INSERT INTO isds_files(message_id, name, mime, data) VALUES(?,?,?,?)", (msg, name, "application/xml", xml))
        try:   # podepsaná odeslaná zpráva (ZFO) do archivu – nemusí být hned k dispozici
            db.run("UPDATE isds_messages SET zfo = ? WHERE id = ?", (b.zfo(mid, True), msg))
        except isds.IsdsError:
            pass
        flash_redirect("/datovka/zprava/%d" % msg, "Odesláno – číslo zprávy %s" % mid)

    @app.route("/datovka/stav", ("POST",))
    def refresh(req):
        b = box(req)
        try:
            rows = b.sent()
        except isds.IsdsError as e:
            flash_redirect("/datovka", str(e))
        n = 0
        with db.tx():
            for r in rows:
                db.run("UPDATE isds_messages SET status = ?, delivery_time = ?, acceptance_time = ? WHERE env = ? AND dm_id = ?",
                       (r["dmMessageStatus"], r["dmDeliveryTime"], r["dmAcceptanceTime"], b.env, r["dmID"]))
                n += db.one("SELECT changes()")[0]
        flash_redirect("/datovka", "Stav aktualizován (%d zpráv)" % n)

    @app.route("/datovka/prijate", ("POST",))
    def received(req):
        b = box(req)
        try:
            rows = b.received()
        except isds.IsdsError as e:
            flash_redirect("/datovka", str(e))
        new = 0
        with db.tx():
            for r in rows:
                cur = db.one("SELECT id FROM isds_messages WHERE env = ? AND dm_id = ?", (b.env, r["dmID"]))
                if cur:
                    db.run("UPDATE isds_messages SET status = ?, acceptance_time = ? WHERE id = ?",
                           (r["dmMessageStatus"], r["dmAcceptanceTime"], cur["id"]))
                else:
                    new += 1
                    db.run("INSERT INTO isds_messages(env, dm_id, direction, box_id, counterpart, annotation, status, "
                           "delivery_time, acceptance_time, created) VALUES(?,?,?,?,?,?,?,?,?,?)",
                           (b.env, r["dmID"], "in", r["dbIDSender"], r["dmSender"], r["dmAnnotation"], r["dmMessageStatus"],
                            r["dmDeliveryTime"], r["dmAcceptanceTime"], int(time.time())))
        flash_redirect("/datovka", "Načteno %d zpráv, z toho %d nových" % (len(rows), new))

    def message(mid):
        try:
            m = db.one("SELECT * FROM isds_messages WHERE id = ?", (int(mid),)) if len(mid) <= 15 else None
        except ValueError:
            m = None
        if not m:
            raise HTTPError(404, "Zpráva nenalezena")
        return m

    @app.route("/datovka/zprava/<mid>")
    def detail(req, mid):
        m = message(mid)
        b = box(req, False)
        files = db.q("SELECT id, name, LENGTH(data) size FROM isds_files WHERE message_id = ? ORDER BY id", (m["id"],))
        fl = "".join("<li><a href='/datovka/soubor/%d'>%s</a> (%d kB)</li>" % (f["id"], h(f["name"]), max(1, f["size"] // 1024))
                     for f in files)
        acts = ""
        if b and b.env == m["env"]:
            if m["direction"] == "in" and not files:
                acts += '<form method="post" action="/datovka/zprava/%d/stahnout">%s<button class="btn primary">Stáhnout přílohy</button></form>' % (
                    m["id"], app.csrf())
            if m["direction"] == "out":
                acts += '<form method="post" action="/datovka/zprava/%d/dorucenka">%s<button class="btn">Stáhnout doručenku</button></form>' % (
                    m["id"], app.csrf())
        elif m["env"] and not b:
            acts = '<p class="hint">Pro stažení příloh nebo doručenky se <a href="/datovka">připojte k datové schránce</a>.</p>'
        ev = m["events"] or ""
        body = """<section class="card"><table class="kv"><tr><th>%s</th><td>%s (%s)</td></tr><tr><th>Věc</th><td>%s</td></tr>
<tr><th>Číslo zprávy</th><td>%s</td></tr><tr><th>Stav</th><td>%s</td></tr><tr><th>Dodáno</th><td>%s</td></tr>
<tr><th>Doručeno</th><td>%s</td></tr><tr><th>Prostředí</th><td>%s</td></tr></table>
%s%s%s%s<p><a class="btn" href="/datovka">Zpět</a></p></section>""" % (
            "Adresát" if m["direction"] == "out" else "Odesílatel", h(m["counterpart"]), h(m["box_id"]), h(m["annotation"]),
            h(m["dm_id"]), h(isds.STATUS.get(m["status"] or "", m["status"] or "")), h(cz_time(m["delivery_time"])),
            h(cz_time(m["acceptance_time"])), h(isds.ENV_NAMES.get(m["env"], m["env"])),
            ("<h3>Soubory</h3><ul>%s</ul>" % fl) if fl else "",
            "<p><a href='/datovka/zprava/%d/zfo'>Podepsaná zpráva (ZFO)</a></p>" % m["id"] if m["zfo"] else "",
            ("<p><a href='/datovka/zprava/%d/dorucenka.zfo'>Doručenka (ZFO)</a></p><pre>%s</pre>" % (m["id"], h(ev)))
            if m["delivery_zfo"] else "", acts)
        return app.page("Datová zpráva", "<h1>Datová zpráva</h1>" + flash(req) + body, "/datovka")

    @app.route("/datovka/zprava/<mid>/stahnout", ("POST",))
    def download(req, mid):
        m = message(mid)
        b = box(req)
        if m["direction"] != "in" or m["env"] != b.env:
            raise HTTPError(400, "Zprávu nejde stáhnout")
        try:
            env, files = b.download(m["dm_id"])
            zfo = b.zfo(m["dm_id"], False)
        except isds.IsdsError as e:
            flash_redirect("/datovka/zprava/%d" % m["id"], str(e))
        with db.tx():
            if not db.one("SELECT 1 FROM isds_files WHERE message_id = ?", (m["id"],)):
                for name, mime, data in files[:50]:
                    db.run("INSERT INTO isds_files(message_id, name, mime, data) VALUES(?,?,?,?)", (m["id"], safe_name(name),
                                                                                                  mime[:100], data))
            db.run("UPDATE isds_messages SET zfo = ? WHERE id = ?", (zfo or None, m["id"]))
        flash_redirect("/datovka/zprava/%d" % m["id"], "Staženo %d příloh" % len(files))

    @app.route("/datovka/zprava/<mid>/dorucenka", ("POST",))
    def delivery(req, mid):
        m = message(mid)
        b = box(req)
        if m["direction"] != "out" or m["env"] != b.env:
            raise HTTPError(400, "Doručenka jen k odeslaným zprávám")
        try:
            status, events = b.delivery(m["dm_id"])
            dz = b.signed_delivery(m["dm_id"])
            zfo = m["zfo"] or b.zfo(m["dm_id"], True)
        except isds.IsdsError as e:
            flash_redirect("/datovka/zprava/%d" % m["id"], str(e))
        db.run("UPDATE isds_messages SET status = COALESCE(NULLIF(?, ''), status), events = ?, delivery_zfo = ?, zfo = ? WHERE id = ?",
               (status, "\n".join("%s  %s" % (cz_time(t), d) for t, d in events), dz or None, zfo or None, m["id"]))
        flash_redirect("/datovka/zprava/%d" % m["id"], "Doručenka stažena")

    def attachment(data, name, mime):
        return Response(data, ctype=mime or "application/octet-stream",
                        headers=[("Content-Disposition", 'attachment; filename="%s"' % safe_name(name).encode("ascii", "replace").decode()),
                                 ("X-Content-Type-Options", "nosniff")])

    @app.route("/datovka/zprava/<mid>/zfo")
    def zfo(req, mid):
        m = message(mid)
        if not m["zfo"]:
            raise HTTPError(404, "Podepsaná zpráva není stažená")
        return attachment(m["zfo"], "zprava-%s.zfo" % m["dm_id"], MIME["zfo"])

    @app.route("/datovka/zprava/<mid>/dorucenka.zfo")
    def delivery_zfo(req, mid):
        m = message(mid)
        if not m["delivery_zfo"]:
            raise HTTPError(404, "Doručenka není stažená")
        return attachment(m["delivery_zfo"], "dorucenka-%s.zfo" % m["dm_id"], MIME["zfo"])

    @app.route("/datovka/soubor/<fid>")
    def file(req, fid):
        f = db.one("SELECT * FROM isds_files WHERE id = ?", (int(fid),)) if len(fid) <= 15 else None
        if not f:
            raise HTTPError(404, "Soubor nenalezen")
        # přílohy z cizích zpráv vždy ke stažení (nikdy nezobrazovat v prohlížeči – mohou obsahovat HTML/skripty)
        return attachment(f["data"], f["name"], "application/octet-stream")
