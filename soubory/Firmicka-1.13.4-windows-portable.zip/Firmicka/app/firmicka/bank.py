"""Banka: import výpisu (GPC/ABO, XML camt.053, CSV) a párování plateb s fakturami podle VS a částky.
Příchozí platba → vydaná faktura uhrazena, odchozí → přijatá faktura uhrazena (zápis do deníku dělají
moduly faktur). Nespárované jde spárovat ručně, zapsat rovnou do deníku, nebo ignorovat."""
import csv
import hashlib
import io
import re
import xml.etree.ElementTree as ET
from datetime import date

from .db import invoice_totals, now, CATEGORIES_IN, CATEGORIES_OUT
from .web import h, money, cz_date, flash, flash_redirect, HTTPError, parse_id

STATUS = {"nesparovano": "Nespárováno", "sparovano": "Spárováno", "denik": "V deníku", "ignorovano": "Ignorováno"}


def _decode(raw):
    for enc in ("utf-8-sig", "cp1250"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("latin-1")


def _digits(s):
    return "".join(c for c in (s or "") if c.isdigit()).lstrip("0")


def _ref(*parts):
    return hashlib.sha1("|".join(str(p) for p in parts).encode()).hexdigest()[:20]


# ---------- GPC (ABO) – formát, který umí skoro každá česká banka ----------

def parse_gpc(raw):
    """Řádky 075 = transakce (pevné pozice), 078/079 = doplňující zpráva k předchozí transakci."""
    out, skipped = [], 0
    for line in _decode(raw).splitlines():
        if line.startswith("075"):
            if len(line) < 97:
                skipped += 1
                continue
            code = line[60]
            d = line[91:97]                        # valuta DDMMRR
            try:
                amount = int(line[48:60])
                day = date(2000 + int(d[4:6]), int(d[2:4]), int(d[0:2])).isoformat()
            except ValueError:
                skipped += 1
                continue
            if code in ("1", "5"):                 # 1 = debet (odchozí), 5 = storno kreditu
                amount = -amount
            ksf = line[71:81]
            bank = ksf[2:6]
            acc = line[19:35].lstrip("0")
            tx = {"date": day, "amount": amount, "vs": _digits(line[61:71]), "ks": _digits(ksf[6:10]),
                  "ss": _digits(line[81:91]), "counter_account": ("%s/%s" % (acc, bank)) if acc else "",
                  "counter_name": line[97:117].strip(), "message": "", "id": line[35:48].strip()}
            out.append(tx)
        elif line[:3] in ("078", "079") and out:
            out[-1]["message"] = (out[-1]["message"] + " " + line[3:].strip()).strip()
    for tx in out:
        tx["ref"] = _ref("gpc", tx.pop("id"), tx["date"], tx["amount"], tx["vs"], tx["counter_account"])
    return out, skipped


# ---------- camt.053 (XML ISO 20022) ----------

def _local(tag):
    return tag.rsplit("}", 1)[-1]


def _find(el, path):
    """Hledání bez ohledu na jmenný prostor: 'NtryDtls/TxDtls/Refs/EndToEndId'."""
    cur = [el]
    for part in path.split("/"):
        cur = [c for e in cur for c in e if _local(c.tag) == part]
        if not cur:
            return None
    return cur[0]


def _text(el, path):
    e = _find(el, path)
    return (e.text or "").strip() if e is not None and e.text else ""


def symbols_from_text(*texts):
    """České banky dávají VS/SS/KS do EndToEndId ('/VS123/SS/KS0308') nebo do zprávy."""
    vs = ks = ss = ""
    for t in texts:
        if not t:
            continue
        m = re.search(r"VS[:\s]*(\d{1,10})", t)
        if m and not vs:
            vs = m.group(1).lstrip("0")
        m = re.search(r"KS[:\s]*(\d{1,10})", t)
        if m and not ks:
            ks = m.group(1).lstrip("0")
        m = re.search(r"SS[:\s]*(\d{1,10})", t)
        if m and not ss:
            ss = m.group(1).lstrip("0")
    return vs, ks, ss


def parse_camt(raw):
    root = ET.fromstring(raw)
    out, skipped = [], 0
    for ntry in root.iter():
        if _local(ntry.tag) != "Ntry":
            continue
        amt = _find(ntry, "Amt")
        day = (_text(ntry, "BookgDt/Dt") or _text(ntry, "BookgDt/DtTm") or _text(ntry, "ValDt/Dt"))[:10]
        try:
            amount = int(round(float(amt.text) * 100))
            date.fromisoformat(day)
        except (AttributeError, TypeError, ValueError):
            skipped += 1
            continue
        credit = _text(ntry, "CdtDbtInd") == "CRDT"
        if not credit:
            amount = -amount
        tx = _find(ntry, "NtryDtls/TxDtls")
        e2e = _text(tx, "Refs/EndToEndId") if tx is not None else ""
        msg = _text(tx, "RmtInf/Ustrd") if tx is not None else ""
        cref = _text(tx, "RmtInf/Strd/CdtrRefInf/Ref") if tx is not None else ""
        vs, ks, ss = symbols_from_text(e2e, cref, msg)
        if not vs and cref.isdigit():
            vs = cref.lstrip("0")
        party, acct = ("Dbtr", "DbtrAcct") if credit else ("Cdtr", "CdtrAcct")
        name = _text(tx, "RltdPties/%s/Nm" % party) if tx is not None else ""
        acc = ""
        if tx is not None:
            acc = _text(tx, "RltdPties/%s/Id/IBAN" % acct) or _text(tx, "RltdPties/%s/Id/Othr/Id" % acct)
        ref = _text(ntry, "AcctSvcrRef") or _text(ntry, "NtryRef") or (_text(tx, "Refs/AcctSvcrRef") if tx is not None else "")
        out.append({"date": day, "amount": amount, "vs": vs, "ks": ks, "ss": ss, "counter_account": acc,
                    "counter_name": name, "message": msg,
                    "ref": _ref("camt", ref, day, amount, vs, acc, msg) if not ref else _ref("camt", ref)})
    return out, skipped


# ---------- CSV (export z internetbankingu) ----------

CSV_COLUMNS = {
    "date": ["datum zaúčtování", "datum provedení", "datum splatnosti", "datum", "date", "booking date"],
    "amount": ["částka", "objem", "amount", "castka"],
    "vs": ["variabilní symbol", "vs", "variable symbol"],
    "ks": ["konstantní symbol", "ks"],
    "ss": ["specifický symbol", "ss"],
    "counter_account": ["protiúčet", "číslo protiúčtu", "účet protistrany", "partner account", "protistrana účet"],
    "counter_bank": ["kód banky", "kód banky protiúčtu", "banka protiúčtu"],
    "counter_name": ["název protiúčtu", "název protistrany", "protistrana", "jméno protistrany", "partner name", "partner"],
    "message": ["zpráva pro příjemce", "zpráva", "popis", "poznámka", "message", "reference"],
    "id": ["id pohybu", "id transakce", "reference banky", "id"],
}


def _num(s):
    s = (s or "").replace(" ", "").replace(" ", "").replace("CZK", "").replace("Kč", "")
    if "," in s and "." in s:
        s = s.replace(".", "") if s.rfind(",") > s.rfind(".") else s.replace(",", "")
    return float(s.replace(",", "."))


def _date(s):
    s = s.strip()[:10]
    m = re.match(r"(\d{1,2})\.\s*(\d{1,2})\.\s*(\d{4})", s)
    if m:
        return date(int(m.group(3)), int(m.group(2)), int(m.group(1))).isoformat()
    m = re.match(r"(\d{4})-(\d{2})-(\d{2})", s)
    if m:
        return s
    raise ValueError("neznámý formát data: %s" % s)


def parse_csv(raw):
    text = _decode(raw)
    lines = text.splitlines()
    # banky dávají nad tabulku hlavičku výpisu – najít řádek s názvy sloupců
    start = 0
    for i, ln in enumerate(lines[:40]):
        low = ln.lower()
        if ("částka" in low or "amount" in low or "objem" in low) and ("datum" in low or "date" in low):
            start = i
            break
    body = "\n".join(lines[start:])
    try:
        dialect = csv.Sniffer().sniff(body[:4000], delimiters=";,\t")
    except csv.Error:
        dialect = csv.excel
        dialect.delimiter = ";"
    rows = list(csv.reader(io.StringIO(body.replace("\0", "")), dialect))
    if not rows:
        return [], 0
    head = [c.strip().strip('"').lower() for c in rows[0]]
    col = {}
    for key, names in CSV_COLUMNS.items():
        for n in names:
            if n in head:
                col[key] = head.index(n)
                break
    if "date" not in col or "amount" not in col:
        raise BankFileError("V souboru jsem nenašel sloupce Datum a Částka – je to výpis z banky ve formátu CSV, GPC "
                            "(ABO) nebo XML camt.053?%s" % (" Nalezené sloupce: %s" % ", ".join(rows[0][:8])[:200]
                                                             if len(rows[0]) > 1 else ""))
    out, skipped = [], 0
    for r in rows[1:]:
        if not any(c.strip() for c in r):
            continue
        if len(r) <= max(col.values()) or not r[col["amount"]].strip():
            skipped += 1
            continue
        g = lambda k: r[col[k]].strip() if k in col else ""
        try:
            amount = int(round(_num(g("amount")) * 100))
            day = _date(g("date"))
            date.fromisoformat(day)
        except ValueError:
            skipped += 1
            continue
        acc = g("counter_account")
        if g("counter_bank") and "/" not in acc and acc:
            acc += "/" + g("counter_bank")
        vs = _digits(g("vs")) or symbols_from_text(g("message"))[0]
        out.append({"date": day, "amount": amount, "vs": vs, "ks": _digits(g("ks")), "ss": _digits(g("ss")),
                    "counter_account": acc, "counter_name": g("counter_name"), "message": g("message"),
                    "ref": _ref("csv", g("id"), day, amount, vs, acc, g("message"), g("counter_name"))})
    return out, skipped


class BankFileError(ValueError):
    """Výpis nejde načíst – text je pro uživatele (česky, bez technických podrobností)."""


def parse(filename, raw):
    """(formát, pohyby, počet přeskočených nečitelných řádků)."""
    head = raw[:600].lstrip(b"\xef\xbb\xbf").lstrip()
    if not head:
        raise BankFileError("Soubor je prázdný")
    try:
        if head.startswith(b"<"):
            return ("camt.053",) + parse_camt(raw)
        if head.startswith(b"074"):
            return ("GPC",) + parse_gpc(raw)
        if b"\0" in raw[:4000] or sum(c < 9 for c in raw[:4000]) > 20:
            raise BankFileError("Soubor není textový výpis z banky (CSV, GPC/ABO nebo XML camt.053) – "
                                "nenahráváte omylem PDF nebo Excel?")
        return ("CSV",) + parse_csv(raw)
    except BankFileError:
        raise
    except ET.ParseError:
        raise BankFileError("Soubor XML je poškozený nebo neúplný (výpis camt.053 se nedá přečíst)")
    except (ValueError, csv.Error, UnicodeError):
        raise BankFileError("Výpis má neočekávaný obsah a nedá se přečíst – zkuste ho z banky stáhnout znovu, "
                            "případně v jiném formátu (CSV, GPC/ABO, camt.053)")


# ---------- párování ----------

def receipt_vs(number):
    from .pos import receipt_vs as rv
    return rv(number).lstrip("0")


def unpaid_qr(db):
    """Účtenky placené QR kódem, které ještě nejsou spárované s výpisem (s doplněnou částkou)."""
    from .pos import rlines
    out = []
    for r in db.q("SELECT * FROM receipts WHERE payment = 'qr' AND status = 'ok' AND paid_date = '' ORDER BY id"):
        d = dict(r)
        d["total"] = invoice_totals(rlines(db, r["id"]), r["vat_payer"])["total"]
        out.append(d)
    return out


def match(db, tx):
    """Najde doklad k platbě: shodný VS a přesná částka. Vrací ('invoice'|'purchase'|'receipt', id) nebo None."""
    from .invoices import lines_of
    from .purchases import plines, ptotals
    if not tx["vs"]:
        return None
    if tx["amount"] > 0:
        for inv in db.q("SELECT * FROM invoices WHERE status = 'vystavena' AND kind IN ('faktura', 'zaloha')"):
            if _digits(inv["vs"]) == tx["vs"] and invoice_totals(lines_of(db, inv["id"]), inv["vat_payer"])["total"] == tx["amount"]:
                return "invoice", inv["id"]
        for r in unpaid_qr(db):
            if receipt_vs(r["number"]) == tx["vs"].lstrip("0") and r["total"] == tx["amount"]:
                return "receipt", r["id"]
    else:
        for inv in db.q("SELECT * FROM invoices WHERE status = 'vystavena' AND kind IN ('dobropis', 'faktura')"):   # vrácení peněz
            if _digits(inv["vs"]) == tx["vs"] and invoice_totals(lines_of(db, inv["id"]), inv["vat_payer"])["total"] == tx["amount"]:
                return "invoice", inv["id"]
        for p in db.q("SELECT * FROM purchases WHERE status = 'neuhrazena'"):
            if _digits(p["vs"]) == tx["vs"] and ptotals(p, plines(db, p["id"]))["total"] == -tx["amount"]:
                return "purchase", p["id"]
    return None


def still_open(db, kind, doc_id, tx_id):
    """Doklad je pořád neuhrazený a platba nespárovaná (kontrola až v transakci – souběh víc uživatelů)."""
    if not db.one("SELECT 1 FROM bank_tx WHERE id = ? AND status = 'nesparovano'", (tx_id,)):
        return False
    sql = {"invoice": "SELECT 1 FROM invoices WHERE id = ? AND status = 'vystavena'",
           "purchase": "SELECT 1 FROM purchases WHERE id = ? AND status = 'neuhrazena'",
           "receipt": "SELECT 1 FROM receipts WHERE id = ? AND payment = 'qr' AND status = 'ok' AND paid_date = ''"}.get(kind)
    return bool(sql and db.one(sql, (doc_id,)))


def pay(db, settings, kind, doc_id, tx_id, day):
    """Označí fakturu za uhrazenou platbou z výpisu (uvnitř transakce). False = doklad mezitím uhrazený / platba
    zpracovaná – nic se nezmění."""
    from .invoices import sync_side_effects, after_status
    from .purchases import sync_purchase
    if not still_open(db, kind, doc_id, tx_id):
        return False
    if kind == "receipt":
        db.run("UPDATE receipts SET paid_date=? WHERE id=? AND paid_date=''", (day, doc_id))
        db.run("UPDATE bank_tx SET status='sparovano', receipt_id=? WHERE id=?", (doc_id, tx_id))
        return True     # tržba je v deníku (účet banka) už od prodeje
    if kind == "invoice":
        db.run("UPDATE invoices SET status='zaplacena', paid_date=? WHERE id=? AND status='vystavena'", (day, doc_id))
        sync_side_effects(db, doc_id)
        after_status(db, settings, doc_id)
        db.run("UPDATE bank_tx SET status='sparovano', invoice_id=? WHERE id=?", (doc_id, tx_id))
    else:
        db.run("UPDATE purchases SET status='uhrazena', paid_date=? WHERE id=? AND status='neuhrazena'", (day, doc_id))
        sync_purchase(db, doc_id, settings["vat_payer"] == "1")
        db.run("UPDATE bank_tx SET status='sparovano', purchase_id=? WHERE id=?", (doc_id, tx_id))
    # zápis v deníku převezme datum a účet banky
    db.run("UPDATE cashbook SET account='banka' WHERE %s = ?" % ("invoice_id" if kind == "invoice" else "purchase_id"), (doc_id,))
    return True


def import_statement(db, settings, filename, raw):
    fmt, txs, skipped = parse(filename, raw)
    new = paired = dup = 0
    seen = {}
    for tx in txs:     # stejný pohyb vícekrát v jednom výpisu (CSV bez ID, dvě stejné platby za den) není duplicita
        seen[tx["ref"]] = seen.get(tx["ref"], 0) + 1
        if seen[tx["ref"]] > 1:
            tx["ref"] = "%s#%d" % (tx["ref"], seen[tx["ref"]])
    with db.tx():
        for tx in txs:
            if db.one("SELECT 1 FROM bank_tx WHERE ref = ?", (tx["ref"],)):
                dup += 1
                continue
            tid = db.run("INSERT INTO bank_tx(ref, date, amount, vs, ks, ss, counter_account, counter_name, message, source, "
                         "created) VALUES(?,?,?,?,?,?,?,?,?,?,?)", (tx["ref"], tx["date"], tx["amount"], tx["vs"], tx["ks"],
                                                                     tx["ss"], tx["counter_account"], tx["counter_name"],
                                                                     tx["message"], "%s %s" % (fmt, filename), now()))
            new += 1
            m = match(db, tx)
            if m:
                pay(db, settings, m[0], m[1], tid, tx["date"])
                paired += 1
    return fmt, len(txs), new, paired, dup, skipped


# ---------- hromadné párování: návrhy dokladů k nespárovaným platbám ----------

LEGAL = {"sro", "spol", "as", "vos", "ks", "zs", "se", "ops", "zu", "druzstvo", "ing", "mgr", "bc", "platba", "faktura",
         "uhrada", "prevod", "firma", "company"}


def _words(text):
    import unicodedata
    t = unicodedata.normalize("NFKD", text or "").encode("ascii", "ignore").decode().lower()
    t = re.sub(r"\bs\.?\s*r\.?\s*o\.?|\ba\.?\s*s\.?(?=\s|$)|\bspol\.", " ", t)
    return {w for w in re.findall(r"[a-z0-9]+", t) if len(w) >= 3 and w not in LEGAL}


def _account(a):
    """'000019-2000145399/0800' i '19-2000145399/0800' → '19-2000145399/0800' (pro porovnání účtů)."""
    a = (a or "").replace(" ", "")
    if "/" not in a:
        return a.lstrip("0")
    num, bank = a.split("/", 1)
    pre, _, num = num.rpartition("-")
    if not pre and len(num) > 10:          # GPC: předčíslí a číslo dohromady (000019 2000145399)
        pre, num = num[:-10], num[-10:]
    pre, num = pre.lstrip("0"), num.lstrip("0")
    return ("%s-%s" % (pre, num) if pre else num) + "/" + bank


def open_docs(db):
    """Neuhrazené doklady, které jde zaplatit z banky: expect = očekávaná částka pohybu (příjem +, výdaj −)."""
    from .invoices import lines_of
    from .purchases import plines, ptotals
    out = []
    for inv in db.q("SELECT * FROM invoices WHERE status = 'vystavena' AND kind IN ('faktura', 'zaloha', 'dobropis')"):
        t = invoice_totals(lines_of(db, inv["id"]), inv["vat_payer"])["total"]
        if inv["kind"] == "dobropis" or t < 0:
            if t >= 0:
                continue
        out.append({"key": "invoice:%d" % inv["id"], "kind": "invoice", "id": inv["id"], "expect": t, "vs": _digits(inv["vs"]),
                    "name": inv["cust_name"], "account": "", "label": "%s %s – %s" % (
                        {"dobropis": "Dobropis", "zaloha": "Záloha"}.get(inv["kind"], "Faktura"), inv["number"], inv["cust_name"])})
    for r in unpaid_qr(db):
        out.append({"key": "receipt:%d" % r["id"], "kind": "receipt", "id": r["id"], "expect": r["total"],
                    "vs": receipt_vs(r["number"]), "name": "", "account": "",
                    "label": "Účtenka %s (QR %s)" % (r["number"], cz_date(r["date"]))})
    for p in db.q("SELECT * FROM purchases WHERE status = 'neuhrazena'"):
        t = ptotals(p, plines(db, p["id"]))["total"]
        out.append({"key": "purchase:%d" % p["id"], "kind": "purchase", "id": p["id"], "expect": -t, "vs": _digits(p["vs"]),
                    "name": p["supp_name"], "account": _account(p["supp_account"]),
                    "label": "Přijatá %s (%s) – %s" % (p["doc_number"], p["number"], p["supp_name"])})
    return out


def suggest(tx, docs):
    """Kandidáti k platbě seřazení podle jistoty: [(skóre, doklad, důvod)]."""
    out = []
    vs = _digits(tx["vs"])
    text = " ".join(x for x in (tx["message"], tx["counter_name"]) if x)
    words = _words(tx["counter_name"])            # jen protistrana – ve zprávě bývají obecná slova (platba, faktura…)
    acc = _account(tx["counter_account"])
    for d in docs:
        if (d["expect"] > 0) != (tx["amount"] > 0):
            continue
        amount = d["expect"] == tx["amount"]
        vs_eq = bool(vs) and d["vs"] == vs
        vs_msg = len(d["vs"]) >= 4 and re.search(r"(?<!\d)0*%s(?!\d)" % d["vs"], text or "") is not None
        acc_eq = bool(d["account"]) and d["account"] == acc
        name_eq = bool(_words(d["name"]) & words)
        if amount and vs_eq:
            out.append((100, d, "VS i částka sedí"))
        elif amount and vs_msg:
            out.append((90, d, "VS ve zprávě, částka sedí"))
        elif amount and acc_eq:
            out.append((85, d, "účet dodavatele, částka sedí"))
        elif amount and name_eq:
            out.append((75, d, "protistrana a částka sedí"))
        elif vs_eq or vs_msg:
            out.append((50, d, "VS sedí, částka se liší o %s" % money(abs(tx["amount"] - d["expect"]))))
        elif amount:
            out.append((40, d, "sedí jen částka"))
        elif acc_eq or name_eq:
            out.append((20, d, "stejná protistrana, jiná částka"))
    out.sort(key=lambda x: (-x[0], abs(x[1]["expect"] - tx["amount"])))
    return out[:6]


def plan(db, txs):
    """Návrhy pro všechny platby + předvýběr: jistá shoda (skóre ≥ 75), jediná nejlepší, každý doklad jen jednou."""
    docs = open_docs(db)
    rows = [(tx, suggest(tx, docs)) for tx in txs]
    chosen, used = {}, set()
    order = sorted(rows, key=lambda r: -(r[1][0][0] if r[1] else 0))
    for tx, cands in order:
        if not cands or cands[0][0] < 75:
            continue
        if len(cands) > 1 and cands[1][0] == cands[0][0]:
            continue                                   # dva stejně dobré doklady → nechat na člověku
        if cands[0][1]["key"] in used:
            continue
        used.add(cands[0][1]["key"])
        chosen[tx["id"]] = cands[0][1]["key"]
    return rows, chosen


def register(app):
    db = app.db

    @app.route("/banka/parovani", ("GET", "POST"))
    def bulk(req):
        txs = db.q("SELECT * FROM bank_tx WHERE status = 'nesparovano' ORDER BY date, id LIMIT 500")
        if req.method == "POST":
            docs = {d["key"]: d for d in open_docs(db)}
            done = {"doc": 0, "denik": 0, "ignorovano": 0}
            skipped = []
            used = set()
            with db.tx():
                for tx in txs:
                    a = req.f("akce_%d" % tx["id"])
                    if not a:
                        continue
                    if a.startswith("doc:"):
                        key = a[4:]
                        d = docs.get(key)
                        if not d or key in used or (d["expect"] > 0) != (tx["amount"] > 0):
                            skipped.append("%s %s" % (cz_date(tx["date"]), money(tx["amount"])))
                            continue
                        used.add(key)
                        if not pay(db, req.settings, d["kind"], d["id"], tx["id"], tx["date"]):
                            skipped.append("%s %s" % (cz_date(tx["date"]), money(tx["amount"])))
                            continue
                        done["doc"] += 1
                    elif a in ("denik", "ignorovat") and not db.one(
                            "SELECT 1 FROM bank_tx WHERE id = ? AND status = 'nesparovano'", (tx["id"],)):
                        skipped.append("%s %s" % (cz_date(tx["date"]), money(tx["amount"])))
                    elif a == "denik":
                        cid = db.run("INSERT INTO cashbook(date, doc, text, direction, account, amount, taxable, category) "
                                     "VALUES(?,?,?,?, 'banka', ?, 1, '')", (
                                         tx["date"], "VS " + tx["vs"] if tx["vs"] else "",
                                         tx["counter_name"] or tx["message"] or "Platba",
                                         "prijem" if tx["amount"] > 0 else "vydaj", abs(tx["amount"])))
                        db.run("UPDATE bank_tx SET status='denik', cashbook_id=? WHERE id=?", (cid, tx["id"]))
                        done["denik"] += 1
                    elif a == "ignorovat":
                        db.run("UPDATE bank_tx SET status='ignorovano' WHERE id=?", (tx["id"],))
                        done["ignorovano"] += 1
            n = done["doc"]
            msg = "Spárováno %d %s" % (n, "platba" if n == 1 else "platby" if 2 <= n <= 4 else "plateb")
            if done["denik"]:
                msg += ", do deníku %d" % done["denik"]
            if done["ignorovano"]:
                msg += ", ignorováno %d" % done["ignorovano"]
            if skipped:
                msg += " · přeskočeno (doklad nebo platba mezitím zpracované, nebo doklad vybraný dvakrát): " + ", ".join(skipped[:5])
            flash_redirect("/banka" if not db.one("SELECT 1 FROM bank_tx WHERE status='nesparovano'") else "/banka/parovani", msg)
        rows, chosen = plan(db, txs)
        trs = []
        for tx, cands in rows:
            sel = chosen.get(tx["id"], "")
            opts = ['<option value="">— nechat nespárované —</option>']
            for score, d, why in cands:
                opts.append('<option value="doc:%s"%s>%s · %s · %s</option>' % (
                    d["key"], " selected" if d["key"] == sel else "", h(d["label"]), money(abs(d["expect"])), h(why)))
            opts.append('<option value="denik">Zapsat do peněžního deníku (daňový %s)</option>' % (
                "příjem" if tx["amount"] > 0 else "výdaj"))
            opts.append('<option value="ignorovat">Ignorovat (např. převod mezi vlastními účty)</option>')
            best = cands[0][0] if cands else 0
            tag = ("zaplacena", "jistá shoda") if sel else ("vystavena", "návrh") if best >= 40 else ("", "bez návrhu")
            hint = ""
            if not sel and best >= 40:
                hint = "<div class=hint>Návrh: %s · %s</div>" % (h(cands[0][1]["label"]), h(cands[0][2]))
            trs.append("<tr class=pay-head><td>%s</td><td class='num %s'>%s</td><td>%s<div class=hint>%s%s</div></td></tr>"
                       "<tr class=pay-doc><td colspan=3><span class='tag %s'>%s</span> <select name='akce_%d' "
                       "aria-label='Co s platbou'>%s</select>%s</td></tr>" % (
                           cz_date(tx["date"]), "in" if tx["amount"] > 0 else "out", money(tx["amount"]),
                           h(tx["counter_name"] or tx["counter_account"] or "—"), ("VS %s · " % h(tx["vs"])) if tx["vs"] else "",
                           h(tx["message"]), tag[0], tag[1], tx["id"], "".join(opts), hint))
        n_sure = len(chosen)
        return app.page("Hromadné párování", """%s<div class="bar"><a href="/banka">← Banka</a></div>
<h1>Hromadné párování plateb</h1>
<div class="stats"><div><span>Nespárované platby</span><b>%d</b></div><div><span>Jistá shoda</span><b>%d</b>
<small>předvybráno</small></div><div><span>Jen návrh</span><b>%d</b><small>vyberte ručně</small></div></div>
<p class="hint">U každé platby je nabídka dokladů seřazená podle shody (VS, částka, účet a jméno protistrany).
Předvybrané jsou jen jisté shody – ostatní zkontrolujte a vyberte. Spárovaná faktura se označí jako uhrazená k datu platby.</p>
<form method="post">%s<table class="list bulkpay"><thead><tr><th>Datum</th><th class=num>Částka</th>
<th>Protistrana / zpráva</th></tr></thead><tbody>%s</tbody></table>
<div class="actions"><button class="btn primary"%s>Provést vybrané</button><a class="btn" href="/banka">Zpět</a></div></form>""" % (
            flash(req), len(txs), n_sure, sum(1 for tx, c in rows if c and c[0][0] >= 40 and tx["id"] not in chosen),
            app.csrf(), "".join(trs) or "<tr><td colspan=3 class=empty>Všechny platby jsou spárované.</td></tr>",
            "" if txs else " disabled"), "/banka")

    @app.route("/banka", ("GET", "POST"))
    def index(req):
        if req.method == "POST":
            f = req.files.get("vypis")
            if not f:
                flash_redirect("/banka", "Vyberte soubor s výpisem")
            try:
                fmt, total, new, paired, dup, skipped = import_statement(db, req.settings, f[0], f[1])
            except BankFileError as e:
                flash_redirect("/banka", "Výpis se nepodařilo načíst: %s" % e)
            except Exception as e:
                print("import výpisu:", repr(e))
                flash_redirect("/banka", "Výpis se nepodařilo načíst – soubor má neočekávaný obsah")
            flash_redirect("/banka", "%s: %d %s, nových %d, automaticky spárováno %d%s%s" % (
                fmt, total, "pohyb" if total == 1 else "pohyby" if 1 < total < 5 else "pohybů", new, paired,
                ", už načtených %d" % dup if dup else "",
                " · POZOR: %d %s (chybné datum nebo částka) – zkontrolujte výpis" % (
                    skipped, "řádek se nedal přečíst a byl přeskočen" if skipped == 1 else
                    "řádky se nedaly přečíst a byly přeskočeny" if skipped < 5 else
                    "řádků se nedalo přečíst a bylo přeskočeno") if skipped else ""))
        st = req.args.get("stav", "nesparovano")
        sql, args = "SELECT * FROM bank_tx", ()
        if st in STATUS:
            sql, args = sql + " WHERE status = ?", (st,)
        rows = db.q(sql + " ORDER BY date DESC, id DESC LIMIT 500", args)
        counts = {r["status"]: r["n"] for r in db.q("SELECT status, COUNT(*) AS n FROM bank_tx GROUP BY status")}
        tabs = "".join('<a class="btn%s" href="/banka?stav=%s">%s (%d)</a>' % (
            " primary" if k == st else "", k, v, counts.get(k, 0)) for k, v in STATUS.items())
        trs = []
        for r in rows:
            link = ""
            if r["invoice_id"]:
                n = db.one("SELECT number FROM invoices WHERE id=?", (r["invoice_id"],))
                link = "<a href='/faktury/%d'>%s</a>" % (r["invoice_id"], h(n["number"] if n else "?"))
            elif r["receipt_id"]:
                n = db.one("SELECT number FROM receipts WHERE id=?", (r["receipt_id"],))
                link = "<a href='/pokladna/%d'>%s</a>" % (r["receipt_id"], h(n["number"] if n else "?"))
            elif r["purchase_id"]:
                n = db.one("SELECT doc_number FROM purchases WHERE id=?", (r["purchase_id"],))
                link = "<a href='/prijate/%d'>%s</a>" % (r["purchase_id"], h(n["doc_number"] if n else "?"))
            elif r["status"] == "nesparovano":
                link = "<a class='btn' href='/banka/%d'>Spárovat…</a>" % r["id"]
            trs.append("<tr><td>%s</td><td class='num %s'>%s</td><td>%s</td><td>%s<div class=hint>%s</div></td>"
                       "<td>%s</td></tr>" % (
                           cz_date(r["date"]), "in" if r["amount"] > 0 else "out", money(r["amount"]), h(r["vs"]),
                           h(r["counter_name"] or r["counter_account"]), h(r["message"]), link))
        nopen = counts.get("nesparovano", 0)
        bulk_btn = '<a class="btn primary" href="/banka/parovani">Hromadné párování (%d)</a>' % nopen if nopen else ""
        return app.page("Banka", """%s<div class="bar"><h1>Banka – párování plateb</h1>%s</div>
<section class="card"><h2>Načíst výpis</h2>
<form method="post" enctype="multipart/form-data" class="filters">%s
<input type="file" name="vypis" accept=".gpc,.abo,.xml,.csv,.txt" required><button class="btn primary">Načíst a spárovat</button></form>
<p class="hint">Výpis stáhněte z internetbankingu (Česká spořitelna – George: Pohyby → Export) ve formátu
<b>GPC/ABO</b>, <b>XML (camt.053)</b> nebo <b>CSV</b>. Platby se samy spárují s fakturami podle variabilního
symbolu a částky; opakované načtení stejného výpisu nevadí.</p></section>
<div class="filters">%s</div>
<table class="list"><thead><tr><th>Datum</th><th class=num>Částka</th><th>VS</th><th>Protistrana / zpráva</th><th></th></tr>
</thead><tbody>%s</tbody></table>%s""" % (
            flash(req), bulk_btn, app.csrf(), tabs, "".join(trs), "" if rows else "<p class=empty>Nic tu není.</p>"), "/banka")

    @app.route("/banka/<tid>", ("GET", "POST"))
    def detail(req, tid):
        from .invoices import lines_of
        from .purchases import plines, ptotals
        tx = db.one("SELECT * FROM bank_tx WHERE id = ?", (tid,))
        if not tx:
            raise HTTPError(404)
        if req.method == "POST":
            a = req.f("akce")
            with db.tx():
                if tx["status"] != "nesparovano":
                    raise HTTPError(400, "Platba už je zpracovaná")
                if a == "faktura":
                    doc = req.f("doc")
                    kind, _, did = doc.partition(":")
                    if kind not in ("invoice", "purchase", "receipt") or parse_id(did) is None:
                        raise HTTPError(400, "Vyberte fakturu")
                    if not pay(db, req.settings, kind, int(did), tx["id"], tx["date"]):
                        raise HTTPError(409, "Doklad je mezitím uhrazený (třeba jinou platbou) – vyberte jiný")
                    msg = "Spárováno"
                elif a == "denik":
                    cid = db.run("INSERT INTO cashbook(date, doc, text, direction, account, amount, taxable, category) "
                                 "VALUES(?,?,?,?, 'banka', ?, ?, ?)", (
                                     tx["date"], "VS " + tx["vs"] if tx["vs"] else "",
                                     req.f("text") or tx["counter_name"] or tx["message"] or "Platba",
                                     "prijem" if tx["amount"] > 0 else "vydaj", abs(tx["amount"]),
                                     1 if req.f("taxable") else 0, req.f("category")))
                    db.run("UPDATE bank_tx SET status='denik', cashbook_id=? WHERE id=?", (cid, tx["id"]))
                    msg = "Zapsáno do peněžního deníku"
                elif a == "ignorovat":
                    db.run("UPDATE bank_tx SET status='ignorovano' WHERE id=?", (tx["id"],))
                    msg = "Ignorováno"
                else:
                    raise HTTPError(400, "Neznámá akce")
            flash_redirect("/banka", msg)
        # kandidáti: neuhrazené faktury ve správném směru, nejbližší částkou nahoře
        cands = []
        if tx["amount"] > 0:
            for inv in db.q("SELECT * FROM invoices WHERE status = 'vystavena' AND kind IN ('faktura', 'zaloha')"):
                t = invoice_totals(lines_of(db, inv["id"]), inv["vat_payer"])["total"]
                cands.append((abs(t - tx["amount"]), "invoice:%d" % inv["id"], "%s – %s – %s" % (inv["number"], inv["cust_name"], money(t))))
            for r in unpaid_qr(db):
                cands.append((abs(r["total"] - tx["amount"]), "receipt:%d" % r["id"],
                              "Účtenka %s (QR platba %s) – %s" % (r["number"], cz_date(r["date"]), money(r["total"]))))
        else:
            for inv in db.q("SELECT * FROM invoices WHERE status = 'vystavena' AND kind = 'dobropis'"):
                t = invoice_totals(lines_of(db, inv["id"]), inv["vat_payer"])["total"]
                cands.append((abs(t - tx["amount"]), "invoice:%d" % inv["id"], "Dobropis %s – %s – %s" % (
                    inv["number"], inv["cust_name"], money(t))))
            for p in db.q("SELECT * FROM purchases WHERE status = 'neuhrazena'"):
                t = ptotals(p, plines(db, p["id"]))["total"]
                cands.append((abs(t + tx["amount"]), "purchase:%d" % p["id"], "%s – %s – %s" % (p["doc_number"], p["supp_name"], money(t))))
        cands.sort()
        opts = "".join('<option value="%s">%s%s</option>' % (v, h(t), " ✓ částka sedí" if d == 0 else "") for d, v, t in cands)
        cats = CATEGORIES_IN if tx["amount"] > 0 else CATEGORIES_OUT
        return app.page("Platba", """<div class="bar"><a href="/banka">← Banka</a></div>
<section class="card"><h1 class="%s">%s</h1><p>%s · VS %s · %s %s</p><p class="hint">%s</p></section>
<div class="cols">
<section class="card"><h2>Spárovat s fakturou</h2><form method="post">%s<input type="hidden" name="akce" value="faktura">
<label>Faktura<select name="doc">%s</select></label>
<p class="hint">Faktura se označí jako uhrazená k datu platby.</p><button class="btn primary"%s>Spárovat</button></form></section>
<section class="card"><h2>Zapsat do deníku</h2><form method="post">%s<input type="hidden" name="akce" value="denik">
<label>Text<input name="text" value="%s"></label><label>Kategorie<input name="category" list="cats"></label>
<label class="check"><input type="checkbox" name="taxable" value="1" checked> Daňový</label>
<button class="btn">Zapsat</button></form><datalist id="cats">%s</datalist></section>
<section class="card"><h2>Ignorovat</h2><form method="post">%s<input type="hidden" name="akce" value="ignorovat">
<p class="hint">Např. převod mezi vlastními účty.</p><button class="btn">Ignorovat</button></form></section></div>""" % (
            "in" if tx["amount"] > 0 else "out", money(tx["amount"]), cz_date(tx["date"]), h(tx["vs"] or "—"),
            h(tx["counter_name"]), h(tx["counter_account"]), h(tx["message"]), app.csrf(),
            opts or "<option value=''>Žádné neuhrazené doklady</option>", "" if cands else " disabled",
            app.csrf(), h(tx["counter_name"] or tx["message"]), "".join("<option>%s</option>" % h(c) for c in cats),
            app.csrf()), "/banka")
