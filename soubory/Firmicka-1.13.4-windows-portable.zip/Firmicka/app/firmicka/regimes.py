"""Režimy DPH mimo běžné tuzemské plnění: přenesení daňové povinnosti v tuzemsku (§ 92a–92i), plnění do a z jiných
členských států EU a mimo EU. Doklady v těchto režimech jsou bez DPH; daň (pokud vůbec) přiznává odběratel.

Vydaná faktura (dodavatel)                                      přiznání (DPHDP3)   kontrolní hlášení   souhrnné hlášení
  pdp        přenesená daňová povinnost v tuzemsku (§ 92a)       ř. 25               A.1 (s kódem)       –
  eu_zbozi   dodání zboží do jiného členského státu (§ 64)       ř. 20               –                   kód 0
  eu_sluzby  služba s místem plnění v jiném čl. státě (§ 9/1)    ř. 21               –                   kód 3
  vyvoz      vývoz zboží mimo EU (§ 66)                          ř. 22               –                   –
  mimo       jiné plnění s místem plnění mimo tuzemsko           ř. 26               –                   –

Přijatá faktura (odběratel si daň sám přizná i odečte – „samovyměření“; dodavateli se platí jen základ)
  pdp        přenesená daňová povinnost v tuzemsku               ř. 10/11 + odpočet ř. 43/44     B.1 (s kódem)
  eu_zbozi   pořízení zboží z jiného členského státu             ř. 3/4   + odpočet ř. 43/44     A.2
  eu_sluzby  přijetí služby z jiného členského státu (§ 9/1)     ř. 5/6   + odpočet ř. 43/44     A.2
  mimo       ostatní plnění, kde daň přiznává příjemce           ř. 12/13 + odpočet ř. 43/44     A.2
             (např. služba od osoby ze země mimo EU)
"""
import re

ISSUED = {
    "pdp": ("Přenesená daňová povinnost (tuzemsko, § 92a)",
            "Daň odvede zákazník – režim přenesení daňové povinnosti podle § 92a zákona o DPH."),
    "eu_zbozi": ("Dodání zboží do jiného státu EU (§ 64)",
                 "Dodání zboží do jiného členského státu – osvobozeno od daně podle § 64 zákona o DPH."),
    "eu_sluzby": ("Služba do jiného státu EU (§ 9 odst. 1)",
                  "Daň odvede zákazník (reverse charge) – místo plnění v jiném členském státě podle § 9 odst. 1 zákona o DPH."),
    "vyvoz": ("Vývoz zboží mimo EU (§ 66)", "Vývoz zboží – osvobozeno od daně podle § 66 zákona o DPH."),
    "mimo": ("Jiné plnění s místem plnění mimo tuzemsko",
             "Místo plnění mimo tuzemsko – plnění nepodléhá české DPH."),
}
RECEIVED = {
    "pdp": "Přenesená daňová povinnost (tuzemsko) – daň přiznávám já",
    "eu_zbozi": "Pořízení zboží z jiného státu EU",
    "eu_sluzby": "Přijetí služby z jiného státu EU",
    "mimo": "Služba ze země mimo EU (daň přiznávám já)",
}
# kód předmětu plnění pro kontrolní hlášení (A.1 / B.1) podle pokynů finanční správy k vyplnění KH (ověřeno 17. 11. 2026)
PDP_CODES = [
    ("4", "4 – stavební nebo montážní práce (§ 92e)"),
    ("5", "5 – odpady a šrot (příloha č. 5, § 92c)"),
    ("1", "1 – zlato (§ 92b)"),
    ("3", "3 – nemovitá věc (§ 92d)"),
    ("11", "11 – povolenky na emise"),
    ("12", "12 – obiloviny a technické plodiny"),
    ("13", "13 – kovy včetně drahých kovů"),
    ("14", "14 – mobilní telefony"),
    ("15", "15 – integrované obvody"),
    ("16", "16 – přenosná zařízení pro automatizované zpracování dat"),
    ("17", "17 – videoherní konzole"),
]
# kódy ISDOC (LocalReverseChargeCode) – starší číselník: 1 zlato, 2 povolenky, 4 stavební práce, 5 odpady
ISDOC_CODES = {"1": "1", "11": "2", "4": "4", "5": "5"}
EU = {"AT", "BE", "BG", "CY", "DE", "DK", "EE", "EL", "ES", "FI", "FR", "HR", "HU", "IE", "IT", "LT", "LU", "LV", "MT", "NL",
      "PL", "PT", "RO", "SE", "SI", "SK", "XI"}


def note(regime):
    """Povinný text na dokladu (§ 29 odst. 2 zákona o DPH)."""
    return ISSUED.get(regime, ("", ""))[1]


def eu_vat(dic):
    """DIČ z jiného členského státu → (kód státu, číslo bez kódu), jinak None. Řecko má v DIČ „EL“, ne „GR“."""
    d = re.sub(r"[\s.\-]", "", dic or "").upper()
    if d[:2] == "GR":
        d = "EL" + d[2:]
    if len(d) > 4 and d[:2] in EU and re.match(r"^[A-Z0-9+*]{2,12}$", d[2:]):
        return d[:2], d[2:]
    return None


def check_issued(regime, code, dic, kind, has_advance):
    """Chyba formuláře vydané faktury v režimu (prázdné = v pořádku)."""
    if not regime:
        return ""
    if regime not in ISSUED:
        return "Neznámý režim DPH"
    if kind not in ("faktura", "dobropis"):
        return "Režim DPH jde nastavit jen u faktury a dobropisu"
    if has_advance:
        return "Odečet zálohy s DPH u faktury v režimu %s Firmička neumí – zálohu vyúčtujte zvlášť" % ISSUED[regime][0].lower()
    from .epo import cz_dic, dic_ok
    if regime == "pdp":
        if not cz_dic(dic):
            return "U přenesené daňové povinnosti musí mít odběratel české DIČ (CZ…) – je to plátce DPH"
        if not dic_ok(cz_dic(dic)):
            return "DIČ odběratele %s má chybný kontrolní součet – kontrolní hlášení by EPO odmítlo" % dic
        if not code:
            return "Vyberte kód předmětu plnění (pro kontrolní hlášení)"
    if regime in ("eu_zbozi", "eu_sluzby") and not eu_vat(dic):
        return "U plnění do EU vyplňte DIČ odběratele z jiného členského státu (např. DE123456789)"
    return ""


def check_received(regime, code, dic):
    if not regime:
        return ""
    if regime not in RECEIVED:
        return "Neznámý režim DPH"
    from .epo import cz_dic, dic_ok
    if regime == "pdp":
        if not cz_dic(dic):
            return "U přenesené daňové povinnosti musí mít dodavatel české DIČ (CZ…)"
        if not dic_ok(cz_dic(dic)):
            return "DIČ dodavatele %s má chybný kontrolní součet – kontrolní hlášení by EPO odmítlo" % dic
        if not code:
            return "Vyberte kód předmětu plnění (pro kontrolní hlášení)"
    return ""


def code_select(name, current, attrs=""):
    opts = ['<option value="">— kód předmětu plnění —</option>']
    known = {c for c, _ in PDP_CODES}
    for c, label in PDP_CODES:
        opts.append('<option value="%s"%s>%s</option>' % (c, " selected" if c == current else "", label))
    if current and current not in known:
        opts.append('<option value="%s" selected>%s</option>' % (current, current))
    return '<select name="%s"%s>%s</select>' % (name, attrs, "".join(opts))


def regime_select(name, options, current):
    return '<select name="%s">%s</select>' % (name, '<option value="">Běžné tuzemské plnění (s DPH)</option>' + "".join(
        '<option value="%s"%s>%s</option>' % (k, " selected" if k == current else "", v[0] if isinstance(v, tuple) else v)
        for k, v in options.items()))
