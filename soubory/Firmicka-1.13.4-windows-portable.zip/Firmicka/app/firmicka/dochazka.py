"""Docházka: příchody a odchody (evidence odpracované doby podle § 96 zákoníku práce), měsíční výkaz k podpisu,
přehled pro účetní (podklad pro mzdy), píchačka na společném počítači s PINem a hodiny odpracované na zakázkách.

Záznam = jeden úsek práce (den, od, do). Odchod přes půlnoc: konec je menší než začátek. Otevřený záznam (bez konce)
= člověk je právě v práci. Dovolenou a nemoc bere výkaz z Kalendáře (podle jména nebo přihlašovacího jména).
Přestávka: po 6 hodinách nepřetržité práce se odečte 30 minut (§ 88 ZP), když si ji člověk nezapsal sám (mezera
aspoň 30 minut) – dá se vypnout.
Opravy: kdo nemá „Docházka všech“, své záznamy nemění přímo – ruční záznam čeká na schválení (pending) a oprava
existujícího se uloží jako žádost (req_*); do výkazu se počítá až po schválení. Původní odpípnutý čas zůstane v orig.
Přímé opravy pro všechny jde povolit v nastavení docházky (att_self_edit)."""
import datetime
import re
import threading
import time
import urllib.parse

from .calendar_notes import holidays, MONTHS, DAYS, ABSENCE, KIND
from .web import (h, cz_date, flash, flash_redirect, HTTPError, allowed, hash_password, check_password,
                  parse_id, BadInput, money)

TIME = re.compile(r"^([01]?\d|2[0-3]):([0-5]\d)$")
PIN = re.compile(r"^\d{4,8}$")
STALE = 16 * 60           # příchod starší než 16 hodin bez odchodu = zapomenutý odchod (doplní se ručně)
BREAK_AFTER = 6 * 60      # § 88 ZP: nejdéle po 6 hodinách nepřetržité práce přestávka aspoň 30 minut
BREAK_GAP = 30
TRIES, LOCK_S = 5, 300    # píchačka: 5 špatných PINů → 5 minut blokace osoby
_fails = {}
_fails_lock = threading.Lock()


def mins(hhmm):
    a, b = hhmm.split(":")
    return int(a) * 60 + int(b)


def hm(m, sign=False):
    """Minuty → „7:45“ (se znaménkem pro rozdíl proti fondu)."""
    s = ("+" if m > 0 else "−" if m < 0 else "") if sign else ("−" if m < 0 else "")
    m = abs(int(m))
    return "%s%d:%02d" % (s, m // 60, m % 60)


def dec(m):
    """Minuty → desetinné hodiny pro Excel („7,75“)."""
    return ("%.2f" % (m / 60)).replace(".", ",")


def norm_time(s):
    s = (s or "").strip().replace(".", ":")
    if s.isdigit() and len(s) in (3, 4):        # 758 / 0758 → 7:58
        s = s[:-2] + ":" + s[-2:]
    m = TIME.match(s)
    return "%02d:%s" % (int(m.group(1)), m.group(2)) if m else None


def span(r):
    """(začátek, konec) v minutách od půlnoci dne záznamu; přes půlnoc konec > 1440; otevřený záznam → konec None."""
    s = mins(r["start"])
    if not r["end"]:
        return s, None
    e = mins(r["end"])
    return s, e + 1440 if e < s else e


def night(s, e):
    """Minuty noční práce (22:00–6:00) v úseku."""
    return sum(max(0, min(e, b) - max(s, a)) for a, b in ((-120, 360), (1320, 1800), (2760, 3240)))


def merged(spans):
    """Uzavřené úseky seřazené a sloučené – překryv (ruční záznam přes odpípnutý čas) se nesečte dvakrát."""
    out = []
    for s, e in sorted(x for x in spans if x[1] is not None):
        if out and s <= out[-1][1]:
            out[-1][1] = max(out[-1][1], e)
        else:
            out.append([s, e])
    return [tuple(x) for x in out]


def day_minutes(spans, auto_break):
    """(odpracováno po přestávce, odečtená přestávka) za den. Úseky s mezerou kratší než 30 min = nepřetržitá práce."""
    segs = merged(spans)
    worked = sum(e - s for s, e in segs)
    if not auto_break or not segs:
        return worked, 0
    brk, block, last_end = 0, 0, None
    for s, e in segs + [(10 ** 6, 10 ** 6)]:
        if last_end is not None and s - last_end >= BREAK_GAP:
            brk += 30 * max(0, (block - 1) // BREAK_AFTER)
            block = 0
        if s < 10 ** 6:
            block += e - s
            last_end = e
    return worked - brk, brk


def day_hours(s):
    try:
        v = float(str(s.get("att_hours") or "8").replace(",", "."))
    except ValueError:
        v = 8
    return int(round(min(max(v, 1), 12) * 60))


def month_of(arg):
    t = datetime.date.today()
    if arg and re.match(r"^\d{4}-\d{2}$", arg):
        y, m = int(arg[:4]), int(arg[5:])
        if 1900 <= y <= 2200 and 1 <= m <= 12:
            return y, m
    return t.year, t.month


def month_days(y, m):
    first = datetime.date(y, m, 1)
    nxt = datetime.date(y + (m == 12), m % 12 + 1, 1)
    return [first + datetime.timedelta(days=i) for i in range((nxt - first).days)]


def people(db, y=None, m=None):
    """Aktivní uživatelé + bývalí, kteří mají v měsíci záznam (výkaz za odešlého zaměstnance)."""
    rows = db.q("SELECT username, name, active, att_pin FROM users ORDER BY COALESCE(NULLIF(name, ''), username) COLLATE NOCASE")
    used = set()
    if y:
        used = {r[0].lower() for r in db.q("SELECT DISTINCT username FROM attendance WHERE substr(day, 1, 7) = ?",
                                            ("%04d-%02d" % (y, m),))}
    return [r for r in rows if r["active"] or r["username"].lower() in used]


def display(u):
    return u["name"] or u["username"]


def absences(db, names, days, per_day):
    """{den: [(druh, minuty, název)]} z Kalendáře – dovolená a nemoc dané osoby v pracovní dny."""
    low = {n.lower() for n in names if n}
    out = {}
    if not low or not days:
        return out
    hol = holidays(days[0].year)
    for e in db.q("SELECT * FROM events WHERE kind IN (%s) AND date_from <= ? AND date_to >= ?" % ",".join("?" * len(ABSENCE)),
                  list(ABSENCE) + [days[-1].isoformat(), days[0].isoformat()]):
        if (e["person"] or "").strip().lower() not in low:
            continue
        part = None
        if e["date_from"] == e["date_to"] and norm_time(e["time_from"]) and norm_time(e["time_to"]):
            part = max(0, mins(norm_time(e["time_to"])) - mins(norm_time(e["time_from"])))
        for d in days:
            if e["date_from"] <= d.isoformat() <= e["date_to"] and d.weekday() < 5 and d not in hol:
                out.setdefault(d, []).append((e["kind"], min(part, per_day) if part is not None else per_day, e["title"]))
    return out


def report(db, u, y, m, s):
    """Měsíční výkaz jedné osoby: řádky po dnech a součty."""
    days = month_days(y, m)
    hol = holidays(y)
    per_day = day_hours(s)
    auto = s.get("att_break", "1") == "1"
    recs = db.q("SELECT a.*, j.number AS job_number, j.title AS job_title FROM attendance a "
                "LEFT JOIN jobs j ON j.id = a.job_id WHERE a.username = ? AND a.day BETWEEN ? AND ? ORDER BY a.day, a.start",
                (u["username"], days[0].isoformat(), days[-1].isoformat()))
    by_day = {}
    for r in recs:
        by_day.setdefault(r["day"], []).append(r)
    absn = absences(db, (u["name"], u["username"]), days, per_day)
    t = dict(worked=0, brk=0, night=0, weekend=0, holiday=0, fond=0, vac=0, vac_days=0, sick=0, sick_days=0,
             open=0, manual=0, pending=0, workdays=0, fond_now=0, absent_now=0, worked_now=0)
    cut = datetime.date.today()                    # probíhající měsíc: rozdíl proti fondu do včerejška (dnešek není hotový)
    t["partial"] = days[0] <= cut <= days[-1]
    rows = []
    now = datetime.datetime.now()
    for d in days:
        rs = by_day.get(d.isoformat(), [])
        spans = [span(r) for r in rs if not r["pending"]]
        worked, brk = day_minutes(spans, auto)
        raw = merged(spans)
        nig = sum(night(a, b) for a, b in raw)
        work_day = d.weekday() < 5 and d not in hol
        if work_day:
            t["workdays"] += 1
            t["fond"] += per_day
            if d < cut:
                t["fond_now"] += per_day
        if d.weekday() >= 5:
            t["weekend"] += worked
        if d in hol:
            t["holiday"] += worked
        t["worked"] += worked
        if d < cut:
            t["worked_now"] += worked
        t["brk"] += brk
        t["night"] += nig
        stale = []
        for r in rs:
            if r["pending"] or r["req_at"]:
                t["pending"] += 1
            if r["pending"]:
                continue
            if not r["end"]:
                started = datetime.datetime.fromisoformat(r["day"] + " " + r["start"])
                if (now - started).total_seconds() > STALE * 60:
                    stale.append(r)
            if r["manual"]:
                t["manual"] += 1
        t["open"] += len(stale)
        ab = absn.get(d, [])
        for kind, mm, _ in ab:
            if d < cut:
                t["absent_now"] += mm
            if kind == "dovolena":
                t["vac"] += mm
                t["vac_days"] += mm / per_day
            else:
                t["sick"] += mm
                t["sick_days"] += mm / per_day
        rows.append({"d": d, "recs": rs, "worked": worked, "brk": brk, "night": nig, "holiday": hol.get(d, ""),
                     "absence": ab, "stale": stale})
    t["diff"] = t["worked_now"] + t["absent_now"] - t["fond_now"]
    return rows, t


def open_record(db, username):
    return db.one("SELECT * FROM attendance WHERE username = ? AND end = '' AND pending = 0 "
                  "ORDER BY day DESC, start DESC LIMIT 1", (username,))


def times(day, start, end, ref_day=None):
    """„07:30–16:00“, u jiného dne s datem."""
    return "%s%s–%s" % ("" if day == ref_day else cz_date(day) + " ", start, end or "…")


def punch(db, username, action, by, job_id=None, now=None):
    """Příchod / odchod / přepnutí zakázky. Vrací (výsledek, text). Opakované kliknutí nic nezdvojí."""
    dt = now or datetime.datetime.now()
    hhmm, day, ts = dt.strftime("%H:%M"), dt.date().isoformat(), int(time.time())
    with db.tx():
        o = open_record(db, username)
        if o:
            started = datetime.datetime.fromisoformat(o["day"] + " " + o["start"])
            if (dt - started).total_seconds() > STALE * 60 and o["req_at"]:
                o = None                  # doplnění odchodu čeká na schválení – další příchod nesmí blokovat
            elif (dt - started).total_seconds() > STALE * 60:
                return "stale", "Chybí odchod z %s (příchod %s). Doplňte ho prosím ručně." % (cz_date(o["day"]), o["start"])
        if action == "prichod":
            if o:
                return "noop", "V práci už jste od %s." % o["start"]
            db.run("INSERT INTO attendance(username, day, start, job_id, created_by, created) VALUES(?,?,?,?,?,?)",
                   (username, day, hhmm, job_id, by, ts))
            return "in", "Příchod %s" % hhmm
        if not o:
            return "noop", "Nejste zapsaný v práci – nejdřív příchod."
        db.run("UPDATE attendance SET end = ?, updated_by = ?, updated = ? WHERE id = ?", (hhmm, by, ts, o["id"]))
        if action == "prepnout":
            db.run("INSERT INTO attendance(username, day, start, job_id, created_by, created) VALUES(?,?,?,?,?,?)",
                   (username, day, hhmm, job_id, by, ts))
            return "switch", "Od %s pracujete na jiné zakázce" % hhmm
        return "out", "Odchod %s" % hhmm


def overlaps(db, username, day, s, e, skip=None, counted=False):
    """Překryv s jiným záznamem dne (counted = jen započítané, bez čekajících na schválení)."""
    for r in db.q("SELECT * FROM attendance WHERE username = ? AND day = ? AND id != ?%s" % (" AND pending = 0" if counted else ""),
                  (username, day, skip or 0)):
        a, b = span(r)
        b = b if b is not None else 10 ** 6
        if s < b and a < (e if e is not None else 10 ** 6):
            return r
    return None


def pin_ok(db, username, pin):
    """Ověření PINu s blokací po opakovaných pokusech (vrací (ok, chyba))."""
    key = username.lower()
    with _fails_lock:
        n, until = _fails.get(key, (0, 0))
        if until > time.time():
            return False, "Příliš mnoho špatných pokusů – zkuste to za %d min." % (int(until - time.time()) // 60 + 1)
    u = db.one("SELECT att_pin FROM users WHERE username = ? AND active = 1", (username,))
    if u and u["att_pin"] and check_password(pin, u["att_pin"]):
        with _fails_lock:
            _fails.pop(key, None)
        return True, ""
    with _fails_lock:
        n += 1
        _fails[key] = (0, time.time() + LOCK_S) if n >= TRIES else (n, 0)
    return False, "Špatný PIN."


def active_jobs(db):
    return db.q("SELECT id, number, title, cust_name FROM jobs WHERE status NOT IN ('hotova', 'vyfakturovana') "
                "ORDER BY id DESC LIMIT 200")


def job_options(db, sel=None, empty="— bez zakázky —"):
    rows = active_jobs(db)
    if sel and not any(r["id"] == sel for r in rows):
        rows = list(db.q("SELECT id, number, title, cust_name FROM jobs WHERE id = ?", (sel,))) + list(rows)
    return '<option value="">%s</option>' % empty + "".join(
        '<option value="%d"%s>%s – %s</option>' % (r["id"], " selected" if r["id"] == sel else "", h(r["number"]),
                                                   h((r["title"] or r["cust_name"])[:50])) for r in rows)


def job_hours(db, job_id, auto_break=False):
    """Odpracováno na zakázce po lidech (minuty, uzavřené záznamy; nevyfakturované zvlášť)."""
    out = {}
    for r in db.q("SELECT * FROM attendance WHERE job_id = ? AND end != '' AND pending = 0 ORDER BY day, start", (job_id,)):
        s, e = span(r)
        o = out.setdefault(r["username"], {"all": 0, "open": 0, "ids": []})
        o["all"] += e - s
        if not r["billed"]:
            o["open"] += e - s
            o["ids"].append(r["id"])
    return out


def register(app):
    db = app.db

    def users_exist():
        return bool(db.one("SELECT 1 FROM users WHERE active = 1"))

    def can_all(req):
        return allowed(req.perms, "/dochazka/prehled")

    def can_edit(req):
        """Přímá oprava vlastních záznamů – vedoucí vždy, ostatní jen když to nastavení povolí."""
        return can_all(req) or req.settings.get("att_self_edit") == "1"

    def person(req, username):
        """Osoba z adresy/formuláře – svoje vždy, cizí jen s oprávněním Docházka všech."""
        username = (username or req.user or "").strip()
        u = db.one("SELECT username, name, active, att_pin FROM users WHERE username = ?", (username,))
        if not u:
            raise HTTPError(404, "Uživatel nenalezen")
        if u["username"].lower() != (req.user or "").lower() and not can_all(req):
            raise HTTPError(403, "Docházku ostatních vidí jen ten, kdo má oprávnění „Docházka všech“.")
        return u

    def no_users():
        return app.page("Docházka", """<h1>Docházka</h1><div class="card"><p>Docházka se vede pro jednotlivé lidi, kteří
se do Firmičky přihlašují. Založte je v <a href="/nastaveni/uzivatele">Nastavení → Uživatelé</a> – každý pak zapisuje
příchod a odchod pod svým jménem, nebo na společném počítači přes píchačku s PINem.</p>
<p class="hint">Evidenci odpracované doby musí vést každý zaměstnavatel (§ 96 zákoníku práce).</p></div>""", "/dochazka")

    def month_nav(base, y, m):
        p = datetime.date(y, m, 1) - datetime.timedelta(days=1)
        n = datetime.date(y + (m == 12), m % 12 + 1, 1)
        sep = "&" if "?" in base else "?"
        return ('<a class="btn" href="%s%smesic=%04d-%02d">←</a><a class="btn" href="%s%smesic=%04d-%02d">→</a>'
                % (base, sep, p.year, p.month, base, sep, n.year, n.month))

    def rec_text(r, link=False):
        txt = "%s–%s" % (r["start"], r["end"] or "…")
        if link:
            txt = '<a href="/dochazka/zaznam/%d">%s</a>' % (r["id"], txt)
        extra = []
        if r["job_number"]:
            extra.append(h(r["job_number"]))
        if r["manual"]:
            extra.append("ručně")
        if r["orig"]:
            extra.append("původně %s" % h(r["orig"]))
        if r["pending"]:
            extra.append("<b class=danger>čeká na schválení, nezapočítáno</b>")
        if r["req_at"]:
            extra.append("<b class=danger>žádost o opravu na %s</b>" % h(times(r["req_day"], r["req_start"], r["req_end"], r["day"])))
        return txt + (" <span class=hint>(%s)</span>" % ", ".join(extra) if extra else "")

    # ---------- moje docházka ----------
    @app.route("/dochazka", ("GET", "POST"))
    def mine(req):
        if not users_exist():
            return no_users()
        if not req.user:
            raise HTTPError(403, "Docházka se zapisuje po přihlášení.")
        if req.method == "POST":
            akce = req.f("akce")
            if akce not in ("prichod", "odchod", "prepnout"):
                raise BadInput("Neznámá akce")
            res, msg = punch(db, req.user, akce, req.user, parse_id(req.f("job_id")))
            flash_redirect("/dochazka", msg)
        u = person(req, req.user)
        y, m = month_of(req.args.get("mesic"))
        rows, t = report(db, u, y, m, req.settings)
        o = open_record(db, req.user)
        waiting = ""
        if o and o["req_at"] and (datetime.datetime.now() - datetime.datetime.fromisoformat(
                o["day"] + " " + o["start"])).total_seconds() > STALE * 60:
            waiting = "<p class=hint>Doplnění odchodu z %s čeká na schválení.</p>" % cz_date(o["day"])
            o = None
        jobs = job_options(db, o["job_id"] if o else None)
        if o:
            started = datetime.datetime.fromisoformat(o["day"] + " " + o["start"])
            stale = (datetime.datetime.now() - started).total_seconds() > STALE * 60
            status = ("<p class='flash error'>Chybí odchod z %s (příchod %s). <a href='/dochazka/zaznam/%d'>Doplnit odchod</a></p>"
                      % (cz_date(o["day"]), o["start"], o["id"]) if stale else
                      """<p class="big">V práci od <b>%s</b>%s</p>
<form method="post" class="actions">%s<button class="btn primary big" name="akce" value="odchod">Odchod</button></form>
<form method="post" class="filters">%s<select name="job_id">%s</select>
<button class="btn" name="akce" value="prepnout">Přepnout zakázku</button></form>""" % (
                          o["start"], "" if o["day"] == datetime.date.today().isoformat() else " (%s)" % cz_date(o["day"]),
                          app.csrf(), app.csrf(), jobs))
        else:
            status = """<p class="big">Nejste v práci</p>
<form method="post" class="filters">%s<select name="job_id">%s</select>
<button class="btn primary big" name="akce" value="prichod">Příchod</button></form>""" % (app.csrf(), jobs)
        status = waiting + status
        today_rows = [r for r in rows if r["d"] == datetime.date.today()]
        today = ", ".join(rec_text(r, True) for r in today_rows[0]["recs"]) if today_rows and today_rows[0]["recs"] else ""
        mon = "%s %d" % (MONTHS[m - 1], y)
        recent = "".join(
            "<tr><td>%s %s</td><td>%s</td><td class=num>%s</td><td>%s</td></tr>" % (
                DAYS[r["d"].weekday()], r["d"].strftime("%d. %m."), ", ".join(rec_text(x, True) for x in r["recs"]),
                hm(r["worked"]) if r["recs"] else "", absence_text(r))
            for r in reversed(rows) if r["recs"] or r["absence"])
        return app.page("Docházka", """%s<div class="bar"><h1>Docházka</h1><div class="actions">
<a class="btn" href="/dochazka/zaznam/novy">+ %s</a>%s</div></div>
<section class="card">%s%s</section>
<div class="bar"><h2>%s</h2><div class="actions">%s<a class="btn" href="/dochazka/vykaz?mesic=%04d-%02d">Výkaz k tisku</a></div></div>
<div class="stats"><div><span>Odpracováno</span><b>%s</b></div><div><span>Fond měsíce</span><b>%s</b></div>
<div><span>Dovolená / nemoc</span><b>%s / %s</b></div><div><span>Rozdíl proti fondu%s</span><b>%s</b></div></div>
<table class="list"><thead><tr><th>Den</th><th>Záznamy</th><th class=num>Odpracováno</th><th>Poznámka</th></tr></thead>
<tbody>%s</tbody></table>""" % (
            flash(req), "Ruční záznam" if can_edit(req) else "Zapomenutý příchod / odchod",
            ('<a class="btn" href="/dochazka/prehled">Všichni%s</a>' % (" (ke schválení %d)" % n_waiting() if n_waiting() else ""))
            if can_all(req) else "", status, "<p class=hint>Dnes: %s</p>" % today if today else "", mon.capitalize(), month_nav("/dochazka", y, m),
            y, m, hm(t["worked"]), hm(t["fond"]), hm(t["vac"]), hm(t["sick"]), " do včerejška" if t["partial"] else "", hm(t["diff"], True),
            recent or "<tr><td colspan=4 class=empty>V tomto měsíci zatím nic.</td></tr>"), "/dochazka")

    def absence_text(r):
        parts = []
        if r["holiday"]:
            parts.append(h(r["holiday"]))
        for kind, mm, title in r["absence"]:
            parts.append("%s%s" % (KIND.get(kind, kind), " %s" % hm(mm) if mm and kind == "nemoc" else ""))
        if r["brk"]:
            parts.append("přestávka −%s" % hm(r["brk"]))
        if r["stale"]:
            parts.append("<b class=danger>chybí odchod</b>")
        return ", ".join(parts)

    # ---------- výkaz ----------
    @app.route("/dochazka/vykaz")
    def statement(req):
        if not users_exist():
            return no_users()
        u = person(req, req.args.get("kdo"))
        y, m = month_of(req.args.get("mesic"))
        rows, t = report(db, u, y, m, req.settings)
        edit = can_all(req) or u["username"].lower() == (req.user or "").lower()
        trs = "".join(
            "<tr%s><td>%s %s</td><td>%s</td><td class=num>%s</td><td class=num>%s</td><td>%s</td></tr>" % (
                " class=muted" if r["d"].weekday() >= 5 or r["holiday"] else "", DAYS[r["d"].weekday()], r["d"].strftime("%d. %m."),
                ", ".join(rec_text(x, edit) for x in r["recs"]), hm(r["worked"]) if r["recs"] else "",
                hm(r["night"]) if r["night"] else "", absence_text(r)) for r in rows)
        s = req.settings
        q = urllib.parse.quote(u["username"])
        summary = [("Odpracováno", hm(t["worked"])), ("Fond pracovní doby", "%s (%d dní × %s)" % (
                       hm(t["fond"]), t["workdays"], hm(day_hours(s)))),
                   ("Dovolená", "%s dne · %s h" % (fmt_days(t["vac_days"]), hm(t["vac"]))),
                   ("Nemoc / lékař", "%s dne · %s h" % (fmt_days(t["sick_days"]), hm(t["sick"]))),
                   ("Rozdíl proti fondu" + (" (do včerejška)" if t["partial"] else ""), hm(t["diff"], True)),
                   ("Z toho v noci (22–6)", hm(t["night"])), ("Z toho o víkendu", hm(t["weekend"])),
                   ("Z toho ve svátek", hm(t["holiday"]))]
        if t["brk"]:
            summary.append(("Odečtené přestávky", hm(t["brk"])))
        warn = ""
        if t["open"]:
            warn += "<p class='flash error noprint'>Chybí odchod u %d záznamu – výkaz není úplný.</p>" % t["open"]
        if t["pending"]:
            warn += ("<p class='flash error noprint'>Ke schválení: %d – ruční záznamy se do výkazu započítají až po schválení, "
                     "u žádostí o opravu platí zatím původní čas.</p>" % t["pending"])
        if t["manual"]:
            warn += "<p class='hint'>Ručně zapsaných nebo upravených záznamů: %d (označené „ručně“).</p>" % t["manual"]
        return app.page("Výkaz docházky", """%s<div class="bar noprint"><a href="%s">← Docházka</a><div class="actions">%s
<a class="btn" href="/dochazka/zaznam/novy?kdo=%s">+ Záznam</a><button class="btn" onclick="window.print()">Tisk</button></div></div>
<h1>Výkaz docházky – %s %d</h1>
<p><b>%s</b> · %s%s</p>%s
<table class="list dense"><thead><tr><th>Den</th><th>Příchod–odchod</th><th class=num>Odpracováno</th><th class=num>Noc</th>
<th>Poznámka</th></tr></thead><tbody>%s</tbody></table>
<table class="list" style="max-width:34rem;margin-top:1rem"><tbody>%s</tbody></table>
<p class="hint">Dovolená a nemoc jsou z Kalendáře. Odpracovaná doba je po odečtení přestávek; noc, víkend a svátek
jsou časy z docházky.%s</p>
<div class="cols" style="margin-top:3rem"><p>Podpis zaměstnance: ………………………………</p><p>Podpis za zaměstnavatele: ………………………………</p></div>""" % (
            flash(req), "/dochazka/prehled?mesic=%04d-%02d" % (y, m) if can_all(req) else "/dochazka?mesic=%04d-%02d" % (y, m),
            month_nav("/dochazka/vykaz?kdo=%s" % q, y, m), q, MONTHS[m - 1], y, h(display(u)),
            h(s["firm_name"]), "" if u["active"] else " · (již není aktivní)", warn, trs,
            "".join("<tr><td>%s</td><td class=num><b>%s</b></td></tr>" % kv for kv in summary),
            " Přestávka 30 min po 6 hodinách práce se odečítá automaticky." if s.get("att_break", "1") == "1" else ""),
            "/dochazka")

    def fmt_days(x):
        return ("%.2f" % x).rstrip("0").rstrip(".").replace(".", ",")

    # ---------- ruční záznam, opravy a schvalování ----------
    def n_waiting():
        return db.one("SELECT COUNT(*) FROM attendance WHERE pending = 1 OR req_at > 0")[0]

    def rec_form(req, r, rid=None, err=""):
        direct = can_edit(req) or bool(r.get("pending"))     # vlastní čekající záznam jde ještě upravit
        u_sel = ""
        if can_all(req):
            u_sel = '<label>Kdo<select name="username">%s</select></label>' % "".join(
                '<option value="%s"%s>%s</option>' % (h(x["username"]), " selected" if x["username"].lower() ==
                                                      (r.get("username") or "").lower() else "", h(display(x)))
                for x in people(db))
        delete = ""
        if rid and (can_edit(req) or r.get("pending")):
            delete = ('<form method="post" action="/dochazka/zaznam/%s/smazat" onsubmit="return confirm(\'%s?\')">%s'
                      '<button class="link danger">%s</button></form>' % (
                          rid, "Smazat záznam" if can_edit(req) else "Zrušit žádost", app.csrf(),
                          "smazat záznam" if can_edit(req) else "zrušit žádost"))
        made = ""
        if rid:
            made = "<p class=hint>Zapsal(a) %s %s%s%s%s</p>" % (
                h(r.get("created_by") or "—"), time.strftime("%d. %m. %Y %H:%M", time.localtime(r["created"])),
                ", upravil(a) %s %s" % (h(r["updated_by"]), time.strftime("%d. %m. %Y %H:%M", time.localtime(r["updated"])))
                if r.get("updated") else "",
                ", schválil(a) %s %s" % (h(r["approved_by"]), time.strftime("%d. %m. %Y %H:%M", time.localtime(r["approved"])))
                if r.get("approved") else "",
                " · původní odpípnutý čas %s" % h(r["orig"]) if r.get("orig") else "")
        box = ""
        if rid and (r.get("pending") or r.get("req_at")):
            what = ("Záznam čeká na schválení vedoucím – do docházky se zatím nepočítá." if r.get("pending") else
                    "Žádost o opravu na <b>%s</b> (%s, %s) čeká na schválení vedoucím." % (
                        h(times(r["req_day"], r["req_start"], r["req_end"], r["day"])), h(r["req_by"]),
                        time.strftime("%d. %m. %H:%M", time.localtime(r["req_at"]))) +
                    (" Důvod: %s" % h(r["req_note"]) if r.get("req_note") else ""))
            btns = ""
            if can_all(req):
                btns = ('<form method="post" action="/dochazka/schvalit/%s" class="actions">%s'
                        '<button class="btn primary">Schválit</button>'
                        '<button class="btn" formaction="/dochazka/zamitnout/%s">Zamítnout</button></form>' % (rid, app.csrf(), rid))
            elif r.get("req_at"):
                btns = ('<form method="post" action="/dochazka/zaznam/%s/zrusit">%s<button class="link danger">'
                        'zrušit žádost</button></form>' % (rid, app.csrf()))
            box = '<div class="card"><p>%s</p>%s</div>' % (what, btns)
        if not rid:
            title = "Ruční záznam docházky" if direct else "Zapomenutý příchod / odchod"
        else:
            title = "Upravit záznam" if direct else "Požádat o opravu záznamu"
        hint = "" if can_edit(req) else ("<p class=hint>Ruční záznam i oprava se do docházky započítají, až je schválí "
                                         "vedoucí (kdo má oprávnění „Docházka všech“). Původní odpípnutý čas zůstane vidět.</p>")
        form = "" if r.get("billed") else """<form method="post" class="card grid">%s%s
<label>Den<input type="date" name="date" value="%s" required></label>
<label>Příchod<input name="start" value="%s" placeholder="7:30" required inputmode="numeric"></label>
<label>Odchod<input name="end" value="%s" placeholder="16:00 (prázdné = ještě v práci)" inputmode="numeric"></label>
<label>Zakázka<select name="job_id">%s</select></label>
<label class="wide">%s<input name="note" value="%s" placeholder="např. zapomněl jsem se odpípnout"%s></label>
<div class="actions wide"><button class="btn primary">%s</button><a class="btn" href="/dochazka">Zpět</a></div>
</form>""" % (app.csrf(), u_sel, h(r.get("day") or ""), h(r.get("start") or ""), h(r.get("end") or ""),
              job_options(db, r.get("job_id")), "Poznámka" if can_edit(req) else "Důvod", h(r.get("note") or ""),
              "" if can_edit(req) else " required", "Uložit" if can_edit(req) else
              ("Uložit žádost" if direct else "Odeslat ke schválení"))
        return app.page("Záznam docházky", """<h1>%s</h1>%s%s%s%s%s%s""" % (
            title, '<div class="flash error">%s</div>' % h(err) if err else "", hint, box, form, made, delete), "/dochazka")

    def rec_from_form(req, rid=None):
        username = req.f("username") if can_all(req) and req.f("username") else req.user
        u = person(req, username)
        r = {"username": u["username"], "day": req.f("date"), "start": req.f("start"), "end": req.f("end"),
             "job_id": parse_id(req.f("job_id")), "note": req.f("note")[:200]}
        s, e = norm_time(r["start"]), norm_time(r["end"]) if r["end"] else ""
        if not r["day"]:
            return r, "Zadejte den."
        if r["day"] > datetime.date.today().isoformat():
            return r, "Docházku nejde zapsat dopředu."
        if not s or e is None:
            return r, "Čas zadejte jako hodiny:minuty, např. 7:30."
        r["start"], r["end"] = s, e
        if not e and r["day"] != datetime.date.today().isoformat():
            return r, "U starších dnů vyplňte i odchod."
        if not e:
            o = open_record(db, u["username"])
            if o and o["id"] != rid:
                return r, "Otevřený příchod už existuje (%s %s) – nejdřív u něj doplňte odchod." % (cz_date(o["day"]), o["start"])
        a, b = span(r)
        clash = overlaps(db, u["username"], r["day"], a, b, rid)
        if clash:
            return r, "Překrývá se se záznamem %s–%s." % (clash["start"], clash["end"] or "…")
        if not can_edit(req) and not r["note"].strip():
            return r, "Napište důvod – vedoucí podle něj opravu schválí."
        return r, ""

    def orig_of(old, day, start, end):
        """Původní odpípnutý čas – uloží se při první změně záznamu z píchačky / tlačítka."""
        if old["orig"] or old["manual"] or (old["day"], old["start"], old["end"]) == (day, start, end):
            return old["orig"] or ""
        return times(old["day"], old["start"], old["end"], day)

    @app.route("/dochazka/zaznam/novy", ("GET", "POST"))
    def new_rec(req):
        if not users_exist():
            return no_users()
        if req.method == "POST":
            r, err = rec_from_form(req)
            if err:
                return rec_form(req, r, err=err)
            wait = not can_edit(req)
            db.run("INSERT INTO attendance(username, day, start, end, job_id, note, manual, pending, created_by, created) "
                   "VALUES(?,?,?,?,?,?,1,?,?,?)", (r["username"], r["day"], r["start"], r["end"], r["job_id"], r["note"],
                                                   int(wait), req.user, int(time.time())))
            flash_redirect(back(req, r), "Odesláno ke schválení vedoucímu" if wait else "Záznam uložen")
        u = person(req, req.args.get("kdo"))
        return rec_form(req, {"username": u["username"], "day": datetime.date.today().isoformat()})

    def back(req, r):
        if r["username"].lower() != (req.user or "").lower():
            return "/dochazka/vykaz?kdo=%s&mesic=%s" % (urllib.parse.quote(r["username"]), r["day"][:7])
        return "/dochazka?mesic=%s" % r["day"][:7]

    def get_rec(req, rid):
        r = db.one("SELECT * FROM attendance WHERE id = ?", (rid,))
        if not r:
            raise HTTPError(404, "Záznam nenalezen")
        person(req, r["username"])
        return r

    @app.route("/dochazka/zaznam/<rid>", ("GET", "POST"))
    def edit_rec(req, rid):
        old = get_rec(req, rid)
        if old["billed"]:
            if req.method == "POST":
                raise HTTPError(409, "Záznam už je přenesený do zakázky – nejde měnit.")
        if req.method == "POST":
            r, err = rec_from_form(req, old["id"])
            if err:
                return rec_form(req, dict(old, **r), rid, err)
            now = int(time.time())
            if can_edit(req) or old["pending"]:
                db.run("UPDATE attendance SET username = ?, day = ?, start = ?, end = ?, job_id = ?, note = ?, manual = 1, "
                       "orig = ?, updated_by = ?, updated = ?, req_day = '', req_start = '', req_end = '', req_note = '', "
                       "req_by = '', req_at = 0 WHERE id = ?",
                       (r["username"], r["day"], r["start"], r["end"], r["job_id"], r["note"],
                        orig_of(old, r["day"], r["start"], r["end"]), req.user, now, old["id"]))
                flash_redirect(back(req, r), "Žádost upravena" if old["pending"] and not can_edit(req) else "Záznam uložen")
            if (old["day"], old["start"], old["end"]) == (r["day"], r["start"], r["end"]):
                return rec_form(req, dict(old, **r), rid, "Čas je stejný jako teď – není co opravit.")
            db.run("UPDATE attendance SET req_day = ?, req_start = ?, req_end = ?, req_note = ?, req_by = ?, req_at = ? "
                   "WHERE id = ?", (r["day"], r["start"], r["end"], r["note"], req.user, now, old["id"]))
            flash_redirect(back(req, r), "Žádost o opravu odeslána ke schválení vedoucímu")
        r = dict(old)
        if r["req_at"] and not can_all(req):        # žadatel vidí ve formuláři svůj návrh
            r.update(day=r["req_day"], start=r["req_start"], end=r["req_end"], note=r["req_note"])
        return rec_form(req, r, rid, "Záznam už je přenesený do zakázky jako práce – nejde měnit." if old["billed"] else "")

    @app.route("/dochazka/zaznam/<rid>/smazat", ("POST",))
    def delete_rec(req, rid):
        r = get_rec(req, rid)
        if r["billed"]:
            raise HTTPError(409, "Záznam už je přenesený do zakázky – nejde smazat.")
        if not (can_edit(req) or r["pending"]):
            raise HTTPError(403, "Záznam může smazat jen vedoucí (oprávnění „Docházka všech“) – požádejte o opravu.")
        db.run("DELETE FROM attendance WHERE id = ?", (r["id"],))
        flash_redirect(back(req, r), "Žádost zrušena" if r["pending"] and not can_edit(req) else "Záznam smazán")

    @app.route("/dochazka/zaznam/<rid>/zrusit", ("POST",))
    def withdraw(req, rid):
        r = get_rec(req, rid)
        db.run("UPDATE attendance SET req_day = '', req_start = '', req_end = '', req_note = '', req_by = '', req_at = 0 "
               "WHERE id = ?", (r["id"],))
        flash_redirect(back(req, r), "Žádost o opravu zrušena")

    def after_decision(req):
        nxt = req.f("next")
        return nxt if nxt.startswith("/dochazka") and "//" not in nxt else "/dochazka/prehled"

    @app.route("/dochazka/schvalit/<rid>", ("POST",))
    def approve(req, rid):
        if not can_all(req):
            raise HTTPError(403, "Schvaluje jen vedoucí (oprávnění „Docházka všech“).")
        now = int(time.time())
        with db.tx():           # dva vedoucí naráz: rozhodne první, druhý dostane „mezitím vyřízeno“
            r = db.one("SELECT * FROM attendance WHERE id = ?", (rid,))
            if not r or not (r["pending"] or r["req_at"]):
                flash_redirect(after_decision(req), "Mezitím to vyřídil někdo jiný")
            if r["billed"]:
                raise HTTPError(409, "Záznam už je přenesený do zakázky – nejde měnit.")
            if r["pending"]:
                day, start, end = r["day"], r["start"], r["end"]
            else:
                day, start, end = r["req_day"], r["req_start"], r["req_end"]
            a, b = span({"start": start, "end": end})
            clash = overlaps(db, r["username"], day, a, b, r["id"], counted=True)
            if clash:
                flash_redirect(after_decision(req), "Nejde schválit – překrývá se se záznamem %s %s–%s. Opravte ho ručně."
                               % (cz_date(day), clash["start"], clash["end"] or "…"))
            if not end:
                o = open_record(db, r["username"])
                if day != datetime.date.today().isoformat() or (o and o["id"] != r["id"]):
                    flash_redirect(after_decision(req), "Nejde schválit – chybí odchod. Doplňte ho ručně.")
            if r["pending"]:
                db.run("UPDATE attendance SET pending = 0, approved_by = ?, approved = ? WHERE id = ?", (req.user, now, r["id"]))
            else:
                db.run("UPDATE attendance SET day = ?, start = ?, end = ?, note = ?, manual = 1, orig = ?, updated_by = ?, "
                       "updated = ?, approved_by = ?, approved = ?, req_day = '', req_start = '', req_end = '', req_note = '', "
                       "req_by = '', req_at = 0 WHERE id = ?",
                       (day, start, end, r["req_note"] or r["note"], orig_of(r, day, start, end), r["req_by"], r["req_at"],
                        req.user, now, r["id"]))
        flash_redirect(after_decision(req), "Schváleno")

    @app.route("/dochazka/zamitnout/<rid>", ("POST",))
    def reject(req, rid):
        if not can_all(req):
            raise HTTPError(403, "Schvaluje jen vedoucí (oprávnění „Docházka všech“).")
        with db.tx():
            r = db.one("SELECT * FROM attendance WHERE id = ?", (rid,))
            if not r or not (r["pending"] or r["req_at"]):
                flash_redirect(after_decision(req), "Mezitím to vyřídil někdo jiný")
            if r["pending"]:
                db.run("DELETE FROM attendance WHERE id = ? AND pending = 1", (r["id"],))
            else:
                db.run("UPDATE attendance SET req_day = '', req_start = '', req_end = '', req_note = '', req_by = '', "
                       "req_at = 0 WHERE id = ?", (r["id"],))
        flash_redirect(after_decision(req), "Zamítnuto")

    # ---------- přehled všech ----------
    @app.route("/dochazka/prehled")
    def overview(req):
        if not users_exist():
            return no_users()
        y, m = month_of(req.args.get("mesic"))
        trs = []
        for u in people(db, y, m):
            rows, t = report(db, u, y, m, req.settings)
            o = open_record(db, u["username"])
            q = urllib.parse.quote(u["username"])
            trs.append("<tr><td><a href='/dochazka/vykaz?kdo=%s&mesic=%04d-%02d'>%s</a></td><td>%s</td><td class=num>%s</td>"
                       "<td class=num>%s</td><td class=num>%s</td><td class=num>%s</td><td class=num><b>%s</b></td><td>%s</td></tr>" % (
                           q, y, m, h(display(u)), "v práci od %s" % o["start"] if o and o["day"] == datetime.date.today().isoformat()
                           else ("<b class=danger>chybí odchod</b>" if o else ""), hm(t["worked"]), hm(t["fond"]),
                           fmt_days(t["vac_days"]), fmt_days(t["sick_days"]), hm(t["diff"], True),
                           "<b class=danger>%d× chybí odchod</b>" % t["open"] if t["open"] else ""))
        s = req.settings
        names = {u["username"].lower(): display(u) for u in db.q("SELECT username, name FROM users")}
        nxt = "/dochazka/prehled?mesic=%04d-%02d" % (y, m)
        wait = "".join(
            "<tr><td>%s</td><td>%s</td><td><span class=lbl>Teď </span>%s</td><td><span class=lbl>Návrh </span>%s</td><td>%s</td>"
            "<td><form method=post action='/dochazka/schvalit/%d' "
            "class=actions>%s<input type=hidden name=next value='%s'><button class='btn primary'>Schválit</button>"
            "<button class=btn formaction='/dochazka/zamitnout/%d'>Zamítnout</button></form></td></tr>" % (
                h(names.get(r["username"].lower(), r["username"])), cz_date(r["day"]),
                "<span class=hint>nový záznam</span>" if r["pending"] else
                '<a href="/dochazka/zaznam/%d">%s</a>' % (r["id"], h(times(r["day"], r["start"], r["end"], r["day"]))),
                "<b>%s</b>" % h(times(r["day"], r["start"], r["end"], r["day"]) if r["pending"] else
                                times(r["req_day"], r["req_start"], r["req_end"], r["day"])),
                h(r["note"] if r["pending"] else r["req_note"]), r["id"], app.csrf(), h(nxt), r["id"])
            for r in db.q("SELECT * FROM attendance WHERE pending = 1 OR req_at > 0 ORDER BY day, start"))
        wait = ("""<section class="card" id="schvalit"><h2>Ke schválení</h2><table class="list"><thead><tr><th>Kdo</th>
<th>Den</th><th>Teď</th><th>Návrh</th><th>Důvod</th><th></th></tr></thead><tbody>%s</tbody></table>
<p class="hint">Do docházky se oprava započítá až po schválení. Původní odpípnutý čas zůstane ve výkazu.</p></section>""" % wait
                if wait else "")
        return app.page("Docházka – přehled", """%s%s<div class="bar"><h1>Docházka – %s %d</h1><div class="actions">%s
<a class="btn" href="/dochazka/export.csv?mesic=%04d-%02d">Export pro účetní (CSV)</a>
<a class="btn" href="/dochazka/terminal">Píchačka</a><a class="btn" href="/dochazka/piny">PINy</a></div></div>
<table class="list"><thead><tr><th>Kdo</th><th>Teď</th><th class=num>Odpracováno</th><th class=num>Fond</th>
<th class=num>Dovolená (dní)</th><th class=num>Nemoc (dní)</th><th class=num>Rozdíl%s</th><th></th></tr></thead><tbody>%s</tbody></table>
<form method="post" action="/dochazka/nastaveni" class="card grid" style="margin-top:1.5rem">%s<h2 class="wide">Nastavení docházky</h2>
<label>Úvazek – hodin denně<input name="att_hours" value="%s" inputmode="decimal"></label>
<label class="check wide"><input type="checkbox" name="att_break" value="1"%s> Po 6 hodinách práce odečíst přestávku 30 minut
<span class="hint">(když si ji člověk nezapíše sám odchodem aspoň na 30 minut)</span></label>
<label class="check wide"><input type="checkbox" name="att_self_edit" value="1"%s> Zaměstnanci smí sami opravovat a mazat
svou docházku <span class="hint">(vypnuté = ruční záznam i oprava čekají na schválení vedoucím)</span></label>
<div class="actions wide"><button class="btn">Uložit</button></div></form>""" % (
            flash(req), wait, MONTHS[m - 1], y, month_nav("/dochazka/prehled", y, m), y, m,
            " do včerejška" if datetime.date(y, m, 1) <= datetime.date.today() <= month_days(y, m)[-1] else "", "".join(trs) or
            "<tr><td colspan=8 class=empty>Nikdo.</td></tr>", app.csrf(), h(s.get("att_hours") or "8"),
            " checked" if s.get("att_break", "1") == "1" else "", " checked" if s.get("att_self_edit") == "1" else ""),
            "/dochazka")

    @app.route("/dochazka/nastaveni", ("POST",))
    def settings(req):
        v = req.f("att_hours").replace(",", ".")
        try:
            hours = float(v)
        except ValueError:
            hours = 0
        if not 1 <= hours <= 12:
            raise BadInput("Úvazek zadejte v hodinách denně (1–12), např. 8 nebo 7,5.")
        db.set_settings({"att_hours": ("%g" % hours).replace(".", ","), "att_break": "1" if req.f("att_break") else "0",
                         "att_self_edit": "1" if req.f("att_self_edit") else "0"})
        flash_redirect("/dochazka/prehled", "Nastavení docházky uloženo")

    @app.route("/dochazka/export.csv")
    def export(req):
        from .core import csv_response
        y, m = month_of(req.args.get("mesic"))
        rows = []
        for u in people(db, y, m):
            _, t = report(db, u, y, m, req.settings)
            rows.append([display(u), u["username"], dec(t["worked"]), dec(t["fond"]), fmt_days(t["vac_days"]), dec(t["vac"]),
                         fmt_days(t["sick_days"]), dec(t["sick"]), dec(t["night"]), dec(t["weekend"]), dec(t["holiday"]),
                         dec(t["diff"]), t["open"], t["pending"]])
        return csv_response("dochazka-%04d-%02d.csv" % (y, m),
                            ["Jméno", "Uživatel", "Odpracováno (h)", "Fond (h)", "Dovolená (dny)", "Dovolená (h)",
                             "Nemoc (dny)", "Nemoc (h)", "Noc (h)", "Víkend (h)", "Svátek (h)", "Rozdíl proti fondu (h)",
                             "Chybí odchod", "Čeká na schválení"], rows)

    # ---------- PINy a píchačka ----------
    @app.route("/dochazka/piny", ("GET", "POST"))
    def pins(req):
        if not users_exist():
            return no_users()
        us = people(db)
        if req.method == "POST":
            n = 0
            with db.tx():
                for u in us:
                    v = req.f("pin_%s" % u["username"])
                    if req.f("smazat_%s" % u["username"]):
                        db.run("UPDATE users SET att_pin = '' WHERE username = ?", (u["username"],))
                        n += 1
                    elif v:
                        if not PIN.match(v):
                            raise BadInput("PIN musí mít 4 až 8 číslic.")
                        db.run("UPDATE users SET att_pin = ? WHERE username = ?", (hash_password(v), u["username"]))
                        n += 1
            flash_redirect("/dochazka/piny", "Uloženo (%d změn)" % n)
        trs = "".join("<tr><td>%s</td><td>%s</td><td><input name='pin_%s' type='password' inputmode='numeric' "
                      "autocomplete='new-password' placeholder='nový PIN'></td><td>%s</td></tr>" % (
                          h(display(u)), "nastavený" if u["att_pin"] else "<span class=hint>není</span>", h(u["username"]),
                          "<label class=check><input type=checkbox name='smazat_%s' value=1> smazat</label>" % h(u["username"])
                          if u["att_pin"] else "") for u in us if u["active"])
        return app.page("PINy pro píchačku", """%s<div class="bar"><a href="/dochazka/prehled">← Docházka</a></div>
<h1>PINy pro píchačku</h1><p class="hint">Na společném počítači nebo tabletu se lidé odpípnou výběrem jména a PINem
(4–8 číslic). PIN se ukládá jen jako otisk, nikdo ho zpětně nepřečte. Po 5 špatných pokusech se osoba na 5 minut zablokuje.</p>
<form method="post" class="card">%s<table class="list"><thead><tr><th>Kdo</th><th>PIN</th><th>Nový PIN</th><th></th></tr></thead>
<tbody>%s</tbody></table><button class="btn primary">Uložit</button></form>""" % (flash(req), app.csrf(), trs), "/dochazka")

    @app.route("/dochazka/terminal", ("GET", "POST"))
    def terminal(req):
        """Píchačka pro společný tablet: dlaždice se jmény, PIN (číselník), velké Příchod/Odchod.
        Bez JavaScriptu funguje taky – dlaždice jsou přepínače (radio), PIN se píše do pole."""
        if not users_exist():
            return no_users()
        us = [u for u in people(db) if u["active"] and u["att_pin"]]
        if req.method == "POST":
            akce = req.f("akce")
            u = db.one("SELECT username, name FROM users WHERE username = ? AND active = 1", (req.f("username"),))
            if not u or akce not in ("prichod", "odchod"):
                flash_redirect("/dochazka/terminal?stav=chyba", "Nejdřív klepněte na své jméno.")
            ok, err = pin_ok(db, u["username"], req.f("pin"))
            if not ok:
                flash_redirect("/dochazka/terminal?stav=chyba", "%s: %s" % (display(u), err))
            res, msg = punch(db, u["username"], akce, "píchačka")
            stav = "chyba" if res == "stale" else "info" if res == "noop" else "ok"
            flash_redirect("/dochazka/terminal?stav=%s" % stav, "%s – %s" % (display(u), msg))
        today = datetime.date.today().isoformat()
        tiles, here = [], 0
        for u in us:
            o = open_record(db, u["username"])
            inside = bool(o and o["day"] == today)
            here += inside
            tiles.append('<label class="ptile%s"><input type="radio" name="username" value="%s" required data-in="%d">'
                         '<b>%s</b><span>%s</span></label>' % (
                             " in" if inside else "", h(u["username"]), inside, h(display(u)),
                             "v práci od %s" % o["start"] if inside else "nepřítomen"))
        msg = req.args.get("msg")
        stav = req.args.get("stav") if req.args.get("stav") in ("ok", "chyba", "info") else "info"
        note = '<div class="pmsg %s" role="status">%s</div>' % (stav, h(msg)) if msg else ""
        keys = "".join('<button type="button" class="pkey" data-k="%s">%s</button>' % (k, t) for k, t in (
            ("1", "1"), ("2", "2"), ("3", "3"), ("4", "4"), ("5", "5"), ("6", "6"), ("7", "7"), ("8", "8"), ("9", "9"),
            ("C", "smazat"), ("0", "0"), ("B", "⌫")))
        body = ("""<form method="post" class="pich" autocomplete="off">%s
<div class="pstep1"><p class="plead">Klepněte na své jméno</p><div class="ptiles">%s</div></div>
<div class="pstep2"><p class="pwho"><button type="button" class="link pback">← jiné jméno</button> <b class="pname"></b></p>
<label class="ppin">PIN<input name="pin" type="password" inputmode="numeric" pattern="[0-9]*" maxlength="8" required
 autocomplete="off"></label>
<div class="pkeys">%s</div>
<div class="pacts"><button class="btn primary pin-btn" name="akce" value="prichod">Příchod</button>
<button class="btn pout-btn" name="akce" value="odchod">Odchod</button></div></div></form>
<p class="hint">V práci: %d z %d</p>""" % (app.csrf(), "".join(tiles), keys, here, len(us))) if us else (
            "<p class=empty>Zatím nikdo nemá PIN. Nastavte ho v <a href='/dochazka/piny'>PINy</a>.</p>")
        tip = ("""<p class="hint noprint">Na společný počítač nebo tablet založte v <a href="/nastaveni/uzivatele">Uživatelích</a>
uživatele (např. „pichacka“) jen s oprávněním <b>Píchačka</b> – kdo k počítači přijde, neuvidí nic jiného. V Nastavení →
Přístup nastavte delší odhlášení po nečinnosti, jinak se píchačka po čase odhlásí.</p>""" if can_all(req) else "")
        return app.page("Píchačka", """%s<div class="terminal">%s<div class="phead"><h1>Píchačka</h1>
<div class="pclock"><b data-clock>%s</b><span>%s %s</span></div></div>%s%s</div>""" % (
            '<div class="bar noprint"><a href="/dochazka/prehled">← Docházka</a></div>' if can_all(req) else "",
            note, datetime.datetime.now().strftime("%H:%M"), DAYS[datetime.date.today().weekday()],
            datetime.date.today().strftime("%d. %m. %Y"), body, tip), "/dochazka")

    # ---------- hodiny na zakázce ----------
    def job_card(j, req):
        hours = job_hours(db, j["id"])
        if not hours:
            return ""
        names = {u["username"].lower(): display(u) for u in db.q("SELECT username, name FROM users")}
        trs = "".join("<tr><td>%s</td><td class=num>%s</td><td class=num>%s</td></tr>" % (
            h(names.get(k.lower(), k)), hm(v["all"]), hm(v["open"]) if v["open"] else "—") for k, v in sorted(hours.items()))
        total_open = sum(v["open"] for v in hours.values())
        form = ""
        if total_open and j["status"] != "vyfakturovana" and allowed(req.perms, "/zakazky/%d/hodiny" % j["id"]):
            svc = db.q("SELECT id, name, unit, price FROM items WHERE active = 1 AND service = 1 ORDER BY name")
            if svc:
                form = """<form method="post" action="/zakazky/%d/hodiny" class="filters">%s
<select name="item_id">%s</select><button class="btn">Přidat %s h do materiálu a práce</button></form>""" % (
                    j["id"], app.csrf(), "".join('<option value="%d">%s (%s/%s)</option>' % (
                        s["id"], h(s["name"]), money(s["price"]), h(s["unit"])) for s in svc), qty_h(total_open))
            else:
                form = "<p class=hint>Pro přenos hodin do zakázky založte ve skladu službu (např. Práce technika, cena za hodinu).</p>"
        return """<section class="card"><h2>Odpracováno na zakázce (docházka)</h2><table class="list"><thead><tr><th>Kdo</th>
<th class=num>Celkem</th><th class=num>Zatím nepřeneseno</th></tr></thead><tbody>%s</tbody></table>%s</section>""" % (trs, form)

    def qty_h(m):
        return ("%.2f" % (round(m / 15) * 0.25)).rstrip("0").rstrip(".").replace(".", ",")

    app.job_cards = getattr(app, "job_cards", []) + [job_card]

    @app.route("/zakazky/<jid>/hodiny", ("POST",))
    def to_job(req, jid):
        j = db.one("SELECT * FROM jobs WHERE id = ?", (jid,))
        if not j:
            raise HTTPError(404, "Zakázka nenalezena")
        if j["status"] == "vyfakturovana":
            raise HTTPError(409, "Zakázka je vyfakturovaná.")
        item = db.one("SELECT * FROM items WHERE id = ? AND service = 1", (parse_id(req.f("item_id")),))
        if not item:
            raise BadInput("Vyberte službu (práci).")
        vp = req.settings["vat_payer"] == "1"
        with db.tx():
            hours = job_hours(db, j["id"])
            ids = [i for v in hours.values() for i in v["ids"]]
            total = sum(v["open"] for v in hours.values())
            if not ids:
                flash_redirect("/zakazky/%d" % j["id"], "Žádné nové hodiny k přenesení")
            qty = round(total / 15) * 0.25 or 0.25
            pos = (db.one("SELECT MAX(pos) FROM job_lines WHERE job_id = ?", (j["id"],))[0] or 0) + 1
            db.run("INSERT INTO job_lines(job_id, pos, item_id, text, qty, unit, price, vat_rate, recycling_fee) "
                   "VALUES(?,?,?,?,?,?,?,?,0)", (j["id"], pos, item["id"], item["name"], qty, item["unit"], item["price"],
                                                item["vat_rate"] if vp else 0))
            line = db.one("SELECT last_insert_rowid()")[0]
            db.run("UPDATE attendance SET billed = ? WHERE id IN (%s)" % ",".join("?" * len(ids)), [line] + ids)
            db.run("INSERT INTO job_events(job_id, ts, user, kind, text) VALUES(?,?,?,?,?)",
                   (j["id"], int(time.time()), req.user or "", "poznamka",
                    "Z docházky přeneseno %s %s – %s" % (qty_h(total), item["unit"], item["name"])))
        flash_redirect("/zakazky/%d" % j["id"], "Přidáno %s %s do materiálu a práce" % (qty_h(total), item["unit"]))
