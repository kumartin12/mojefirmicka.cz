"""Přiznání k DPH (DPHDP3) a kontrolní hlášení (DPHKH1) jako XML pro podání přes EPO finanční správy
(daneelektronicky.cz → „Elektronická podání pro finanční správu“ → nahrát soubor).

Pokrývá: vydané faktury, dobropisy a daňové doklady k přijatým zálohám, účtenky z pokladny (zjednodušené doklady),
přijaté faktury s nárokem na odpočet v plné výši, přenesenou daňovou povinnost v tuzemsku (dodavatel ř. 25 / KH A.1,
odběratel ř. 10–11 + 43–44 / KH B.1), dodání zboží a služeb do EU (ř. 20, 21 + souhrnné hlášení DPHSHV), vývoz (ř. 22),
plnění mimo tuzemsko (ř. 26), pořízení zboží a služeb z EU a služby ze zemí mimo EU (ř. 3–6, 12–13 + 43–44 / KH A.2).
Nepokrývá: dovoz zboží (celní úřad), krácený odpočet, opravy podle § 44/46, třístranný obchod.
Struktura podle XSD dphdp3_epo2.xsd / dphkh1_epo2.xsd (adisspr.mfcr.cz), verze písemností z 9. 3. 2026."""
import re
import xml.etree.ElementTree as ET
from datetime import date

from . import __version__
from .db import invoice_totals, rnd
from .epo_codes import UFO, PRACUFO

DP3_VERSION = "03.01.03"
KH1_VERSION = "03.01.14"
KH_LIMIT = 1000000          # 10 000 Kč vč. DPH v haléřích – nad limit jednotlivě (A.4 / B.2), jinak souhrnně
RATES = {21: "1", 12: "2"}  # zakl_dane1/dan1 = základní sazba, zakl_dane2/dan2 = snížená


def period_range(year, month=None, quarter=None):
    if month:
        od = date(year, month, 1)
        do = date(year + (month == 12), month % 12 + 1, 1)
    else:
        od = date(year, 3 * quarter - 2, 1)
        do = date(year + (quarter == 4), (3 * quarter) % 12 + 1, 1)
    return od.isoformat(), date.fromordinal(do.toordinal() - 1).isoformat()


def digits(s):
    return "".join(c for c in (s or "") if c.isdigit())


def cz_dic(dic):
    """Tuzemské DIČ bez „CZ“ (jen číslice), u zahraničního/žádného prázdné."""
    d = (dic or "").replace(" ", "").upper()
    if d.startswith("CZ") and d[2:].isdigit():
        return d[2:]
    return ""


class Empty(ValueError):
    """Podání se za období nepodává (např. souhrnné hlášení bez plnění do EU)."""


NAMES = {"dp3": ("priznani-dph", "Přiznání k DPH"), "kh1": ("kontrolni-hlaseni", "Kontrolní hlášení DPH"),
         "shv": ("souhrnne-hlaseni", "Souhrnné hlášení")}


def build(db, s, co, y, p, forma):
    """Podání za období → (xml, název souboru, info). y = rok, p = m1…m12 / q1…q4, forma B/O."""
    if not (y.isdigit() and len(y) == 4 and p[:1] in ("m", "q") and p[1:].isdigit()):
        raise ValueError("Neplatné období")
    year, n = int(y), int(p[1:])
    month, quarter = (n, None) if p[0] == "m" else (None, n)
    if month and not 1 <= month <= 12 or quarter and not 1 <= quarter <= 4:
        raise ValueError("Neplatné období")
    od, do = period_range(year, month, quarter)
    data = collect(db, od, do)
    forma = forma if forma in ("B", "O") else "B"
    if co == "dp3":
        xml, info = dp3(s, data, year, month, quarter, forma)
    elif co == "kh1":
        xml, info = kh1(s, data, year, month, quarter, forma)
    elif co == "shv":
        xml, info = shv(s, data, year, month, quarter, "N" if forma == "O" else "R")
        if not info["rows"]:
            raise Empty("V období nejsou žádná plnění do jiných států EU – souhrnné hlášení se nepodává")
    else:
        raise ValueError("Neznámý formulář")
    name = "%s-%d-%s.xml" % (NAMES[co][0], year, "%02d" % month if month else "Q%d" % quarter)
    return xml, name, info


def dic_ok(num):
    """Kontrola tuzemského DIČ (jen číslice) jako v EPO: 8 číslic = IČO s kontrolní číslicí (modulo 11),
    10 číslic = rodné číslo dělitelné 11 (do r. 1985 i se zbytkem 10 a nulou na konci), 9 číslic = rodné číslo
    před r. 1954 nebo DIČ přidělené úřadem (bez kontroly). Prázdné / jiná délka = chyba."""
    if not num or not num.isdigit():
        return False
    if len(num) == 8:
        r = sum(int(c) * w for c, w in zip(num[:7], range(8, 1, -1))) % 11
        return int(num[7]) == (11 - r) % 10
    if len(num) == 9:
        return True
    if len(num) == 10:
        return int(num) % 11 == 0 or (int(num[:9]) % 11 == 10 and num[9] == "0")
    return False


def bad_dics(db, od, do):
    """Doklady za období, kde tuzemské DIČ protistrany neprojde kontrolou EPO (číslo dokladu, DIČ)."""
    out = []
    for kind, sql in (("faktura", "SELECT number, cust_dic d FROM invoices WHERE status != 'stornovana' AND vat_payer = 1 "
                                   "AND tax_date BETWEEN ? AND ?"),
                      ("přijatá", "SELECT COALESCE(NULLIF(number, ''), doc_number) number, supp_dic d FROM purchases "
                                  "WHERE tax_date BETWEEN ? AND ?")):
        for r in db.q(sql, (od, do)):
            num = cz_dic(r["d"])
            if num and not dic_ok(num):
                out.append((kind, r["number"], r["d"]))
    return out


def collect(db, od, do):
    """Doklady s DPH za období podle DUZP. Vrací dict se seznamy (doklad, rekapitulace):
    issued / receipts / received = běžné tuzemské; issued_rc = vydané v režimu (regimes.py),
    received_rc = přijaté v režimu (rekapitulace = daň, kterou si plátce sám přiznává a odečítá)."""
    from .invoices import lines_of
    from .purchases import plines
    from .pos import rlines
    out = {"issued": [], "receipts": [], "received": [], "issued_rc": [], "received_rc": []}
    for inv in db.q("SELECT * FROM invoices WHERE status != 'stornovana' AND vat_payer = 1 AND kind != 'zaloha' "
                    "AND tax_date BETWEEN ? AND ? ORDER BY tax_date, number", (od, do)):
        t = invoice_totals(lines_of(db, inv["id"]), True)
        out["issued_rc" if inv["regime"] else "issued"].append((inv, t))
    for r in db.q("SELECT * FROM receipts WHERE status = 'ok' AND vat_payer = 1 AND date BETWEEN ? AND ? ORDER BY id",
                  (od, do)):
        out["receipts"].append((r, invoice_totals(rlines(db, r["id"]), True)))
    for p in db.q("SELECT * FROM purchases WHERE tax_date BETWEEN ? AND ? ORDER BY tax_date, id", (od, do)):
        t = invoice_totals(plines(db, p["id"]), True)
        if p["regime"]:
            out["received_rc"].append((p, t))
        elif t["vat"]:                     # bez DPH (neplátce dodavatel) → nic k odpočtu
            out["received"].append((p, t))
    return out


def sums(items):
    """{sazba: [základ, daň]} v haléřích."""
    s = {}
    for _, t in items:
        for r in t["recap"]:
            b = s.setdefault(r["rate"], [0, 0])
            b[0] += r["base"]
            b[1] += r["vat"]
    return s


def _kc(hal):
    return str(rnd(hal / 100))           # přiznání: celé koruny


def _hal(hal):
    return "%.2f" % (hal / 100)          # kontrolní hlášení: haléře


def _cz_date(iso):
    return "%s.%s.%s" % (iso[8:10], iso[5:7], iso[:4])


def check_settings(s):
    """Chybějící údaje pro podání (prázdný seznam = vše v pořádku)."""
    miss = []
    if s["vat_payer"] != "1":
        miss.append("v Nastavení nejste plátce DPH")
    if not cz_dic(s["firm_dic"]):
        miss.append("DIČ firmy (CZ…)")
    elif not dic_ok(cz_dic(s["firm_dic"])):
        miss.append("DIČ firmy %s má chybný kontrolní součet (EPO ho odmítne) – opravte ho" % s["firm_dic"])
    if s["epo_ufo"] not in UFO:
        miss.append("finanční úřad")
    if s["epo_pracufo"] and (s["epo_pracufo"] not in PRACUFO or PRACUFO[s["epo_pracufo"]][1] != s["epo_ufo"]):
        miss.append("územní pracoviště nepatří k vybranému finančnímu úřadu")
    if s["epo_typ_ds"] == "F" and not (s["epo_jmeno"] and s["epo_prijmeni"]):
        miss.append("jméno a příjmení (fyzická osoba)")
    if s["epo_typ_ds"] != "F" and not (s["epo_opr_jmeno"] and s["epo_opr_prijmeni"] and s["epo_opr_postaveni"]):
        miss.append("osoba oprávněná podepsat za firmu (jméno, příjmení a vztah k firmě, např. jednatel)")
    return miss


def _street(street):
    """„Hlavní 1234/5a“ → (ulice, č. p., č. or.)."""
    m = re.match(r"^(.*?)[\s,]+(\d{1,6})(?:/(\w{1,4}))?$", (street or "").strip())
    if not m:
        return (street or "")[:38], "", ""
    return m.group(1)[:38], m.group(2), m.group(3) or ""


def _veta_p(parent, s, contact=True):
    p = ET.SubElement(parent, "VetaP")
    ulice, cpop, corient = _street(s["firm_street"])
    vals = [("c_ufo", s["epo_ufo"]), ("c_pracufo", s["epo_pracufo"]), ("dic", cz_dic(s["firm_dic"])),
            ("typ_ds", s["epo_typ_ds"] or "P")]
    if (s["epo_typ_ds"] or "P") == "F":
        vals += [("jmeno", s["epo_jmeno"][:30]), ("prijmeni", s["epo_prijmeni"][:36])]
    else:
        vals += [("zkrobchjm", s["firm_name"][:255]), ("opr_jmeno", s["epo_opr_jmeno"][:20]),
                 ("opr_prijmeni", s["epo_opr_prijmeni"][:36]), ("opr_postaveni", s["epo_opr_postaveni"][:40])]
    vals += [("ulice", ulice), ("c_pop", cpop), ("c_orient", corient), ("naz_obce", (s["firm_city"] or "")[:48]),
             ("psc", digits(s["firm_zip"])[:5]), ("stat", "ČESKÁ REPUBLIKA")]
    if contact:
        vals += [("email", (s["firm_email"] or "")[:255]), ("c_telef", digits(s["firm_phone"])[-14:])]
    for k, v in vals:
        if v:
            p.set(k, v)


def _root(form, version):
    root = ET.Element("Pisemnost", nazevSW="Firmicka", verzeSW=__version__)
    return root, ET.SubElement(root, form, verzePis=version)


def _veta_d(parent, dokument, forma_attr, forma, year, month, quarter, extra=()):
    d = ET.SubElement(parent, "VetaD", dokument=dokument, k_uladis="DPH")
    d.set(forma_attr, forma)
    for k, v in extra:
        d.set(k, v)
    d.set("rok", str(year))
    if month:
        d.set("mesic", str(month))
    else:
        d.set("ctvrt", str(quarter))
    d.set("d_poddp", _cz_date(date.today().isoformat()))
    return d


def _xml(root):
    return ('<?xml version="1.0" encoding="UTF-8"?>\n' + ET.tostring(root, encoding="unicode")).encode("utf-8")


# přijaté v režimu → řádky přiznání (daň na výstupu): (základ 21 %, daň 21 %, základ 12 %, daň 12 %)
RC_IN = {"pdp": ("rez_pren23", "dan_rpren23", "rez_pren5", "dan_rpren5"),       # ř. 10, 11
         "eu_zbozi": ("p_zb23", "dan_pzb23", "p_zb5", "dan_pzb5"),              # ř. 3, 4
         "eu_sluzby": ("p_sl23_e", "dan_psl23_e", "p_sl5_e", "dan_psl5_e"),     # ř. 5, 6
         "mimo": ("p_sl23_z", "dan_psl23_z", "p_sl5_z", "dan_psl5_z")}          # ř. 12, 13
# vydané v režimu → hodnota plnění v Veta2
RC_OUT = {"pdp": "pln_rez_pren", "eu_zbozi": "dod_zb", "eu_sluzby": "pln_sluzby", "vyvoz": "pln_vyvoz", "mimo": "pln_ost"}


def rc_sums(data):
    """Součty dokladů v režimu: přijaté {regime: {sazba: [základ, daň]}}, vydané {regime: hodnota plnění}."""
    rin, rout = {}, {}
    for p, t in data.get("received_rc", []):
        tgt = rin.setdefault(p["regime"], {})
        for r in t["recap"]:
            b = tgt.setdefault(r["rate"], [0, 0])
            b[0] += r["base"]
            b[1] += r["vat"]
    for inv, t in data.get("issued_rc", []):
        rout[inv["regime"]] = rout.get(inv["regime"], 0) + t["base"]
    return rin, rout


def dp3(s, data, year, month=None, quarter=None, forma="B"):
    """Přiznání k DPH – ř. 1, 2 (tuzemsko), 3–6, 10–13 (daň přiznává příjemce), 20–22, 25, 26 (plnění bez daně),
    40, 41 (odpočet tuzemsko), 43, 44 (odpočet z ř. 3–13), 46, 62–65."""
    out = sums(data["issued"] + data["receipts"])
    inp = sums(data["received"])
    rin, rout = rc_sums(data)
    root, f = _root("DPHDP3", DP3_VERSION)
    extra = [("typ_platce", "P")]
    if s["epo_okec"]:
        extra.append(("c_okec", digits(s["epo_okec"])[:6]))
    d = _veta_d(f, "DP3", "dapdph_forma", forma, year, month, quarter, extra)
    d.set("trans", "A" if out or inp or rin or rout else "N")
    _veta_p(f, s)
    o21, o12 = out.get(21, [0, 0]), out.get(12, [0, 0])
    i21, i12 = inp.get(21, [0, 0]), inp.get(12, [0, 0])
    v1 = ET.SubElement(f, "Veta1")
    dan = 0
    fields = [("obrat23", o21[0], False), ("dan23", o21[1], True), ("obrat5", o12[0], False), ("dan5", o12[1], True)]
    for regime, (b23, d23, b5, d5) in RC_IN.items():
        r = rin.get(regime, {})
        fields += [(b23, r.get(21, [0, 0])[0], False), (d23, r.get(21, [0, 0])[1], True),
                   (b5, r.get(12, [0, 0])[0], False), (d5, r.get(12, [0, 0])[1], True)]
    for k, v, is_tax in fields:
        if v:
            v1.set(k, _kc(v))
            if is_tax:
                dan += rnd(v / 100)
    if not v1.attrib:
        f.remove(v1)
    if rout:
        v2 = ET.SubElement(f, "Veta2")
        for regime, k in RC_OUT.items():
            if rout.get(regime):
                v2.set(k, _kc(rout[regime]))
    # odpočet: tuzemsko (ř. 40, 41) + daň přiznaná jako příjemce (ř. 43, 44)
    s21 = sum(r.get(21, [0, 0])[0] for r in rin.values()), sum(r.get(21, [0, 0])[1] for r in rin.values())
    s12 = sum(r.get(12, [0, 0])[0] for r in rin.values()), sum(r.get(12, [0, 0])[1] for r in rin.values())
    odp = 0
    if inp or rin:
        v4 = ET.SubElement(f, "Veta4")
        for k, v, is_tax in (("pln23", i21[0], False), ("odp_tuz23_nar", i21[1], True), ("pln5", i12[0], False),
                             ("odp_tuz5_nar", i12[1], True), ("nar_zdp23", s21[0], False), ("od_zdp23", s21[1], True),
                             ("nar_zdp5", s12[0], False), ("od_zdp5", s12[1], True)):
            if v:
                v4.set(k, _kc(v))
                if is_tax:
                    odp += rnd(v / 100)
        v4.set("odp_sum_nar", str(odp))
    v6 = ET.SubElement(f, "Veta6", dan_zocelk=str(dan), odp_zocelk=str(odp))
    if dan >= odp:
        v6.set("dano_da", str(dan - odp))
    else:
        v6.set("dano_no", str(odp - dan))
    return _xml(root), {"dan": dan, "odp": odp, "out": out, "inp": inp, "rc_in": rin, "rc_out": rout}


def _amounts(el, recap):
    for r in recap:
        n = RATES.get(r["rate"])
        if n and (r["base"] or r["vat"]):
            el.set("zakl_dane" + n, _hal(r["base"]))
            el.set("dan" + n, _hal(r["vat"]))


def kh1(s, data, year, month=None, quarter=None, forma="B"):
    """Kontrolní hlášení – A.1 (přenesená daňová povinnost, dodavatel), A.2 (daň přiznává příjemce: EU a mimo EU),
    A.4 / A.5 (vydané), B.1 (přenesená daňová povinnost, odběratel), B.2 / B.3 (přijaté), C (kontrolní součty).
    Dobropis = záporné částky; do A.4/B.2 jde podle absolutní hodnoty dokladu vč. DPH."""
    from .regimes import eu_vat
    root, f = _root("DPHKH1", KH1_VERSION)
    _veta_d(f, "KH1", "khdph_forma", forma, year, month, quarter)
    _veta_p(f, s)
    rows = {"A1": 0, "A2": 0, "A4": 0, "B1": 0, "B2": 0}
    c = {"pln_rez_pren": 0, "rez_pren23": 0, "rez_pren5": 0, "celk_zd_a2": 0}
    for inv, t in data.get("issued_rc", []):            # A.1
        if inv["regime"] != "pdp":
            continue
        rows["A1"] += 1
        ET.SubElement(f, "VetaA1", c_radku=str(rows["A1"]), dic_odb=cz_dic(inv["cust_dic"]), c_evid_dd=inv["number"][:60],
                      duzp=_cz_date(inv["tax_date"]), zakl_dane1=_hal(t["base"]), kod_pred_pl=(inv["pdp_code"] or "")[:3])
        c["pln_rez_pren"] += t["base"]
    for p, t in data.get("received_rc", []):            # A.2
        if p["regime"] == "pdp":
            continue
        rows["A2"] += 1
        e = ET.SubElement(f, "VetaA2", c_radku=str(rows["A2"]))
        vat = eu_vat(p["supp_dic"])
        if vat and p["regime"] != "mimo":
            e.set("k_stat", vat[0])
            e.set("vatid_dod", vat[1])
        e.set("c_evid_dd", (p["number"] or p["doc_number"])[:60])
        e.set("dppd", _cz_date(p["tax_date"]))
        _amounts(e, t["recap"])
        c["celk_zd_a2"] += sum(r["base"] for r in t["recap"] if r["rate"] in RATES)
    a5, b3 = [], []
    for inv, t in data["issued"]:
        dic = cz_dic(inv["cust_dic"])
        if dic and abs(t["total"]) > KH_LIMIT:
            rows["A4"] += 1
            e = ET.SubElement(f, "VetaA4", c_radku=str(rows["A4"]), dic_odb=dic, c_evid_dd=inv["number"][:60],
                              dppd=_cz_date(inv["tax_date"]))
            _amounts(e, t["recap"])
            e.set("kod_rezim_pl", "0")
            e.set("zdph_44", "N")
        else:
            a5.append((inv, t))
    a5 += data["receipts"]
    if a5:
        e = ET.SubElement(f, "VetaA5")
        _amounts(e, [{"rate": k, "base": v[0], "vat": v[1]} for k, v in sorted(sums(a5).items(), reverse=True)])
    for p, t in data.get("received_rc", []):            # B.1
        if p["regime"] != "pdp":
            continue
        rows["B1"] += 1
        e = ET.SubElement(f, "VetaB1", c_radku=str(rows["B1"]), dic_dod=cz_dic(p["supp_dic"]),
                          c_evid_dd=(p["number"] or p["doc_number"])[:60], duzp=_cz_date(p["tax_date"]))
        _amounts(e, t["recap"])
        e.set("kod_pred_pl", (p["pdp_code"] or "")[:3])
        for r in t["recap"]:
            if r["rate"] == 21:
                c["rez_pren23"] += r["base"]
            elif r["rate"] == 12:
                c["rez_pren5"] += r["base"]
    for p, t in data["received"]:
        dic = cz_dic(p["supp_dic"])
        if dic and abs(t["total"]) > KH_LIMIT:
            rows["B2"] += 1
            e = ET.SubElement(f, "VetaB2", c_radku=str(rows["B2"]), dic_dod=dic, c_evid_dd=(p["number"] or p["doc_number"])[:60],
                              dppd=_cz_date(p["tax_date"]))
            _amounts(e, t["recap"])
            e.set("pomer", "N")
            e.set("zdph_44", "N")
        else:
            b3.append((p, t))
    if b3:
        e = ET.SubElement(f, "VetaB3")
        _amounts(e, [{"rate": k, "base": v[0], "vat": v[1]} for k, v in sorted(sums(b3).items(), reverse=True)])
    out, inp = sums(data["issued"] + data["receipts"]), sums(data["received"])
    vc = ET.SubElement(f, "VetaC")
    for k, v in (("obrat23", out.get(21, [0])[0]), ("obrat5", out.get(12, [0])[0]),
                 ("pln23", inp.get(21, [0])[0]), ("pln5", inp.get(12, [0])[0]), ("pln_rez_pren", c["pln_rez_pren"]),
                 ("rez_pren23", c["rez_pren23"]), ("rez_pren5", c["rez_pren5"]), ("celk_zd_a2", c["celk_zd_a2"])):
        if v:
            vc.set(k, _hal(v))
    return _xml(root), {"a1": rows["A1"], "a2": rows["A2"], "a4": rows["A4"], "a5": len(a5), "b1": rows["B1"],
                        "b2": rows["B2"], "b3": len(b3)}


def shv(s, data, year, month=None, quarter=None, forma="R"):
    """Souhrnné hlášení (DPHSHV): dodání zboží (kód 0) a služeb (kód 3) do jiných členských států EU, souhrnně za
    odběratele (DIČ) a kód plnění. Dobropisy se odečítají; hodnota v celých Kč zaokrouhlená nahoru."""
    import math
    from .regimes import eu_vat
    root = ET.Element("Pisemnost", nazevSW="Firmicka", verzeSW=__version__)
    f = ET.SubElement(root, "DPHSHV")
    d = ET.SubElement(f, "VetaD", dokument="SHV", k_uladis="DPH", shvies_forma=forma, rok=str(year))
    if month:
        d.set("mesic", str(month))
    else:
        d.set("ctvrt", str(quarter))
    d.set("d_poddp", _cz_date(date.today().isoformat()))
    _veta_p(f, s, contact=False)
    groups = {}
    for inv, t in data.get("issued_rc", []):
        code = {"eu_zbozi": "0", "eu_sluzby": "3"}.get(inv["regime"])
        vat = eu_vat(inv["cust_dic"])
        if not code or not vat:
            continue
        g = groups.setdefault((vat[0], vat[1], code), [0, 0])
        g[0] += 1 if t["base"] >= 0 else 0
        g[1] += t["base"]
    for n, ((stat, num, code), (cnt, val)) in enumerate(sorted(groups.items()), 1):
        ET.SubElement(f, "VetaR", c_rad=str(n), k_stat=stat, c_vat=num, k_pln_eu=code, pln_pocet=str(max(cnt, 1)),
                      pln_hodnota=str(math.ceil(val / 100)))
    return _xml(root), {"rows": len(groups)}
