"""Opakované faktury: paušály, nájmy, servisní smlouvy. Firmička v nastavený den vystaví kopii poslední faktury
z řady s novým číslem a daty (cenu nebo položky změníte úpravou poslední vystavené faktury) a případně ji rovnou
pošle e-mailem. Běží ve vlákně jednou za hodinu (main.py); když byl počítač vypnutý, doplní zmeškaná období
(nejvýš 12 naráz). Datum vystavení je den skutečného vystavení, DUZP je plánovaný den."""
import calendar as _cal
import threading
import time
from datetime import date, timedelta

from .calendar_notes import MONTHS
from .db import invoice_totals, next_invoice_number, today
from .web import h, cz_date, flash, flash_redirect, HTTPError, money

EVERY = {"mesic": "měsíčně", "ctvrtleti": "čtvrtletně", "rok": "ročně"}
STEP = {"mesic": 1, "ctvrtleti": 3, "rok": 12}
PERIOD = {"bezne": "období vystavení (listopad)", "predchozi": "předchozí období (říjen)", "": "nedoplňovat"}
PERIOD_PREFIX = "Fakturační období: "
CATCH_UP = 12
_run_lock = threading.Lock()   # hodinové vlákno a „Vystavit teď“ (i víc lidí v síti) nesmí vystavit totéž období dvakrát


def add_months(d, n, day):
    """Datum o n měsíců dál; den v měsíci podle původního dne (31. → 28./30. → zase 31.)."""
    m = d.month - 1 + n
    y, m = d.year + m // 12, m % 12 + 1
    return date(y, m, min(day, _cal.monthrange(y, m)[1]))


def period_label(d, every, which):
    if not which:
        return ""
    if which == "predchozi":
        d = add_months(d, -STEP[every], d.day)
    if every == "mesic":
        return "%s %d" % (MONTHS[d.month - 1], d.year)
    if every == "ctvrtleti":
        return "%d. čtvrtletí %d" % ((d.month - 1) // 3 + 1, d.year)
    return str(d.year)


def template(db, r):
    """Faktura, ze které se kopíruje: poslední vystavená z řady (ne stornovaná), jinak původní."""
    for iid in (r["last_invoice_id"], r["source_id"]):
        inv = db.one("SELECT * FROM invoices WHERE id = ?", (iid,)) if iid else None
        if inv and inv["status"] != "stornovana":
            return inv
    return db.one("SELECT * FROM invoices WHERE recurring_id = ? AND status != 'stornovana' ORDER BY id DESC LIMIT 1",
                  (r["id"],))


def issue(app, r, planned, s):
    """Vystaví jednu fakturu řady k plánovanému dni. Vrací (id faktury, chyba)."""
    from .invoices import lines_of, line_warranty, FORMATS
    db = app.db
    src = template(db, r)
    if not src:
        return None, "Vzorová faktura byla smazána nebo stornována – řadu založte znovu z platné faktury."
    issued = today()
    gap = (date.fromisoformat(src["due_date"]) - date.fromisoformat(src["issue_date"])).days
    note = "\n".join(x for x in (src["note"] or "").split("\n") if not x.startswith(PERIOD_PREFIX))
    label = period_label(planned, r["every"], r["period"])
    if label:
        note = (note + "\n" if note else "") + PERIOD_PREFIX + label
    inv = {x: src[x] for x in ("cust_name", "cust_address", "cust_ico", "cust_dic", "payment", "warehouse_id", "regime",
                               "pdp_code")}
    inv.update({"contact_id": str(src["contact_id"] or ""), "kind": "faktura", "issue_date": issued,
                "tax_date": min(planned.isoformat(), issued), "due_date": (date.fromisoformat(issued) + timedelta(days=max(gap, 0))).isoformat(),
                "vs": "", "note": note, "reason": "", "stock": 1})
    lines = [{k: v for k, v in dict(ln).items() if k not in ("warranty", "id", "invoice_id", "cost")}
             for ln in lines_of(db, src["id"]) if not ln["advance_id"]]
    for ln in lines:                       # nový prodej → záruka podle položky dnes (jako „Duplikovat“)
        ln["warranty"] = line_warranty(db, ln)
    with db.lock:
        inv["number"] = next_invoice_number(db, issued, s[FORMATS["faktura"]] or "{YYYY}{NNNN}")
        err = app.invoice_validate(inv, lines)
        if err:
            return None, err
        iid = app.invoice_save(inv, lines, bool(src["vat_payer"]))
        db.run("UPDATE invoices SET recurring_id = ? WHERE id = ?", (r["id"], iid))
    return iid, ""


def send(db, s, iid, to):
    from .mail import invoice_mail
    from .reminders import send_mail
    inv = db.one("SELECT i.*, c.email FROM invoices i LEFT JOIN contacts c ON c.id = i.contact_id WHERE i.id = ?", (iid,))
    subject, body, att = invoice_mail(db, s, inv)
    send_mail(s, to, subject, body, att)


def run_due(app, now=None, only=None):
    """Vystaví všechny splatné faktury (volá vlákno jednou za hodinu nebo tlačítko „Vystavit teď“). Vrací počet."""
    db = app.db
    s = db.settings()
    from . import licence
    if licence.state(db)["mode"] == "readonly":
        return 0
    d0 = now or date.today()
    with _run_lock:
        return _run(app, db, s, d0, only)


def _run(app, db, s, d0, only):
    n = 0
    rows = db.q("SELECT * FROM recurring WHERE active = 1" + (" AND id = ?" if only else ""), (only,) if only else ())
    for r in rows:
        for _ in range(CATCH_UP):
            r = db.one("SELECT * FROM recurring WHERE id = ?", (r["id"],))
            planned = date.fromisoformat(r["next_date"])
            if planned > d0 or (r["end_date"] and planned.isoformat() > r["end_date"]):
                break
            iid, err = issue(app, r, planned, s)
            nxt = add_months(planned, STEP[r["every"]], r["day"])
            if not iid:
                db.run("UPDATE recurring SET last_error = ? WHERE id = ?", (err, r["id"]))
                break
            msg = ""
            if r["auto_send"] and r["email"]:
                try:
                    send(db, s, iid, r["email"])
                except Exception as e:      # faktura je vystavená, jen e-mail neodešel – ukázat v liště
                    msg = "Faktura %s je vystavená, ale e-mail se nepodařilo odeslat: %s" % (
                        db.one("SELECT number FROM invoices WHERE id = ?", (iid,))["number"], e)
            db.run("UPDATE recurring SET last_invoice_id = ?, next_date = ?, last_error = ?, issued = issued + 1, "
                   "active = CASE WHEN ? != '' AND ? > ? THEN 0 ELSE 1 END WHERE id = ?",
                   (iid, nxt.isoformat(), msg, r["end_date"], nxt.isoformat(), r["end_date"], r["id"]))
            n += 1
    return n


def register(app):
    db = app.db

    def banner():
        bad = db.q("SELECT id, title, last_error FROM recurring WHERE last_error != ''")
        if not bad:
            return ""
        return "<div class='flash error'>Opakované faktury: %s <a href='/faktury/opakovane'>Zobrazit</a></div>" % "; ".join(
            "„%s“ – %s" % (h(b["title"]), h(b["last_error"])) for b in bad[:3])
    app.banners.append(banner)

    def form(req, r, inv, rid=None, err=""):
        s = req.settings
        esel = "".join('<option value="%s"%s>%s</option>' % (k, " selected" if k == r.get("every") else "", v)
                       for k, v in EVERY.items())
        psel = "".join('<option value="%s"%s>%s</option>' % (k, " selected" if k == r.get("period", "bezne") else "", v)
                       for k, v in PERIOD.items())
        smtp = bool(s["smtp_host"])
        total = invoice_totals(db.q("SELECT * FROM invoice_lines WHERE invoice_id = ?", (inv["id"],)), inv["vat_payer"])["total"]
        delete = ('<form method="post" action="/faktury/opakovane/%s/smazat" onsubmit="return confirm(\'Zrušit opakování? '
                  'Vystavené faktury zůstanou.\')">%s<button class="link danger">zrušit opakování</button></form>'
                  % (rid, app.csrf())) if rid else ""
        return app.page("Opakovaná faktura", """<div class="bar"><a href="%s">← Zpět</a></div>
<h1>%s</h1>%s<p>Podle faktury <a href="/faktury/%d">%s</a> – %s, %s. Každá další je kopie poslední vystavené faktury
z řady s novým číslem a daty: <b>cenu nebo položky změníte úpravou poslední faktury</b>.</p>
<form method="post" class="card grid">%s
<label class="wide">Název řady<input name="title" value="%s" required placeholder="např. Servisní paušál Bistro"></label>
<label>Opakovat<select name="every">%s</select></label>
<label>Další vystavení<input type="date" name="next_date" value="%s" required></label>
<label>Ukončit po (nepovinné)<input type="date" name="end_date" value="%s"></label>
<label>Období do poznámky<select name="period">%s</select></label>
<label class="check wide"><input type="checkbox" name="auto_send" value="1"%s%s> Rovnou poslat e-mailem (PDF + ISDOC)%s</label>
<label class="wide">E-mail odběratele<input name="email" type="email" value="%s"></label>
<div class="actions wide"><button class="btn primary">Uložit</button></div></form>%s""" % (
            "/faktury/opakovane" if rid else "/faktury/%d" % inv["id"], "Upravit opakování" if rid else "Opakovat fakturu",
            '<div class="flash error">%s</div>' % h(err) if err else "", inv["id"], h(inv["number"]), h(inv["cust_name"]),
            money(total), app.csrf(), h(r.get("title")), esel, h(r.get("next_date")), h(r.get("end_date")), psel,
            " checked" if r.get("auto_send") and smtp else "", "" if smtp else " disabled",
            "" if smtp else ' <span class="hint">– nejdřív nastavte odchozí e-mail v Nastavení → E-mail</span>',
            h(r.get("email")), delete), "/faktury")

    def read(req):
        r = {"title": req.f("title")[:120], "every": req.f("every"), "next_date": req.f("next_date"),
             "end_date": req.f("end_date"), "period": req.f("period"), "auto_send": 1 if req.f("auto_send") else 0,
             "email": req.f("email")[:200]}
        if not r["title"]:
            return r, "Vyplňte název řady."
        if r["every"] not in EVERY or r["period"] not in PERIOD:
            return r, "Vyberte, jak často opakovat."
        if not r["next_date"]:
            return r, "Zadejte den dalšího vystavení."
        if r["end_date"] and r["end_date"] < r["next_date"]:
            return r, "Konec je dřív než další vystavení."
        if r["auto_send"] and "@" not in r["email"]:
            return r, "Pro automatické odeslání zadejte e-mail odběratele."
        if r["auto_send"] and not req.settings["smtp_host"]:
            r["auto_send"] = 0
        return r, ""

    def get_inv(iid):
        inv = db.one("SELECT * FROM invoices WHERE id = ?", (iid,))
        if not inv:
            raise HTTPError(404, "Faktura nenalezena")
        return inv

    @app.route("/faktury/<iid>/opakovat", ("GET", "POST"))
    def create(req, iid):
        from .invoices import kind_of
        inv = get_inv(iid)
        if kind_of(inv) != "faktura" or inv["status"] == "stornovana":
            raise HTTPError(400, "Opakovat jde jen platnou fakturu (ne zálohu ani dobropis).")
        if req.method == "POST":
            r, err = read(req)
            if err:
                return form(req, r, inv, err=err)
            d = date.fromisoformat(r["next_date"])
            rid = db.run("INSERT INTO recurring(title, source_id, last_invoice_id, every, day, next_date, end_date, period, "
                         "auto_send, email, active, created, created_by) VALUES(?,?,?,?,?,?,?,?,?,?,1,?,?)",
                         (r["title"], inv["id"], inv["id"], r["every"], d.day, r["next_date"], r["end_date"], r["period"],
                          r["auto_send"], r["email"], int(time.time()), req.user or ""))
            db.run("UPDATE invoices SET recurring_id = ? WHERE id = ? AND recurring_id IS NULL", (rid, inv["id"]))
            flash_redirect("/faktury/opakovane", "Opakování uloženo – další faktura %s" % cz_date(r["next_date"]))
        c = db.one("SELECT email FROM contacts WHERE id = ?", (inv["contact_id"],)) if inv["contact_id"] else None
        nxt = add_months(date.fromisoformat(inv["issue_date"]), 1, date.fromisoformat(inv["issue_date"]).day)
        while nxt <= date.today():
            nxt = add_months(nxt, 1, date.fromisoformat(inv["issue_date"]).day)
        return form(req, {"title": inv["cust_name"], "every": "mesic", "next_date": nxt.isoformat(), "period": "bezne",
                          "email": c["email"] if c else ""}, inv)

    def get(rid):
        r = db.one("SELECT * FROM recurring WHERE id = ?", (rid,))
        if not r:
            raise HTTPError(404, "Opakovaná faktura nenalezena")
        return r

    @app.route("/faktury/opakovane")
    def index(req):
        rows = db.q("SELECT * FROM recurring ORDER BY active DESC, next_date")
        trs = []
        for r in rows:
            src = template(db, r)
            total = invoice_totals(db.q("SELECT * FROM invoice_lines WHERE invoice_id = ? AND advance_id IS NULL",
                                        (src["id"],)), src["vat_payer"])["total"] if src else 0
            state = ("<b class=danger>%s</b>" % h(r["last_error"]) if r["last_error"] else
                     "aktivní" if r["active"] else "<span class=hint>pozastaveno</span>")
            trs.append("""<tr><td><a href="/faktury/opakovane/%d">%s</a></td><td>%s</td><td class=num>%s</td><td>%s</td>
<td>%s</td><td>%s</td><td>%s</td><td>%s</td><td class=actions>
<form method="post" action="/faktury/opakovane/%d/stav" class="inline">%s<button class="btn small" name="akce" value="%s">%s</button></form>
<form method="post" action="/faktury/opakovane/%d/vystavit" class="inline" onsubmit="return confirm('Vystavit fakturu teď? Další se posune o jedno období.')">%s<button class="btn small">Vystavit teď</button></form></td></tr>""" % (
                r["id"], h(r["title"]), h(src["cust_name"]) if src else "—", money(total) if src else "", EVERY[r["every"]],
                cz_date(r["next_date"]) if r["active"] else "—", "e-mailem" if r["auto_send"] else "<span class=hint>ne</span>",
                '<a href="/faktury/%d">%s</a>' % (src["id"], h(src["number"])) if src else "", state,
                r["id"], app.csrf(), "pauza" if r["active"] else "obnovit", "Pozastavit" if r["active"] else "Obnovit",
                r["id"], app.csrf()))
        return app.page("Opakované faktury", """%s<div class="bar"><a href="/faktury">← Vydané faktury</a></div>
<h1>Opakované faktury</h1><p class="hint">Paušály, nájmy, servisní smlouvy. Novou řadu založíte na detailu faktury tlačítkem
„Opakovat“. Firmička fakturu vystaví sama v nastavený den (když je spuštěná; zmeškané dny doplní při dalším spuštění).</p>
<table class="list"><thead><tr><th>Řada</th><th>Odběratel</th><th class=num>Částka</th><th>Opakování</th><th>Další</th>
<th>Poslat</th><th>Poslední faktura</th><th>Stav</th><th></th></tr></thead><tbody>%s</tbody></table>""" % (
            flash(req), "".join(trs) or "<tr><td colspan=9 class=empty>Zatím žádné. Otevřete fakturu a zvolte „Opakovat“.</td></tr>"),
            "/faktury")

    @app.route("/faktury/opakovane/<rid>", ("GET", "POST"))
    def edit(req, rid):
        r = get(rid)
        inv = template(db, r)
        if not inv:
            raise HTTPError(409, "Vzorová faktura byla smazána nebo stornována – řadu zrušte a založte znovu.")
        if req.method == "POST":
            new, err = read(req)
            if err:
                return form(req, dict(dict(r), **new), inv, rid, err)
            db.run("UPDATE recurring SET title = ?, every = ?, day = ?, next_date = ?, end_date = ?, period = ?, auto_send = ?, "
                   "email = ?, last_error = '' WHERE id = ?",
                   (new["title"], new["every"], date.fromisoformat(new["next_date"]).day, new["next_date"], new["end_date"],
                    new["period"], new["auto_send"], new["email"], r["id"]))
            flash_redirect("/faktury/opakovane", "Uloženo")
        return form(req, dict(r), inv, rid)

    @app.route("/faktury/opakovane/<rid>/stav", ("POST",))
    def toggle(req, rid):
        r = get(rid)
        on = req.f("akce") == "obnovit"
        if on and r["end_date"] and r["next_date"] > r["end_date"]:
            flash_redirect("/faktury/opakovane", "Řada už skončila – prodlužte konec v úpravě")
        db.run("UPDATE recurring SET active = ?, last_error = '' WHERE id = ?", (1 if on else 0, r["id"]))
        flash_redirect("/faktury/opakovane", "Obnoveno" if on else "Pozastaveno")

    @app.route("/faktury/opakovane/<rid>/vystavit", ("POST",))
    def issue_now(req, rid):
        r = get(rid)
        if not r["active"]:
            flash_redirect("/faktury/opakovane", "Řada je pozastavená")
        planned = r["next_date"]
        # nejbližší plánovanou fakturu vystavit hned (další se posune o období), zmeškané doplnit
        if not run_due(app, now=max(date.fromisoformat(planned), date.today()), only=r["id"]):
            r2 = get(rid)
            if r2["next_date"] != planned and r2["last_invoice_id"]:     # mezitím ji vystavil někdo jiný (dvojklik, síť)
                flash_redirect("/faktury/%d" % r2["last_invoice_id"], "Faktura už byla vystavena")
            flash_redirect("/faktury/opakovane", "Fakturu se nepodařilo vystavit")
        r = get(rid)
        flash_redirect("/faktury/%d" % r["last_invoice_id"], "Faktura vystavena%s" % (
            " · " + r["last_error"] if r["last_error"] else ""))

    @app.route("/faktury/opakovane/<rid>/smazat", ("POST",))
    def delete(req, rid):
        r = get(rid)
        with db.tx():
            db.run("UPDATE invoices SET recurring_id = NULL WHERE recurring_id = ?", (r["id"],))
            db.run("DELETE FROM recurring WHERE id = ?", (r["id"],))
        flash_redirect("/faktury/opakovane", "Opakování zrušeno, vystavené faktury zůstaly")

    app.recurring_run = lambda: run_due(app)
