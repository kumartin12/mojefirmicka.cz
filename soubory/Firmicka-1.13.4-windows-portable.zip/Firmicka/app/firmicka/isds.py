"""Datová schránka (ISDS) – odeslání podání na finanční úřad, přehled odeslaných a přijatých zpráv.

Webové služby ISDS (SOAP, http://isds.czechpoint.cz/v20) s přihlášením jménem a heslem (basic autentizace) podle
Provozního řádu ISDS. Heslo se nikam neukládá – drží se jen v paměti programu po dobu práce (30 minut nečinnosti).
Pozor: načtení seznamu PŘIJATÝCH zpráv je podle zákona doručí (začnou běžet lhůty) – proto jen na výslovný pokyn.
"""
import base64
import os
import threading
import time
import urllib.error
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone

NS = "http://isds.czechpoint.cz/v20"
HOSTS = {"test": "https://ws1.datovka-test.gov.cz", "ostre": "https://ws1.datovka.gov.cz"}
ENV_NAMES = {"test": "testovací prostředí (Veřejný test ISDS)", "ostre": "ostrý provoz"}
PORTALS = {"test": "https://www.datovka-test.gov.cz", "ostre": "https://www.datovka.gov.cz"}
# ID datových schránek finančních úřadů (kód FÚ z EPO → ID). Před odesláním se název ověří přímo v ISDS.
FU_BOX = {"13": "7cs8cge", "451": "7nyn2d9", "452": "6sxny3p", "453": "scdnz6b", "454": "gf9n2e3", "455": "q9in2ev",
          "456": "qjfn2bj", "457": "zcqn2bf", "458": "fj8ny4i", "459": "95zn2bb", "460": "tqjn2cy", "461": "qdhny4c",
          "462": "25nnz67", "463": "4hun2cu", "464": "n69nz5y"}
STATUS = {"1": "podána", "2": "opatřena časovým razítkem", "3": "nalezen virus – nedoručena", "4": "dodána",
          "5": "doručena fikcí", "6": "doručena", "7": "přečtena", "8": "nedoručitelná (schránka znepřístupněna)",
          "9": "smazána", "10": "v datovém trezoru"}
IDLE = 30 * 60
TIMEOUT = 90


class IsdsError(Exception):
    pass


def q(tag):
    return "{%s}%s" % (NS, tag)


def esc(s):
    return (str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;"))


def call(env, user, pwd, path, op, inner, base=None):
    """SOAP 1.1 požadavek → element odpovědi (…Response). Chyba přihlášení / stavový kód ≠ 0000 → IsdsError."""
    url = (base or HOSTS[env]) + path
    body = ('<?xml version="1.0" encoding="UTF-8"?><soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" '
            'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><soap:Body><%s xmlns="%s">%s</%s></soap:Body>'
            '</soap:Envelope>' % (op, NS, inner, op)).encode("utf-8")
    auth = base64.b64encode(("%s:%s" % (user, pwd)).encode("utf-8")).decode()
    req = urllib.request.Request(url, data=body, headers={"Content-Type": "text/xml; charset=utf-8", "SOAPAction": '""',
                                                          "Authorization": "Basic " + auth})
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
            raw = r.read()
    except urllib.error.HTTPError as e:
        if e.code == 401:
            raise IsdsError("Přihlášení odmítnuto – zkontrolujte jméno a heslo. Pokud máte ve schránce zakázané "
                            "přihlašování heslem (jen Mobilní klíč / Identita občana), tímto způsobem se připojit nejde.")
        raw = e.read()
        if not raw:
            raise IsdsError("Datová schránka odpověděla chybou HTTP %d" % e.code)
    except (urllib.error.URLError, OSError) as e:
        raise IsdsError("Datová schránka nedostupná: %s" % getattr(e, "reason", e))
    trace = os.environ.get("FIRMICKA_ISDS_TRACE")   # jen pro ladění: odpovědi (bez hesla) do souboru
    if trace:
        with open(trace, "ab") as f:
            f.write(b"\n=== " + op.encode() + b" " + url.encode() + b"\n" + raw[:20000] + b"\n")
    try:
        root = ET.fromstring(raw)
    except ET.ParseError:
        raise IsdsError("Nečitelná odpověď datové schránky")
    fault = root.find(".//{http://schemas.xmlsoap.org/soap/envelope/}Fault")
    if fault is not None:
        raise IsdsError("Chyba datové schránky: %s" % (fault.findtext("faultstring") or "neznámá")[:300])
    resp = root.find(".//" + q(op + "Response"))
    if resp is None:
        raise IsdsError("Neočekávaná odpověď datové schránky")
    st = resp.find(q("dmStatus"))
    if st is None:
        st = resp.find(q("dbStatus"))
    if st is not None:
        code = st.findtext(q("dmStatusCode")) or st.findtext(q("dbStatusCode")) or ""
        if code and code != "0000":
            msg = st.findtext(q("dmStatusMessage")) or st.findtext(q("dbStatusMessage")) or ""
            raise IsdsError("Datová schránka: %s (kód %s)" % (msg[:300], code))
    return resp


def text(el, tag):
    return (el.findtext(q(tag)) or "").strip() if el is not None else ""


class Box:
    """Přihlášení k jedné schránce (jméno + heslo jen v paměti)."""

    def __init__(self, env, user, pwd, base=None):
        self.env, self.user, self.pwd, self.base = env, user, pwd, base
        self.last = time.time()
        self.owner = {}

    def _call(self, path, op, inner):
        self.last = time.time()
        return call(self.env, self.user, self.pwd, path, op, inner, self.base)

    def owner_info(self):
        r = self._call("/DS/DsManage", "GetOwnerInfoFromLogin", "<dbDummy/>")
        o = r.find(q("dbOwnerInfo"))
        name = text(o, "firmName") or " ".join(x for x in (text(o, "pnFirstName"), text(o, "pnLastName")) if x)
        self.owner = {"id": text(o, "dbID"), "name": name, "type": text(o, "dbType")}
        return self.owner

    def box_name(self, dbid):
        """Oficiální název schránky podle ID (vyhledávání ISDS) – kvůli kontrole adresáta před odesláním."""
        r = self._call("/DS/df", "ISDSSearch2", "<searchText>%s</searchText><searchType>DBID</searchType>"
                                               "<searchScope>ALL</searchScope><page>0</page><pageSize>1</pageSize>"
                                               "<highlighting>false</highlighting>" % esc(dbid))
        for res in r.iter(q("dbResult")):
            if text(res, "dbID") == dbid:
                return text(res, "dbName"), text(res, "dbAddress")
        raise IsdsError("Schránka s ID %s neexistuje (nebo není dostupná)" % dbid)

    def search(self, phrase, limit=20):
        """Vyhledání schránek podle názvu (jen orgány veřejné moci) → [(id, název, adresa)]."""
        r = self._call("/DS/df", "ISDSSearch2", "<searchText>%s</searchText><searchType>GENERAL</searchType>"
                                               "<searchScope>OVM</searchScope><page>0</page><pageSize>%d</pageSize>"
                                               "<highlighting>false</highlighting>" % (esc(phrase[:100]), limit))
        return [(text(x, "dbID"), text(x, "dbName"), text(x, "dbAddress")) for x in r.iter(q("dbResult"))]

    def send(self, recipient, annotation, files, ref=""):
        """files = [(název, mime, bytes)], první je hlavní písemnost. Vrací ID zprávy."""
        nil = lambda t: '<%s xsi:nil="true"/>' % t  # noqa: E731 – pořadí prvků obálky podle specifikace (CreateMessage)
        env = ("<dmEnvelope>" + nil("dmSenderOrgUnit") + nil("dmSenderOrgUnitNum") +
               "<dbIDRecipient>%s</dbIDRecipient>" % esc(recipient) + nil("dmRecipientOrgUnit") + nil("dmRecipientOrgUnitNum") +
               nil("dmToHands") + "<dmAnnotation>%s</dmAnnotation>" % esc(annotation[:255]) + nil("dmRecipientRefNumber") +
               ("<dmSenderRefNumber>%s</dmSenderRefNumber>" % esc(ref[:50]) if ref else nil("dmSenderRefNumber")) +
               nil("dmRecipientIdent") + nil("dmSenderIdent") + nil("dmLegalTitleLaw") + nil("dmLegalTitleYear") +
               nil("dmLegalTitleSect") + nil("dmLegalTitlePar") + nil("dmLegalTitlePoint") +
               "<dmPersonalDelivery>false</dmPersonalDelivery>" + nil("dmAllowSubstDelivery") + "</dmEnvelope>")
        fs = "".join('<dmFile dmMimeType="%s" dmFileMetaType="%s" dmFileDescr="%s"><dmEncodedContent>%s</dmEncodedContent>'
                     '</dmFile>' % (esc(mime), "main" if i == 0 else "enclosure", esc(name[:255]),
                                    base64.b64encode(data).decode()) for i, (name, mime, data) in enumerate(files))
        r = self._call("/DS/dz", "CreateMessage", env + "<dmFiles>" + fs + "</dmFiles>")
        mid = text(r, "dmID")
        if not mid:
            raise IsdsError("Datová schránka nevrátila číslo zprávy")
        return mid

    def _list(self, op, days):
        to = datetime.now(timezone.utc) + timedelta(minutes=5)
        fr = to - timedelta(days=days)
        f = lambda d: d.strftime("%Y-%m-%dT%H:%M:%S.000+00:00")  # noqa: E731
        r = self._call("/DS/dx", op, "<dmFromTime>%s</dmFromTime><dmToTime>%s</dmToTime>%s<dmStatusFilter>-1</dmStatusFilter>"
                                     "<dmOffset>1</dmOffset><dmLimit>500</dmLimit>" % (
                           f(fr), f(to), "<dmSenderOrgUnitNum xsi:nil=\"true\"/>" if "Sent" in op else
                           "<dmRecipientOrgUnitNum xsi:nil=\"true\"/>"))
        out = []
        for rec in r.iter(q("dmRecord")):
            out.append({k: text(rec, k) for k in ("dmID", "dbIDSender", "dmSender", "dbIDRecipient", "dmRecipient",
                                                  "dmAnnotation", "dmMessageStatus", "dmDeliveryTime", "dmAcceptanceTime",
                                                  "dmSenderRefNumber")})
        return out

    def sent(self, days=90):
        return self._list("GetListOfSentMessages", days)

    def received(self, days=90):
        """POZOR: doručí došlé zprávy (právní účinky)."""
        return self._list("GetListOfReceivedMessages", days)

    def download(self, mid):
        """Přijatá zpráva → (obálka dict, [(název, mime, bytes)])."""
        r = self._call("/DS/dz", "MessageDownload", "<dmID>%s</dmID>" % esc(mid))
        env = r.find(".//" + q("dmEnvelope"))
        files = []
        for f in r.iter(q("dmFile")):
            files.append((f.get("dmFileDescr") or "priloha", f.get("dmMimeType") or "",
                          base64.b64decode(f.findtext(q("dmEncodedContent")) or "")))
        return {k: text(env, k) for k in ("dmID", "dmSender", "dbIDSender", "dmAnnotation", "dmDeliveryTime")}, files

    def zfo(self, mid, sent):
        """Podepsaná zpráva (ZFO) – doklad pro archiv."""
        op = "SignedSentMessageDownload" if sent else "SignedMessageDownload"
        r = self._call("/DS/dz", op, "<dmID>%s</dmID>" % esc(mid))
        return base64.b64decode(r.findtext(q("dmSignature")) or "")

    def delivery(self, mid):
        """Doručenka: (stav, [(čas, událost)]) a podepsaná doručenka (ZFO)."""
        r = self._call("/DS/dx", "GetDeliveryInfo", "<dmID>%s</dmID>" % esc(mid))
        events = [(text(e, "dmEventTime"), text(e, "dmEventDescr")) for e in r.iter(q("dmEvent"))]
        status = ""
        for el in r.iter(q("dmMessageStatus")):
            status = (el.text or "").strip()
        return status, events

    def signed_delivery(self, mid):
        r = self._call("/DS/dx", "GetSignedDeliveryInfo", "<dmID>%s</dmID>" % esc(mid))
        return base64.b64decode(r.findtext(q("dmSignature")) or "")


class Sessions:
    """Přihlášení ke schránce podle přihlášení do Firmičky (klíč = token relace)."""

    def __init__(self):
        self.lock = threading.Lock()
        self.boxes = {}

    def get(self, key):
        with self.lock:
            b = self.boxes.get(key)
            if b and time.time() - b.last > IDLE:
                self.boxes.pop(key, None)
                b = None
            return b

    def put(self, key, box):
        with self.lock:
            self.boxes[key] = box

    def drop(self, key):
        with self.lock:
            self.boxes.pop(key, None)
