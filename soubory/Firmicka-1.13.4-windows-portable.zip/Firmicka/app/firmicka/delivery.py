"""Dodací listy: průvodní doklad o předání zboží odběrateli (není daňový doklad ani faktura). Vydáním se zboží odepíše
ze skladu; fakturovat jde jeden nebo víc dodacích listů téhož odběratele najednou – faktura už sklad znovu neodepisuje
(invoices.from_delivery). Storno dodacího listu vrátí zboží na sklad. Tisk s cenami nebo bez nich, s podpisem převzetí."""
from datetime import date

from . import docs, images
from .db import next_invoice_number, today, now, service_ids, invoice_totals, kit_map, expand_kit
from .warehouses import wh_select, read_wh, default_wh, wh_names
from .web import h, qty, cz_date, flash, flash_redirect, HTTPError, Response, allowed

STATUS = {"vydan": "Vydaný", "vyfakturovan": "Vyfakturovaný", "stornovan": "Stornovaný"}
TAG = {"vydan": "vystavena", "vyfakturovan": "zaplacena", "stornovan": "stornovana"}
NOTE = "Dodací list není daňový doklad."


def dlines(db, did):
    return db.q("SELECT * FROM delivery_lines WHERE delivery_id = ? ORDER BY pos", (did,))


def sync_stock(db, did):
    """Výdej ze skladu podle dodacího listu (volat v transakci); stornovaný nic neodepisuje."""
    d = db.one("SELECT * FROM delivery_notes WHERE id = ?", (did,))
    db.run("DELETE FROM movements WHERE delivery_id = ?", (did,))
    if not d or d["status"] == "stornovan":
        return
    svc = service_ids(db)
    km = kit_map(db)
    for ln in dlines(db, did):
        if not ln["item_id"]:
            continue
        for item, q in expand_kit(km, ln["item_id"], ln["qty"]):          # sada → součásti
            if item not in svc:
                db.run("INSERT INTO movements(item_id, date, qty, kind, doc, delivery_id, warehouse_id, unit_cost) "
                       "VALUES(?,?,?,'dodaci',?,?,?,0)", (item, d["issue_date"], -q, d["number"], did, d["warehouse_id"]))


def release_for_invoice(db, inv_id):
    """Faktura z dodacích listů stornována / smazána → dodací listy jsou znovu k vyfakturování (v transakci)."""
    db.run("UPDATE delivery_notes SET status = 'vydan', invoice_id = NULL WHERE invoice_id = ?", (inv_id,))


def register(app):
    db = app.db

    @app.route("/dodaci")
    def index(req):
        st = req.args.get("stav", "")
        sql, args = "SELECT * FROM delivery_notes", ()
        if st in STATUS:
            sql, args = sql + " WHERE status = ?", (st,)
        rows = db.q(sql + " ORDER BY issue_date DESC, id DESC LIMIT 500", args)
        inv_ok = allowed(req.perms, "/faktury")
        trs = "".join(
            "<tr><td>%s</td><td><a href='/dodaci/%d'>%s</a></td><td>%s</td><td>%s</td><td class=num>%s</td>"
            "<td><span class='tag %s'>%s</span></td></tr>" % (
                ("<input type=checkbox name=dl value=%d form=fakturovat aria-label='Vybrat %s'>" % (d["id"], h(d["number"])))
                if d["status"] == "vydan" and inv_ok else "", d["id"], h(d["number"]), h(d["cust_name"]),
                cz_date(d["issue_date"]), db.one("SELECT COUNT(*) FROM delivery_lines WHERE delivery_id = ?", (d["id"],))[0],
                TAG[d["status"]], STATUS[d["status"]] + (" – faktura" if d["invoice_id"] else "")) for d in rows)
        ssel = "".join('<option value="%s"%s>%s</option>' % (k, " selected" if k == st else "", v)
                       for k, v in [("", "Všechny")] + list(STATUS.items()))
        bulk = ('<form id="fakturovat" action="/faktury/nova" class="actions"><input type="hidden" name="dodaci_vyber" value="1">'
                '<button class="btn ok">Vyfakturovat vybrané</button><span class="hint">Vyberte dodací listy jednoho odběratele – '
                'vznikne jedna faktura se všemi položkami.</span></form>') if inv_ok and rows else ""
        return app.page("Dodací listy", """%s<div class="bar"><h1>Dodací listy</h1>
<a class="btn primary" href="/dodaci/novy">+ Nový dodací list</a></div>
<form class="filters"><select name="stav" onchange="this.form.submit()">%s</select></form>
<table class="list"><thead><tr><th></th><th>Číslo</th><th>Odběratel</th><th>Datum</th><th class=num>Položek</th><th>Stav</th>
</tr></thead><tbody>%s</tbody></table>%s%s
<p class="hint">Dodací list potvrzuje předání zboží a odepíše ho ze skladu. Není to daňový doklad – fakturu vystavíte potom,
klidně za víc dodacích listů najednou (zboží se podruhé neodepíše).</p>""" % (
            flash(req), ssel, trs, "" if rows else "<p class=empty>Zatím žádné dodací listy.</p>", bulk), "/sklad")

    def form(req, d, lines, did=None, err=""):
        vp = d.get("vat_payer", req.settings["vat_payer"] == "1") if did else req.settings["vat_payer"] == "1"
        return app.page("Dodací list", """<h1>%s</h1>%s<form method="post" id="invoice" data-vat="%d" data-sale="1">%s
<div class="grid">%s
<label>Číslo<input name="number" value="%s" required>%s</label>
<label>Datum předání<input type="date" name="issue_date" value="%s" required></label>
%s
<label class="check wide"><input type="checkbox" name="show_prices" value="1"%s> Tisknout ceny <span class="hint">(bez nich
dodací list ukazuje jen zboží a množství)</span></label></div>
%s<label class="wide">Poznámka<textarea name="note" rows="2">%s</textarea></label>
<div class="actions"><button class="btn primary">Uložit dodací list</button><a class="btn" href="%s">Zrušit</a></div></form>""" % (
            "Upravit dodací list %s" % h(d["number"]) if did else "Nový dodací list",
            '<div class="flash error">%s</div>' % h(err) if err else "", 1 if vp else 0, app.csrf(),
            docs.customer_box(db, d), h(d["number"]),
            docs.rev_input(d) if did else docs.auto_number_input(d, series="dodaci"), h(d["issue_date"]),
            wh_select(db, d.get("warehouse_id") or default_wh(db, req), label="Vydat ze skladu"),
            " checked" if d.get("show_prices", 1) else "", docs.lines_editor(db, lines, vp), h(d.get("note")),
            "/dodaci/%s" % did if did else "/dodaci"), "/sklad")

    def read(req, vp, fallback=None):
        d = docs.read_customer(req)
        d.update({k: req.f(k) for k in ("number", "issue_date")})
        d["note"] = req.form.get("note", "").strip()
        d["show_prices"] = 1 if req.f("show_prices") else 0
        d["warehouse_id"] = read_wh(db, req, fallback)
        return d, docs.read_lines(req, vp, db)

    def validate(d, lines, did=None):
        if not d["cust_name"] or not d["number"]:
            return "Vyplňte odběratele a číslo"
        if not lines:
            return "Dodací list musí mít aspoň jednu položku"
        if any(ln["qty"] <= 0 for ln in lines):
            return "Množství musí být kladné (vrácení zboží řešte dobropisem nebo příjemkou)"
        if db.one("SELECT id FROM delivery_notes WHERE number = ? AND id != ?", (d["number"], did or 0)):
            return "Dodací list %s už existuje" % d["number"]
        try:
            date.fromisoformat(d["issue_date"])
        except ValueError:
            return "Neplatné datum"
        return ""

    def save(d, lines, vp, did=None):
        with db.tx():
            cid = docs.save_contact(db, d)
            vals = (cid, d["cust_name"], d["cust_address"], d["cust_ico"], d["cust_dic"], d["number"], d["issue_date"],
                    d["warehouse_id"], d["note"], d["show_prices"])
            cols = "contact_id, cust_name, cust_address, cust_ico, cust_dic, number, issue_date, warehouse_id, note, show_prices"
            if did:
                db.run("UPDATE delivery_notes SET %s WHERE id = ?" % ", ".join(c.strip() + "=?" for c in cols.split(",")),
                       vals + (did,))
            else:
                did = db.run("INSERT INTO delivery_notes(%s, vat_payer, created) VALUES(%s)" % (
                    cols, ",".join("?" * (len(vals) + 2))), vals + (1 if vp else 0, now()))
            docs.write_lines(db, "delivery_lines", "delivery_id", did, lines)
            sync_stock(db, did)
        return did

    def get(did):
        d = db.one("SELECT * FROM delivery_notes WHERE id = ?", (did,))
        if not d:
            raise HTTPError(404, "Dodací list neexistuje")
        return d

    @app.route("/dodaci/cislo")
    def number_for_date(req):
        try:
            day = date.fromisoformat(req.args.get("datum", "")).isoformat()
        except ValueError:
            raise HTTPError(400)
        return Response(next_invoice_number(db, day, req.settings["delivery_format"] or "DL{YYYY}{NNNN}", "delivery_notes"),
                        ctype="text/plain; charset=utf-8")

    @app.route("/dodaci/novy", ("GET", "POST"))
    def new(req):
        vp = req.settings["vat_payer"] == "1"
        fmt = req.settings["delivery_format"] or "DL{YYYY}{NNNN}"
        if req.method == "POST":
            d, lines = read(req, vp)
            with db.lock:
                d["number"], msg = docs.auto_number(db, req, d["number"], d["issue_date"], fmt, "delivery_notes")
                d["number_auto"] = d["number"] if msg else req.f("number_auto")
                err = validate(d, lines)
                if err:
                    return form(req, d, lines, err=err)
                did = save(d, lines, vp)
            flash_redirect("/dodaci/%d" % did, "Dodací list uložen, zboží odepsáno ze skladu" + (" · " + msg if msg else ""))
        day = today()
        d = {"number": next_invoice_number(db, day, fmt, "delivery_notes"), "issue_date": day, "show_prices": 1}
        from .contacts import prefill
        d.update({x: v for x, v in prefill(db, req).items() if x in ("contact_id", "cust_name", "cust_address", "cust_ico", "cust_dic")})
        lines = []
        if req.args.get("z"):                     # duplikovat
            o = db.one("SELECT * FROM delivery_notes WHERE id = ?", (req.args["z"],))
            if o:
                d.update({k: o[k] for k in ("contact_id", "cust_name", "cust_address", "cust_ico", "cust_dic", "note",
                                            "warehouse_id", "show_prices")})
                lines = [dict(ln) for ln in dlines(db, o["id"])]
        return form(req, d, lines)

    @app.route("/dodaci/<did>/upravit", ("GET", "POST"))
    def edit(req, did):
        d = get(did)
        if d["status"] != "vydan":
            flash_redirect("/dodaci/%d" % d["id"], "Vyfakturovaný nebo stornovaný dodací list už nejde upravit")
        if req.method == "POST":
            nd, lines = read(req, d["vat_payer"], d["warehouse_id"])
            with db.lock:
                err = docs.REV_MSG if docs.rev_conflict(db, req, "delivery_notes", d["id"], nd) else validate(nd, lines, d["id"])
                if err:
                    return form(req, dict(nd, vat_payer=d["vat_payer"]), lines, d["id"], err)
                save(nd, lines, d["vat_payer"], d["id"])
            flash_redirect("/dodaci/%d" % d["id"], "Uloženo")
        return form(req, dict(d, rev=docs.doc_rev(db, "delivery_notes", d["id"])), [dict(ln) for ln in dlines(db, d["id"])],
                    d["id"])

    @app.route("/dodaci/<did>/stav", ("POST",))
    def set_status(req, did):
        d = get(did)
        a = req.f("akce")
        with db.tx():
            d = get(did)
            if a == "storno" and d["status"] == "vydan":
                db.run("UPDATE delivery_notes SET status = 'stornovan' WHERE id = ?", (d["id"],))
                msg = "Dodací list stornován, zboží vráceno na sklad"
            elif a == "obnovit" and d["status"] == "stornovan":
                db.run("UPDATE delivery_notes SET status = 'vydan' WHERE id = ?", (d["id"],))
                msg = "Dodací list obnoven, zboží znovu odepsáno"
            else:
                raise HTTPError(400, "Tuto akci nejde provést" + (" – dodací list je vyfakturovaný" if d["invoice_id"] else ""))
            sync_stock(db, d["id"])
        flash_redirect("/dodaci/%d" % d["id"], msg)

    @app.route("/dodaci/<did>/smazat", ("POST",))
    def delete(req, did):
        d = get(did)
        if d["invoice_id"]:
            flash_redirect("/dodaci/%d" % d["id"], "Vyfakturovaný dodací list nejde smazat – nejdřív stornujte fakturu")
        with db.tx():
            db.run("DELETE FROM movements WHERE delivery_id = ?", (d["id"],))
            db.run("DELETE FROM delivery_notes WHERE id = ?", (d["id"],))
        flash_redirect("/dodaci", "Dodací list %s smazán (zboží vráceno na sklad)" % d["number"])

    @app.route("/dodaci/<did>/pdf")
    def pdf(req, did):
        from . import pdfdoc
        d = get(did)
        return Response(pdfdoc.delivery_pdf(d, dlines(db, d["id"]), req.settings, app.data_dir), ctype="application/pdf",
                        headers=[("Content-Disposition", 'inline; filename="dodaci-list-%s.pdf"' %
                                  "".join(c for c in d["number"] if c.isalnum() or c in "-_"))])

    @app.route("/dodaci/<did>")
    def detail(req, did):
        d = get(did)
        s = req.settings
        lines = dlines(db, d["id"])
        if d["show_prices"]:
            table, _ = docs.lines_table(lines, d["vat_payer"])
        else:
            table = ("<table class='lines-print'><thead><tr><th>Popis</th><th class=num>Množství</th></tr></thead><tbody>%s"
                     "</tbody></table>" % "".join("<tr><td>%s</td><td class=num>%s %s</td></tr>" % (
                         h(ln["text"]), qty(ln["qty"]), h(ln["unit"])) for ln in lines))
        acts = ['<a class="btn primary" href="/dodaci/%d/pdf" target="_blank">PDF / tisk</a>' % d["id"]]
        inv_ok = allowed(req.perms, "/faktury")
        if d["status"] == "vydan":
            acts.append('<a class="btn" href="/dodaci/%d/upravit">Upravit</a>' % d["id"])
            if inv_ok:
                acts.append('<a class="btn ok" href="/faktury/nova?dodaci=%d">Vyfakturovat</a>' % d["id"])
            acts.append('<form method="post" action="/dodaci/%d/stav" class="inline" onsubmit="return confirm(\'Stornovat dodací '
                        'list? Zboží se vrátí na sklad.\')">%s<input type="hidden" name="akce" value="storno"><button class="btn">'
                        'Stornovat</button></form>' % (d["id"], app.csrf()))
        elif d["status"] == "stornovan":
            acts.append('<form method="post" action="/dodaci/%d/stav" class="inline">%s<input type="hidden" name="akce" '
                        'value="obnovit"><button class="btn">Obnovit</button></form>' % (d["id"], app.csrf()))
        if d["invoice_id"]:
            n = db.one("SELECT number FROM invoices WHERE id = ?", (d["invoice_id"],))
            acts.append('<a class="btn" href="/faktury/%d">→ Faktura %s</a>' % (d["invoice_id"], h(n["number"] if n else "")))
        acts.append('<a class="btn" href="/dodaci/novy?z=%d">Duplikovat</a>' % d["id"])
        if not d["invoice_id"]:
            acts.append('<form method="post" action="/dodaci/%d/smazat" class="inline" onsubmit="return confirm(\'Smazat dodací '
                        'list? Zboží se vrátí na sklad.\')">%s<button class="link danger">smazat</button></form>' % (d["id"], app.csrf()))
        whn = wh_names(db)
        doc = """<article class="invoice"><header><div>%s<h1>Dodací list %s</h1><div class="sub">%s</div></div></header>
<div class="parties"><section><h3>Dodavatel</h3>%s</section>
<section><h3>Odběratel</h3><b>%s</b><div>%s</div>%s</section></div>
<div class="payinfo"><div><span>Datum předání</span>%s</div>%s%s</div>
%s%s<p class='note'>%s</p>
<div class="sign"><div>Předal (podpis)</div><div>Převzal (jméno, podpis, datum)</div></div>
<footer><div>%s</div><div>Vystaveno programem Firmička</div></footer></article>""" % (
            images.inline(app.data_dir, "logo"), h(d["number"]), STATUS[d["status"]] if d["status"] != "vydan" else "",
            docs.firm_block(s), h(d["cust_name"]), h(d["cust_address"]).replace("\n", "<br>"),
            "".join("<div>%s: %s</div>" % (k, h(v)) for k, v in (("IČO", d["cust_ico"]), ("DIČ", d["cust_dic"])) if v),
            cz_date(d["issue_date"]),
            "<div><span>Sklad</span>%s</div>" % h(whn.get(d["warehouse_id"], "")) if len(whn) > 1 else "",
            "<div><span>Faktura</span>%s</div>" % h(db.one("SELECT number FROM invoices WHERE id = ?", (d["invoice_id"],))["number"])
            if d["invoice_id"] and db.one("SELECT 1 FROM invoices WHERE id = ?", (d["invoice_id"],)) else "",
            table, "<p class='note'>%s</p>" % h(d["note"]).replace("\n", "<br>") if d["note"] else "", NOTE,
            s["firm_register"])
        return app.page("Dodací list " + d["number"], flash(req) + '<div class="bar noprint"><a href="/dodaci">← Dodací listy</a>'
                        '<div class="actions">%s</div></div>' % "".join(acts) + doc, "/sklad")
