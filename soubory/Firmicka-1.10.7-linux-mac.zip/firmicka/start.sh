#!/bin/sh
# Firmička pro Linux / macOS – potřebuje python3 (3.8+); šifrovaná záloha na USB navíc
# balíček cryptography (pip3 install cryptography). Data: ~/.local/share/firmicka
cd "$(dirname "$0")/app" && exec python3 -m firmicka "$@"
