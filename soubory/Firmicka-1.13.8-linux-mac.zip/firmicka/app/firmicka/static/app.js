// Firmička – formuláře: řádky faktury (ceny, DPH, součty), výběr z adresáře a skladu, ARES.
(function () {
  "use strict";
  var $ = function (s, el) { return (el || document).querySelector(s); };
  var $$ = function (s, el) { return Array.prototype.slice.call((el || document).querySelectorAll(s)); };
  // široké tabulky: posuvník v tabulce místo useknutého posledního sloupce
  $$("table.list").forEach(function (t) {
    if (t.parentNode.classList.contains("tablewrap")) return;
    var w = document.createElement("div");
    w.className = "tablewrap";
    t.parentNode.insertBefore(w, t);
    w.appendChild(t);
  });

  function num(v) { v = String(v || "").replace(/\s| /g, "").replace(",", "."); var n = parseFloat(v); return isNaN(n) ? 0 : n; }
  function money(hal) {
    var neg = hal < 0; hal = Math.abs(Math.round(hal));
    var kc = Math.floor(hal / 100), h = hal % 100;
    return (neg ? "-" : "") + String(kc).replace(/\B(?=(\d{3})+(?!\d))/g, " ") + "," + (h < 10 ? "0" : "") + h + " Kč";
  }
  // haléře zaokrouhlit stejně jako server (db.rnd): půlka od nuly – Math.round(-2.5) by dal −2
  function rnd(x) { var a = Math.floor(Math.abs(x) + 0.5 + 1e-9); return x < 0 ? -a : a; }
  function fmtPrice(hal) { return (hal / 100).toFixed(2).replace(".", ","); }

  // ---------- kontrola čísel už v prohlížeči ----------
  // Stejná pravidla jako web._num. Formulář s překlepem se vůbec neodešle – řádky přidané skriptem
  // by se po „Zpět“ ze stránky s chybou ztratily (prohlížeč obnoví jen pole, která na stránce byla od začátku).
  var NUM_OK = /^[+-]?(\d+([.,]\d*)?|[.,]\d+)$/;
  function checkNum(el) {
    var t = String(el.value || "").replace(/[\s  ]/g, "").replace(/Kč/g, "");
    var bad = t !== "" && (!NUM_OK.test(t) || Math.abs(parseFloat(t.replace(",", "."))) > 1e9);
    el.setCustomValidity(bad ? "Zadejte číslo, např. 1 234,50" : "");
    return !bad;
  }
  var NUM_SEL = "input[inputmode=decimal]";
  document.addEventListener("input", function (e) {
    if (e.target.matches && e.target.matches(NUM_SEL)) checkNum(e.target);
  }, true);
  document.addEventListener("submit", function (e) {
    var bad = $$(NUM_SEL, e.target).filter(function (el) { return !checkNum(el); });
    if (bad.length) { e.preventDefault(); e.stopImmediatePropagation(); bad[0].reportValidity(); }
  }, true);
  document.addEventListener("click", function (e) {      // před odesláním: nativní bublina u pole s chybou
    var b = e.target.closest && e.target.closest("button, input[type=submit]");
    if (!(b && b.form && b.type === "submit" && !b.formNoValidate)) return;
    var bad = $$(NUM_SEL, b.form).filter(function (el) { return !checkNum(el); });
    if (bad.length) {               // pole ve sbaleném oddílu by prohlížeč neukázal a odeslání tiše zastavil
      for (var d = bad[0].closest("details"); d; d = d.parentElement && d.parentElement.closest("details")) d.open = true;
    }
  }, true);

  // ---------- ARES ----------
  function ares(ico, done) {
    var msg = $("#ares-msg");
    if (msg) msg.textContent = "Hledám…";
    fetch("/api/ares/" + encodeURIComponent(ico.replace(/\D/g, "")))
      .then(function (r) { return r.json(); })
      .then(function (j) {
        if (msg) msg.textContent = j.ok ? "Načteno z ARES" : j.error;
        if (j.ok) done(j.data); else if (!msg) alert(j.error);
      })
      .catch(function () { if (msg) msg.textContent = "ARES nedostupný"; });
  }
  $$("[data-ares]").forEach(function (b) {
    b.addEventListener("click", function () {
      var f = b.form;
      ares(f.ico.value, function (d) { Object.keys(d).forEach(function (k) { if (f[k] && d[k]) f[k].value = d[k]; }); });
    });
  });
  $$("[data-ares-firm]").forEach(function (b) {
    b.addEventListener("click", function () {
      var f = b.form;
      ares(f.firm_ico.value, function (d) {
        var map = { name: "firm_name", dic: "firm_dic", street: "firm_street", city: "firm_city", zip: "firm_zip" };
        Object.keys(map).forEach(function (k) { if (d[k]) f[map[k]].value = d[k]; });
      });
    });
  });

  // ---------- čtečka čárových kódů ----------
  // čtečka = rychlé psaní + Enter; Enter v poli čtečky nikdy neodešle formulář
  function onScan(input, handler) {
    input.addEventListener("keydown", function (e) {
      if (e.key !== "Enter") return;
      e.preventDefault();
      var code = input.value.trim();
      input.value = "";
      if (code) handler(code);
    });
  }
  function findItem(items, code) {
    var ids = Object.keys(items);
    for (var i = 0; i < ids.length; i++) if (items[ids[i]].ean === code) return ids[i];
    for (i = 0; i < ids.length; i++) if (items[ids[i]].code === code) return ids[i];
    return null;
  }
  function beep(ok) {
    try {
      var c = new (window.AudioContext || window.webkitAudioContext)(), o = c.createOscillator();
      o.frequency.value = ok ? 1200 : 300; o.connect(c.destination); o.start(); o.stop(c.currentTime + (ok ? 0.06 : 0.25));
    } catch (e) { /* bez zvuku */ }
  }

  var take = $("#stocktake");
  if (take) {
    onScan($("#scan"), function (code) {
      var tr = $("tr[data-ean='" + CSS.escape(code) + "']", take) || $("tr[data-code='" + CSS.escape(code) + "']", take);
      var msg = $("#scan-msg");
      if (!tr) { msg.textContent = "Neznámý kód " + code; beep(false); return; }
      var inp = tr.querySelector(".count");
      inp.value = String(num(inp.value) + 1).replace(".", ",");
      $$("tr.hit", take).forEach(function (r) { r.classList.remove("hit"); });
      tr.classList.add("hit"); tr.scrollIntoView({ block: "center" });
      msg.textContent = tr.children[1].textContent + ": " + inp.value; beep(true);
    });
  }

  // převodka: stav ve zdrojovém a cílovém skladu podle výběru
  if (take && take.dataset.stocks) {
    var stocks = JSON.parse(take.dataset.stocks), fromW = $("#from_wh"), toW = $("#to_wh"), only = $("#only-src");
    var fmtQ = function (v) { return v ? String(Math.round(v * 1000) / 1000).replace(".", ",") : ""; };
    var showStocks = function () {
      $$("tr[data-id]", take).forEach(function (tr) {
        var st = stocks[tr.dataset.id] || {}, src = st[fromW.value] || 0;
        tr.querySelector(".src-q").textContent = fmtQ(src);
        tr.querySelector(".dst-q").textContent = fmtQ(st[toW.value] || 0);
        tr.hidden = only.checked && src <= 0 && !tr.querySelector(".count").value;
      });
    };
    fromW.addEventListener("change", showStocks); toW.addEventListener("change", showStocks);
    only.addEventListener("change", showStocks);
    only.checked = true; showStocks();
  }

  // ---------- odhlášení po nečinnosti ----------
  // Server ruší relaci po N minutách bez požadavku. Když uživatel jen píše (dlouhá faktura), prohlížeč relaci
  // prodlužuje (/keepalive nejvýš jednou za minutu); po N minutách bez myši a klávesnice se odhlásí sám.
  var idle = parseInt(document.body.dataset.idle || "0", 10) * 1000;
  if (idle) {
    var lastAct = Date.now(), lastPing = Date.now(), every = Math.min(60000, idle / 3);   // prodloužit dřív, než relace vyprší
    var activity = function () {
      lastAct = Date.now();
      if (lastAct - lastPing > every) { lastPing = lastAct; fetch("/keepalive", { credentials: "same-origin" }); }
    };
    ["keydown", "mousedown", "input", "touchstart", "wheel"].forEach(function (ev) {
      document.addEventListener(ev, activity, { passive: true, capture: true });
    });
    setInterval(function () {
      if (Date.now() - lastAct < idle) return;
      var tok = $("input[name=_csrf]"), body = new FormData();
      if (tok) body.append("_csrf", tok.value);
      var go = function () { location.href = "/login?vyprselo=1&next=" + encodeURIComponent(location.pathname + location.search); };
      fetch("/logout", { method: "POST", body: body, credentials: "same-origin" }).then(go, go);
    }, 15000);
  }

  // ---------- karta položky: cena bez / s DPH, zboží / služba ----------
  // Stejný výpočet jako rekapitulace dokladu: s DPH = základ + DPH zaokrouhlená na haléře.
  function grossOf(net, r) { return net + rnd(net * r / 100); }
  function netOf(gross, r) {
    var b = rnd(gross * 100 / (100 + r));
    for (var i = 0, c = [b, b - 1, b + 1]; i < 3; i++) if (grossOf(c[i], r) === gross) return c[i];
    return b;
  }
  $$("[data-gross]").forEach(function (g) {
    var f = g.form, name = g.dataset.gross;
    var n = f.querySelector("[data-net='" + name + "']"), src = f.querySelector("[name='" + name + "_src']");
    var rateEl = f.querySelector("[name=vat_rate]");
    function rate() { return rateEl ? parseInt(rateEl.value, 10) || 0 : parseInt(f.dataset.rate || "0", 10); }
    function fromNet() { g.value = n.value.trim() ? fmtPrice(grossOf(rnd(num(n.value) * 100), rate())) : ""; }
    // některé ceny s DPH z haléřového základu přesně složit nejdou (např. 999,50 při 21 %) – říct, kolik vyjde
    var hint = document.createElement("span");
    hint.className = "hint"; hint.hidden = true;
    g.closest("label").appendChild(hint);
    function fromGross() {
      hint.hidden = true;
      if (!g.value.trim()) { n.value = ""; return; }
      var want = rnd(num(g.value) * 100), net = netOf(want, rate()), got = grossOf(net, rate());
      n.value = fmtPrice(net);
      if (got !== want) {
        hint.textContent = "na dokladu vyjde " + money(got) + " (přesně " + fmtPrice(want) + " při " + rate() + " % nejde)";
        hint.hidden = false;
      }
    }
    n.addEventListener("input", function () { src.value = "net"; hint.hidden = true; fromNet(); });
    g.addEventListener("input", function () { src.value = "vat"; fromGross(); });
    if (rateEl) rateEl.addEventListener("change", function () { if (src.value === "vat") fromGross(); else fromNet(); });
    fromNet();
  });
  var itemForm = $("[data-item-form]");
  if (itemForm) {
    var kinds = $$("[name=service]", itemForm);
    var syncKind = function () {
      var svc = kinds.some(function (k) { return k.checked && k.value === "1"; });
      $$("[data-goods]", itemForm).forEach(function (el) {
        var box = el.tagName === "INPUT" ? el.closest("label") : el;
        box.hidden = svc;
      });
    };
    kinds.forEach(function (k) {
      k.addEventListener("change", function () {
        var unit = itemForm.querySelector("[name=unit]");      // výchozí jednotka podle druhu
        if (k.value === "1" && unit.value === "ks") unit.value = "h";
        else if (k.value === "0" && unit.value === "h") unit.value = "ks";
        syncKind();
      });
    });
    syncKind();
  }

  // ---------- pokladna: rozpracovaný nákup ----------
  // Uloží se v prohlížeči (localStorage), takže odskok do zakázky nebo skladu a návrat do Pokladny ho nesmaže.
  // Smaže se po úspěšném prodeji (účtenka s data-pos-sold) nebo tlačítkem Zrušit nákup.
  var DRAFT = "firmicka-pokladna-v1";
  function store(fn) { try { return fn(window.localStorage); } catch (e) { return null; } }   // soukromé okno apod.
  function draftRead() {
    var d = store(function (ls) { return JSON.parse(ls.getItem(DRAFT) || "null"); });
    return d && d.lines && d.lines.length ? d : null;
  }
  function draftClear() { store(function (ls) { ls.removeItem(DRAFT); }); }
  if ($("[data-pos-sold]")) { var sold = draftRead(); if (sold && sold.sent) draftClear(); }

  // ---------- faktura ----------
  var form = $("#invoice");
  if (!form) return;
  var vatPayer = form.dataset.vat === "1";
  var purchase = form.dataset.purchase === "1";   // přijatá faktura: nákupní cena, bez kontroly zásoby
  // vydaná faktura v režimu (přenesená daňová povinnost, EU, vývoz) je bez DPH – součty hned bez daně
  var regimeEl = purchase ? null : form.querySelector("[name=regime]");
  if (regimeEl && regimeEl.tagName === "SELECT") {
    vatPayer = vatPayer && !regimeEl.value;
    regimeEl.addEventListener("change", function () {
      vatPayer = form.dataset.vat === "1" && !regimeEl.value;
      if (typeof recalc === "function") recalc();
    });
  }
  var shortage = [];                               // prodej do mínusu → při uložení potvrdit
  var kindEl = form.querySelector("[name=kind]");
  var noStock = !!(kindEl && (kindEl.value === "zaloha" || kindEl.value === "dobropis"));   // sklad nemění / vrací
  var sale = form.dataset.sale === "1", draftReady = false;
  var pos = form.classList.contains("pos");          // jen pokladna: rozpracovaný nákup, stav skladu u řádku
  if (sale) {
    form.addEventListener("submit", function (e) {
      recalc();
      if (shortage.length && !confirm("Na skladě není dost zboží:\n\n" + shortage.join("\n") +
          "\n\nProdat přesto? Stav skladu půjde do mínusu – dorovnejte ho pak příjemkou nebo inventurou.")) {
        e.preventDefault();
      }
    });
  }
  if (pos) {
    form.addEventListener("submit", function (e) { if (!e.defaultPrevented) draftSave(true); });
    var cancel = form.querySelector("[data-pos-cancel]");
    if (cancel) cancel.addEventListener("click", draftClear);
  }
  function priceOf(it) { return purchase ? (it.cost || 0) : it.price; }
  var tbody = $("#lines");
  var items = JSON.parse(tbody.dataset.items || "{}");
  var tpl = $("#line-tpl");

  // popisky sloupců u každého pole (na telefonu je hlavička tabulky skrytá a pole jsou pod sebou)
  var sumHead = $("th.sum-head", tbody.closest("table"));
  if (sumHead && vatPayer) sumHead.textContent = "Celkem s DPH";
  var heads = $$("thead th", tbody.closest("table")).map(function (th) { return th.textContent.trim(); });
  function warrantyText(m) {
    m = parseInt(m || 0, 10);
    return m ? "záruka " + m + " " + (m === 1 ? "měsíc" : m <= 4 ? "měsíce" : "měsíců") : "";
  }
  function setWarranty(tr, m) {
    var w = tr.querySelector("[name=line_warranty]");
    if (!w) return;
    w.value = m ? String(m) : "";
    tr.querySelector("small.warranty").textContent = warrantyText(m);
  }
  // ---- řádky: cena/j. bez DPH, cena/j. s DPH, celkem za řádek ----
  // Zdola (výchozí): na server jde cena/j. bez DPH; DPH = součet základů za sazbu × sazba / 100.
  // Ceny s DPH (zaškrtnuto „Ceny s DPH“, výpočet shora § 37 ZDPH): na server jde částka řádku s DPH (pole Celkem);
  // DPH = součet částek za sazbu × sazba / (100 + sazba). Cenu bez DPH z ní odvodí server stejně jako tady (db.py).
  var grossBox = form.querySelector("[name=prices_gross]");
  function gm() { return !!(grossBox && grossBox.checked); }
  function rdiv(a, b) { var q = Math.floor((2 * Math.abs(a) + b) / (2 * b)); return a < 0 ? -q : q; }   // = db.rdiv
  function vatFromGross(g, r) { return rdiv(g * r, 100 + r); }
  function cents(el) { return rnd(num(el.value) * 100); }
  function feeGross(q, fee, r) { var b = rnd(q * fee); return b + rnd(b * r / 100); }
  function netFromLineGross(G, q, fee, r) { return q ? rnd((G - vatFromGross(G, r)) / q - fee) : 0; }
  // zdola částka s DPH přesně nevyjde → nabídnout ceny s DPH (pak platí přesně, jak je zadaná)
  function offerGross(hint) {
    if (!grossBox) return;
    var b = document.createElement("button");
    b.type = "button"; b.className = "link"; b.textContent = "přesně";
    b.title = "Zapnout „Ceny s DPH“ – zadané částky s DPH budou platit přesně";
    b.addEventListener("click", function () {
      grossBox.checked = true;
      grossBox.dispatchEvent(new Event("change", { bubbles: true }));
    });
    hint.appendChild(document.createTextNode(" · "));
    hint.appendChild(b);
  }
  function lineRate(tr) { return parseInt(tr.querySelector("[name=line_vat]").value, 10) || 0; }
  function effRate(tr) { return vatPayer ? lineRate(tr) : 0; }
  function hideSumHint(tr) { var x = tr.querySelector(".sum-hint"); if (x) x.hidden = true; }
  function grossFromNet(tr) {
    var g = tr.querySelector(".line-gross"), n = tr.querySelector("[name=line_price]");
    tr.dataset.src = "net";
    hideSumHint(tr);
    if (!g) return;
    tr.querySelector(".gross-hint").hidden = true;
    g.value = n.value.trim() ? fmtPrice(grossOf(rnd(num(n.value) * 100), lineRate(tr))) : "";
  }
  function netFromGross(tr) {
    var g = tr.querySelector(".line-gross"), n = tr.querySelector("[name=line_price]"), hint = tr.querySelector(".gross-hint");
    tr.dataset.src = "vat";
    hint.hidden = true;
    hideSumHint(tr);
    if (!g.value.trim()) { n.value = ""; return; }
    var r = lineRate(tr), want = rnd(num(g.value) * 100), net = netOf(want, r), got = grossOf(net, r);
    n.value = fmtPrice(net);
    if (got !== want) {     // např. 100 Kč při 21 % z haléřového základu přesně nevyjde
      hint.textContent = "vyjde " + money(got);
      hint.title = "Přesně " + fmtPrice(want) + " s DPH při " + r + " % z ceny bez DPH na haléře nejde.";
      offerGross(hint);
      hint.hidden = false;
    }
  }
  // celkem za řádek (s DPH u plátce): z něj se dopočítá cena/j. bez DPH = (základ − rec. poplatky) / množství
  function priceFromSum(tr) {
    var s = tr.querySelector(".line-sum"), n = tr.querySelector("[name=line_price]"), hint = tr.querySelector(".sum-hint");
    var g = tr.querySelector(".line-gross");
    tr.dataset.src = "sum";
    hint.hidden = true;
    if (g) tr.querySelector(".gross-hint").hidden = true;
    if (!s.value.trim()) return;
    var q = num(tr.querySelector("[name=line_qty]").value);
    if (!q) { hint.textContent = "zadejte množství"; hint.hidden = false; return; }
    var r = effRate(tr), want = rnd(num(s.value) * 100);
    var fee = rnd(num(tr.querySelector("[name=line_fee]").value) * 100);
    var unit = rnd((netOf(want, r) - rnd(q * fee)) / q);
    n.value = fmtPrice(unit);
    if (g) g.value = fmtPrice(grossOf(unit, lineRate(tr)));
    var got = grossOf(rnd(q * unit) + rnd(q * fee), r);
    if (got !== want) {     // např. 1000 Kč za 3 ks – cena za kus na haléře přesně nevyjde
      hint.textContent = "vyjde " + money(got);
      hint.title = "Přesně " + fmtPrice(want) + " při tomto množství z ceny za jednotku na haléře nejde.";
      offerGross(hint);
      hint.hidden = false;
    }
  }
  // ceny s DPH: částka řádku s DPH (tr.dataset.g) z toho, co uživatel psal naposled (tr.dataset.src)
  function syncGross(tr) {
    var src = tr.dataset.src || "net";
    var n = tr.querySelector("[name=line_price]"), g = tr.querySelector(".line-gross"), s = tr.querySelector(".line-sum");
    var q = num(tr.querySelector("[name=line_qty]").value), r = effRate(tr);
    var fee = cents(tr.querySelector("[name=line_fee]")), fg = fee ? feeGross(q, fee, r) : 0, G = null;
    var hint = tr.querySelector(".sum-hint");
    hint.hidden = true;
    if (g) tr.querySelector(".gross-hint").hidden = true;
    if (src === "sum") { if (s.value.trim()) G = cents(s); }
    else if (src === "vat") { if (g && g.value.trim()) G = rnd(q * cents(g)) + fg; }
    else if (n.value.trim()) G = rnd(q * grossOf(cents(n), r)) + fg;
    if (G !== null && !q) {
      if (src === "sum" && G) { hint.textContent = "zadejte množství"; hint.hidden = false; }
      G = 0;
    }
    tr.dataset.g = G === null ? "" : String(G);
    if (G === null) {
      if (src !== "net") n.value = "";
      if (g && src !== "vat") g.value = "";
      if (src !== "sum") s.value = "";
      return;
    }
    if (src !== "net") n.value = fmtPrice(netFromLineGross(G, q, fee, r));
    if (g && src !== "vat") g.value = q ? fmtPrice(rnd((G - fg) / q)) : "";
    if (src !== "sum") s.value = fmtPrice(G);
  }
  function syncRow(tr) {
    if (gm()) return syncGross(tr);
    var src = tr.dataset.src || "net";
    if (src === "sum") priceFromSum(tr); else if (src === "vat") netFromGross(tr); else grossFromNet(tr);
  }
  // zboží a práce zvlášť: řádek „práce“ nabízí jen služby (ceník práce), řádek „zboží“ jen zboží – nemusí se hledat v celém skladu
  var GROUP = { goods: "Zboží", svc: "Služby a práce" };
  var hasSvc = !!tpl.content.querySelector('optgroup[label="' + GROUP.svc + '"]');
  function kindOf(d) { var it = d && d.item && items[d.item]; return hasSvc && it ? (it.service ? "svc" : "goods") : ""; }
  function addLine(d, kind) {
    var tr = tpl.content.firstElementChild.cloneNode(true);
    kind = kind || kindOf(d);
    if (kind) {
      tr.dataset.kind = kind;
      var keep = tr.querySelector('optgroup[label="' + GROUP[kind] + '"]');
      $$("optgroup", tr).forEach(function (g) { if (g !== keep) g.remove(); });
      if (keep) { while (keep.firstChild) keep.parentNode.insertBefore(keep.firstChild, keep); keep.remove(); }
    }
    $$("td", tr).forEach(function (td, i) { if (heads[i]) td.setAttribute("data-label", heads[i]); });
    tbody.appendChild(tr);
    if (d) {
      tr.querySelector("[name=line_item]").value = d.item || "";
      tr.querySelector("[name=line_text]").value = d.text || "";
      tr.querySelector("[name=line_qty]").value = String(d.qty).replace(".", ",");
      tr.querySelector("[name=line_unit]").value = d.unit || "ks";
      tr.querySelector("[name=line_price]").value = fmtPrice(d.price || 0);
      tr.querySelector("[name=line_vat]").value = String(d.vat || 0);
      tr.querySelector("[name=line_fee]").value = d.fee ? fmtPrice(d.fee) : "";
      setWarranty(tr, d.warranty);
    } else {
      tr.querySelector("[name=line_vat]").value = "21";
    }
    tr.dataset.src = "net";
    if (d && d.gross !== null && d.gross !== undefined && gm()) {
      // uložená částka s DPH platí: jako cena/j. s DPH, když z ní vychází přesně, jinak jako „Celkem“
      var q = num(d.qty), r = effRate(tr), fg = d.fee ? feeGross(q, d.fee, r) : 0;
      var ug = q ? rnd((d.gross - fg) / q) : 0, g = tr.querySelector(".line-gross");
      if (g && q && rnd(q * ug) + fg === d.gross) { g.value = fmtPrice(ug); tr.dataset.src = "vat"; }
      else { tr.querySelector(".line-sum").value = fmtPrice(d.gross); tr.dataset.src = "sum"; }
    }
    syncRow(tr);
    return tr;
  }

  // pokladna: řádky se ukládají tak, jak je uživatel napsal (texty polí + čím řádek zadal), po obnovení se dopočítají stejně
  var FORM_KEYS = ["payment", "received", "warehouse_id"];
  function draftSave(sent) {
    if (!pos) return;
    var lines = $$("tr", tbody).map(function (tr) {
      var o = { src: tr.dataset.src || "net" };
      $$("input, select", tr).forEach(function (el) {
        if (el.name) o[el.name] = el.value; else if (el.classList.contains("line-gross")) o.gross = el.value;
      });
      return o;
    }).filter(function (o) { return o.line_item || String(o.line_text || "").trim(); });
    if (!lines.length) { draftClear(); return; }
    var d = { t: Date.now(), sent: !!sent, gross: gm(), lines: lines, form: {} };
    FORM_KEYS.forEach(function (k) { if (form[k]) d.form[k] = form[k].value; });
    store(function (ls) { ls.setItem(DRAFT, JSON.stringify(d)); });
  }
  function draftRestore(d) {
    if (grossBox) grossBox.checked = !!d.gross;
    d.lines.forEach(function (o) {
      var tr = addLine(null, kindOf({ item: o.line_item }));
      Object.keys(o).forEach(function (k) {
        var el = k === "gross" ? tr.querySelector(".line-gross") : k === "src" ? null : tr.querySelector('[name="' + k + '"]');
        if (el) el.value = o[k];
      });
      setWarranty(tr, o.line_warranty);
      tr.dataset.src = o.src || "net";
      syncRow(tr);
    });
    FORM_KEYS.forEach(function (k) {
      var el = form[k];
      if (el && d.form && d.form[k] !== undefined && (el.tagName !== "SELECT" || $$("option", el).some(function (x) {
        return x.value === d.form[k]; }))) el.value = d.form[k];
    });
    var t = new Date(d.t), hm = t.getHours() + ":" + (t.getMinutes() < 10 ? "0" : "") + t.getMinutes();
    var note = document.createElement("div");
    note.className = "flash";
    note.textContent = "Obnoven rozpracovaný nákup (" + hm + ")." + (d.sent ?
      " Při odeslání se neuložil – pokud jste ho už zaplatili, zkontrolujte účtenky v Uzávěrce dne." : "") +
      " Nechcete ho? Klikněte na Zrušit nákup.";
    form.parentNode.insertBefore(note, form);
  }

  function haveOf(it) {           // stav na skladu vybraném ve formuláři (sada: kolik jde sestavit)
    if (!it) return 0;
    var whEl = form.querySelector("[name=warehouse_id]");
    return whEl && it.stocks ? (it.stocks[whEl.value] || 0) : it.stock;
  }
  function qty(n) { return String(Math.round(n * 1000) / 1000).replace(".", ","); }

  function recalc() {
    var byRate = {}, warn = [], need = {}, shora = gm();
    shortage = [];
    $$("tr", tbody).forEach(function (tr) {
      var q = num(tr.querySelector("[name=line_qty]").value);
      var rate = vatPayer ? parseInt(tr.querySelector("[name=line_vat]").value, 10) : 0;
      if (shora) {
        byRate[rate] = (byRate[rate] || 0) + (tr.dataset.g ? Number(tr.dataset.g) : 0);
      } else {
        var p = rnd(num(tr.querySelector("[name=line_price]").value) * 100);
        var fee = rnd(num(tr.querySelector("[name=line_fee]").value) * 100);
        var base = rnd(q * p) + rnd(q * fee);
        var sum = tr.querySelector(".line-sum");
        if (tr.dataset.src !== "sum")        // pole, do kterého se právě píše, nepřepisovat
          sum.value = tr.querySelector("[name=line_price]").value.trim() ? fmtPrice(grossOf(base, rate)) : "";
        byRate[rate] = (byRate[rate] || 0) + base;
      }
      var it = tr.querySelector("[name=line_item]").value;
      if (it) need[it] = (need[it] || 0) + q;
    });
    Object.keys(need).forEach(function (id) {
      var it = items[id], have = haveOf(it);
      if (it && !it.service && !purchase && !noStock && need[id] > have) {
        warn.push(it.name + " (skladem " + String(have).replace(".", ",") + " " + it.unit + ")");
        shortage.push("• " + it.name + ": prodáváte " + String(need[id]).replace(".", ",") + ", skladem " +
                      String(have).replace(".", ",") + " " + it.unit);
      }
    });
    // pokladna: pod každou položkou kolik je skladem a kolik zbude po prodeji (víc řádků téže položky se sčítá)
    if (pos) $$("tr", tbody).forEach(function (tr) {
      var id = tr.querySelector("[name=line_item]").value, it = items[id];
      var td = tr.querySelector("[name=line_text]").parentNode, el = $("small.stock-hint", td);
      if (!it || it.service) { if (el) el.remove(); return; }
      if (!el) { el = document.createElement("small"); el.className = "stock-hint"; td.appendChild(el); }
      var have = haveOf(it), left = have - (need[id] || 0);
      el.textContent = "";
      ["skladem " + qty(have) + " " + it.unit, need[id] ? "zbude " + qty(left) : ""].forEach(function (t, i) {
        if (!t) return;
        if (i) el.appendChild(document.createTextNode(" · "));     // zalomit jde jen u tečky, „zbude -2“ drží pohromadě
        var sp = document.createElement("span"); sp.className = "nw"; sp.textContent = t; el.appendChild(sp);
      });
      el.classList.toggle("low", left < 0);
    });
    $("#stock-warn").textContent = warn.length ? "⚠ Nedostatek na skladě: " + warn.join(", ") : "";
    var html = "", total = 0;
    Object.keys(byRate).sort(function (a, b) { return b - a; }).forEach(function (r) {
      r = Number(r);
      var base, vat;
      if (shora) { vat = vatPayer ? vatFromGross(byRate[r], r) : 0; base = byRate[r] - vat; }
      else { base = byRate[r]; vat = vatPayer ? rnd(base * r / 100) : 0; }
      total += base + vat;
      if (vatPayer) html += "<div>Základ " + r + " %: " + money(base) + " · DPH " + money(vat) + "</div>";
    });
    // konečná faktura: zaškrtnuté uhrazené zálohy se odečtou při uložení – ukázat to už tady
    // (základ i DPH se snižují přesně o daňový doklad zálohy, takže k úhradě = celkem − záloha)
    var adv = 0;
    $$("input[name=advance]:checked").forEach(function (x) { adv += Number(x.dataset.total || 0); });
    if (adv) {
      html += "<div>Celkem za plnění: " + money(total) + "</div><div>Odpočet uhrazené zálohy: −" + money(adv) + "</div>";
      total -= adv;
    }
    html += "<div class='grand'>Celkem k úhradě: " + money(total) + "</div>";
    $("#totals").innerHTML = html;
    lastTotal = total;
    change();
    if (draftReady) draftSave();
  }

  // pokladna: kolik vrátit
  var lastTotal = 0;
  function change() {
    var rec = $("#received"), out = $("#change"), pay = $("#payment");
    if (!rec || !out) return;
    $("#received-l").hidden = pay.value !== "hotove";
    var r = rnd(num(rec.value) * 100);
    out.textContent = r ? (r >= lastTotal ? money(r - lastTotal) : "chybí " + money(lastTotal - r)) : "—";
  }
  if ($("#received")) { $("#received").addEventListener("input", change); $("#payment").addEventListener("change", change); }

  tbody.addEventListener("input", function (e) {
    var tr = e.target.closest("tr"), t = e.target;
    if (t.classList.contains("line-sum")) tr.dataset.src = "sum";
    else if (t.classList.contains("line-gross")) tr.dataset.src = "vat";
    else if (t.name === "line_price") tr.dataset.src = "net";
    if (t.classList.contains("line-sum") || t.classList.contains("line-gross") || t.name === "line_price" ||
        t.name === "line_qty" || t.name === "line_fee") syncRow(tr);
    recalc();
  });
  if (form.querySelector("select[data-warehouse]")) form.querySelector("select[data-warehouse]").addEventListener("change", recalc);
  $$("input[name=advance]").forEach(function (x) { x.addEventListener("change", recalc); });
  tbody.addEventListener("change", function (e) {
    if (e.target.name === "line_item") {
      var it = items[e.target.value], tr = e.target.closest("tr");
      if (it) {
        tr.querySelector("[name=line_text]").value = it.name;
        tr.querySelector("[name=line_unit]").value = it.unit;
        tr.querySelector("[name=line_price]").value = fmtPrice(priceOf(it));
        tr.querySelector("[name=line_vat]").value = String(it.vat);
        tr.querySelector("[name=line_fee]").value = it.fee ? fmtPrice(it.fee) : "";
        setWarranty(tr, it.warranty);
        tr.dataset.src = "net";
        syncRow(tr);
      } else if (!e.target.value) {
        setWarranty(tr, 0);
      }
    }
    if (e.target.name === "line_vat") syncRow(e.target.closest("tr"));   // změna sazby: zachovat to, co uživatel psal naposled
    recalc();
  });
  tbody.addEventListener("click", function (e) {
    if (e.target.hasAttribute("data-del")) {
      e.target.closest("tr").remove();
      if (!tbody.children.length) addLine();
      recalc();
    }
  });
  function blank(tr) {
    return !tr.querySelector("[name=line_item]").value && !tr.querySelector("[name=line_text]").value.trim() &&
      !tr.querySelector("[name=line_price]").value.trim();
  }
  function addTyped(kind) {
    $$("tr", tbody).filter(blank).forEach(function (tr) { tr.remove(); });   // prázdný výchozí řádek nahradit
    var tr = addLine(null, kind);
    if (kind === "svc") tr.querySelector("[name=line_unit]").value = "h";      // práce se většinou počítá v hodinách
    tr.querySelector("[name=line_item]").focus();
    recalc();
  }
  var addWork = $("#add-work");
  if (hasSvc && addWork) {
    addWork.hidden = false;
    $("#add-line").textContent = "+ Přidat zboží";
    $("#add-line").addEventListener("click", function () { addTyped("goods"); });
    addWork.addEventListener("click", function () { addTyped("svc"); });
  } else {
    $("#add-line").addEventListener("click", function () { addLine().querySelector("[name=line_item]").focus(); recalc(); });
  }

  // pípnutí: stejná položka už na faktuře → +1 ks, jinak nový řádek
  onScan($("#scan"), function (code) {
    var id = findItem(items, code), msg = $("#scan-msg");
    if (!id) {
      // kód ze čtečky může obsahovat cokoli (i „<“) – jen jako text, nikdy jako HTML
      var a = document.createElement("a");
      a.href = "/sklad/nova?ean=" + encodeURIComponent(code); a.target = "_blank"; a.textContent = "založit";
      msg.textContent = "Kód " + code + " není ve skladu – "; msg.appendChild(a);
      beep(false); return;
    }
    var hit = $$("tr", tbody).filter(function (tr) { return tr.querySelector("[name=line_item]").value === id; })[0];
    if (hit) {
      var q = hit.querySelector("[name=line_qty]");
      q.value = String(num(q.value) + 1).replace(".", ",");
      syncRow(hit);
    } else {
      var empty = $$("tr", tbody).filter(function (tr) { return !tr.querySelector("[name=line_text]").value; })[0];
      if (empty) empty.remove();
      var it = items[id];
      addLine({ item: id, text: it.name, qty: 1, unit: it.unit, price: priceOf(it), vat: it.vat, fee: it.fee, warranty: it.warranty });
    }
    msg.textContent = items[id].name + " ✓"; beep(true);
    recalc();
  });

  var rows = JSON.parse(tbody.dataset.rows || "[]"), draft = pos && !rows.length ? draftRead() : null;
  if (rows.length) rows.forEach(function (r) { addLine(r); }); else if (draft) draftRestore(draft); else addLine();
  if (grossBox) grossBox.addEventListener("change", function () {   // přepnutí: přepočítat řádky podle toho, co bylo zadané
    $$("tr", tbody).forEach(syncRow);
    recalc();
  });
  draftReady = true;
  recalc();
  if (pos) {
    form.addEventListener("input", function () { draftSave(); });
    form.addEventListener("change", function () { draftSave(); });
  }

  // odběratel z adresáře (formuláře bez odběratele – pokladna – tuhle část přeskočí)
  var csel = form.contact_id;
  if (!csel) return;
  var contacts = JSON.parse(csel.dataset.contacts || "{}");
  csel.addEventListener("change", function () {
    var c = contacts[csel.value];
    if (!c) return;
    form.cust_name.value = c.name; form.cust_ico.value = c.ico; form.cust_dic.value = c.dic; form.cust_address.value = c.address;
  });
  var aresBtn = $("[data-ares-inv]");
  if (aresBtn) aresBtn.addEventListener("click", function () {
    ares(form.cust_ico.value, function (d) {
      form.cust_name.value = d.name; form.cust_dic.value = d.dic;
      form.cust_address.value = [d.street, (d.zip + " " + d.city).trim()].concat(d.country && d.country !== "Česká republika" ? [d.country] : []).join("\n");
      csel.value = "";
      if (form.save_contact) form.save_contact.checked = true;
    });
  });
  // splatnost se posune s datem vystavení
  if (!form.issue_date || !form.due_date) return;
  var due0 = form.due_date.value, iss0 = form.issue_date.value;
  form.issue_date.addEventListener("change", function () {
    var d = (new Date(due0) - new Date(iss0)) / 864e5;
    if (!isNaN(d) && form.issue_date.value) {
      var n = new Date(form.issue_date.value); n.setDate(n.getDate() + d);
      form.due_date.value = n.toISOString().slice(0, 10);
      if (form.tax_date && form.tax_date.value === iss0) form.tax_date.value = form.issue_date.value;
      due0 = form.due_date.value; iss0 = form.issue_date.value;
    }
  });
})();

// navržené číslo dokladu: při změně roku v datu vystavení nabídne číslo z řady toho roku
// (jen když uživatel číslo nepřepsal; server to při uložení stejně ohlídá i při souběhu)
(function () {
  var auto = document.querySelector("input[name=number_auto]");
  if (!auto || !auto.dataset.date || !auto.dataset.series) return;
  var form = auto.form, num = form.elements[auto.dataset.field], dt = form.elements[auto.dataset.date];
  if (!num || !dt) return;
  var url = auto.dataset.series === "nabidka" ? "/nabidky/cislo?datum=" : auto.dataset.series === "dodaci" ? "/dodaci/cislo?datum=" :
    "/faktury/cislo?druh=" + auto.dataset.series + "&datum=";
  var year = (dt.value || "").slice(0, 4);
  dt.addEventListener("change", function () {
    var y = (dt.value || "").slice(0, 4);
    if (y.length !== 4 || y === year || num.value !== auto.value) return;
    year = y;
    fetch(url + encodeURIComponent(dt.value)).then(function (r) { return r.ok ? r.text() : ""; }).then(function (t) {
      if (t && num.value === auto.value) {
        num.value = auto.value = t;
        num.classList.add("changed"); setTimeout(function () { num.classList.remove("changed"); }, 1500);
      }
    });
  });
})();

// ---------- vzhled: podle systému / světlý / tmavý (bez obnovení stránky – rozepsaný doklad zůstane) ----------
document.addEventListener("submit", function (e) {
  var f = e.target;
  if (!f.matches || !f.matches("form[data-theme-form]") || !window.fetch) return;
  e.preventDefault();
  fetch(f.action, {method: "POST", body: new URLSearchParams(new FormData(f)), headers: {"X-Fetch": "1"},
                   credentials: "same-origin"})
    .then(function (r) { if (!r.ok) throw r; return r.json(); })
    .then(function (d) {
      if (d.theme === "auto") document.documentElement.removeAttribute("data-theme");
      else document.documentElement.setAttribute("data-theme", d.theme);
      var t = document.createElement("div"); t.innerHTML = d.button;
      var nf = t.firstElementChild; f.replaceWith(nf); nf.querySelector("button").focus();
    })
    .catch(function () { f.submit(); });
});

// ---------- majetek: vybrat vše, formát štítků ----------
document.querySelectorAll("input[data-check-all]").forEach(function (all) {
  var form = all.getAttribute("data-check-all");
  all.addEventListener("change", function () {
    document.querySelectorAll('input[type=checkbox][form="' + form + '"]').forEach(function (c) { c.checked = all.checked; });
  });
});
(function () {
  var sel = document.querySelector("select[data-label-format]");
  if (!sel) return;
  function upd() {
    var v = sel.value;
    document.querySelectorAll("[data-custom]").forEach(function (el) { el.hidden = v !== "r-vlastni"; });
    document.querySelectorAll("[data-sheet]").forEach(function (el) { el.hidden = v.indexOf("a4-") !== 0; });
  }
  sel.addEventListener("change", upd); upd();
})();

// horní lišta: co se nevejde do jednoho řádku, přesune se do nabídky „Další“ (na telefonu se lišta posouvá – beze změny)
(function () {
  var top = document.querySelector("header.top"), nav = top && top.querySelector("nav"), more = top && top.querySelector(".more");
  if (!nav || !more) return;
  var menu = more.querySelector(".menu"), wide = window.matchMedia("(min-width: 721px)");
  function fit() {
    while (menu.firstChild) nav.appendChild(menu.firstChild);      // vrátit vše zpět (ve správném pořadí)
    more.hidden = true; more.classList.remove("on"); top.classList.toggle("fit", wide.matches);
    if (!wide.matches) return;
    more.hidden = false;
    var links = Array.prototype.slice.call(nav.querySelectorAll("a"));
    while (nav.scrollWidth > nav.clientWidth + 1 && links.length > 1) {
      var a = links.pop();
      menu.insertBefore(a, menu.firstChild);
    }
    more.hidden = !menu.firstChild;
    if (menu.querySelector("a.on")) more.classList.add("on");
  }
  fit();
  window.addEventListener("resize", function () { clearTimeout(fit.t); fit.t = setTimeout(fit, 80); });
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(fit);
  document.addEventListener("click", function (e) { if (!more.contains(e.target)) more.open = false; });
})();

// Píchačka (tablet): klepnout na jméno → PIN číselníkem → Příchod/Odchod; po nečinnosti zpět na jména
(function () {
  "use strict";
  var f = document.querySelector("form.pich");
  if (!f) return;
  f.classList.add("js-on");
  var pin = f.querySelector("[name=pin]"), name = f.querySelector(".pname");
  var bIn = f.querySelector(".pin-btn"), bOut = f.querySelector(".pout-btn"), idle;
  function reset() {
    f.classList.remove("picked");
    Array.prototype.forEach.call(f.querySelectorAll("[name=username]"), function (r) { r.checked = false; });
    pin.value = "";
  }
  function poke() { clearTimeout(idle); idle = setTimeout(reset, 30000); }
  f.addEventListener("change", function (e) {
    if (e.target.name !== "username") return;
    var inside = e.target.getAttribute("data-in") === "1";
    name.textContent = e.target.parentNode.querySelector("b").textContent;
    bIn.className = "btn pin-btn" + (inside ? "" : " primary");
    bOut.className = "btn pout-btn" + (inside ? " primary" : "");
    pin.value = "";
    Array.prototype.forEach.call(f.querySelectorAll(".ptile"), function (t) { t.classList.toggle("sel", t.contains(e.target)); });
    f.classList.add("picked");
    poke();
  });
  f.querySelector(".pback").addEventListener("click", reset);
  Array.prototype.forEach.call(f.querySelectorAll(".pkey"), function (k) {
    k.addEventListener("click", function () {
      var v = k.getAttribute("data-k");
      if (v === "B") pin.value = pin.value.slice(0, -1);
      else if (v === "C") pin.value = "";
      else if (pin.value.length < 8) pin.value += v;
      poke();
    });
  });
  pin.addEventListener("input", poke);
  var msg = document.querySelector(".pmsg");
  if (msg) setTimeout(function () { msg.classList.add("gone"); }, 6000);
  var clock = document.querySelector("[data-clock]");
  if (clock) setInterval(function () {
    var d = new Date();
    clock.textContent = (d.getHours() < 10 ? "0" : "") + d.getHours() + ":" + (d.getMinutes() < 10 ? "0" : "") + d.getMinutes();
  }, 5000);
})();

// ---------- dvojklik: odeslaný formulář nejde odeslat podruhé (dvě faktury, dvě platby…) ----------
document.addEventListener("submit", function (e) {
  var f = e.target;
  if (e.defaultPrevented || !f.matches || (f.method || "").toLowerCase() !== "post" || f.target === "_blank" ||
      f.matches("[data-theme-form]")) return;
  if (f.dataset.sent === "1") { e.preventDefault(); return; }
  f.dataset.sent = "1";
  setTimeout(function () {          // až po odeslání – hodnota stisknutého tlačítka se musí poslat
    Array.prototype.forEach.call(f.querySelectorAll("button:not([type=button]), input[type=submit]"), function (b) {
      b.disabled = true;
    });
  }, 0);
  setTimeout(function () {          // stahování souboru stránku neopustí – za chvíli zase povolit
    delete f.dataset.sent;
    Array.prototype.forEach.call(f.querySelectorAll("button:not([type=button]), input[type=submit]"), function (b) {
      b.disabled = false;
    });
  }, 5000);
});
window.addEventListener("pageshow", function (e) {   // návrat zpět z historie: tlačítka zase aktivní
  if (!e.persisted) return;
  Array.prototype.forEach.call(document.querySelectorAll("form[data-sent]"), function (f) {
    delete f.dataset.sent;
    Array.prototype.forEach.call(f.querySelectorAll("button, input[type=submit]"), function (b) { b.disabled = false; });
  });
});


// Hledání při psaní (sklad): samostatně, aby nezáviselo na ostatních částech skriptu.
(function () {
  "use strict";
  var $ = function (s, el) { return (el || document).querySelector(s); };
  var $$ = function (s, el) { return Array.prototype.slice.call((el || document).querySelectorAll(s)); };
  // ---------- hledání při psaní (form[data-live]) ----------
  // Po krátké pauze v psaní stáhne stránku znovu a vymění jen výsledky (#live, #live-stats) – pole hledání
  // zůstane, takže se dá psát dál. Enter funguje jako dřív (čtečka EAN pošle Enter → rovnou karta položky).
  $$("form[data-live]").forEach(function (f) {
    var q = f.querySelector("input[name=q]"), box = $(f.getAttribute("data-live"));
    if (!q || !box || !window.fetch || !window.DOMParser) return;
    var timer = null, seq = 0, last = q.value;
    function url() {
      var p = [];
      $$("input, select", f).forEach(function (el) {
        if (!el.name || el.disabled || el.name === "scan") return;   // bez scan: rozepsaný kód nesmí přeskočit na kartu
        if (el.value === "" ) return;
        p.push(encodeURIComponent(el.name) + "=" + encodeURIComponent(el.value));
      });
      return (f.getAttribute("action") || location.pathname) + (p.length ? "?" + p.join("&") : "");
    }
    function swap(doc, sel) {
      var cur = $(sel), neu = doc.querySelector(sel);
      if (cur && neu) cur.parentNode.replaceChild(document.importNode(neu, true), cur);
    }
    function run() {
      var u = url(), my = ++seq;
      fetch(u, { credentials: "same-origin" }).then(function (r) {
        if (!r.ok || r.redirected) throw new Error("http");
        return r.text();
      }).then(function (t) {
        if (my !== seq) return;            // mezitím se psalo dál – starší odpověď zahodit
        var doc = new DOMParser().parseFromString(t, "text/html");
        if (!doc.querySelector(f.getAttribute("data-live"))) return;
        swap(doc, f.getAttribute("data-live"));
        swap(doc, "#live-stats");
        $$("table.list", $(f.getAttribute("data-live"))).forEach(function (tb) {
          if (tb.parentNode.classList.contains("tablewrap")) return;
          var w = document.createElement("div"); w.className = "tablewrap";
          tb.parentNode.insertBefore(w, tb); w.appendChild(tb);
        });
        try { history.replaceState(null, "", u); } catch (e) { /* nevadí */ }
      }).catch(function () { /* při chybě zůstane starý výsledek, Enter funguje dál */ });
    }
    q.addEventListener("input", function () {
      if (q.value === last) return;
      last = q.value;
      clearTimeout(timer);
      timer = setTimeout(run, 250);
    });
    f.addEventListener("submit", function () { clearTimeout(timer); seq++; });
  });
})();
